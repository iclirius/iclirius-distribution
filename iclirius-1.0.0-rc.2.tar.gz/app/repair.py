"""Explicit, role-aware repair planning and execution.

Repair is deliberately separate from Doctor: planning observes, execution
mutates only approved, typed actions.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from app.doctor import collect as collect_doctor
from app.node_capability_profile import build_node_capability_profile

SCHEMA_VERSION = 1
RISK = {"SAFE", "CONFIRM", "MANUAL", "POLICY_BLOCKED"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class RepairAction:
    id: str
    capability: str
    title: str
    description: str
    risk_class: str
    required: bool = False
    target_role: str = ""
    estimated_download: str = ""
    requires_network: bool = False
    requires_admin: bool = False
    executable: str = ""
    verification: str = ""
    status: str = "PROPOSED"

    def __post_init__(self):
        if self.risk_class not in RISK:
            raise ValueError("invalid repair risk class")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class RepairPlan:
    actions: tuple[RepairAction, ...] = field(default_factory=tuple)
    schema_version: int = SCHEMA_VERSION
    generated_at: str = field(default_factory=_now)
    overall: str = ""
    eligible_roles: tuple[str, ...] = field(default_factory=tuple)
    communication_ready: bool = False

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "generated_at": self.generated_at,
                "overall": self.overall, "eligible_roles": list(self.eligible_roles),
                "communication_ready": self.communication_ready,
                "actions": [a.to_dict() for a in self.actions]}


class RepairPlanner:
    def build(self, report: dict, role: str | None = None) -> RepairPlan:
        profile = build_node_capability_profile(report)
        actions: list[RepairAction] = []
        setup = report.get("setup", {})
        node_ready = bool(setup.get("node", {}).get("node_id"))
        if not node_ready:
            actions.append(RepairAction("node.identity", "NODE_COMMUNICATION_READY",
                "Initialize node identity", "Create the missing machine-local Ed25519 identity in Keychain.",
                "SAFE", target_role="INTERFACE", executable="security", verification="node identity"))

        ollama = report.get("ollama", {})
        brew = bool(report.get("homebrew", {}).get("installed"))
        if not ollama.get("installed") and role in {None, "local-compute", "full-node"}:
            actions.append(RepairAction("ollama.install", "LOCAL_REASONING", "Install Ollama",
                "Install the official Ollama Homebrew package after confirmation.",
                "CONFIRM" if brew else "MANUAL", required=role in {"local-compute", "full-node"},
                target_role="LOCAL_COMPUTE", requires_network=True, requires_admin=False,
                executable="brew", verification="Ollama API"))
        elif not ollama.get("running"):
            actions.append(RepairAction("ollama.start", "LOCAL_REASONING", "Start Ollama",
                "Start the existing Ollama runtime after confirmation; no installation is performed.",
                "MANUAL", target_role="LOCAL_COMPUTE", executable="ollama", verification="Ollama API"))

        models = report.get("models", {})
        required = models.get("required", [])
        installed = set(models.get("installed", []))
        default = required[0] if required else ""
        if default and default not in installed and ollama.get("running"):
            actions.append(RepairAction("model.default", "LOCAL_REASONING", f"Download {default}",
                f"Download the configured default model with Ollama after confirmation.", "CONFIRM",
                required=role in {"local-compute", "full-node"}, target_role="LOCAL_COMPUTE",
                estimated_download="size reported by Ollama when available", requires_network=True,
                executable="ollama", verification="model listing"))

        if not report.get("voice", {}).get("ffmpeg") and role in {None, "full-node", "code-worker"}:
            actions.append(RepairAction("voice.ffmpeg", "VOICE", "Install ffmpeg",
                "Install ffmpeg through Homebrew for optional media features.",
                "CONFIRM" if brew else "MANUAL", target_role="FULL_NODE", requires_network=True,
                executable="brew", verification="ffmpeg --version"))

        return RepairPlan(tuple(actions), overall=profile.get("overall_readiness", ""),
                          eligible_roles=tuple(profile.get("eligible_roles", [])),
                          communication_ready=node_ready)


class RepairExecutor:
    def __init__(self, runner=None):
        self.runner = runner or subprocess.run

    def execute(self, plan: RepairPlan, approved: bool = False) -> dict:
        if not approved:
            return {"schema_version": SCHEMA_VERSION, "status": "DECLINED", "actions": []}
        results = []
        for action in plan.actions:
            if action.risk_class in {"MANUAL", "POLICY_BLOCKED"}:
                results.append({"id": action.id, "result": "MANUAL" if action.risk_class == "MANUAL" else "POLICY_BLOCKED"})
                continue
            try:
                results.append({"id": action.id, "result": self._run_action(action)})
            except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                results.append({"id": action.id, "result": "FAILED", "error_category": type(exc).__name__})
        report = collect_doctor()
        try:
            from app.deep_diagnostics import run as run_deep
            deep = run_deep(report)
            if isinstance(deep, dict):
                report = dict(report)
                report["capability_audit"] = deep.get("capability_audit", report.get("capability_audit", {}))
                report["deep_diagnostics"] = deep
        except Exception:
            # Verification remains useful even when an optional deep probe is
            # unavailable in a restricted environment.
            pass
        profile = build_node_capability_profile(report)
        return {"schema_version": SCHEMA_VERSION, "status": "COMPLETE", "actions": results,
                "verification": {"overall": profile.get("overall_readiness"),
                                 "eligible_roles": profile.get("eligible_roles", [])}}

    def _run_action(self, action: RepairAction) -> str:
        if action.id == "node.identity":
            from app.node_pairing import identity
            identity(); return "SUCCESS"
        if action.id == "ollama.install":
            self.runner(["brew", "install", "ollama"], check=True, capture_output=True, text=True, timeout=300); return "SUCCESS"
        if action.id == "model.default":
            self.runner(["ollama", "pull", action.title.removeprefix("Download ")], check=True, capture_output=True, text=True, timeout=1800); return "SUCCESS"
        if action.id == "voice.ffmpeg":
            self.runner(["brew", "install", "ffmpeg"], check=True, capture_output=True, text=True, timeout=300); return "SUCCESS"
        raise RuntimeError("unsupported repair action")


def render(plan: RepairPlan) -> str:
    lines = ["ICLIRIUS REPAIR", "", "Current role eligibility"]
    lines.extend(f"  {role:20} READY" for role in plan.eligible_roles)
    lines += ["", "Proposed actions"]
    if not plan.actions:
        lines.append("  No repair required.")
    for index, action in enumerate(plan.actions, 1):
        lines.append(f"  {index}. {action.title} [{action.risk_class}]")
        lines.append(f"     {action.description}")
    lines += ["", f"Node communication runtime: {'READY' if plan.communication_ready else 'NOT READY'}"]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(prog="iclirius repair")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--role", choices=("interface", "local-compute", "code-worker", "full-node"))
    args = parser.parse_args(argv or [])
    plan = RepairPlanner().build(collect_doctor(), args.role)
    if args.json or args.plan:
        print(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) if args.json else render(plan))
        return 0
    print(render(plan))
    if not plan.actions:
        return 0
    if not sys.stdin.isatty():
        print("Confirmation required; no actions executed in non-interactive mode.")
        return 2
    answer = input("\nApply repair plan? [y/N] ").strip().lower()
    if answer not in {"y", "yes"}:
        print("Repair declined; no changes made."); return 0
    result = RepairExecutor().execute(plan, approved=True)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if all(item.get("result") not in {"FAILED"} for item in result["actions"]) else 1
