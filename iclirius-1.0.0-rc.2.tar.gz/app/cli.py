"""Official lightweight Iclirius CLI entrypoint."""

from __future__ import annotations

import sys
from app.version import VERSION


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    debug = "--debug" in args
    plain = "--plain" in args
    if debug:
        args = [arg for arg in args if arg != "--debug"]
    if plain:
        args = [arg for arg in args if arg != "--plain"]
    if args in (["--version"], ["-V"]):
        print(f"Iclirius {VERSION}")
        return 0

    if args and args[0].lower() == "doctor":
        from app.doctor import main as doctor_main
        return doctor_main(args[1:])

    if args and args[0].lower() == "setup":
        from app.setup import main as setup_main
        return setup_main(args[1:])

    if args and args[0].lower() == "auth":
        from app.auth_cli import main as auth_main
        return auth_main(args[1:])

    if args and args[0].lower() == "node":
        from app.node_cli import main as node_main
        return node_main(args[1:])

    if args and args[0].lower() == "repair":
        from app.repair import main as repair_main
        return repair_main(args[1:])

    if len(args) >= 2 and args[0].lower() == "memory" and args[1].lower() == "enrollment":
        from app.memory_cli import main as memory_main
        return memory_main(args[2:])

    from app.logger import configure_cli_logging
    configure_cli_logging(debug=debug)
    from app.config import settings
    if not args and not settings.setup_complete and sys.stdin.isatty() and sys.stdout.isatty():
        print("Iclirius is not configured on this machine.")
        print("Run: iclirius setup")
        return 2
    if sys.stdin.isatty() and sys.stdout.isatty():
        from app.local_auth import authenticate_interactive, status as get_auth_status
        from app.runtime_events import EventType, Status, emit
        # Phase 5 installations predate local-auth enrollment. Preserve their
        # existing interactive behavior until the user explicitly runs
        # `iclirius auth setup`; enrolled machines are always gated.
        if get_auth_status().get("enrolled"):
            try:
                emit(EventType.AUTH_REQUIRED, status=Status.STARTED, interface="cli")
            except Exception:
                pass
            if not plain:
                from app.auth_ui import run_auth_gate
                session = run_auth_gate(settings.principal_user_name, settings.user_id)
            else:
                session = authenticate_interactive()
            if session is None:
                return 2
    # Import the agent only after CLI logging has been configured.  Agent
    # construction registers providers and must never leak those diagnostics
    # into the normal conversation stream.
    from interfaces.cli_chat import _agent

    if not args:
        if not plain:
            from app.tui import IcliriusTUI
            if IcliriusTUI.compatible():
                return IcliriusTUI(_agent).run()
        from app.cli_session import InteractiveCLISession
        return InteractiveCLISession(_agent).run()

    # Preserve the established administrative/coding commands while making
    # the no-argument invocation the canonical interactive session.
    from interfaces.cli import main as legacy_main
    previous = sys.argv
    try:
        sys.argv = ["iclirius", *args]
        return int(legacy_main() or 0)
    finally:
        sys.argv = previous


if __name__ == "__main__":
    raise SystemExit(main())
