"""Read-only capability observations used by ``iclirius doctor``.

This module deliberately performs no remediation and no active deep tests.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path


class CapabilityStatus(str, Enum):
    READY = "READY"
    AVAILABLE = "AVAILABLE"
    DEGRADED = "DEGRADED"
    OPTIONAL = "OPTIONAL"
    MISSING = "MISSING"
    BLOCKED = "BLOCKED"
    POLICY_BLOCKED = "POLICY_BLOCKED"
    UNTESTED = "UNTESTED"


@dataclass(frozen=True)
class CapabilityResult:
    id: str
    category: str
    status: str
    available: bool | None
    required: bool
    summary: str
    evidence: str = ""
    limitation: str = ""
    remediation_hint: str = ""
    source: str = "doctor"
    tested: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


def _result(cap_id: str, category: str, status: CapabilityStatus,
            *, required=False, available=None, summary="", evidence="",
            limitation="", remediation_hint="", tested=False) -> CapabilityResult:
    return CapabilityResult(cap_id, category, status.value, available, required,
                            summary, evidence, limitation, remediation_hint,
                            tested=tested)


def _memory_bytes() -> tuple[int | None, int | None]:
    try:
        total = int(os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        available = int(os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        return total, available
    except (AttributeError, OSError, TypeError, ValueError):
        sysctl = shutil.which("sysctl")
        if not sysctl and platform.system() == "Darwin":
            candidate = Path("/usr/sbin/sysctl")
            if candidate.exists():
                sysctl = str(candidate)
        if sysctl:
            try:
                total = int(subprocess.run([sysctl, "-n", "hw.memsize"],
                                           capture_output=True, text=True,
                                           timeout=2, check=False).stdout.strip())
                # macOS does not expose a stable, permission-free available
                # value through this lightweight probe; report total only.
                return total, None
            except (OSError, ValueError, subprocess.SubprocessError):
                pass
        return None, None


def _disk(path: str | Path) -> dict:
    try:
        usage = shutil.disk_usage(Path(path).expanduser())
        return {"total_bytes": usage.total, "free_bytes": usage.free,
                "available": True}
    except OSError:
        return {"total_bytes": None, "free_bytes": None, "available": False}


def _tailscale() -> dict:
    binary = shutil.which("tailscale")
    if not binary:
        return {"installed": False, "status": CapabilityStatus.OPTIONAL.value,
                "connected": None, "cli": False}
    try:
        proc = subprocess.run([binary, "status", "--json"], capture_output=True,
                              text=True, timeout=3, check=False)
        if proc.returncode != 0:
            return {"installed": True, "status": CapabilityStatus.UNTESTED.value,
                    "connected": None, "cli": True}
        data = json.loads(proc.stdout or "{}")
        backend = str(data.get("BackendState") or "")
        connected = backend.lower() == "running"
        return {"installed": True, "status": CapabilityStatus.AVAILABLE.value if connected else CapabilityStatus.DEGRADED.value,
                "connected": connected, "backend_state": backend, "cli": True}
    except (OSError, subprocess.SubprocessError, ValueError, TypeError):
        return {"installed": True, "status": CapabilityStatus.UNTESTED.value,
                "connected": None, "cli": True}


def collect(*, ollama: dict, setup: dict, authentication: dict) -> dict:
    """Build serializable observations without changing local state."""
    from app.config import settings

    total, available = _memory_bytes()
    state_root = Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()
    disk = _disk(state_root)
    capabilities: list[CapabilityResult] = []
    capabilities.append(_result("system.runtime", "system", CapabilityStatus.READY,
                                 required=True, available=True,
                                 summary=f"Python {platform.python_version()}",
                                 evidence="stdlib", tested=True))
    capabilities.append(_result("system.ram", "system", CapabilityStatus.AVAILABLE if total else CapabilityStatus.UNTESTED,
                                 available=bool(total), summary="RAM metadata",
                                 evidence=str(total) if total else "unavailable", tested=bool(total)))
    capabilities.append(_result("system.disk", "system", CapabilityStatus.AVAILABLE if disk["available"] else CapabilityStatus.UNTESTED,
                                 available=disk["available"], summary="Local state disk metadata",
                                 tested=disk["available"]))
    setup_ready = bool(setup.get("setup_complete"))
    capabilities.append(_result("iclirius.setup", "core", CapabilityStatus.READY if setup_ready else CapabilityStatus.BLOCKED,
                                 required=True, available=setup_ready, summary="Machine setup",
                                 evidence="setup_complete" if setup_ready else "incomplete", tested=True))
    identity = setup.get("identity", {})
    capabilities.append(_result("iclirius.identity", "core", CapabilityStatus.READY if identity.get("configured") else CapabilityStatus.BLOCKED,
                                 required=True, available=bool(identity.get("configured")), summary="User identity"))
    node = setup.get("node", {})
    capabilities.append(_result("iclirius.node", "core", CapabilityStatus.READY if node.get("configured") else CapabilityStatus.BLOCKED,
                                 required=True, available=bool(node.get("configured")), summary="Node identity"))
    auth_ready = bool(authentication.get("enrolled"))
    capabilities.append(_result("auth.local", "authentication", CapabilityStatus.READY if auth_ready else CapabilityStatus.OPTIONAL,
                                 available=auth_ready, summary="Local authentication", tested=True))

    ollama_installed = bool(ollama.get("installed"))
    ollama_running = bool(ollama.get("running"))
    capabilities.append(_result("ai.ollama", "local_ai", CapabilityStatus.READY if ollama_running else (CapabilityStatus.MISSING if not ollama_installed else CapabilityStatus.BLOCKED),
                                 required=True, available=ollama_running, summary="Ollama API",
                                 evidence=ollama.get("state", "unknown"), tested=True))
    models = ollama.get("models", {})
    default = str(models.get("default", ""))
    installed_models = set(models.get("installed", []))
    default_ready = ollama_running and default in installed_models
    capabilities.append(_result("ai.default_model", "local_ai", CapabilityStatus.READY if default_ready else CapabilityStatus.BLOCKED,
                                 required=True, available=default_ready, summary=default or "default model",
                                 evidence="installed" if default in installed_models else "missing", tested=ollama_running))
    for tier in ("fast", "heavy", "embed"):
        name = str(models.get(tier, ""))
        if not name:
            continue
        present = name in installed_models
        capabilities.append(_result(f"ai.{tier}_model", "local_ai", CapabilityStatus.AVAILABLE if present else CapabilityStatus.OPTIONAL,
                                     available=present, summary=name, evidence="installed" if present else "optional model missing",
                                     tested=ollama_running))

    fs_enabled = bool(settings.enable_local_read_tools and settings.file_manager_allowed_roots)
    capabilities.append(_result("tools.filesystem", "tools", CapabilityStatus.AVAILABLE if fs_enabled else CapabilityStatus.OPTIONAL,
                                 available=fs_enabled, summary="Configured filesystem read roots",
                                 limitation="No active read/write test in normal doctor", tested=False))
    shell_enabled = bool(settings.execute_enabled)
    capabilities.append(_result("tools.shell", "tools", CapabilityStatus.AVAILABLE if shell_enabled else CapabilityStatus.OPTIONAL,
                                 available=shell_enabled, summary="Shell execution policy",
                                 limitation="No command executed in normal doctor", tested=False))
    for tool in ("git", "python"):
        path = shutil.which(tool) or (os.sys.executable if tool == "python" else None)
        capabilities.append(_result(f"tools.{tool}", "tools", CapabilityStatus.AVAILABLE if path else CapabilityStatus.OPTIONAL,
                                     available=bool(path), summary=tool, evidence=path or "not installed", tested=False))

    home = setup.get("memory_home", {})
    memory_ready = bool(home.get("configured") and home.get("readable"))
    capabilities.append(_result("memory.home", "memory", CapabilityStatus.READY if memory_ready else CapabilityStatus.BLOCKED,
                                 required=True, available=memory_ready, summary="Memory Home", evidence=home.get("status", "unknown"), tested=True))
    keychain = setup.get("keychain", {})
    encryption = bool(keychain.get("configured"))
    encryption_state = keychain.get("observation", "ready" if encryption else "missing")
    if encryption_state == "unknown":
        encryption_status = CapabilityStatus.UNTESTED
        encryption_available = None
    else:
        encryption_status = CapabilityStatus.READY if encryption else CapabilityStatus.BLOCKED
        encryption_available = encryption
    capabilities.append(_result("memory.encryption", "memory", encryption_status,
                                 required=True, available=encryption_available,
                                 summary="Keychain encryption readiness",
                                 limitation="Keychain observation was unavailable" if encryption_state == "unknown" else "",
                                 tested=encryption_state != "unknown"))

    network = {"interface": bool(shutil.which("ifconfig")), "internet": CapabilityStatus.UNTESTED.value,
               "github": CapabilityStatus.UNTESTED.value}
    tailscale = _tailscale()
    remote = {"ssh": CapabilityStatus.UNTESTED.value, "screen_sharing": CapabilityStatus.UNTESTED.value}
    voice = {
        "tts": bool(shutil.which("say")),
        "stt": bool(_module_available("faster_whisper")),
        "ffmpeg": bool(shutil.which("ffmpeg")),
    }
    capabilities.append(_result("network.outbound", "network", CapabilityStatus.UNTESTED,
                                 available=None, summary="Outbound network", limitation="Active probes belong to doctor --deep"))
    capabilities.append(_result("network.tailscale", "network", CapabilityStatus(tailscale["status"]),
                                 available=tailscale.get("connected"), summary="Tailscale", tested=bool(tailscale.get("installed"))))
    capabilities.append(_result("voice.tts", "voice", CapabilityStatus.AVAILABLE if voice["tts"] else CapabilityStatus.OPTIONAL,
                                 available=voice["tts"], summary="macOS say", tested=False))
    capabilities.append(_result("voice.stt", "voice", CapabilityStatus.AVAILABLE if voice["stt"] else CapabilityStatus.OPTIONAL,
                                 available=voice["stt"], summary="faster-whisper", tested=False))
    serialized = [item.to_dict() for item in capabilities]
    blockers = [item["id"] for item in serialized if item.get("required") and
                item.get("status") in {"BLOCKED", "MISSING", "POLICY_BLOCKED"}]
    limitations = [item["id"] for item in serialized if item.get("status") in {"DEGRADED", "UNTESTED"}]
    optional = [item["id"] for item in serialized if item.get("status") == "OPTIONAL"]
    return {"schema_version": 2, "capabilities": serialized,
            "system": {"platform": platform.system(), "release": platform.mac_ver()[0] or platform.release(),
                        "architecture": platform.machine(), "hostname": platform.node(),
                        "python": platform.python_version(), "cpu_count": os.cpu_count(),
                        "ram_total_bytes": total, "ram_available_bytes": available, "disk": disk},
            "network": network, "tailscale": tailscale, "remote_access": remote, "voice": voice,
            "blockers": blockers, "limitations": limitations, "optional": optional,
            "overall": "BLOCKED" if blockers else ("DEGRADED" if limitations else "READY")}


def _module_available(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False
