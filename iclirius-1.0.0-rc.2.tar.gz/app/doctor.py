"""Read-only installation and runtime diagnostics for Iclirius."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _command(name: str) -> str | None:
    return shutil.which(name)


def _run(argv: list[str], timeout: float = 8) -> tuple[bool, str]:
    try:
        result = subprocess.run(argv, capture_output=True, text=True,
                                timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return False, ""
    return result.returncode == 0, (result.stdout or result.stderr or "").strip()


def _configured_models() -> tuple[list[str], list[str]]:
    try:
        from app.config import settings
        required = [settings.default_model, settings.fast_model, settings.heavy_model]
        optional = [settings.embed_model]
    except Exception:
        required, optional = [], []
    return (list(dict.fromkeys(name for name in required if name)),
            list(dict.fromkeys(name for name in optional if name)))


def _installed_models(ollama: str | None) -> list[str]:
    if not ollama:
        return []
    ok, output = _run([ollama, "list"])
    if not ok:
        return []
    models = []
    for line in output.splitlines()[1:]:
        fields = line.split()
        if fields:
            models.append(fields[0])
    return models


def _ollama_service() -> tuple[bool, str]:
    try:
        with urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as response:
            return response.status == 200, "running"
    except (OSError, URLError, ValueError):
        return False, "not running"


def collect() -> dict:
    """Return safe, machine-readable diagnostics without secrets or mutation."""
    python_ok = sys.version_info >= (3, 10)
    git = _command("git")
    brew = _command("brew")
    ollama = _command("ollama")
    ffmpeg = _command("ffmpeg")
    ollama_running, ollama_state = _ollama_service() if ollama else (False, "not installed")
    configured_required, configured_optional = _configured_models()
    configured = configured_required + configured_optional
    installed = _installed_models(ollama) if ollama_running else []
    model_state = {name: (name in installed) for name in configured}

    try:
        import faster_whisper  # noqa: F401
        stt_installed = True
    except Exception:
        stt_installed = False

    try:
        from app.config import settings
        memory_enabled = settings.enable_memory_core
        local_read = settings.enable_local_read_tools
        execute = settings.execute_enabled
        telegram_enabled = settings.enable_telegram
        telegram_configured = bool(settings.telegram_bot_token and settings.allowed_user_ids)
        identity = settings.principal_user_name or "not configured"
    except Exception:
        memory_enabled = local_read = execute = telegram_enabled = False
        telegram_configured = False
        identity = "not configured"

    keychain_ok = False
    keychain_observation = "missing"
    security = _command("security")
    if security:
        keychain_ok, keychain_output = _run([security, "find-generic-password", "-a", "iclirius",
                               "-s", "iclirius_memory_key", "-w"])
        if not keychain_ok:
            detail = keychain_output.lower()
            if "not valid" in detail or "not permitted" in detail or "permission" in detail:
                keychain_observation = "unknown"

    venv = Path(sys.prefix) != Path(sys.base_prefix)
    package_ok = (PROJECT_ROOT / "app" / "cli.py").exists()
    git_repo = (PROJECT_ROOT / ".git").exists()
    try:
        from app.setup import status as setup_status
        setup = setup_status()
    except Exception:
        setup = {
            "setup_complete": False,
            "identity": {"configured": False},
            "memory_home": {"configured": False, "status": "unavailable"},
            "keychain": {"configured": False},
            "node": {"configured": False},
        }
    try:
        from app.local_auth import status as auth_status
        authentication = auth_status()
    except Exception:
        authentication = {"enrolled": False, "touch_id": "unavailable",
                          "recovery_credential": False, "user_id": "",
                          "primary_identity": ""}
    required_models_ok = bool(configured_required) and bool(model_state.get(configured_required[0], False))
    blockers = {
        "platform": platform.system() == "Darwin",
        "python": python_ok,
        "venv": venv,
        # A packaged installation is valid without a .git directory. Git is
        # reported separately for project tooling.
        "package": package_ok,
        "git": bool(git),
        "ollama": bool(ollama and ollama_running),
        "models": required_models_ok,
        "setup": bool(setup.get("setup_complete")),
    }
    overall = "ready" if all(blockers.values()) else "blocked"
    from app.capability_audit import collect as collect_capabilities
    try:
        from app.config import settings
        capability_setup = dict(setup)
        capability_setup["keychain"] = dict(setup.get("keychain", {}))
        capability_setup["keychain"]["observation"] = keychain_observation if security else "unknown"
        capability = collect_capabilities(
            ollama={"installed": bool(ollama), "running": ollama_running,
                    "state": ollama_state,
                    "models": {"default": settings.default_model,
                                "fast": settings.fast_model,
                                "heavy": settings.heavy_model,
                                "embed": settings.embed_model,
                                "installed": installed}},
            setup=capability_setup, authentication=authentication)
    except Exception:
        capability = {"schema_version": 2, "capabilities": [],
                      "network": {}, "tailscale": {}, "remote_access": {}, "voice": {}}
    required_capabilities = [item for item in capability.get("capabilities", []) if item.get("required")]
    capability_blocked = [item["id"] for item in required_capabilities
                          if item.get("status") in {"BLOCKED", "MISSING", "POLICY_BLOCKED"}]
    limitations = [item["id"] for item in capability.get("capabilities", [])
                   if item.get("status") in {"DEGRADED", "UNTESTED"}]
    optional = [item["id"] for item in capability.get("capabilities", [])
                if item.get("status") == "OPTIONAL"]
    capability["blockers"] = capability_blocked
    capability["limitations"] = limitations
    capability["optional"] = optional
    capability["overall"] = "BLOCKED" if capability_blocked else ("DEGRADED" if limitations else "READY")
    return {
        "overall": overall,
        "platform": {"system": platform.system(), "release": platform.mac_ver()[0] or platform.release(),
                      "architecture": platform.machine(), "supported": blockers["platform"]},
        "python": {"version": platform.python_version(), "supported": python_ok, "venv": venv},
        "package": {"runtime": "OpenClaw embedded", "present": package_ok, "repository": git_repo},
        "git": {"installed": bool(git), "branch": _git_branch(git), "dirty": _git_dirty(git)},
        "homebrew": {"installed": bool(brew), "path": brew or ""},
        "ollama": {"installed": bool(ollama), "running": ollama_running, "state": ollama_state},
        "models": {"configured": configured, "required": configured_required,
                    "optional": configured_optional, "installed": installed,
                    "available": model_state},
        "memory": {"enabled": memory_enabled,
                    "status": "ready" if memory_enabled and keychain_ok else ("not configured" if memory_enabled else "disabled")},
        "identity": {"display_name": identity, "configured": identity != "not configured"},
        "setup": setup,
        "authentication": authentication,
        "tools": {"filesystem": local_read, "shell": execute, "git": bool(git), "python": python_ok},
        "voice": {"tts": bool(shutil.which("say")), "stt": stt_installed, "ffmpeg": bool(ffmpeg)},
        "interfaces": {"cli": package_ok, "telegram": telegram_enabled and telegram_configured},
        "providers": {"local": "ollama" if ollama else "not installed", "gemini": "disabled by default"},
        "blockers": blockers,
        "capability_audit": capability,
        "capability_overall": capability["overall"],
        "limitations": limitations,
        "optional": optional,
    }


def _git_branch(git: str | None) -> str:
    if not git:
        return ""
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "branch", "--show-current"])
    return value if ok else ""


def _git_dirty(git: str | None) -> bool:
    if not git:
        return False
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "status", "--porcelain"])
    return bool(value) if ok else False


def _mark(ok: bool, text: str, optional: bool = False) -> str:
    return f"{'✓' if ok else ('○' if optional else '✗')} {text}"


def _cap_mark(item: dict) -> str:
    status = str(item.get("status", "UNTESTED"))
    glyph = {"READY": "✓", "AVAILABLE": "✓", "DEGRADED": "!",
             "OPTIONAL": "○", "MISSING": "✗", "BLOCKED": "⛔",
             "POLICY_BLOCKED": "⛔", "UNTESTED": "?"}.get(status, "?")
    return f"{glyph} {item.get('summary', item.get('id', 'unknown'))} [{status}]"


def render(report: dict) -> str:
    lines = ["Iclirius Doctor", "", "CORE"]
    lines += [_mark(report["platform"]["supported"], "macOS"),
              _mark(report["python"]["supported"], f"Python {report['python']['version']}"),
              _mark(report["python"]["venv"], "virtualenv", optional=True),
              _mark(report["package"]["present"], "Iclirius runtime"),
              _mark(report["git"]["installed"], "Git")]
    lines.append(_mark(report["memory"]["status"] == "ready", "Memory Core", optional=True))
    setup = report.get("setup", {})
    identity = setup.get("identity", {})
    home = setup.get("memory_home", {})
    lines += ["", "SETUP",
              _mark(bool(setup.get("setup_complete")), "Setup complete"),
              _mark(bool(identity.get("configured")), "Identity", optional=True),
              _mark(home.get("status") == "ready", "Memory Home", optional=True),
              _mark(bool(setup.get("keychain", {}).get("configured")), "Keychain", optional=True),
              _mark(bool(setup.get("node", {}).get("configured")), "Node", optional=True)]
    enrollment = setup.get("enrollment", {})
    lines.append(_mark(enrollment.get("state") in {"prepared", "not_prepared"},
                       f"Cross-device enrollment ({enrollment.get('state', 'unknown')})", optional=True))
    auth = report.get("authentication", {})
    lines += ["", "LOCAL AUTHENTICATION",
              _mark(bool(auth.get("enrolled")), "Recovery credential", optional=True),
              _mark(auth.get("touch_id") == "available", f"Touch ID ({auth.get('touch_id', 'unavailable')})", optional=True)]
    lines += ["", "LOCAL AI",
              _mark(report["ollama"]["installed"], "Ollama installed"),
              _mark(report["ollama"]["running"], f"Ollama service ({report['ollama']['state']})"),]
    optional = set(report["models"].get("optional", []))
    for name, available in report["models"]["available"].items():
        lines.append(_mark(available, name, optional=name in optional))
    lines += ["", "TOOLS",
              _mark(report["tools"]["filesystem"], "Filesystem", optional=True),
              _mark(report["tools"]["shell"], "Shell", optional=True),
              _mark(report["tools"]["git"], "Git"),
              _mark(report["tools"]["python"], "Python"),
              "", "VOICE",
              _mark(report["voice"]["tts"], "TTS", optional=True),
              _mark(report["voice"]["stt"], "STT", optional=True),
              _mark(report["voice"]["ffmpeg"], "ffmpeg", optional=True),
              "", "INTERFACES",
              _mark(report["interfaces"]["cli"], "CLI"),
              _mark(report["interfaces"]["telegram"], "Telegram", optional=True),
              ""]
    audited = report.get("capability_audit", {}).get("capabilities", [])
    for category, title in (("system", "SYSTEM"), ("core", "ICLIRIUS CORE"),
                            ("authentication", "AUTHENTICATION"),
                            ("local_ai", "LOCAL AI"), ("tools", "TOOLS"),
                            ("memory", "MEMORY"), ("network", "NETWORK"),
                            ("voice", "VOICE")):
        items = [item for item in audited if item.get("category") == category]
        if items:
            lines.append(title)
            lines.extend(_cap_mark(item) for item in items)
    lines.append(f"Overall: {report.get('capability_overall', report['overall']).upper()}")
    blockers = report.get("capability_audit", {}).get("blockers", [])
    limitations = report.get("limitations", [])
    optional_items = report.get("optional", [])
    if blockers:
        lines.extend(["", "BLOCKERS", *[f"- {value}" for value in blockers]])
    if limitations:
        lines.extend(["", "LIMITATIONS", *[f"- {value}" for value in limitations]])
    if optional_items:
        lines.extend(["", "OPTIONAL", *[f"- {value}" for value in optional_items]])
    deep = report.get("deep_diagnostics")
    if deep:
        lines.extend(["", "DEEP DIAGNOSTICS"])
        for probe in deep.get("probes", []):
            status = probe.get("status", "UNTESTED")
            duration = f" {probe['duration_ms']} ms" if probe.get("duration_ms") else ""
            glyph = {"READY": "✓", "AVAILABLE": "✓", "DEGRADED": "!",
                     "OPTIONAL": "○", "MISSING": "✗", "BLOCKED": "⛔",
                     "POLICY_BLOCKED": "⛔", "UNTESTED": "?"}.get(status, "?")
            lines.append(f"{glyph} {probe.get('summary', probe.get('id', 'probe'))} [{status}]{duration}")
    if report["git"]["dirty"]:
        lines.append("Note: repository has uncommitted changes.")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = list(argv or [])
    report = collect()
    if "--deep" in args:
        from app.deep_diagnostics import run as run_deep
        deep = run_deep(report)
        report["deep_diagnostics"] = {key: value for key, value in deep.items()
                                      if key != "capability_audit"}
        report["capability_audit"] = deep["capability_audit"]
        report["capability_overall"] = deep["capability_audit"]["overall"]
        report["limitations"] = deep["capability_audit"]["limitations"]
        report["optional"] = deep["capability_audit"]["optional"]
    if "--json" in args:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(render(report))
    overall = report.get("capability_overall") or report.get("overall", "blocked")
    return 0 if overall.upper() != "BLOCKED" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
