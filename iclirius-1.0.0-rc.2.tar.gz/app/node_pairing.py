"""Minimal authenticated node pairing and ping transport for Phase 5.5a."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import socket
import ssl
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
from cryptography.x509.oid import NameOID

from app.config import settings
from app.node_identity import ensure_node, read_node
from app.secure_storage import KeychainMaterialMissing, SecureStorageError, load_node_identity_key, store_node_identity_key

PROTOCOL = "iclirius-node"
VERSION = 1
MAX_MESSAGE = 16 * 1024
PAIR_TTL = 300
DEFAULT_PORT = 18890
PEERS_FILE = "peers.json"


class PairingError(RuntimeError):
    pass


@dataclass
class NodeIdentity:
    node_id: str
    public_key: str
    private_key: ed25519.Ed25519PrivateKey

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(base64.b64decode(self.public_key)).hexdigest()[:16]


def _node_id() -> str:
    return str((read_node() or ensure_node()).get("node_id") or settings.node_id)


def identity() -> NodeIdentity:
    node_id = _node_id()
    try:
        raw = load_node_identity_key(node_id)
        private = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(raw))
    except KeychainMaterialMissing:
        private = ed25519.Ed25519PrivateKey.generate()
        raw = base64.b64encode(private.private_bytes(serialization.Encoding.Raw,
                    serialization.PrivateFormat.Raw, serialization.NoEncryption())).decode()
        store_node_identity_key(node_id, raw)
    except (SecureStorageError, ValueError, TypeError) as exc:
        raise PairingError("node identity unavailable") from exc
    public = private.public_key().public_bytes(serialization.Encoding.Raw,
                                               serialization.PublicFormat.Raw)
    return NodeIdentity(node_id, base64.b64encode(public).decode(), private)


def _peers_path() -> Path:
    return Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser() / PEERS_FILE


def peers() -> dict:
    try:
        data = json.loads(_peers_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"schema_version": 1, "peers": {}}
    except (OSError, ValueError):
        return {"schema_version": 1, "peers": {}}


def _save_peers(data: dict) -> None:
    path = _peers_path(); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)


def _record(peer: dict, address: str = "") -> None:
    data = peers(); data.setdefault("schema_version", 1); data.setdefault("peers", {})
    peer = dict(peer); peer["address"] = address or peer.get("address", "")
    data["peers"][peer["node_id"]] = peer; _save_peers(data)


def _sign(identity_obj: NodeIdentity, payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return base64.b64encode(identity_obj.private_key.sign(raw)).decode()


def _verify(public: str, payload: dict, signature: str) -> bool:
    try:
        key = ed25519.Ed25519PublicKey.from_public_bytes(base64.b64decode(public))
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        key.verify(base64.b64decode(signature), raw); return True
    except Exception:
        return False


def _cert_context(server=True):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "iclirius-node")])
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(datetime.now(timezone.utc))
            .not_valid_after(datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year + 1))
            .sign(key, hashes.SHA256()))
    directory = tempfile.TemporaryDirectory(prefix="iclirius-node-tls-")
    cert_path, key_path = Path(directory.name) / "cert.pem", Path(directory.name) / "key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile=cert_path, keyfile=key_path)
    return context, directory


def _client_context() -> ssl.SSLContext:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    # The certificate is ephemeral; application Ed25519 signatures pin the
    # node identity. TLS still provides confidentiality and integrity.
    context.check_hostname = False; context.verify_mode = ssl.CERT_NONE
    return context


def _send(sock: ssl.SSLSocket, message: dict) -> None:
    raw = json.dumps(message, separators=(",", ":")).encode()
    if len(raw) > MAX_MESSAGE: raise PairingError("message too large")
    sock.sendall(raw + b"\n")


def _recv(sock: ssl.SSLSocket) -> dict:
    data = bytearray()
    while len(data) <= MAX_MESSAGE:
        chunk = sock.recv(1)
        if not chunk: break
        if chunk == b"\n": break
        data.extend(chunk)
    if not data or len(data) > MAX_MESSAGE: raise PairingError("invalid or oversized message")
    value = json.loads(data.decode());
    if not isinstance(value, dict): raise PairingError("invalid message")
    if value.get("protocol") != PROTOCOL or value.get("version") != VERSION:
        raise PairingError("PROTOCOL_VERSION_UNSUPPORTED")
    if value.get("type") not in {"PAIR_INIT", "HELLO", "PING", "PONG"}:
        raise PairingError("unknown message type")
    return value


def _envelope(kind: str, sender: NodeIdentity, payload: dict) -> dict:
    body = {"protocol": PROTOCOL, "version": VERSION, "type": kind,
            "request_id": uuid.uuid4().hex, "sender_node_id": sender.node_id,
            "timestamp": int(time.time()), "payload": payload}
    body["signature"] = _sign(sender, {k: body[k] for k in body if k != "signature"})
    return body


def _fresh(message: dict, window: int = 300) -> bool:
    return abs(int(time.time()) - int(message.get("timestamp", 0))) <= window


class NodeListener:
    def __init__(self, bind: str = "127.0.0.1", port: int = DEFAULT_PORT, code: str | None = None):
        self.bind, self.port, self.code = bind, port, code or f"{secrets.randbelow(1_000_000):06d}"
        self.identity = identity(); self._stop = threading.Event(); self._server = None; self._code_used = False

    def serve(self, once: bool = False) -> None:
        context, temp = _cert_context(); self._temp = temp
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM); server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.bind, self.port)); server.listen(5); server.settimeout(1); self._server = server
        print(f"Pairing code: {self.code}")
        try:
            while not self._stop.is_set():
                try: conn, address = server.accept()
                except socket.timeout: continue
                if once:
                    self._handle(context, conn, address)
                    break
                threading.Thread(target=self._handle, args=(context, conn, address), daemon=True).start()
        finally:
            server.close(); temp.cleanup()

    def stop(self):
        self._stop.set()
        if self._server:
            try: self._server.close()
            except OSError: pass

    def _handle(self, context, conn, address):
        try:
            with context.wrap_socket(conn, server_side=True) as sock:
                msg = _recv(sock)
                if msg["type"] == "PAIR_INIT":
                    if self._code_used or msg.get("payload", {}).get("code") != self.code or not _fresh(msg): raise PairingError("pairing code invalid or expired")
                    peer = msg["payload"]; signed = {k: msg[k] for k in msg if k != "signature"}
                    if not _verify(peer["public_key"], signed, msg.get("signature", "")): raise PairingError("peer signature invalid")
                    _record({"node_id": peer["node_id"], "public_key": peer["public_key"], "fingerprint": hashlib.sha256(base64.b64decode(peer["public_key"])).hexdigest()[:16], "trust": "TRUSTED", "paired_at": _now(), "last_successful_handshake": _now()}, str(address[0]))
                    self._code_used = True
                    reply = _envelope("HELLO", self.identity, {"public_key": self.identity.public_key, "trust": "TRUSTED", "challenge": peer.get("challenge", "")})
                    _send(sock, reply)
                elif msg["type"] in {"HELLO", "PING"}:
                    self._authenticated(sock, msg)
        except Exception:
            try: conn.close()
            except OSError: pass

    def _authenticated(self, sock, msg):
        peer_id = msg.get("sender_node_id"); peer = peers().get("peers", {}).get(peer_id, {})
        signed = {k: msg[k] for k in msg if k != "signature"}
        if not peer or peer.get("trust") != "TRUSTED" or peer.get("public_key") != msg.get("payload", {}).get("public_key", peer.get("public_key")) or not _verify(peer.get("public_key", ""), signed, msg.get("signature", "")) or not _fresh(msg):
            raise PairingError("peer not trusted")
        if msg["type"] == "PING": _send(sock, _envelope("PONG", self.identity, {"request_id": msg["request_id"]}))


def _now() -> str: return datetime.now(timezone.utc).isoformat(timespec="seconds")


def pair(address: str, port: int = DEFAULT_PORT, code: str = "") -> dict:
    me = identity(); challenge = secrets.token_urlsafe(16)
    context = _client_context()
    with socket.create_connection((address, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            msg = _envelope("PAIR_INIT", me, {"code": code, "node_id": me.node_id,
                                               "public_key": me.public_key, "challenge": challenge})
            _send(sock, msg); reply = _recv(sock)
            peer = reply.get("payload", {}); signed = {k: reply[k] for k in reply if k != "signature"}
            if reply["type"] != "HELLO" or not _fresh(reply) or not _verify(peer.get("public_key", ""), signed, reply.get("signature", "")):
                raise PairingError("peer handshake invalid")
            peer_id = reply["sender_node_id"]
            _record({"node_id": peer_id, "public_key": peer["public_key"], "fingerprint": hashlib.sha256(base64.b64decode(peer["public_key"])).hexdigest()[:16], "trust": "TRUSTED", "paired_at": _now(), "last_successful_handshake": _now()}, address)
            return {"node_id": peer_id, "fingerprint": hashlib.sha256(base64.b64decode(peer["public_key"])).hexdigest()[:16], "trust": "TRUSTED"}


def ping(address: str, port: int = DEFAULT_PORT) -> dict:
    me = identity(); all_peers = peers().get("peers", {}); peer_data = all_peers.get(address, {})
    if not peer_data:
        peer_data = next((item for item in all_peers.values() if item.get("node_id") == address), {})
    if not peer_data: raise PairingError("peer is not trusted")
    target = peer_data.get("address") or address
    context = _client_context(); started = time.monotonic()
    with socket.create_connection((target, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            request = _envelope("PING", me, {"public_key": me.public_key})
            request_id = request["request_id"]
            _send(sock, request)
            reply = _recv(sock)
            signed = {k: reply[k] for k in reply if k != "signature"}
            payload = reply.get("payload", {})
            if (reply["type"] != "PONG" or reply.get("sender_node_id") != peer_data.get("node_id")
                    or payload.get("request_id") != request_id
                    or not _fresh(reply) or not _verify(peer_data.get("public_key", ""), signed, reply.get("signature", ""))):
                raise PairingError("invalid pong")
    return {"node_id": peer_data.get("node_id", address), "trust": "VERIFIED", "transport": "READY", "protocol": VERSION, "latency_ms": int((time.monotonic() - started) * 1000)}


def unpair(node_id: str) -> bool:
    data = peers(); existed = node_id in data.get("peers", {})
    data.get("peers", {}).pop(node_id, None); _save_peers(data); return existed
