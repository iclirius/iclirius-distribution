from __future__ import annotations

import argparse
import json
import getpass

from app.node_snapshot import collect, render
from app.doctor import collect as collect_doctor
from app.node_capability_profile import build_node_capability_profile, render as render_capabilities
from app.node_pairing import NodeListener, PairingError, pair, peers, ping, unpair


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius node")
    parser.add_argument("command", nargs="?", choices=("status", "capabilities", "listen", "pair", "peers", "peer", "ping", "unpair"), default="status")
    parser.add_argument("target", nargs="?")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--deep", action="store_true",
                        help="run the existing bounded probes before building capabilities")
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18890)
    parser.add_argument("--code", default="")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args(argv or [])
    if args.command == "listen":
        try:
            listener = NodeListener(bind=args.bind, port=args.port, code=args.code or None)
            print(f"Node: {listener.identity.node_id}")
            print(f"Fingerprint: {listener.identity.fingerprint}")
            listener.serve(once=args.once)
            return 0
        except (PairingError, OSError, ValueError) as exc:
            print(f"Node listener failed: {exc}")
            return 1
    if args.command == "pair":
        if not args.target:
            parser.error("node pair requires an address")
        code = args.code or getpass.getpass("Pairing code: ").strip()
        try:
            result = pair(args.target, args.port, code)
            print(json.dumps(result, indent=2, sort_keys=True) if args.json else f"Paired and trusted: {result['node_id']} ({result['fingerprint']})")
            return 0
        except (PairingError, OSError, ValueError) as exc:
            print(f"Pairing failed: {exc}")
            return 1
    if args.command == "peers":
        data = peers()
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else "\n".join(["TRUSTED PEERS"] + [f"  {p['node_id']}  {p.get('trust')}  {p.get('address', '')}" for p in data.get('peers', {}).values()]) if data.get('peers') else "TRUSTED PEERS\n  None")
        return 0
    if args.command == "peer":
        if not args.target: parser.error("node peer requires a node_id")
        data = peers().get("peers", {}).get(args.target)
        if not data: print("Peer not found"); return 1
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else "\n".join(f"{k}: {v}" for k, v in data.items()))
        return 0
    if args.command == "unpair":
        if not args.target: parser.error("node unpair requires a node_id")
        removed = unpair(args.target)
        print("Peer unpaired" if removed else "Peer not found")
        return 0 if removed else 1
    if args.command == "ping":
        if not args.target: parser.error("node ping requires a node_id")
        try:
            result = ping(args.target, args.port)
            print(json.dumps(result, indent=2, sort_keys=True) if args.json else f"Peer: {result['node_id']}\nTrust: {result['trust']}\nTransport: {result['transport']}\nLatency: {result['latency_ms']} ms\nProtocol: v{result['protocol']}")
            return 0
        except (PairingError, OSError, ValueError) as exc:
            print(f"Ping failed: {exc}")
            return 1
    if args.command == "capabilities":
        evidence = collect_doctor()
        if args.deep:
            from app.deep_diagnostics import run as run_deep
            deep = run_deep(evidence)
            evidence["deep_diagnostics"] = {key: value for key, value in deep.items()
                                            if key != "capability_audit"}
            evidence["capability_audit"] = deep["capability_audit"]
        profile = build_node_capability_profile(evidence)
        print(json.dumps(profile, ensure_ascii=False, indent=2, sort_keys=True)
              if args.json else render_capabilities(profile))
    else:
        snapshot = collect()
        print(json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True)
              if args.json else render(snapshot))
    return 0
