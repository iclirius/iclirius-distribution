# Changelog

## 1.0.0-rc.2

- Adds Doctor deep diagnostics, NodeCapabilityProfile, explicit node repair
  planning/execution, and secure Ed25519/TLS node pairing with authenticated
  ping/pong. Real two-Mac pairing and remote work remain future validation and
  feature phases.

## Unreleased

- Local identity authentication for interactive sessions: macOS Touch ID with
  a machine-local scrypt recovery passphrase, safe auth status, and no changes
  to Fernet Memory Core encryption or Telegram authentication.
- Canonical local `NodeSnapshot`, `iclirius node status`, bounded resource and
  Ollama probes, Memory Core revision metadata, and a small responsive TUI
  status panel.
- Standalone Python packaging, console entrypoint, release-archive builder and
  local Homebrew formula prototype; no public release or tap published.
- Private-source `v1.0.0-rc.1` release candidate published with a verified
  artifact SHA-256.
- Public distribution-only repository and Homebrew tap published for the
  audited RC artifact; source remains private.
- Phase 5.4 existing-identity enrollment foundation: versioned authenticated
  enrollment envelope, real Memory Core validation, local Keychain
  provisioning, and new-node setup flow. Real Mac 1 preparation and Mac 2
  acceptance remain pending.
- Guided local Ollama onboarding in `iclirius setup`: runtime/model detection,
  explicit install/start/pull choices, alternative model selection and
  continue-without-local-AI behavior. Homebrew installation remains
  non-interactive.
- Phase 5.4b capability audit: versioned structured Doctor results with
  required/optional/degraded/blocked/untested semantics, conservative system,
  memory, local-AI, tool, network, remote-access and voice observations, and
  backward-compatible JSON output. Deep diagnostics remain future work.
- Phase 5.4d node capability profiles: structured operational eligibility,
  evidence levels, role-specific blockers and safe `node capabilities` JSON.
  Distributed role assignment and node communication remain future work.
- Phase 5.5a secure node pairing foundation: machine-local Ed25519 node
  identities, ephemeral TLS transport, explicit one-use pairing codes,
  trusted-peer storage, authenticated ping/pong, and local unpair/revocation.
  Remote execution, capability exchange, and real two-Mac acceptance remain
  future work.
- Phase 5.4e node repair/bootstrap: role-aware dry-run plans, explicit approval
  for package/model changes, safe local identity initialization, typed executor
  actions, and post-repair Doctor verification. Restricted capabilities remain
  manual or policy-blocked.

- CLI interactiva limpia: logs operativos permanecen en archivo y se muestran
  explícitamente con `--debug`.
- Clasificación de tareas locales y awareness de capacidades del nodo sin
  relajar sandboxing ni permisos.
- Entradas vacías o secuencias de terminal no generan turnos ni llamadas al
  modelo.
- Capa visual ligera para el chat CLI: header runtime, color TTY opcional,
  indicador de trabajo y señales breves de lectura/fallback.
- Instalador reproducible para macOS (`install.sh`), diagnóstico read-only
  (`iclirius doctor --json`) y desinstalación que preserva datos de usuario.
- `iclirius setup` para identidad humana, Memory Home versionado, bootstrap
  local de Keychain y migración cifrada sin borrar el estado anterior.
- Phase 5 hardening: setup reuses an existing Memory Home user ID, validates
  its complete structure, avoids duplicating the legacy encrypted core, rejects
  unsafe symlinks/overlapping paths, and keeps session node metadata stable.
- Chat TUI mínima basada en Textual: alternate screen, historial desplazable,
  composer multilinea con pegado seguro, worker para generación local y
  fallback `iclirius --plain`.

## 1.0.0-rc.1

- Canonical Iclirius identity shared by Telegram and the interactive CLI.
- Encrypted Memory Core with shared Project and Task continuity.
- Task Engine, Context Engine and ReasoningGateway boundaries.
- Local Ollama reasoning as the default.
- Optional Gemini provider, account pool and durable budget governor.
- Safe Web, READ, WRITE and EXECUTE flows with verification.
- Telegram interface with local TTS/STT voice support.
- Lightweight interactive CLI and shared RuntimeSnapshot/StatusView observability.

### Known limitations

- Real Gemini generation smoke is pending explicit credentials and model configuration.
- No cloud provider other than Gemini is implemented.
- AUTO, DEEP and COUNCIL routing modes are not implemented.
- Multi-node orchestration is not production-ready.
- TTS and STT are local; no cloud voice provider exists.
- Nine legacy files under `data/audio` are preserved intentionally because deletion was prohibited.
- `app/pending_scan.py` remains an untracked historical file intentionally.
