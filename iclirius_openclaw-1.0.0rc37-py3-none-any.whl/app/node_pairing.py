"""Minimal authenticated node pairing and ping transport for Phase 5.5a."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import socket
import ssl
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
from cryptography.x509.oid import NameOID

from app.config import settings
from app.node_identity import ensure_node, read_node
from app.secure_storage import KeychainMaterialMissing, SecureStorageError, load_node_identity_key, store_node_identity_key

PROTOCOL = "iclirius-node"
VERSION = 1
MAX_MESSAGE = 16 * 1024
PAIR_TTL = 300
DEFAULT_PORT = 18890
DEFAULT_BIND = "0.0.0.0"
PEERS_FILE = "peers.json"


class PairingError(RuntimeError):
    pass


@dataclass
class NodeIdentity:
    node_id: str
    public_key: str
    private_key: ed25519.Ed25519PrivateKey

    @property
    def fingerprint(self) -> str:
        return hashlib.sha256(base64.b64decode(self.public_key)).hexdigest()[:16]


def _node_id() -> str:
    return str((read_node() or ensure_node()).get("node_id") or settings.node_id)


def identity() -> NodeIdentity:
    node_id = _node_id()
    try:
        raw = load_node_identity_key(node_id)
        private = ed25519.Ed25519PrivateKey.from_private_bytes(base64.b64decode(raw))
    except KeychainMaterialMissing:
        private = ed25519.Ed25519PrivateKey.generate()
        raw = base64.b64encode(private.private_bytes(serialization.Encoding.Raw,
                    serialization.PrivateFormat.Raw, serialization.NoEncryption())).decode()
        store_node_identity_key(node_id, raw)
    except (SecureStorageError, ValueError, TypeError) as exc:
        raise PairingError("node identity unavailable") from exc
    public = private.public_key().public_bytes(serialization.Encoding.Raw,
                                               serialization.PublicFormat.Raw)
    return NodeIdentity(node_id, base64.b64encode(public).decode(), private)


def _peers_path() -> Path:
    return Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser() / PEERS_FILE


def peers() -> dict:
    try:
        data = json.loads(_peers_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"schema_version": 1, "peers": {}}
    except (OSError, ValueError):
        return {"schema_version": 1, "peers": {}}


def _save_peers(data: dict) -> None:
    path = _peers_path(); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)


def _record(peer: dict, address: str = "") -> None:
    data = peers(); data.setdefault("schema_version", 1); data.setdefault("peers", {})
    peer = dict(peer); peer["address"] = address or peer.get("address", "")
    data["peers"][peer["node_id"]] = peer; _save_peers(data)


def _cluster_peer_trusted(peer_id: str, peer: dict) -> bool:
    """Require the CLUSTER-2 registry when it exists; legacy state is not authority."""
    try:
        from app.cluster_security import read_registry
        registry = read_registry(_peers_path().parent)
        item = registry.get("peers", {}).get(peer_id, {})
        return (item.get("trust_state") == "TRUSTED"
                and item.get("public_key") == peer.get("public_key"))
    except Exception:
        return False


def _sign(identity_obj: NodeIdentity, payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return base64.b64encode(identity_obj.private_key.sign(raw)).decode()


def _verify(public: str, payload: dict, signature: str) -> bool:
    try:
        key = ed25519.Ed25519PublicKey.from_public_bytes(base64.b64decode(public))
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        key.verify(base64.b64decode(signature), raw); return True
    except Exception:
        return False


def _cert_context(server=True):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "iclirius-node")])
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(datetime.now(timezone.utc))
            .not_valid_after(datetime.now(timezone.utc).replace(year=datetime.now(timezone.utc).year + 1))
            .sign(key, hashes.SHA256()))
    directory = tempfile.TemporaryDirectory(prefix="iclirius-node-tls-")
    cert_path, key_path = Path(directory.name) / "cert.pem", Path(directory.name) / "key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.load_cert_chain(certfile=cert_path, keyfile=key_path)
    return context, directory


def _client_context() -> ssl.SSLContext:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    # The certificate is ephemeral; application Ed25519 signatures pin the
    # node identity. TLS still provides confidentiality and integrity.
    context.check_hostname = False; context.verify_mode = ssl.CERT_NONE
    return context


def _send(sock: ssl.SSLSocket, message: dict) -> None:
    raw = json.dumps(message, separators=(",", ":")).encode()
    if len(raw) > MAX_MESSAGE: raise PairingError("message too large")
    sock.sendall(raw + b"\n")


def _recv(sock: ssl.SSLSocket) -> dict:
    data = bytearray()
    while len(data) <= MAX_MESSAGE:
        chunk = sock.recv(1)
        if not chunk: break
        if chunk == b"\n": break
        data.extend(chunk)
    if not data or len(data) > MAX_MESSAGE: raise PairingError("invalid or oversized message")
    value = json.loads(data.decode());
    if not isinstance(value, dict): raise PairingError("invalid message")
    if value.get("protocol") != PROTOCOL or value.get("version") != VERSION:
        raise PairingError("PROTOCOL_VERSION_UNSUPPORTED")
    if value.get("type") not in {"PAIR_INIT", "HELLO", "PING", "PONG", "CAPABILITIES_REQUEST", "CAPABILITIES_RESPONSE"}:
        raise PairingError("unknown message type")
    return value


def _envelope(kind: str, sender: NodeIdentity, payload: dict) -> dict:
    message_id = uuid.uuid4().hex
    body = {"protocol": PROTOCOL, "version": VERSION, "type": kind,
            "message_id": message_id, "request_id": message_id,
            "source_node_id": sender.node_id, "sender_node_id": sender.node_id,
            "destination_node_id": payload.get("destination_node_id", ""),
            "timestamp": int(time.time()), "nonce": secrets.token_urlsafe(16),
            "payload": payload}
    body["signature"] = _sign(sender, {k: body[k] for k in body if k != "signature"})
    return body


def _fresh(message: dict, window: int = 300) -> bool:
    return abs(int(time.time()) - int(message.get("timestamp", 0))) <= window


def resolve_lan_advertise_address(bind: str = DEFAULT_BIND) -> str:
    """Resolve a concrete IPv4 endpoint; wildcards are never advertised."""
    import ipaddress
    try:
        candidate = ipaddress.ip_address(bind)
        if candidate.version == 4 and not (candidate.is_unspecified or candidate.is_loopback):
            return str(candidate)
    except ValueError:
        pass
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("192.0.2.1", 9))
        address = probe.getsockname()[0]
        if not ipaddress.ip_address(address).is_loopback:
            return address
    except OSError:
        pass
    finally:
        probe.close()
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_STREAM):
            address = item[4][0]
            if not ipaddress.ip_address(address).is_loopback:
                return address
    except OSError:
        pass
    return ""


class NodeListener:
    def __init__(self, bind: str = DEFAULT_BIND, port: int = DEFAULT_PORT, code: str | None = None):
        self.bind, self.port, self.code = bind, port, code or f"{secrets.randbelow(1_000_000):06d}"
        self.advertise_address = resolve_lan_advertise_address(bind)
        self.identity = identity(); self._stop = threading.Event(); self._server = None; self._code_used = False
        self._enrolled_ids: set[str] = set()

    def serve(self, once: bool = False) -> None:
        context, temp = _cert_context(); self._temp = temp
        discovery_service = None
        try:
            from app.node_discovery import BonjourDiscovery, secure_advertisement, discovery_enabled
            from app.version import VERSION
            if discovery_enabled():
                discovery_service = BonjourDiscovery(
                    name=f"Iclirius-enroll-{self.identity.node_id[:12]}", port=self.port,
                    runtime_file="enrollment-discovery-runtime.json",
                    txt=secure_advertisement(node_id=self.identity.node_id,
                                             display_name=self.identity.node_id,
                                             fingerprint=self.identity.fingerprint,
                                             version=VERSION, port=self.port))
                discovery_service.start()
        except Exception:
            # LAN discovery is a convenience; the authenticated listener must
            # remain usable when Bonjour is unavailable or blocked.
            discovery_service = None
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM); server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind((self.bind, self.port)); server.listen(5); server.settimeout(1); self._server = server
        except Exception:
            if discovery_service:
                discovery_service.stop()
            temp.cleanup()
            raise
        print(f"Pairing code: {self.code}")
        try:
            while not self._stop.is_set():
                try: conn, address = server.accept()
                except socket.timeout: continue
                if once:
                    self._handle(context, conn, address)
                    break
                threading.Thread(target=self._handle, args=(context, conn, address), daemon=True).start()
        finally:
            server.close(); temp.cleanup()
            if discovery_service:
                discovery_service.stop()

    def stop(self):
        self._stop.set()
        if self._server:
            try: self._server.close()
            except OSError: pass

    def _handle(self, context, conn, address):
        try:
            with context.wrap_socket(conn, server_side=True) as sock:
                msg = _recv(sock)
                if msg["type"] == "PAIR_INIT":
                    payload = msg.get("payload", {})
                    enrollment = bool(payload.get("enrollment"))
                    # Legacy pairing is never an authority.  A network peer
                    # must use the signed enrollment ceremony and stop at
                    # CONFIRMATION_REQUIRED until a local operator confirms
                    # the verified fingerprint.  Keep parsing the message so
                    # callers receive the same closed failure, but do not
                    # validate a pairing code or mutate either trust store.
                    if not enrollment:
                        raise PairingError("legacy network pairing is disabled; enrollment is required")
                    from app.node_discovery import enrollment_is_open
                    if not _fresh(msg):
                        raise PairingError("pairing request expired")
                    if enrollment:
                        if not enrollment_is_open():
                            raise PairingError("enrollment window closed")
                        if payload.get("node_id") in self._enrolled_ids:
                            raise PairingError("enrollment request replayed")
                    peer = msg["payload"]; signed = {k: msg[k] for k in msg if k != "signature"}
                    if not _verify(peer["public_key"], signed, msg.get("signature", "")): raise PairingError("peer signature invalid")
                    existing = peers().get("peers", {}).get(peer.get("node_id"), {})
                    if existing and existing.get("public_key") != peer.get("public_key"):
                        raise PairingError("node identity fingerprint mismatch")
                    from app.cluster_security import record_verified_enrollment
                    verified_session = record_verified_enrollment(peer, address=str(address[0]))
                    print("REMOTE IDENTITY VERIFIED", flush=True)
                    print(json.dumps({"node_id": verified_session["node_id"],
                                      "public_key": verified_session["public_key"],
                                      "fingerprint": verified_session["fingerprint"],
                                      "proof": "VERIFIED",
                                      "trust_state": verified_session["state"],
                                      "session_id": verified_session["session_id"],
                                      "verification_code": verified_session["verification_code"],
                                      "expires_at": verified_session["expires_at"]},
                                     sort_keys=True), flush=True)
                    self._enrolled_ids.add(peer["node_id"])
                    reply_payload = {"public_key": self.identity.public_key,
                                     "trust": "CONFIRMATION_REQUIRED",
                                     "challenge": peer.get("challenge", "")}
                    reply_payload["enrollment_session"] = verified_session
                    reply = _envelope("HELLO", self.identity, reply_payload)
                    _send(sock, reply)
                elif msg["type"] in {"HELLO", "PING", "CAPABILITIES_REQUEST"}:
                    self._authenticated(sock, msg)
        except Exception:
            try: conn.close()
            except OSError: pass

    def _authenticated(self, sock, msg):
        peer_id = msg.get("sender_node_id"); peer = peers().get("peers", {}).get(peer_id, {})
        signed = {k: msg[k] for k in msg if k != "signature"}
        if (not peer or peer.get("trust") != "TRUSTED"
                or not _cluster_peer_trusted(peer_id, peer)
                or peer.get("public_key") != msg.get("payload", {}).get("public_key", peer.get("public_key"))
                or not _verify(peer.get("public_key", ""), signed, msg.get("signature", ""))
                or not _fresh(msg)):
            raise PairingError("peer not trusted")
        if msg["type"] == "PING":
            _send(sock, _envelope("PONG", self.identity, {"request_id": msg["request_id"]}))
        elif msg["type"] == "CAPABILITIES_REQUEST":
            from app.remote_capabilities import build_advertisement
            _send(sock, _envelope("CAPABILITIES_RESPONSE", self.identity,
                                  {"request_id": msg["request_id"], "advertisement": build_advertisement()}))


def _now() -> str: return datetime.now(timezone.utc).isoformat(timespec="seconds")


def pair(address: str, port: int = DEFAULT_PORT, code: str = "", *, enrollment: bool = False) -> dict:
    if not enrollment:
        raise PairingError("legacy trust-changing pairing is disabled; use enrollment=True")
    me = identity(); challenge = secrets.token_urlsafe(16)
    context = _client_context()
    with socket.create_connection((address, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            msg = _envelope("PAIR_INIT", me, {"code": code, "enrollment": enrollment,
                                               "node_id": me.node_id, "public_key": me.public_key,
                                               "challenge": challenge})
            _send(sock, msg); reply = _recv(sock)
            peer = reply.get("payload", {}); signed = {k: reply[k] for k in reply if k != "signature"}
            if reply["type"] != "HELLO" or not _fresh(reply) or not _verify(peer.get("public_key", ""), signed, reply.get("signature", "")):
                raise PairingError("peer handshake invalid")
            peer_id = reply["sender_node_id"]
            existing = peers().get("peers", {}).get(peer_id, {})
            if existing and existing.get("public_key") != peer.get("public_key"):
                raise PairingError("node identity fingerprint mismatch")
            from app.cluster_security import record_verified_enrollment
            session = record_verified_enrollment({"node_id": peer_id, "public_key": peer["public_key"]}, address=address)
            return {"node_id": peer_id, "fingerprint": session["fingerprint"],
                    "trust": "CONFIRMATION_REQUIRED", "enrollment_session": session,
                    "proof": "VERIFIED"}


def ping(address: str, port: int = DEFAULT_PORT) -> dict:
    me = identity(); all_peers = peers().get("peers", {}); peer_data = all_peers.get(address, {})
    if not peer_data:
        peer_data = next((item for item in all_peers.values() if item.get("node_id") == address), {})
    if not peer_data or not _cluster_peer_trusted(peer_data.get("node_id", address), peer_data):
        raise PairingError("peer is not trusted")
    target = peer_data.get("address") or address
    context = _client_context(); started = time.monotonic()
    with socket.create_connection((target, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            request = _envelope("PING", me, {"public_key": me.public_key})
            request_id = request["request_id"]
            _send(sock, request)
            reply = _recv(sock)
            signed = {k: reply[k] for k in reply if k != "signature"}
            payload = reply.get("payload", {})
            if (reply["type"] != "PONG" or reply.get("sender_node_id") != peer_data.get("node_id")
                    or payload.get("request_id") != request_id
                    or not _fresh(reply) or not _verify(peer_data.get("public_key", ""), signed, reply.get("signature", ""))):
                raise PairingError("invalid pong")
    return {"node_id": peer_data.get("node_id", address), "trust": "VERIFIED", "transport": "READY", "protocol": VERSION, "latency_ms": int((time.monotonic() - started) * 1000)}


def ping_endpoint(node_id: str, address: str, port: int = DEFAULT_PORT) -> dict:
    """Verify a newly discovered endpoint before replacing a trusted address."""
    peer_data = peers().get("peers", {}).get(node_id, {})
    if not peer_data or peer_data.get("trust") != "TRUSTED" or not _cluster_peer_trusted(node_id, peer_data):
        raise PairingError("peer is not trusted")
    me = identity(); context = _client_context(); started = time.monotonic()
    with socket.create_connection((address, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            request = _envelope("PING", me, {"public_key": me.public_key})
            _send(sock, request); reply = _recv(sock)
            signed = {k: reply[k] for k in reply if k != "signature"}
            payload = reply.get("payload", {})
            if (reply.get("type") != "PONG" or reply.get("sender_node_id") != node_id
                    or payload.get("request_id") != request["request_id"]
                    or not _fresh(reply)
                    or not _verify(peer_data.get("public_key", ""), signed, reply.get("signature", ""))):
                raise PairingError("endpoint identity verification failed")
    _record({**peer_data, "last_successful_handshake": _now()}, address)
    return {"node_id": node_id, "trust": "VERIFIED", "transport": "READY",
            "protocol": VERSION, "latency_ms": int((time.monotonic() - started) * 1000)}


def capabilities(address: str, port: int = DEFAULT_PORT) -> dict:
    """Fetch and cache a bounded capability profile from a trusted peer."""
    me = identity(); all_peers = peers().get("peers", {}); peer_data = all_peers.get(address, {})
    if not peer_data:
        peer_data = next((item for item in all_peers.values() if item.get("node_id") == address), {})
    if not peer_data or peer_data.get("trust") != "TRUSTED":
        raise PairingError("peer is not trusted")
    target = peer_data.get("address") or address; started = time.monotonic()
    context = _client_context()
    with socket.create_connection((target, port), timeout=8) as raw:
        with context.wrap_socket(raw, server_hostname="iclirius-node") as sock:
            request = _envelope("CAPABILITIES_REQUEST", me, {})
            try:
                _send(sock, request); reply = _recv(sock)
            except (PairingError, OSError):
                # An rc.3 peer does not know this message type. Preserve the
                # trusted transport and report capability discovery explicitly.
                return {"status": "UNSUPPORTED_BY_PEER", "node_id": peer_data.get("node_id"),
                        "trust": "VERIFIED", "transport": "READY", "protocol": VERSION}
            signed = {k: reply[k] for k in reply if k != "signature"}
            payload = reply.get("payload", {})
            if (reply.get("type") != "CAPABILITIES_RESPONSE"
                    or reply.get("sender_node_id") != peer_data.get("node_id")
                    or payload.get("request_id") != request["request_id"]
                    or not _fresh(reply)
                    or not _verify(peer_data.get("public_key", ""), signed, reply.get("signature", ""))):
                raise PairingError("invalid capability response")
            from app.remote_capabilities import cache_advertisement, validate_advertisement
            advertisement = validate_advertisement(payload.get("advertisement", {}))
            cache_advertisement(advertisement)
            result = dict(advertisement)
            result["transport_observation"] = {"status": "READY", "latency_ms": int((time.monotonic() - started) * 1000), "trust": "VERIFIED"}
            return result


def unpair(node_id: str) -> bool:
    data = peers(); existed = node_id in data.get("peers", {})
    data.get("peers", {}).pop(node_id, None); _save_peers(data); return existed
