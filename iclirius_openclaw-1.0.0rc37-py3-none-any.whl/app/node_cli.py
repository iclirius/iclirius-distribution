from __future__ import annotations

import argparse
import json
import getpass
import os
import signal
import subprocess
import sys
from pathlib import Path

from app.node_snapshot import collect, render
from app.doctor import collect as collect_doctor
from app.node_capability_profile import build_node_capability_profile, render as render_capabilities
from app.node_pairing import DEFAULT_BIND, NodeListener, PairingError, pair, peers, ping, unpair, capabilities
from app.secure_channel import SecureChannelError, SecureNodeClient, status as secure_status
from app.remote_capabilities import read_cached
from app.node_identity import node_role, set_node_role
from app.node_discovery import (enrollment_close, enrollment_open, discover,
                                enrollment_status, fingerprint_hint_matches, set_discovery_enabled,
                                status as discovery_status, refresh_trusted_endpoint,
                                verify_trusted_endpoint)
from app import cluster_security
from app import cluster_membership
from app import cluster_presence
from app import node_capabilities
from app import node_selection
from app import cluster_observability


def _service_pid_path() -> Path:
    return Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser() / "node-service.pid"


def _service_status() -> dict:
    path = _service_pid_path()
    try:
        pid = int(path.read_text(encoding="utf-8").strip())
        os.kill(pid, 0)
        return {"state": "RUNNING", "pid": pid}
    except (OSError, ValueError):
        path.unlink(missing_ok=True)
        return {"state": "STOPPED"}


def _service_start(bind: str, port: int) -> dict:
    current = _service_status()
    if current["state"] == "RUNNING":
        return current
    path = _service_pid_path(); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    process = subprocess.Popen([sys.executable, "-m", "app.node_service", "--bind", bind,
                                "--port", str(port)], stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               start_new_session=True)
    path.write_text(str(process.pid), encoding="utf-8"); os.chmod(path, 0o600)
    return {"state": "RUNNING", "pid": process.pid}


def _service_stop() -> dict:
    current = _service_status()
    if current["state"] == "RUNNING":
        try:
            os.kill(current["pid"], signal.SIGTERM)
        except OSError:
            pass
    _service_pid_path().unlink(missing_ok=True)
    return {"state": "STOPPED"}


def main(argv: list[str] | None = None) -> int:
    raw_args = list(argv or [])
    if "--help" in raw_args and raw_args and raw_args[0] in {
        "enrollment", "enroll", "confirm", "trust", "revoke", "secure-status", "ping"
    }:
        help_text = {
            "enrollment": "node enrollment open|close|cleanup [session_id] [--minutes N]",
            "enroll": "node enroll <node_id> [--plan] -- creates pending state only; proof is required",
            "confirm": "node confirm <session_id> --code CODE --fingerprint FINGERPRINT",
            "trust": "legacy disabled; use signed identity verification then node confirm",
            "revoke": "node revoke <node_id>",
            "secure-status": "node secure-status [--json]",
            "ping": "node ping <node_id> -- secure channel only after TRUSTED enrollment",
        }[raw_args[0]]
        print(help_text)
        return 0
    parser = argparse.ArgumentParser(prog="iclirius node")
    parser.add_argument("command", nargs="?", choices=("status", "nodes", "cluster-status", "members", "member-add", "member-remove", "member-enable", "member-disable", "member-status", "presence", "discover", "select", "secure", "secure-status", "enrollment-status", "enroll", "confirm", "trust", "revoke", "capabilities", "role", "listen", "pair", "peers", "peer", "ping", "unpair", "discovery", "enrollment", "service", "install", "start", "stop", "restart", "uninstall", "migrate", "run"), default="status")
    parser.add_argument("target", nargs="?")
    parser.add_argument("role_value", nargs="?")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--deep", action="store_true",
                        help="run the existing bounded probes before building capabilities")
    parser.add_argument("--bind", default=DEFAULT_BIND,
                        help="local node-to-node listen address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=18890)
    parser.add_argument("--code", default="")
    parser.add_argument("--fingerprint", default="")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--yes", action="store_true", help="confirm local membership removal")
    parser.add_argument("--minutes", type=int, default=10)
    parser.add_argument("--require", action="append", default=[],
                        help="capability requirement (repeatable; evaluates one node only)")
    parser.add_argument("--prefer", action="append", default=[],
                        help="preferred capability (repeatable; does not affect eligibility)")
    parser.add_argument("--locality", default="NEUTRAL", choices=("local", "remote", "neutral"))
    parser.add_argument("--preferred-node", default="")
    parser.add_argument("--presence-required", action="store_true")
    args = parser.parse_args(argv or [])
    if args.command == "secure-status":
        data = secure_status()
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) if args.json else
              f"SECURE CHANNEL\n  TLS         {data['tls']}\n  Protocol    v{data['protocol_version']}\n"
              f"  Port        {data['port']}\n  Identity    {data['identity_binding'].get('status')}\n"
              f"  Trusted     {data['trusted_peers']}\n  Revoked     {data['revoked_peers']}\n"
              "  Execution   disabled")
        return 0
    if args.command == "cluster-status":
        try:
            data = cluster_observability.build()
            if args.target:
                data["nodes"] = [item for item in data["nodes"] if item["node_id"] == args.target]
                if not data["nodes"]:
                    data = {"state": "UNKNOWN", "node_id": args.target, "nodes": []}
            print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
                  if args.json else cluster_observability.render(data))
            return 0 if data.get("state") != "UNKNOWN" else 1
        except (OSError, ValueError, TypeError, KeyError) as exc:
            print(json.dumps({"state": "UNKNOWN", "error": type(exc).__name__}, sort_keys=True)
                  if args.json else "CLUSTER\nUnavailable")
            return 1
    if args.command == "secure":
        from app import secure_channel, node_service
        if args.target in {"enable", "disable"}:
            secure_channel.configure(args.target == "enable")
            node_service.restart()
        data = secure_channel.status()
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) if args.json else
              f"SECURE CHANNEL\n  Configured  {data.get('configured_enabled')}\n"
              f"  Runtime     {data.get('runtime_enabled')}\n  Listener    {data.get('listener_state')}\n"
              f"  Bind        {data.get('bind')}\n  Port        {data.get('port')}\n  TLS         {data.get('tls')}\n"
              f"  Protocol    v{data.get('protocol_version')}\n  Identity    {data.get('identity_binding', {}).get('status')}")
        return 0
    if args.command == "nodes":
        data = cluster_security.nodes()
        if args.json:
            print(json.dumps({"nodes": data}, ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print("ICLIRIUS CLUSTER")
            for item in data:
                state = item.get("trust_state", "UNKNOWN")
                print(f"  {item.get('display_name') or item.get('node_id')}  {state}  {item.get('node_id')}")
        return 0
    if args.command in {"members", "member-status", "member-add", "member-remove", "member-enable", "member-disable"}:
        try:
            if args.command == "members":
                data = cluster_membership.list_members()
            elif args.command == "member-status":
                if not args.target:
                    parser.error("node member-status requires a node_id")
                data = cluster_membership.status(args.target)
            elif args.command == "member-add":
                if not args.target:
                    parser.error("node member-add requires a node_id")
                data = cluster_membership.add_member(args.target, role_policy=args.role_value or "")
            elif args.command == "member-remove":
                if not args.target:
                    parser.error("node member-remove requires a node_id")
                if not args.yes:
                    raise cluster_membership.MembershipError("CONFIRMATION_REQUIRED_USE_--YES")
                data = cluster_membership.remove_member(args.target)
            else:
                if not args.target:
                    parser.error(f"node {args.command} requires a node_id")
                data = cluster_membership.set_enabled(args.target, args.command == "member-enable")
            if args.json:
                print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
            elif isinstance(data, list):
                print("CLUSTER MEMBERS")
                for item in data:
                    print(f"  {item['node_id']}  {item['effective_state']}  {item['fingerprint']}")
            else:
                print(f"{data.get('result', data.get('effective_state', 'UNKNOWN'))}: {data.get('node_id', '')}")
            return 0
        except cluster_membership.MembershipError as exc:
            if args.json:
                print(json.dumps({"state": "FAILED", "error": str(exc)}, sort_keys=True))
            else:
                print(f"Membership failed: {exc}")
            return 1
    if args.command == "presence":
        try:
            data = (cluster_presence.probe(args.target) if args.target
                    else cluster_presence.list_presence(probe_now=True))
            if args.json:
                print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
            elif isinstance(data, list):
                print("NODE                         TRUSTED  MEMBER  PRESENCE")
                for item in data:
                    print(f"{item['node_id']:<28} yes      {item.get('membership_state', 'NOT_MEMBER'):<7} {item['presence_state']}")
            else:
                print(f"Node: {data['node_id']}\nPresence: {data['presence_state']}\n"
                      f"Authenticated: {'yes' if data.get('authenticated') else 'no'}\nReason: {data.get('reason', '')}")
            return 0
        except (OSError, ValueError, TypeError) as exc:
            print(f"Presence failed: {type(exc).__name__}")
            return 1
    if args.command == "select":
        try:
            requirements = {"required_capabilities": args.require,
                            "preferred_capabilities": args.prefer,
                            "locality": args.locality,
                            "preferred_node_id": args.preferred_node,
                            "presence_required": args.presence_required}
            result = node_selection.select(requirements=requirements)
            print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
                  if args.json else node_selection.render(result))
            return 0 if result["state"] == "SELECTED" else 1
        except (node_selection.SelectionError, OSError, ValueError, TypeError) as exc:
            print(json.dumps({"state": "FAILED", "error": str(exc)}, sort_keys=True) if args.json
                  else f"Selection failed: {exc}")
            return 1
    if args.command == "discover":
        found = discover()
        observed = []
        for item in found:
            try:
                entry = cluster_security.record_discovered(item.record, item.address)
                membership_item = next((member for member in cluster_membership.list_members()
                                        if member["node_id"] == entry["node_id"]), None)
                observed.append({**entry, "service_instance": item.name,
                                 "address_family": item.address_family,
                                 "correlation_status": item.record.get("correlation_status", "OBSERVED"),
                                 "membership_state": membership_item["effective_state"] if membership_item else "NOT_MEMBER"})
            except ValueError:
                continue
        data = {"state": "DISCOVERED", "count": len(observed), "nodes": observed}
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) if args.json else
              "DISCOVERED\n" + ("\n".join(f"  {item['node_id']}  {item.get('fingerprint', '')}" for item in observed)
                                  if observed else "  None"))
        return 0
    if args.command == "enrollment-status":
        data = cluster_security.status()
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True) if args.json else
              f"ENROLLMENT\n  Identity  {data['identity'].get('fingerprint', 'UNAVAILABLE')}\n"
              f"  Pending   {data['pending_enrollment']}\n  Trusted   {data['trusted']}\n  Revoked   {data['revoked']}\n"
              f"  Legacy    {len(data.get('legacy', []))}")
        return 0
    if args.command == "enroll":
        if not args.target:
            parser.error("node enroll requires a node_id")
        if args.plan:
            print(json.dumps({"state": "PLAN_ONLY", "node_id": args.target,
                              "message": "No session or persistent state was created."},
                             indent=2, sort_keys=True) if args.json else
                  f"PLAN ONLY\n  Node {args.target}\n  No enrollment state was changed.")
            return 0
        try:
            data = cluster_security.begin_enrollment(args.target)
        except (ValueError, RuntimeError) as exc:
            print(f"Enrollment failed: {exc}"); return 1
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              f"ENROLLMENT_PENDING\n  Node        {data['node_id']}\n  Session     {data['session_id']}\n"
              f"  Fingerprint {data.get('fingerprint') or 'compare with peer'}\n"
              f"  Code        {data['verification_code']}\n  Expires     {data['expires_at']}")
        return 0
    if args.command == "confirm":
        if not args.target or not args.code or not args.fingerprint:
            parser.error("node confirm requires session_id, --code and --fingerprint")
        try:
            data = cluster_security.confirm_enrollment(args.target, args.code,
                                                       fingerprint_value=args.fingerprint)
        except (ValueError, RuntimeError) as exc:
            print(f"Trust confirmation failed: {exc}"); return 1
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              f"TRUSTED\n  Node        {data['node_id']}\n  Fingerprint {data['fingerprint']}")
        return 0
    if args.command == "trust":
        print("Trust command is legacy and disabled; use node confirm after signed identity verification.")
        return 1
    if args.command == "revoke":
        if not args.target:
            parser.error("node revoke requires a node_id")
        changed = cluster_security.revoke(args.target)
        print("REVOKED" if changed else "Peer not found")
        return 0 if changed else 1
    if args.command == "migrate":
        from app.node_service import migration_plan
        print(json.dumps(migration_plan(), indent=2, sort_keys=True))
        return 0
    if args.command in {"install", "start", "stop", "restart", "uninstall"}:
        from app import node_service
        operation = getattr(node_service, args.command)
        data = operation()
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              f"Node service: {data.get('state', 'UNKNOWN')}")
        return 0 if data.get("state") not in {"FAILED", "NOT_INSTALLED"} else 1
    if args.command == "run":
        from app.node_runtime import main as run_node
        return run_node()
    if args.command == "service":
        if args.target == "start":
            data = _service_start(args.bind, args.port)
        elif args.target == "stop":
            data = _service_stop()
        else:
            data = _service_status()
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else f"Node service: {data['state']}" + (f" (pid {data['pid']})" if data.get("pid") else ""))
        return 0
    if args.command == "discovery":
        if args.target in {"on", "off"}:
            data = set_discovery_enabled(args.target == "on")
            data = {**discovery_status(), **data}
        else:
            data = discovery_status()
        found = discover() if data.get("enabled") else []
        data["found"] = [{"name": node.name, "address": node.address, "port": node.port,
                          "enrollment": node.record.get("enrollment"), "trusted": node.trusted}
                         for node in found]
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              f"LOCAL DISCOVERY\n  Status: {'ON' if data.get('enabled') else 'OFF'}\n"
              f"  Service: {data.get('service')}\n  Available: {'YES' if data.get('available') else 'NO'}\n"
              + ("  FOUND\n" + "\n".join(f"    {item['name']}  {item['enrollment']}" for item in data['found'])
                 if data["found"] else "  FOUND\n    None"))
        return 0
    if args.command == "enrollment":
        try:
            if args.target == "open":
                data = enrollment_open(args.minutes)
            elif args.target == "close":
                data = enrollment_close()
            elif args.target == "cleanup":
                from app.cluster_security import cleanup_enrollment
                data = cleanup_enrollment(args.role_value or "")
            else:
                data = enrollment_status()
        except ValueError as exc:
            print(str(exc)); return 2
        if args.target == "open":
            try:
                local = cluster_security.local_identity()
                data = {**data, "node_id": local["node_id"], "fingerprint": local["fingerprint"]}
            except Exception:
                data = {**data, "node_id": "unavailable", "fingerprint": "unavailable"}
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              f"LOCAL NODE ENROLLMENT\n  Status: {data['state']}\n"
              f"  Expires: {data.get('expires_at') or '-'}\n"
              f"  Node: {data.get('node_id', 'unavailable')}\n"
              f"  Fingerprint: {data.get('fingerprint', 'unavailable')}")
        return 0
    if args.command == "role":
        requested = args.role_value if args.target == "set" else args.target
        if requested:
            try:
                data = set_node_role(requested)
            except ValueError as exc:
                print(str(exc)); return 2
        else:
            data = {"role": node_role()}
        print(json.dumps(data, sort_keys=True) if args.json else f"Role: {data.get('role', node_role())}")
        return 0
    if args.command == "listen":
        try:
            listener = NodeListener(bind=args.bind, port=args.port, code=args.code or None)
            print(f"Node: {listener.identity.node_id}")
            print(f"Fingerprint: {listener.identity.fingerprint}")
            try:
                listener.serve(once=args.once)
            except KeyboardInterrupt:
                listener.stop()
                print("Node listener stopped.")
            return 0
        except (PairingError, OSError, ValueError) as exc:
            print(f"Node listener failed: {exc}")
            return 1
    if args.command == "pair":
        if not args.target:
            parser.error("node pair requires an address")
        code = args.code or getpass.getpass("Pairing code: ").strip()
        try:
            # CLI pairing is the explicit CLUSTER-2 ceremony and therefore
            # requires the peer's bounded enrollment window.  The lower-level
            # legacy API remains available only for compatibility tests.
            result = pair(args.target, args.port, code, enrollment=True)
            print(json.dumps(result, indent=2, sort_keys=True) if args.json else
                  f"Remote identity verified: {result['node_id']} ({result['fingerprint']})\n"
                  f"Trust state: {result['trust']}\n"
                  "No trust was written; confirm the displayed fingerprint explicitly.")
            return 0
        except (PairingError, OSError, ValueError) as exc:
            print(f"Pairing failed: {exc}")
            return 1
    if args.command == "peers":
        data = peers()
        enriched = []
        for peer in data.get("peers", {}).values():
            item = dict(peer); cached = read_cached(item.get("node_id", ""))
            if cached:
                freshness = cached["freshness"].get("status", "UNKNOWN")
                item.update({"role": cached["node"].get("role"), "health": cached["node"].get("health"),
                             "state": cached["node"].get("state") if freshness == "FRESH" else "OFFLINE",
                             "capabilities": freshness})
            enriched.append(item)
        data = {**data, "peers": {p["node_id"]: p for p in enriched}}
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else "\n".join(["TRUSTED PEERS"] + [f"  {p['node_id']}  {p.get('trust')}  {p.get('transport', 'UNKNOWN')}  {p.get('role', 'UNKNOWN')}  {p.get('health', 'UNKNOWN')}  {p.get('capabilities', 'UNKNOWN')}" for p in enriched]) if enriched else "TRUSTED PEERS\n  None")
        return 0
    if args.command == "peer":
        if not args.target: parser.error("node peer requires a node_id")
        data = peers().get("peers", {}).get(args.target)
        if not data: print("Peer not found"); return 1
        if args.refresh:
            try:
                capabilities(args.target, args.port)
            except (PairingError, OSError, ValueError) as exc:
                print(f"Capability refresh failed: {exc}"); return 1
            data = peers().get("peers", {}).get(args.target, data)
        cached = read_cached(data.get("node_id", args.target))
        if cached:
            data = {**data, "capabilities": cached}
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else "\n".join(f"{k}: {v}" for k, v in data.items()))
        return 0
    if args.command == "unpair":
        if not args.target: parser.error("node unpair requires a node_id")
        removed = unpair(args.target)
        print("Peer unpaired" if removed else "Peer not found")
        return 0 if removed else 1
    if args.command == "ping":
        if not args.target: parser.error("node ping requires a node_id")
        failure = {"cached_endpoint_failed": False, "discovery_used": False,
                   "candidate_count": 0, "error_category": ""}
        try:
            # The authoritative CLUSTER-2 registry carries the verified endpoint.
            # peers.json is legacy compatibility data and must not authorize a peer.
            peer = cluster_security.read_registry().get("peers", {}).get(args.target, {})
            address = peer.get("address") or args.target
            # Secure ping defaults to the CLUSTER-3 port.  A stale trusted
            # endpoint is recovered only through authenticated discovery.
            from app.secure_channel import DEFAULT_SECURE_PORT
            port = DEFAULT_SECURE_PORT if args.port == 18890 else args.port
            refreshed = False; previous_endpoint = address; discovery_used = False
            try:
                result = SecureNodeClient().ping(address, port, args.target)
            except (SecureChannelError, PairingError, OSError, ValueError) as first_error:
                failure["cached_endpoint_failed"] = True
                discovery_used = True
                failure["discovery_used"] = True
                candidates = [item for item in discover(timeout=2.0)
                              if item.record.get("node_id") == args.target]
                expected_fp = peer.get("fingerprint", "")
                candidates = [item for item in candidates
                              if (not item.record.get("identity_fingerprint")
                                  or fingerprint_hint_matches(item.record.get("identity_fingerprint"), expected_fp))]
                candidates = [item for item in candidates
                              if item.record.get("correlation_status") != "CONFLICT"]
                failure["candidate_count"] = len(candidates)
                unique = {(item.address, int(item.port)) : item for item in candidates}
                if not unique or len(unique) > 8:
                    failure["error_category"] = ("DISCOVERY_NO_TRUSTED_CANDIDATE"
                                                  if not unique else "DISCOVERY_AMBIGUOUS")
                    raise first_error
                verified = []
                for item in unique.values():
                    try:
                        verified.append((item, verify_trusted_endpoint(args.target, item)))
                    except (SecureChannelError, PairingError, OSError, ValueError):
                        continue
                if len(verified) != 1:
                    failure["error_category"] = ("DISCOVERY_IDENTITY_VERIFICATION_FAILED"
                                                  if verified else "DISCOVERY_NO_TRUSTED_CANDIDATE")
                    raise first_error
                item, refreshed_result = verified[0]
                from app.cluster_security import update_trusted_endpoint
                update_trusted_endpoint(args.target, item.address)
                result = refreshed_result
                result.update({"endpoint": item.address, "port": int(item.port),
                               "endpoint_refreshed": True, "previous_endpoint": previous_endpoint,
                               "discovery_used": True, "identity_verified": True})
                refreshed = True
                failure["error_category"] = ""
            result.setdefault("endpoint", address); result.setdefault("port", port)
            result.setdefault("endpoint_refreshed", refreshed)
            result.setdefault("previous_endpoint", previous_endpoint)
            result.setdefault("discovery_used", discovery_used)
            result.setdefault("identity_verified", True)
            print(json.dumps(result, indent=2, sort_keys=True) if args.json else
                  f"Peer: {result['node_id']}\nState: {result['state']}\n"
                  f"Encrypted: {'yes' if result['encrypted'] else 'no'}\n"
                  f"Fingerprint: {result['fingerprint']}\nProtocol: v{result['protocol_version']}")
            return 0
        except (SecureChannelError, PairingError, OSError, ValueError) as exc:
            if not failure["error_category"]:
                failure["error_category"] = ("CACHED_ENDPOINT_FAILED"
                                               if not failure["discovery_used"]
                                               else "DISCOVERY_FAILED")
            diagnostic = {"state": "FAILED", "error": "Ping failed",
                          "node_id": args.target,
                          "endpoint": address, **failure}
            print(json.dumps(diagnostic, indent=2, sort_keys=True) if args.json
                  else f"Ping failed: {failure['error_category']} ({address}:{port})")
            return 1
    if args.command == "capabilities":
        try:
            evidence = collect_doctor()
            if args.deep:
                from app.deep_diagnostics import run as run_deep
                deep = run_deep(evidence)
                evidence["deep_diagnostics"] = {key: value for key, value in deep.items()
                                                if key != "capability_audit"}
                evidence["capability_audit"] = deep["capability_audit"]
            import app.node_identity as _node_identity
            target = args.target or (_node_identity.read_node() or {}).get("node_id", "")
            registry = node_capabilities.capabilities_for(
                target, doctor_report=evidence) if target else node_capabilities.local_registry(doctor_report=evidence)
            result = (node_capabilities.evaluate_requirements(
                target, args.require) if args.require else registry)
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            else:
                print(f"NODE: {result.get('node_id', target)}")
                print(f"ROLE: {result.get('role', 'UNKNOWN')}")
                if "eligible" in result:
                    print(f"ELIGIBLE: {'yes' if result['eligible'] else 'no'}")
                    print(f"MISSING: {', '.join(result['missing']) or 'none'}")
                    print(f"UNAVAILABLE: {', '.join(result['unavailable']) or 'none'}")
                print("CAPABILITY                         AVAILABILITY")
                for item in result.get("capabilities", []):
                    print(f"{item['capability_id']:<35} {item['availability']}")
            return 0
        except (node_capabilities.CapabilityError, OSError, ValueError, TypeError) as exc:
            print(json.dumps({"state": "FAILED", "error": str(exc)}, sort_keys=True) if args.json
                  else f"Capabilities failed: {exc}")
            return 1
    else:
        snapshot = collect()
        print(json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True)
              if args.json else render(snapshot))
    return 0
