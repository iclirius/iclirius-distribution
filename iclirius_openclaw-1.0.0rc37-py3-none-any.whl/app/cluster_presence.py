"""Explicit authenticated presence observations for CLUSTER-4.3.

Presence is local evidence only.  It never creates trust or membership and it
never treats Bonjour or TCP reachability as proof of an Iclirius runtime.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from app import cluster_membership, cluster_security
from app.node_discovery import DiscoveredNode, discover, fingerprint_hint_matches, verify_trusted_endpoint
from app.secure_channel import SecureChannelError, SecureNodeClient

PRESENCE_FILE = "cluster-presence.json"
SCHEMA_VERSION = 1
ONLINE = "ONLINE"
STALE = "STALE"
OFFLINE = "OFFLINE"
UNKNOWN = "UNKNOWN"
MAX_NODES = 128
MAX_CANDIDATES = 8
PROBE_TIMEOUT = 5.0
FRESHNESS_TTL = 60.0
OFFLINE_FAILURES = 3


def _root(state_root=None) -> Path:
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def _path(state_root=None) -> Path:
    return _root(state_root) / PRESENCE_FILE


def _read(state_root=None) -> dict:
    try:
        value = json.loads(_path(state_root).read_text(encoding="utf-8"))
        if isinstance(value, dict) and value.get("schema_version") == SCHEMA_VERSION:
            return value
    except (OSError, ValueError, TypeError):
        pass
    return {"schema_version": SCHEMA_VERSION, "observations": {}}


def _write(value: dict, state_root=None) -> None:
    root = _root(state_root); root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = _path(state_root); tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)


def _effective(record: dict, now: float | None = None) -> dict:
    # Persisted observations cross process boundaries.  A monotonic timestamp
    # is process-local and cannot be compared after a TUI/CLI restart; the
    # persisted wall-clock observation is the shared freshness authority.
    now = time.time() if now is None else now
    state = record.get("presence_state", UNKNOWN)
    success = float(record.get("last_authenticated_success", 0) or 0)
    if state == ONLINE and (not success or now - success > FRESHNESS_TTL):
        state = STALE
    return {**record, "presence_state": state}


def _base(node_id: str, *, membership_state: str = "NOT_MEMBER") -> dict:
    return {"node_id": node_id, "presence_state": UNKNOWN,
            "last_authenticated_success": None, "last_probe_attempt": None,
            "last_authenticated_success_monotonic": 0.0,
            "consecutive_failures": 0, "reason": "NEVER_PROBED",
            "endpoint_used": "", "authenticated": False,
            "membership_state": membership_state}


def _membership_states(state_root=None) -> dict[str, str]:
    try:
        return {item["node_id"]: item["effective_state"]
                for item in cluster_membership.list_members(state_root)}
    except cluster_membership.MembershipError:
        return {}


def _trusted_nodes(state_root=None) -> list[dict]:
    registry = cluster_security.read_registry(state_root)
    peers = registry.get("peers", {})
    return [peer for peer in peers.values()
            if peer.get("trust_state") == cluster_security.TRUSTED][:MAX_NODES]


def _candidates(node_id: str, fingerprint: str, state_root=None) -> list[DiscoveredNode]:
    result = []
    for item in discover(timeout=2.0):
        if item.record.get("node_id") != node_id:
            continue
        if item.record.get("correlation_status") == "CONFLICT":
            continue
        hint = item.record.get("identity_fingerprint") or item.record.get("node_hint", "")
        if hint and not fingerprint_hint_matches(hint, fingerprint):
            continue
        result.append(item)
    unique = {(item.address, int(item.port)): item for item in result}
    return [unique[key] for key in sorted(unique)][:MAX_CANDIDATES]


def _probe(peer: dict, state_root=None) -> tuple[bool, str, str]:
    node_id = peer["node_id"]; fingerprint = peer.get("fingerprint", "")
    address = peer.get("address", ""); port = 18891
    if address:
        try:
            result = SecureNodeClient(state_root=state_root, timeout=PROBE_TIMEOUT).ping(address, port, node_id)
            if result.get("fingerprint") != fingerprint:
                return False, "IDENTITY_VERIFICATION_FAILED", address
            return True, "AUTHENTICATED_PROBE", address
        except SecureChannelError as exc:
            reason = exc.code
        except (OSError, ValueError, TypeError, TimeoutError):
            reason = "TRANSPORT_FAILED"
    else:
        reason = "NO_CACHED_ENDPOINT"
    candidates = _candidates(node_id, fingerprint, state_root)
    verified = []
    for item in candidates:
        try:
            verified.append((item, verify_trusted_endpoint(node_id, item, state_root=state_root)))
        except (SecureChannelError, OSError, ValueError, TypeError):
            continue
    if len(verified) != 1:
        if len(verified) > 1:
            reason = "AMBIGUOUS_CANDIDATES"
        elif candidates:
            reason = "IDENTITY_VERIFICATION_FAILED"
        return False, reason, address
    item, _result = verified[0]
    from app.cluster_security import update_trusted_endpoint
    update_trusted_endpoint(node_id, item.address, state_root=state_root)
    return True, "AUTHENTICATED_ENDPOINT_REFRESH", item.address


def probe(node_id: str, *, state_root=None) -> dict:
    peers = {peer.get("node_id"): peer for peer in _trusted_nodes(state_root)}
    peer = peers.get(node_id)
    if not peer:
        return {**_base(node_id), "presence_state": UNKNOWN, "reason": "NOT_TRUSTED"}
    now_wall = int(time.time()); now_mono = time.monotonic()
    old = _read(state_root).get("observations", {}).get(node_id, _base(node_id))
    result = dict(old); result.update({"node_id": node_id, "last_probe_attempt": now_wall})
    ok, reason, endpoint = _probe(peer, state_root)
    if ok:
        result.update({"presence_state": ONLINE, "last_authenticated_success": now_wall,
                       "last_authenticated_success_monotonic": now_mono,
                       "consecutive_failures": 0, "reason": reason,
                       "endpoint_used": endpoint, "authenticated": True})
    else:
        failures = int(result.get("consecutive_failures", 0) or 0) + 1
        result.update({"consecutive_failures": failures, "reason": reason,
                       "endpoint_used": endpoint, "authenticated": False})
        if reason in {"IDENTITY_VERIFICATION_FAILED", "AMBIGUOUS_CANDIDATES"}:
            result["presence_state"] = UNKNOWN
        elif failures >= OFFLINE_FAILURES:
            result["presence_state"] = OFFLINE
        else:
            result["presence_state"] = STALE if result.get("last_authenticated_success") else UNKNOWN
    data = _read(state_root); data.setdefault("observations", {})[node_id] = result; _write(data, state_root)
    return {**result, "membership_state": _membership_states(state_root).get(node_id, "NOT_MEMBER")}


def list_presence(*, state_root=None, probe_now: bool = True) -> list[dict]:
    membership = _membership_states(state_root)
    peers = _trusted_nodes(state_root)
    stored = _read(state_root).get("observations", {})
    result = []
    for peer in sorted(peers, key=lambda item: str(item.get("node_id", "")))[:MAX_NODES]:
        node_id = peer["node_id"]
        if probe_now:
            item = probe(node_id, state_root=state_root)
        else:
            prior = {**_base(node_id, membership_state=membership.get(node_id, "NOT_MEMBER")),
                     **stored.get(node_id, {})}
            item = _effective(prior)
        result.append({**item, "membership_state": membership.get(node_id, "NOT_MEMBER")})
    return result
