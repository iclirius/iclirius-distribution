"""Bounded local membership policy for CLUSTER-4.1.

Membership records participation intent only.  ``cluster-trust.json`` remains
the sole authority for node keys, fingerprints, trust and revocation.
"""
from __future__ import annotations

import fcntl
import json
import os
import re
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from app import cluster_security

MEMBERSHIP_FILE = "cluster-membership.json"
SCHEMA_VERSION = 1
MAX_MEMBERS = 1024
MAX_NODE_ID = 128
MAX_ROLE = 32
MEMBER = "MEMBER"
DISABLED = "DISABLED"
INVALID_TRUST = "INVALID_TRUST"
REVOKED = "REVOKED"


class MembershipError(ValueError):
    """A deterministic, operator-safe membership failure."""


def _root(state_root: str | Path | None = None) -> Path:
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def membership_path(state_root: str | Path | None = None) -> Path:
    return _root(state_root) / MEMBERSHIP_FILE


def _empty() -> dict:
    return {"schema_version": SCHEMA_VERSION, "generation": 0, "members": {}}


def _validate(value: object) -> dict:
    if not isinstance(value, dict) or value.get("schema_version") != SCHEMA_VERSION:
        raise MembershipError("UNSUPPORTED_MEMBERSHIP_SCHEMA")
    members = value.get("members")
    if not isinstance(members, dict) or len(members) > MAX_MEMBERS:
        raise MembershipError("MALFORMED_MEMBERSHIP")
    generation = value.get("generation", 0)
    if not isinstance(generation, int) or generation < 0:
        raise MembershipError("MALFORMED_MEMBERSHIP")
    clean = _empty(); clean["generation"] = generation
    for node_id, record in members.items():
        if not isinstance(node_id, str) or not node_id or len(node_id) > MAX_NODE_ID:
            raise MembershipError("MALFORMED_MEMBERSHIP")
        if not isinstance(record, dict) or record.get("node_id") != node_id:
            raise MembershipError("MALFORMED_MEMBERSHIP")
        fingerprint = str(record.get("fingerprint", ""))
        if not re.fullmatch(r"[0-9a-f]{4}(?::[0-9a-f]{4}){7}", fingerprint):
            raise MembershipError("MALFORMED_MEMBERSHIP")
        state = record.get("state")
        if state not in {MEMBER, DISABLED} or (state == MEMBER) != bool(record.get("enabled")):
            raise MembershipError("MALFORMED_MEMBERSHIP")
        if not isinstance(record.get("enabled"), bool):
            raise MembershipError("MALFORMED_MEMBERSHIP")
        role = str(record.get("role_policy", ""))
        if len(role) > MAX_ROLE:
            raise MembershipError("MALFORMED_MEMBERSHIP")
        try:
            added_at = int(record.get("added_at", 0) or 0)
            updated_at = int(record.get("updated_at", 0) or 0)
            trust_schema_version = int(record.get("trust_schema_version", 1) or 1)
        except (TypeError, ValueError) as exc:
            raise MembershipError("MALFORMED_MEMBERSHIP") from exc
        clean["members"][node_id] = {
            "node_id": node_id, "fingerprint": fingerprint,
            "enabled": bool(record["enabled"]), "state": state,
            "role_policy": role,
            "added_at": added_at, "updated_at": updated_at,
            "trust_schema_version": trust_schema_version,
        }
    return clean


def read_membership(state_root: str | Path | None = None) -> dict:
    path = membership_path(state_root)
    if not path.exists():
        return _empty()
    try:
        return _validate(json.loads(path.read_text(encoding="utf-8")))
    except MembershipError:
        raise
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise MembershipError("MALFORMED_MEMBERSHIP") from exc


def _write(value: dict, state_root: str | Path | None = None) -> None:
    path = membership_path(state_root); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(_validate(value), ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)


@contextmanager
def _locked(state_root: str | Path | None = None) -> Iterator[None]:
    root = _root(state_root); root.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock = (root / MEMBERSHIP_FILE).with_suffix(".lock")
    with lock.open("a+") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _authoritative(node_id: str, state_root: str | Path | None = None) -> tuple[dict, str]:
    registry = cluster_security.read_registry(state_root)
    peer = registry.get("peers", {}).get(node_id)
    if not isinstance(peer, dict):
        raise MembershipError("UNKNOWN_TRUST_IDENTITY")
    trust_state = peer.get("trust_state")
    if trust_state == cluster_security.REVOKED:
        raise MembershipError("REVOKED_TRUST_IDENTITY")
    if trust_state != cluster_security.TRUSTED:
        raise MembershipError("IDENTITY_NOT_TRUSTED")
    try:
        derived = cluster_security.fingerprint(str(peer.get("public_key", "")))
    except (ValueError, TypeError):
        raise MembershipError("INVALID_TRUST_IDENTITY")
    if derived != peer.get("fingerprint"):
        raise MembershipError("INVALID_TRUST_IDENTITY")
    return peer, derived


def _effective(record: dict, state_root: str | Path | None = None) -> tuple[str, dict]:
    try:
        peer, derived = _authoritative(record["node_id"], state_root)
    except MembershipError as exc:
        state = REVOKED if str(exc) == "REVOKED_TRUST_IDENTITY" else INVALID_TRUST
        return state, {"trust_state": "UNKNOWN", "reason": str(exc)}
    if derived != record["fingerprint"]:
        return INVALID_TRUST, {"trust_state": peer.get("trust_state"), "reason": "FINGERPRINT_MISMATCH"}
    if peer.get("trust_state") == cluster_security.REVOKED:
        return REVOKED, {"trust_state": peer.get("trust_state"), "reason": "REVOKED"}
    return (MEMBER if record["enabled"] and record["state"] == MEMBER else DISABLED), {
        "trust_state": peer.get("trust_state"), "reason": ""
    }


def list_members(state_root: str | Path | None = None) -> list[dict]:
    data = read_membership(state_root)
    result = []
    for node_id in sorted(data["members"]):
        record = dict(data["members"][node_id]); effective, trust = _effective(record, state_root)
        result.append({**record, "effective_state": effective, **trust})
    return result


def add_member(node_id: str, *, role_policy: str = "", state_root: str | Path | None = None) -> dict:
    node_id = str(node_id or "").strip()
    if not node_id:
        raise MembershipError("NODE_ID_REQUIRED")
    local = cluster_security.local_identity()["node_id"]
    if node_id == local:
        raise MembershipError("LOCAL_NODE_IS_IMPLICIT")
    _peer, fingerprint = _authoritative(node_id, state_root)
    if len(str(role_policy)) > MAX_ROLE:
        raise MembershipError("ROLE_POLICY_TOO_LONG")
    with _locked(state_root):
        data = read_membership(state_root)
        previous = data["members"].get(node_id)
        if previous:
            if previous["fingerprint"] != fingerprint:
                raise MembershipError("FINGERPRINT_MISMATCH")
            return {**previous, "effective_state": _effective(previous, state_root)[0], "result": "ALREADY_MEMBER"}
        if len(data["members"]) >= MAX_MEMBERS:
            raise MembershipError("MEMBERSHIP_LIMIT")
        now = int(time.time())
        record = {"node_id": node_id, "fingerprint": fingerprint, "enabled": True,
                  "state": MEMBER, "role_policy": str(role_policy), "added_at": now,
                  "updated_at": now, "trust_schema_version": 1}
        data["members"][node_id] = record; data["generation"] += 1; _write(data, state_root)
        return {**record, "effective_state": MEMBER, "result": "ADDED"}


def remove_member(node_id: str, *, state_root: str | Path | None = None) -> dict:
    with _locked(state_root):
        data = read_membership(state_root)
        if node_id not in data["members"]:
            return {"node_id": node_id, "result": "NOT_MEMBER"}
        del data["members"][node_id]; data["generation"] += 1; _write(data, state_root)
        return {"node_id": node_id, "result": "REMOVED"}


def set_enabled(node_id: str, enabled: bool, *, state_root: str | Path | None = None) -> dict:
    with _locked(state_root):
        data = read_membership(state_root); record = data["members"].get(node_id)
        if not record:
            raise MembershipError("NOT_MEMBER")
        _authoritative(node_id, state_root)
        record = dict(record); record.update({"enabled": bool(enabled), "state": MEMBER if enabled else DISABLED,
                                              "updated_at": int(time.time())})
        data["members"][node_id] = record; data["generation"] += 1; _write(data, state_root)
        return {**record, "effective_state": _effective(record, state_root)[0],
                "result": "ENABLED" if enabled else "DISABLED"}


def status(node_id: str | None = None, *, state_root: str | Path | None = None) -> dict | list[dict]:
    members = list_members(state_root)
    if node_id is None:
        return members
    for item in members:
        if item["node_id"] == node_id:
            return item
    raise MembershipError("NOT_MEMBER")
