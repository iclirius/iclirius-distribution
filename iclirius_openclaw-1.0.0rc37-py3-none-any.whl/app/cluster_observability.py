"""Read-only projection of real cluster evidence for CLI/TUI consumers."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from app import cluster_membership, cluster_presence, cluster_security
from app.node_capability_profile import from_snapshot
from app.node_identity import read_node, node_role
from app.remote_capabilities import read_cached

MAX_NODES = 128
MAX_TEXT = 120
MAX_CAPABILITIES = 128


def _text(value, limit=MAX_TEXT):
    return str(value or "")[:limit]


def _root(state_root=None):
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def _presence(state_root=None):
    try:
        return {item["node_id"]: item for item in cluster_presence.list_presence(state_root=state_root, probe_now=False)}
    except (OSError, ValueError, TypeError, cluster_membership.MembershipError):
        return {}


def _membership(state_root=None):
    try:
        return {item["node_id"]: item for item in cluster_membership.list_members(state_root)}
    except cluster_membership.MembershipError:
        return {}


def _capability_summary(registry):
    result = []
    values = (registry or {}).get("capabilities", [])
    if isinstance(values, dict):
        values = [{"capability_id": key,
                   "availability": ("AVAILABLE" if (value is True or (isinstance(value, dict) and value.get("available") is True and value.get("status") not in {"BLOCKED", "UNAVAILABLE"})) else "UNKNOWN")}
                  for key, value in values.items()]
    for item in list(values)[:MAX_CAPABILITIES]:
        result.append({"capability_id": _text(item.get("capability_id"), 96),
                       "availability": _text(item.get("availability"), 24),
                       "observed_at": item.get("observed_at")})
    return sorted(result, key=lambda item: item["capability_id"])


def _local_node(snapshot, local_registry=None):
    node = (snapshot or {}).get("node", {})
    registry = local_registry or from_snapshot(snapshot or {})
    resources = (snapshot or {}).get("resources", {})
    return {"node_id": _text(node.get("node_id")),
            "display_name": _text(node.get("hostname") or node.get("display_name") or "THIS MAC"),
            "local": True, "identity": "VERIFIED" if node.get("node_id") else "UNKNOWN",
            "trust": "LOCAL", "membership": "IMPLICIT_LOCAL",
            "discovery": "LOCAL", "presence": "LOCAL_RUNTIME",
            "role": _text(node.get("role") or registry.get("current_role") or node_role()),
            "platform": _text((snapshot or {}).get("runtime", {}).get("platform") or "UNKNOWN"),
            "architecture": _text((snapshot or {}).get("runtime", {}).get("architecture") or "UNKNOWN"),
            "logical_cpu_count": resources.get("logical_cpu_count", resources.get("cpu_count")),
            "memory_total_bytes": resources.get("memory_total_bytes"),
            "capabilities": _capability_summary(registry),
            "capability_freshness": "CURRENT" if registry else "UNKNOWN",
            "endpoint": "", "observed_at": int(time.time())}


def build(*, snapshot=None, local_registry=None, state_root=None,
          discovered=None, presence=None, memberships=None, capability_records=None) -> dict:
    """Build a deterministic, bounded, read-only cluster projection.

    Callers may inject evidence for tests/UI adapters. No discovery or probe is
    performed here; absence of injected evidence remains UNKNOWN.
    """
    if snapshot is None:
        from app.node_snapshot import collect
        snapshot = collect()
    local_id = str((read_node() or {}).get("node_id") or snapshot.get("node", {}).get("node_id") or "")
    trust = cluster_security.read_registry(state_root).get("peers", {})
    member_map = memberships if memberships is not None else _membership(state_root)
    presence_map = presence if presence is not None else _presence(state_root)
    discovered = discovered or {}
    capability_records = capability_records or {}
    node_ids = {local_id, *trust.keys(), *member_map.keys(), *discovered.keys()}
    node_ids = sorted(item for item in node_ids if item)[:MAX_NODES]
    nodes = [_local_node(snapshot, local_registry) if node_id == local_id else None for node_id in node_ids]
    remote = []
    for node_id in node_ids:
        if node_id == local_id:
            continue
        peer = trust.get(node_id, {}) if isinstance(trust.get(node_id, {}), dict) else {}
        member = member_map.get(node_id, {})
        observed = discovered.get(node_id, {}) if isinstance(discovered.get(node_id, {}), dict) else {}
        cached = capability_records.get(node_id) if node_id in capability_records else read_cached(node_id, state_root=state_root)
        p = presence_map.get(node_id, {})
        if cached is None:
            caps = {"capabilities": []}; freshness = "UNKNOWN"
        else:
            caps = cached; freshness = cached.get("freshness", {}).get("status", "UNKNOWN")
        display_name = (peer.get("display_name") or observed.get("display_name") or
                        ((cached or {}).get("node", {}).get("display_name") if cached else None) or node_id)
        node = {"node_id": _text(node_id),
                "display_name": _text(display_name),
                "local": False,
                "identity": "VERIFIED" if peer.get("trust_state") == cluster_security.TRUSTED else ("REVOKED" if peer.get("trust_state") == cluster_security.REVOKED else "UNKNOWN"),
                "trust": _text(peer.get("trust_state") or "UNKNOWN"),
                "membership": _text(member.get("effective_state") or "NOT_MEMBER"),
                "discovery": "OBSERVED" if node_id in discovered else "UNKNOWN",
                "presence": _text(p.get("presence_state") or "UNKNOWN"),
                "role": _text((cached or {}).get("node", {}).get("role") or member.get("role_policy") or "UNKNOWN"),
                "platform": _text((cached or {}).get("runtime", {}).get("platform") or "UNKNOWN"),
                "architecture": _text((cached or {}).get("runtime", {}).get("architecture") or "UNKNOWN"),
                "logical_cpu_count": (cached or {}).get("runtime", {}).get("logical_cpu_count"),
                "memory_total_bytes": (cached or {}).get("runtime", {}).get("memory_bytes"),
                "capabilities": _capability_summary(caps), "capability_freshness": freshness,
                "endpoint": _text(peer.get("address") or observed.get("address") or ""),
                "observed_at": p.get("last_authenticated_success") or cached.get("freshness", {}).get("generated_at") if cached else None}
        remote.append(node)
    nodes = [node for node in nodes if node] + remote
    summary = {"nodes_observed": len(nodes),
               "trusted": sum(item["trust"] in {cluster_security.TRUSTED, "LOCAL"} for item in nodes),
               "members": sum(item["membership"] in {cluster_membership.MEMBER, "IMPLICIT_LOCAL"} for item in nodes),
               "online": sum(item["presence"] == cluster_presence.ONLINE for item in nodes),
               "local": sum(item["local"] for item in nodes),
               "remote": sum(not item["local"] for item in nodes)}
    return {"schema_version": 1, "summary": summary, "nodes": nodes,
            "evidence_scope": "authoritative trust + membership + persisted authenticated observations",
            "generated_at": int(time.time())}


def render(data: dict, *, width: int = 120, ascii_safe: bool = False) -> str:
    lines = ["CLUSTER", f"Nodes observed: {data['summary']['nodes_observed']}",
             f"Trusted:        {data['summary']['trusted']}", f"Members:        {data['summary']['members']}",
             f"Online:         {data['summary']['online']}", f"Local:           {data['summary']['local']}",
             f"Remote:         {data['summary']['remote']}", ""]
    for node in data.get("nodes", []):
        label = "THIS MAC" if node["local"] else "REMOTE"
        lines.append(f"{label}: {_text(node['display_name'], 40)} [{node['node_id']}]")
        lines.append(f"  Identity {node['identity']}  Trust {node['trust']}  Membership {node['membership']}")
        lines.append(f"  Presence {node['presence']}  Role {node['role']}  Discovery {node['discovery']}")
        if width >= 90:
            lines.append("  Capabilities: " + (", ".join(f"{x['capability_id']}={x['availability']}" for x in node["capabilities"]) or "UNKNOWN"))
    return "\n".join(lines)
