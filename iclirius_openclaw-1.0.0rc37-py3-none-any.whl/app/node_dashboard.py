"""Presentation data for the TUI node dashboard.

This module only adapts canonical snapshots and cached peer observations. It
does not probe, ping, infer health, or persist state.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class NodeDisplayState:
    node_id: str
    display_name: str
    role: str
    health: str
    state: str
    is_local: bool = False
    latency_ms: int | None = None
    local_ai: str = ""
    model: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _local(snapshot: dict) -> NodeDisplayState | None:
    node = snapshot.get("node", {})
    if node.get("state", "").upper() != "ACTIVE":
        return None
    provider = snapshot.get("provider", {})
    ollama = provider.get("ollama", {})
    return NodeDisplayState(
        node_id=str(node.get("node_id", "")),
        display_name=str(node.get("hostname") or node.get("display_name") or "Local node")[:80],
        role=str(node.get("role") or "INTERFACE"),
        health=str(node.get("health") or "UNKNOWN"), state="ACTIVE", is_local=True,
        local_ai="Ollama" if ollama.get("reachable") else "LOCAL",
        model=str(provider.get("active_model") or ""),
    )


def active_nodes(snapshot: dict, peers: dict | None = None, caches: dict | None = None) -> list[NodeDisplayState]:
    """Return only active local and fresh trusted remote nodes."""
    result: list[NodeDisplayState] = []
    local = _local(snapshot)
    if local:
        result.append(local)
    peers = peers or {}
    caches = caches or {}
    for node_id, peer in peers.items():
        if peer.get("trust") != "TRUSTED":
            continue
        cached = caches.get(node_id)
        if not cached or cached.get("freshness", {}).get("status") != "FRESH":
            continue
        node = cached.get("node", {})
        if node.get("state") != "ACTIVE":
            continue
        result.append(NodeDisplayState(
            node_id=str(node_id), display_name=str(node.get("display_name") or "Remote node")[:80],
            role=str(node.get("role") or "UNKNOWN"), health=str(node.get("health") or "UNKNOWN"),
            state="ACTIVE", latency_ms=peer.get("latency_ms"),
            local_ai="Ollama" if cached.get("local_ai", {}).get("ollama_healthy") else "LOCAL",
            model=str((cached.get("local_ai", {}).get("installed_model_ids") or [""])[0]),
        ))
    return result


def collect_active_nodes(*, agent=None, interface: str = "tui", session_id: str = "") -> list[NodeDisplayState]:
    """Collect presentation inputs without network activity."""
    from app.node_snapshot import collect
    from app.node_pairing import peers as read_peers
    from app.remote_capabilities import read_cached
    snapshot = collect(agent=agent, interface=interface, session_id=session_id, active=True)
    peer_map = read_peers().get("peers", {})
    caches = {node_id: cached for node_id in peer_map
              if (cached := read_cached(node_id)) is not None}
    return active_nodes(snapshot, peer_map, caches)


def _short_name(name: str, width: int = 48) -> str:
    return name if len(name) <= width else name[: max(1, width - 1)] + "…"


def _laptop(unicode_safe: bool = True) -> tuple[str, str]:
    if unicode_safe:
        return ("┌──────┐", "│  ╱╱  │")
    return ("+------+", "|  //  |")


def render_nodes(nodes: list[NodeDisplayState], *, compact: bool = True,
                 unicode_safe: bool = True) -> str:
    """Render only already-filtered active nodes with terminal-native markup."""
    lines = [f"[bold cyan]ACTIVE NODES ({len(nodes)})[/bold cyan]"]
    if not nodes:
        return "\n".join(lines + ["[dim]  No active nodes[/dim]"])
    screen, bezel = _laptop(unicode_safe)
    for node in nodes:
        name = _short_name(node.display_name)
        location = "LOCAL" if node.is_local else (f"REMOTE · {node.latency_ms} ms" if node.latency_ms is not None else "REMOTE")
        lines.append("[dim]╭──────────────────────────────────────────────╮[/dim]")
        lines.append(f"[dim]│[/dim]  [cyan]{screen}[/cyan]  [bold white]{name}[/bold white]")
        lines.append(f"[dim]│[/dim]  [cyan]{bezel}[/cyan]  [cyan]{node.role}[/cyan] · [green]{node.health} ●[/green] · "
                     f"[{'cyan' if node.is_local else 'magenta'}]{location}[/{'cyan' if node.is_local else 'magenta'}]")
        ai = ""
        if node.local_ai and node.model:
            ai = f"[magenta]{node.local_ai}[/magenta] · [yellow]{_short_name(node.model, 36)}[/yellow]"
        lines.append(f"[dim]│[/dim]  [cyan]╲______/[/cyan]  {ai}".rstrip())
        lines.append("[dim]╰──────────────────────────────────────────────╯[/dim]")
    return "\n".join(lines)


def collect_cluster_nodes(*, agent=None, interface: str = "tui", session_id: str = "") -> dict:
    """Collect the read-only normalized cluster projection for the TUI."""
    from app.node_snapshot import collect
    from app.cluster_observability import build
    return build(snapshot=collect(agent=agent, interface=interface, session_id=session_id, active=True))


def render_cluster_nodes(data: dict, *, width: int = 120, unicode_safe: bool = True) -> str:
    """Render normalized cluster evidence; no card is fabricated by the renderer."""
    from app.cluster_observability import render
    return "ACTIVE NODES / " + render(data, width=width, ascii_safe=not unicode_safe)
