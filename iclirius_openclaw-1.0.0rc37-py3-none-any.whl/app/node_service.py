"""User-level packaged-node LaunchAgent lifecycle.

The service is deliberately user scoped.  It never touches Memory Home,
credentials, AllowedRoots or user documents.
"""
from __future__ import annotations

import json
import argparse
import os
import plistlib
import signal
import shutil
import subprocess
import sys
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from app.node_pairing import DEFAULT_BIND, NodeListener

LABEL = "com.iclirius.openclaw.node"
LEGACY_LABEL = "com.iclirius.node"
START_TIMEOUT_SECONDS = 5.0
START_POLL_SECONDS = 0.1
_VERSION_RE = re.compile(r"(?:/|^)iclirius/(\d+\.\d+\.\d+(?:rc\.?\d+)?)")


def service_dir() -> Path:
    return Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LABEL}.plist"


def metadata_path() -> Path:
    return service_dir() / "node-service.json"


def _clear_dead_discovery_marker() -> None:
    path = service_dir() / "secure-discovery-runtime.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        pid = int(data.get("pid", 0))
        try:
            os.kill(pid, 0)
            return
        except OSError:
            pass
        path.unlink(missing_ok=True)
    except (OSError, ValueError, TypeError):
        path.unlink(missing_ok=True)


def legacy_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LEGACY_LABEL}.plist"


def legacy_status() -> dict:
    path = legacy_plist_path()
    if not path.exists():
        return {"state": "NOT_INSTALLED", "label": LEGACY_LABEL}
    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return {"state": "UNKNOWN", "label": LEGACY_LABEL}
    source = "LEGACY_SOURCE" if "run_node.sh" in content else "UNKNOWN"
    return {"state": source, "label": LEGACY_LABEL, "plist": str(path)}


def migration_plan() -> dict:
    return {"legacy": legacy_status(), "target": descriptor() | {"label": LABEL},
            "preserves": ["configuration", "Memory Home", "identity", "Keychain", "AllowedRoots"],
            "requires_confirmation": True, "rollback": "legacy LaunchAgent remains available until verified",
            "executable": False}


def _executable() -> str:
    """Find the interpreter that can import this installed package.

    ``sys.executable`` is not authoritative for Homebrew virtualenvs.  The
    generated console script carries the environment's interpreter in its
    shebang, so prefer that and verify the import from a clean working
    directory before writing a LaunchAgent.
    """
    module_path = Path(__file__).resolve()
    candidates: list[str] = []
    script = Path(sys.argv[0]) if sys.argv and sys.argv[0] else Path()
    if not script.is_absolute():
        found = shutil.which(str(script))
        script = Path(found) if found else script
    if script.name == "iclirius" and script.is_file():
        try:
            first = script.read_text(encoding="utf-8").splitlines()[0]
            if first.startswith("#!"):
                candidates.append(first[2:].strip().split()[0])
        except (OSError, UnicodeError, IndexError):
            pass
    for parent in (module_path.parent, *module_path.parents):
        if (parent / "pyvenv.cfg").is_file():
            candidate = parent / "bin" / "python"
            if candidate.exists():
                candidates.append(str(candidate))
    source_root = module_path.parents[1]
    candidate = source_root / ".venv" / "bin" / "python"
    if candidate.exists():
        candidates.append(str(candidate))
    candidates.extend([sys.prefix + "/bin/python", sys.executable])
    seen = set()
    for value in candidates:
        # Keep the virtualenv path lexical.  Homebrew venv Python launchers
        # are commonly symlinks into python@3.14's Cellar; realpath() would
        # erase the venv boundary and recreate the physical RC15 bug.
        resolved = os.path.abspath(value)
        if resolved in seen or not Path(resolved).is_file():
            continue
        seen.add(resolved)
        if _interpreter_imports_current_package(resolved):
            return resolved
    return os.path.abspath(candidates[0] if candidates else sys.executable)


def _interpreter_imports_current_package(interpreter: str) -> bool:
    """Bounded, read-only probe used for runtime provenance validation."""
    try:
        env = {key: value for key, value in os.environ.items() if key != "PYTHONPATH"}
        probe_cwd = Path(__file__).resolve().parents[1] if "/Cellar/iclirius/" not in str(Path(__file__).resolve()) else Path("/")
        result = subprocess.run(
            [interpreter, "-c", "import app.node_runtime as m; print(m.__file__)"],
            cwd=str(probe_cwd), env=env, capture_output=True, text=True, timeout=2, check=False,
        )
        if result.returncode != 0:
            return False
        imported = Path(result.stdout.strip().splitlines()[-1]).resolve()
        return imported.parent == Path(__file__).resolve().parent
    except (OSError, subprocess.SubprocessError, IndexError, ValueError):
        return False


def descriptor() -> dict:
    return {"label": LABEL, "installation_mode": installation_mode(),
            "executable": _executable(), "module": "app.node_runtime",
            "created_by": "iclirius", "managed": True}


def installation_mode() -> str:
    path = Path(__file__).resolve()
    return "HOMEBREW" if "/Cellar/" in str(path) else "SOURCE_CHECKOUT"


def _plist() -> dict:
    executable = _executable()
    # A source checkout cannot import ``app`` from the machine-state runtime
    # directory.  LaunchAgents do not inherit the caller's CWD, so point the
    # service at the package root in that installation mode.  Packaged builds
    # keep their isolated runtime directory as the working directory.
    workdir = (Path(__file__).resolve().parents[1]
               if installation_mode() == "SOURCE_CHECKOUT"
               else service_dir() / "runtime")
    workdir.mkdir(mode=0o700, parents=True, exist_ok=True)
    return {"Label": LABEL, "ProgramArguments": [executable, "-m", "app.node_runtime"],
            "WorkingDirectory": str(workdir),
            "RunAtLoad": True, "KeepAlive": True, "ThrottleInterval": 30,
            "ProcessType": "Background", "EnvironmentVariables": {
                "PATH": os.getenv("PATH", "/usr/bin:/bin:/usr/sbin:/sbin")},
            "StandardOutPath": str(service_dir() / "runtime" / "logs" / "node.out.log"),
            "StandardErrorPath": str(service_dir() / "runtime" / "logs" / "node.err.log")}


def _launchctl(*args: str) -> subprocess.CompletedProcess:
    launchctl = shutil.which("launchctl") or "/bin/launchctl"
    return subprocess.run([launchctl, *args], capture_output=True, text=True,
                          check=False)


def _domain() -> str:
    return f"gui/{os.getuid()}"


def _launchctl_status() -> dict:
    """Read launchd state; logical node health is deliberately not consulted."""
    result = _launchctl("print", f"{_domain()}/{LABEL}")
    output = f"{result.stdout}\n{result.stderr}"
    match = re.search(r"\bpid\s*=\s*(\d+)", output)
    exit_match = re.search(r"last exit code\s*=\s*(-?\d+)", output, re.I)
    state_match = re.search(r"\bstate\s*=\s*([^\n]+)", output)
    return {"loaded": result.returncode == 0, "pid": int(match.group(1)) if match else None,
            "exit_code": int(exit_match.group(1)) if exit_match else None,
            "launch_state": state_match.group(1).strip() if state_match else "",
            "error": (result.stderr or "").strip()}


def _process_alive(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _process_command(pid: int | None) -> str:
    if not pid:
        return ""
    try:
        result = subprocess.run(["ps", "-p", str(pid), "-o", "command="],
                                capture_output=True, text=True, timeout=1, check=False)
        return (result.stdout or "").strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _process_matches_runtime(pid: int | None) -> bool:
    command = _process_command(pid)
    return bool(command) and "app.node_runtime" in command


def _plist_runtime(path: Path) -> str:
    try:
        data = plistlib.loads(path.read_bytes())
        arguments = data.get("ProgramArguments", [])
        return str(arguments[0]) if arguments else ""
    except (OSError, plistlib.InvalidFileException, ValueError, TypeError):
        return ""


def _plist_data(path: Path) -> dict:
    try:
        value = plistlib.loads(path.read_bytes())
        return value if isinstance(value, dict) else {}
    except (OSError, plistlib.InvalidFileException, ValueError, TypeError):
        return {}


def _version_from_path(value: str) -> str:
    match = _VERSION_RE.search(value or "")
    return match.group(1) if match else "UNKNOWN"


def _service_state() -> dict:
    path = plist_path()
    launch = _launchctl_status()
    expected = _executable()
    data = _plist_data(path) if path.exists() else {}
    arguments = data.get("ProgramArguments", [])
    actual = str(arguments[0]) if arguments else ""
    working_directory = str(data.get("WorkingDirectory", ""))
    expected_working_directory = str(Path(__file__).resolve().parents[1]
                                     if installation_mode() == "SOURCE_CHECKOUT"
                                     else service_dir() / "runtime")
    arguments_valid = arguments[1:] == ["-m", "app.node_runtime"]
    label_valid = data.get("Label") == LABEL
    module_location = str(Path(__file__).resolve())
    expected_mode = "HOMEBREW" if "/Cellar/iclirius/" in module_location else "SOURCE_CHECKOUT"
    mode_compatible = installation_mode() == expected_mode
    stale_reasons = []
    expected_import_ok = _interpreter_imports_current_package(expected)
    actual_import_ok = _interpreter_imports_current_package(actual) if actual else False
    if not label_valid:
        stale_reasons.append("LABEL_MISMATCH")
    if not arguments_valid:
        stale_reasons.append("ENTRYPOINT_MISMATCH")
    if actual != expected:
        stale_reasons.append("RUNTIME_EXECUTABLE_MISMATCH")
    if not Path(actual).is_file():
        stale_reasons.append("RUNTIME_EXECUTABLE_MISSING")
    if not actual_import_ok:
        stale_reasons.append("RUNTIME_IMPORT_UNAVAILABLE")
    if not expected_import_ok:
        stale_reasons.append("EXPECTED_RUNTIME_IMPORT_UNAVAILABLE")
    if not working_directory or working_directory != expected_working_directory:
        stale_reasons.append("WORKING_DIRECTORY_MISMATCH")
    if not Path(working_directory).is_dir():
        stale_reasons.append("WORKING_DIRECTORY_MISSING")
    if not mode_compatible:
        stale_reasons.append("INSTALLATION_MODE_MISMATCH")
    stale = bool(path.exists() and stale_reasons)
    if not path.exists():
        state = "NOT_INSTALLED"
    elif stale:
        state = "SERVICE_RUNTIME_STALE"
    elif launch["loaded"] and launch["pid"]:
        state = "RUNNING" if (_process_alive(launch["pid"])
                              and _process_matches_runtime(launch["pid"])) else "FAILED"
    elif launch["loaded"]:
        state = "STOPPED"
    else:
        state = "INSTALLED_NOT_LOADED"
    health = ("SERVICE_RUNTIME_STALE" if stale else
              ("SERVICE_NOT_LOADED" if path.exists() and not launch["loaded"] else
               ("SERVICE_HEALTHY" if state == "RUNNING" else "SERVICE_BOOTSTRAP_FAILED")))
    return {"state": state, "service_health": health, "label": LABEL, "installed": path.exists(),
            "loaded": launch["loaded"], "pid": launch["pid"],
            "launch_state": launch.get("launch_state", ""),
            "exit_code": launch.get("exit_code"),
            "plist": str(path) if path.exists() else "",
            "metadata": str(metadata_path()) if metadata_path().exists() else "",
            "installation_mode": installation_mode(), "runtime": expected,
            "version": _runtime_version(), "current_cli_version": _runtime_version(),
            "service_runtime_version": (_version_from_path(actual)
                                         if _version_from_path(actual) != "UNKNOWN"
                                         else _version_from_path(working_directory)),
            "logs": str(service_dir() / "runtime" / "logs"),
            "runtime_expected": expected, "runtime_plist": actual,
            "runtime_stale": stale, "stale_reasons": stale_reasons,
            "expected_runtime_import_ok": expected_import_ok,
            "runtime_import_ok": actual_import_ok,
            "process_command": _process_command(launch["pid"]),
            "process_matches_runtime": _process_matches_runtime(launch["pid"]),
            "working_directory": working_directory,
            "working_directory_expected": expected_working_directory,
            "working_directory_exists": Path(working_directory).is_dir() if working_directory else False,
            "arguments_valid": arguments_valid, "label_valid": label_valid,
            "installation_mode_compatible": mode_compatible,
            "error": launch["error"]}


def _runtime_version() -> str:
    try:
        from app.version import VERSION
        return VERSION
    except Exception:
        return "UNKNOWN"


def _validate_plist(path: Path) -> None:
    plistlib.loads(path.read_bytes())


def _write_json_atomic(path: Path, value: dict) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, path)


def _validate_production_plist(path: Path) -> None:
    data = _plist_data(path)
    args = data.get("ProgramArguments", [])
    if args[1:] != ["-m", "app.node_runtime"]:
        raise ValueError("ENTRYPOINT_MISMATCH")
    expected_logs = service_dir() / "runtime" / "logs"
    for key in ("StandardOutPath", "StandardErrorPath"):
        value = str(data.get(key, ""))
        if not value.startswith(str(expected_logs) + os.sep):
            raise ValueError(f"PRODUCTION_LOG_PATH_INVALID:{key}")
    if not Path(str(data.get("WorkingDirectory", ""))).is_dir():
        raise ValueError("WORKING_DIRECTORY_MISSING")


def install() -> dict:
    """Install the managed LaunchAgent, without starting it."""
    current = _service_state()
    target = plist_path()
    old_plist = target.read_bytes() if target.exists() else None
    old_metadata = metadata_path().read_bytes() if metadata_path().exists() else None
    temp = None
    metadata_temp = None
    try:
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        service_dir().mkdir(mode=0o700, parents=True, exist_ok=True)
        (service_dir() / "runtime").mkdir(mode=0o700, parents=True, exist_ok=True)
        (service_dir() / "runtime" / "logs").mkdir(mode=0o700, parents=True, exist_ok=True)
        temp = target.with_name(f".{target.name}.tmp-{os.getpid()}")
        temp.write_bytes(plistlib.dumps(_plist(), fmt=plistlib.FMT_XML, sort_keys=False))
        os.chmod(temp, 0o600)
        _validate_plist(temp)
        _validate_production_plist(temp)

        # Validate and stage the complete replacement before unloading a live
        # service.  This prevents a malformed generated plist from destroying
        # a working service during an upgrade.
        metadata = descriptor() | {"installed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                                   "plist": str(target)}
        metadata_temp = metadata_path().with_name(f".{metadata_path().name}.tmp-{os.getpid()}")
        _write_json_atomic(metadata_temp, metadata)

        if current.get("loaded"):
            result = _launchctl("bootout", f"{_domain()}/{LABEL}")
            deadline = time.monotonic() + START_TIMEOUT_SECONDS
            while time.monotonic() < deadline and _launchctl_status().get("loaded"):
                time.sleep(START_POLL_SECONDS)
            if _launchctl_status().get("loaded"):
                metadata_temp.unlink(missing_ok=True)
                return {**current, "state": "FAILED",
                        "error": result.stderr or "loaded service could not be replaced",
                        "error_code": "SERVICE_UNLOAD_FAILED"}

        os.replace(temp, target)
        os.replace(metadata_temp, metadata_path())
        return {**_service_state(), **metadata}
    except Exception as exc:
        if temp is not None:
            temp.unlink(missing_ok=True)
        if metadata_temp is not None:
            metadata_temp.unlink(missing_ok=True)
        # Restore files if replacement began but did not complete.  This is
        # deliberately limited to the service files; identity, trust and user
        # data are never part of this transaction.
        try:
            if old_plist is not None and target.exists():
                restore = target.with_name(f".{target.name}.rollback-{os.getpid()}")
                restore.write_bytes(old_plist); os.chmod(restore, 0o600); os.replace(restore, target)
            if old_metadata is not None:
                restore_meta = metadata_path().with_name(f".{metadata_path().name}.rollback-{os.getpid()}")
                restore_meta.write_bytes(old_metadata); os.chmod(restore_meta, 0o600); os.replace(restore_meta, metadata_path())
        except OSError:
            pass
        return {**_service_state(), "state": "FAILED",
                "error_code": "PLIST_GENERATION_FAILED", "error": str(exc)[:240]}


def reinstall() -> dict:
    """Migrate and verify the managed service without touching user state."""
    result = install()
    if result.get("state") == "FAILED":
        return result
    started = start()
    if started.get("state") != "RUNNING":
        return {**started, "state": "FAILED",
                "error_code": started.get("error_code", "SERVICE_VERIFICATION_FAILED"),
                "error": started.get("error", "replacement service did not become RUNNING")}
    verified = _service_state()
    if verified.get("state") != "RUNNING" or verified.get("runtime_stale"):
        return {**verified, "state": "FAILED",
                "error_code": "SERVICE_VERIFICATION_FAILED",
                "error": "replacement service provenance verification failed"}
    return {**verified, "postcondition": "RUNNING"}


def start() -> dict:
    target = plist_path()
    if not target.exists():
        return {"state": "NOT_INSTALLED", "label": LABEL}
    current = _service_state()
    if not current["loaded"]:
        result = _launchctl("bootstrap", _domain(), str(target))
        if result.returncode != 0 and "already" not in (result.stderr or "").lower():
            return {**_service_state(), "state": "FAILED", "error": (result.stderr or "").strip()}
    _launchctl("kickstart", "-k", f"{_domain()}/{LABEL}")
    deadline = time.monotonic() + START_TIMEOUT_SECONDS
    state = _service_state()
    while time.monotonic() < deadline:
        if state["state"] == "RUNNING":
            return state
        time.sleep(START_POLL_SECONDS)
        state = _service_state()
    reason = state.get("error") or "service did not reach RUNNING before timeout"
    if state.get("pid") is None and state.get("exit_code") is not None:
        reason = f"service terminated during startup (exit code {state['exit_code']})"
    return {**state, "state": "FAILED", "error": reason,
            "error_code": "STARTUP_PROCESS_EXITED" if state.get("pid") is None and state.get("exit_code") is not None else "STARTUP_TIMEOUT"}


def stop() -> dict:
    target = plist_path()
    if not target.exists():
        return {"state": "NOT_INSTALLED", "label": LABEL, "installed": False}
    current = _service_state()
    if current["loaded"]:
        result = _launchctl("bootout", f"{_domain()}/{LABEL}")
        deadline = time.monotonic() + START_TIMEOUT_SECONDS
        state = _service_state()
        while time.monotonic() < deadline and (state["loaded"] or state.get("pid")):
            time.sleep(START_POLL_SECONDS)
            state = _service_state()
        if state["loaded"] or state.get("pid") or (state.get("process_matches_runtime") and state.get("pid")):
            return {**state, "state": "FAILED",
                    "error": result.stderr or state.get("error") or "service remained loaded",
                    "error_code": "STOP_POSTCONDITION_FAILED"}
    final = _service_state()
    _clear_dead_discovery_marker()
    if final.get("loaded") or final.get("pid"):
        return {**final, "state": "FAILED", "error_code": "STOP_POSTCONDITION_FAILED"}
    return {**final, "postcondition": "STOPPED"}


def restart() -> dict:
    stopped = stop()
    if stopped.get("state") not in {"STOPPED", "INSTALLED_NOT_LOADED"}:
        return stopped
    return start()


def status() -> dict:
    return _service_state()


def uninstall() -> dict:
    """Remove only this managed service and its metadata."""
    stopped = stop()
    if stopped.get("state") not in {"STOPPED", "INSTALLED_NOT_LOADED", "NOT_INSTALLED"}:
        return stopped
    target = plist_path()
    target.unlink(missing_ok=True)
    metadata_path().unlink(missing_ok=True)
    _clear_dead_discovery_marker()
    return {**_service_state(), "state": "NOT_INSTALLED", "label": LABEL}


def main(argv: list[str] | None = None) -> int:
    """Legacy foreground peer listener retained for existing node service."""
    parser = argparse.ArgumentParser(prog="iclirius node service")
    parser.add_argument("--bind", default=DEFAULT_BIND)
    parser.add_argument("--port", type=int, default=18890)
    args = parser.parse_args(argv)
    listener = NodeListener(bind=args.bind, port=args.port)
    signal.signal(signal.SIGTERM, lambda *_: listener.stop())
    try:
        listener.serve()
    except KeyboardInterrupt:
        listener.stop()
        print("Node listener stopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
