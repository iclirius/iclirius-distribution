"""Bounded, privacy-safe remote capability advertisements and cache."""
from __future__ import annotations

import json
import os
import platform
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

from app.config import settings
from app.doctor import collect as collect_doctor
from app.node_capability_profile import build_node_capability_profile
from app.node_identity import node_role, read_node
from app.version import VERSION

SCHEMA_VERSION = 1
TTL_SECONDS = 300
MAX_MODELS = 32
MAX_STRING = 160
SAFE_HEALTH = {"HEALTHY", "DEGRADED", "BLOCKED", "OFFLINE", "UNKNOWN"}
SAFE_STATE = {"ACTIVE", "STANDBY", "OFFLINE", "DEGRADED", "BLOCKED", "UNKNOWN"}


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.isoformat(timespec="seconds")


def _memory_bytes() -> int | None:
    try:
        return int(os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
    except (AttributeError, OSError, TypeError, ValueError):
        return None


def build_advertisement() -> dict:
    report = collect_doctor()
    profile = build_node_capability_profile({**report, "node_role": node_role()})
    caps = profile.get("capabilities", {})
    node = read_node()
    health = profile.get("health", {}).get("health", "UNKNOWN")
    health = health if health in SAFE_HEALTH else "UNKNOWN"
    state = "ACTIVE" if health in {"HEALTHY", "DEGRADED"} else health
    models = [str(x)[:MAX_STRING] for x in report.get("models", {}).get("installed", [])[:MAX_MODELS]]
    now = _utc_now()
    return {
        "schema_version": SCHEMA_VERSION,
        "protocol_version": 1,
        "iclirius_version": VERSION,
        "node": {"node_id": str(node.get("node_id", "unknown-node"))[:MAX_STRING],
                 "display_name": str(node.get("hostname", platform.node() or "local-node"))[:MAX_STRING],
                 "role": profile.get("current_role", node_role()), "health": health, "state": state},
        "runtime": {"platform": platform.system()[:MAX_STRING], "architecture": platform.machine()[:MAX_STRING],
                     "logical_cpu_count": os.cpu_count(), "memory_bytes": _memory_bytes()},
        "capabilities": {
            "local_reasoning": caps.get("local_reasoning", {}).get("available") is True,
            "filesystem": caps.get("file_access", {}).get("available") is True,
            "code_execution": caps.get("code_execution", {}).get("available") is True,
            "version_control": caps.get("version_control", {}).get("available") is True,
            "python": caps.get("code_execution", {}).get("available") is True,
            "voice": caps.get("voice", {}).get("available") is True,
            "network": caps.get("network_outbound", {}).get("available") is True,
            "local_ai": caps.get("local_reasoning", {}).get("available") is True,
        },
        "local_ai": {"ollama_available": bool(report.get("ollama", {}).get("installed")),
                     "ollama_healthy": bool(report.get("ollama", {}).get("running")),
                     "installed_model_ids": models},
        "transport": {"status": "READY", "protocol": 1},
        "freshness": {"generated_at": _iso(now), "expires_at": _iso(now + timedelta(seconds=TTL_SECONDS)),
                       "ttl_seconds": TTL_SECONDS},
    }


def validate_advertisement(value: dict) -> dict:
    if not isinstance(value, dict) or value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported capability schema")
    node = value.get("node", {})
    if not isinstance(node, dict) or not isinstance(node.get("node_id"), str) or not node["node_id"]:
        raise ValueError("invalid capability node")
    if len(node["node_id"]) > MAX_STRING or node.get("role") not in {"INTERFACE", "LOCAL_COMPUTE", "CODE_WORKER", "REMOTE_WORKER", "FULL_NODE"}:
        raise ValueError("invalid capability node fields")
    if node.get("health") not in SAFE_HEALTH or node.get("state") not in SAFE_STATE:
        raise ValueError("invalid capability health")
    models = value.get("local_ai", {}).get("installed_model_ids", [])
    if not isinstance(models, list) or len(models) > MAX_MODELS or any(not isinstance(x, str) or len(x) > MAX_STRING for x in models):
        raise ValueError("invalid model list")
    capabilities = value.get("capabilities", {})
    if not isinstance(capabilities, dict) or len(capabilities) > 128:
        raise ValueError("invalid capability map")
    freshness = value.get("freshness", {})
    if not isinstance(freshness.get("generated_at"), str) or not isinstance(freshness.get("expires_at"), str):
        raise ValueError("invalid freshness")
    # Return a copy containing only the documented safe fields.
    allowed = {"schema_version", "protocol_version", "iclirius_version", "node", "runtime", "capabilities", "local_ai", "transport", "freshness"}
    return {key: value[key] for key in allowed if key in value}


def cache_path(node_id: str, state_root=None) -> Path:
    root = Path(state_root or os.environ.get("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()
    return root / "capabilities" / f"{node_id}.json"


def cache_advertisement(advertisement: dict, state_root=None) -> Path:
    safe = validate_advertisement(advertisement)
    path = cache_path(safe["node"]["node_id"], state_root); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temp.write_text(json.dumps(safe, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600); os.replace(temp, path)
    return path


def read_cached(node_id: str, state_root=None) -> dict | None:
    try:
        value = validate_advertisement(json.loads(cache_path(node_id, state_root).read_text(encoding="utf-8")))
        expires = datetime.fromisoformat(value["freshness"]["expires_at"])
        value["freshness"] = {**value["freshness"], "status": "FRESH" if expires.timestamp() >= time.time() else "STALE"}
        return value
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None
