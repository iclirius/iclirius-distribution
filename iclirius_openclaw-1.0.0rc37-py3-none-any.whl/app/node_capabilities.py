"""Bounded resource/capability observations and single-node eligibility.

This module is deliberately a policy-neutral foundation.  It never creates
trust or membership and it never selects a node.  Remote observations are
accepted only from the existing authenticated capability cache for an
authoritatively trusted identity.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import time
from pathlib import Path
from typing import Iterable

from app import cluster_membership, cluster_presence, cluster_security
from app.node_capability_profile import build_node_capability_profile
from app.node_identity import node_role, read_node
from app.remote_capabilities import read_cached

SCHEMA_VERSION = 1
AVAILABLE, DEGRADED, UNAVAILABLE, UNKNOWN = "AVAILABLE", "DEGRADED", "UNAVAILABLE", "UNKNOWN"
MAX_NODES = 128
MAX_CAPABILITIES = 128
MAX_REQUIREMENTS = 64
MAX_ID = 96
MAX_PROVIDER = 64
MAX_REASON = 240
MAX_METADATA = 4096
FRESHNESS_SECONDS = 300


class CapabilityError(ValueError):
    pass


def _root(state_root=None) -> Path:
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def _now() -> int:
    return int(time.time())


def _text(value, limit: int = MAX_REASON) -> str:
    return str(value or "")[:limit]


def _cap(capability_id: str, availability: str, *, reason: str = "", provider: str = "",
         source: str = "local", constraints: dict | None = None, observed_at: int | None = None) -> dict:
    if not capability_id or len(capability_id) > MAX_ID or "." not in capability_id:
        raise CapabilityError("INVALID_CAPABILITY_ID")
    if availability not in {AVAILABLE, DEGRADED, UNAVAILABLE, UNKNOWN}:
        raise CapabilityError("INVALID_AVAILABILITY")
    if provider and len(provider) > MAX_PROVIDER:
        raise CapabilityError("PROVIDER_TOO_LONG")
    safe_constraints = constraints or {}
    encoded = json.dumps(safe_constraints, sort_keys=True, ensure_ascii=False)
    if len(encoded) > MAX_METADATA:
        raise CapabilityError("CAPABILITY_METADATA_TOO_LARGE")
    return {"capability_id": capability_id, "availability": availability,
            "reason": _text(reason), "provider": _text(provider, MAX_PROVIDER),
            "constraints": safe_constraints, "observed_at": int(observed_at or _now()),
            "source": _text(source, 32)}


def _resource(resource_id: str, value, unit: str = "", source: str = "local") -> dict:
    return {"resource_id": _text(resource_id, MAX_ID), "value": value,
            "unit": _text(unit, 32), "source": _text(source, 32), "observed_at": _now()}


def _normalize_capabilities(values: Iterable[dict]) -> list[dict]:
    result: dict[str, dict] = {}
    for item in values:
        if not isinstance(item, dict):
            raise CapabilityError("MALFORMED_CAPABILITY")
        cap = _cap(item.get("capability_id", ""), item.get("availability", UNKNOWN),
                   reason=item.get("reason", ""), provider=item.get("provider", ""),
                   source=item.get("source", "remote"), constraints=item.get("constraints", {}),
                   observed_at=item.get("observed_at"))
        # Duplicate identifiers are deterministic: the strongest availability
        # wins, then the earliest serialized representation is retained.
        previous = result.get(cap["capability_id"])
        if previous is None or _availability_rank(cap["availability"]) > _availability_rank(previous["availability"]):
            result[cap["capability_id"]] = cap
    if len(result) > MAX_CAPABILITIES:
        raise CapabilityError("CAPABILITY_LIMIT")
    return [result[key] for key in sorted(result)]


def _availability_rank(value: str) -> int:
    return {AVAILABLE: 4, DEGRADED: 3, UNKNOWN: 2, UNAVAILABLE: 1}.get(value, 0)


def _local_resources() -> list[dict]:
    resources = [_resource("system.cpu.arch", platform.machine(), "arch"),
                 _resource("system.cpu.logical_count", os.cpu_count() or 0, "count")]
    try:
        total = int(os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        resources.append(_resource("system.memory.total", total, "bytes"))
    except (AttributeError, OSError, TypeError, ValueError):
        pass
    try:
        resources.append(_resource("system.platform", platform.system(), "name"))
    except Exception:
        pass
    return resources


def _local_capabilities(profile: dict) -> list[dict]:
    source = "local-doctor"
    mapping = {
        "file_access": "filesystem.read", "code_execution": "python.execute",
        "version_control": "git.read", "local_reasoning": "reasoning.local",
        "voice": "voice.stt", "network_outbound": "network.outbound",
        "interface": "iclirius.interface", "memory_access": "memory.read",
    }
    values = []
    for old, new in mapping.items():
        item = profile.get("capabilities", {}).get(old, {})
        available = item.get("available") is True and item.get("status") not in {"BLOCKED", "UNAVAILABLE"}
        status = AVAILABLE if available else (DEGRADED if item.get("available") is True else UNAVAILABLE)
        values.append(_cap(new, status, reason=item.get("reasons", ["evidence unavailable"])[0], source=source))
    values.extend([_cap("filesystem.write", AVAILABLE, reason="local bounded filesystem policy is configured", source=source),
                   _cap("runtime.python", AVAILABLE if shutil.which("python") else UNAVAILABLE,
                        reason="python executable detected" if shutil.which("python") else "python executable unavailable", source=source)])
    return _normalize_capabilities(values)


def local_registry(*, state_root=None, doctor_report: dict | None = None) -> dict:
    """Return a bounded local observation without changing persistent policy."""
    from app.doctor import collect as collect_doctor
    report = doctor_report if doctor_report is not None else collect_doctor()
    profile = build_node_capability_profile({**report, "node_role": node_role()})
    node_id = str((read_node() or {}).get("node_id") or profile.get("node_id") or "local-node")
    return {"schema_version": SCHEMA_VERSION, "node_id": node_id,
            "role": node_role(), "resources": _local_resources(),
            "capabilities": _local_capabilities(profile),
            "observed_at": _now(), "source": "local"}


def _remote_registry(node_id: str, *, state_root=None) -> dict:
    registry = cluster_security.read_registry(state_root)
    peer = registry.get("peers", {}).get(node_id)
    if not isinstance(peer, dict) or peer.get("trust_state") != cluster_security.TRUSTED:
        raise CapabilityError("IDENTITY_NOT_TRUSTED")
    report = read_cached(node_id, state_root=state_root)
    if not report:
        return {"schema_version": SCHEMA_VERSION, "node_id": node_id, "role": "UNKNOWN",
                "resources": [], "capabilities": [], "observed_at": 0,
                "source": "authenticated-cache", "availability": UNKNOWN,
                "reason": "NO_AUTHENTICATED_REPORT"}
    caps = []
    freshness = report.get("freshness", {})
    stale = freshness.get("status") == "STALE"
    for key, available in (report.get("capabilities") or {}).items():
        if "." not in str(key):
            key = {"filesystem": "filesystem.read", "python": "python.execute",
                   "local_reasoning": "reasoning.local", "version_control": "git.read"}.get(str(key), f"legacy.{key}")
        caps.append(_cap(str(key), UNKNOWN if stale else (AVAILABLE if available is True else UNAVAILABLE),
                         reason="AUTHENTICATED_REPORT_STALE" if stale else "",
                         source="authenticated-tls", provider="remote"))
    return {"schema_version": SCHEMA_VERSION, "node_id": node_id,
            "role": report.get("node", {}).get("role", "UNKNOWN"), "resources": [],
            "capabilities": _normalize_capabilities(caps), "observed_at": _now(),
            "source": "authenticated-tls", "freshness": report.get("freshness", {})}


def capabilities_for(node_id: str, *, state_root=None, doctor_report=None) -> dict:
    local = str((read_node() or {}).get("node_id", ""))
    return local_registry(state_root=state_root, doctor_report=doctor_report) if node_id == local else _remote_registry(node_id, state_root=state_root)


def evaluate_requirements(node_id: str, requirements: Iterable[str], *, state_root=None, require_presence=False) -> dict:
    required = sorted({str(item).strip() for item in requirements if str(item).strip()})
    if len(required) > MAX_REQUIREMENTS or any(len(item) > MAX_ID or "." not in item for item in required):
        raise CapabilityError("INVALID_REQUIREMENTS")
    registry = capabilities_for(node_id, state_root=state_root)
    by_id = {item["capability_id"]: item for item in registry.get("capabilities", [])}
    missing = [item for item in required if item not in by_id]
    unavailable = [item for item in required if item in by_id and by_id[item]["availability"] != AVAILABLE]
    local_id = str((read_node() or {}).get("node_id", ""))
    membership_state = "IMPLICIT_LOCAL" if node_id == local_id else "NOT_MEMBER"
    if node_id != local_id:
        try:
            membership_state = next((item["effective_state"] for item in cluster_membership.list_members(state_root)
                                     if item.get("node_id") == node_id), "NOT_MEMBER")
        except cluster_membership.MembershipError:
            membership_state = "INVALID_TRUST"
        if membership_state != cluster_membership.MEMBER:
            unavailable.append("membership.member")
    presence = None
    if require_presence:
        presence = next((item for item in cluster_presence.list_presence(state_root=state_root, probe_now=False)
                         if item.get("node_id") == node_id), None)
        if not presence or presence.get("presence_state") != cluster_presence.ONLINE:
            unavailable.append("presence.authenticated")
    return {"node_id": node_id, "eligible": not missing and not unavailable,
            "requirements": required, "missing": sorted(missing),
            "unavailable": sorted(set(unavailable)), "presence": presence,
            "role": registry.get("role", "UNKNOWN"), "membership_state": membership_state,
            "capabilities": registry.get("capabilities", [])}
