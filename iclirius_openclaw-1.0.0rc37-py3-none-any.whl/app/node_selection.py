"""Pure, deterministic eligibility and node selection for CLUSTER-4.5.

Selection is advisory policy output. It has no network side effects and cannot
authorize, mutate, or execute anything.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Iterable

from app import cluster_membership, cluster_security
from app.node_capabilities import CapabilityError, MAX_CAPABILITIES, MAX_ID, MAX_NODES, MAX_REQUIREMENTS, capabilities_for, evaluate_requirements

MAX_REASONS = 12
MAX_RESULT_BYTES = 64 * 1024
LOCALITIES = {"PREFER_LOCAL", "PREFER_REMOTE", "NEUTRAL"}
ROLES = {"INTERFACE", "LOCAL_COMPUTE", "CODE_WORKER", "REMOTE_WORKER", "FULL_NODE"}


class SelectionError(ValueError):
    pass


def _local_id() -> str:
    from app.node_identity import read_node
    return str((read_node() or {}).get("node_id", ""))


def validate_requirements(value: dict | None) -> dict:
    value = value or {}
    if not isinstance(value, dict):
        raise SelectionError("MALFORMED_REQUIREMENTS")
    required = value.get("required_capabilities", [])
    preferred = value.get("preferred_capabilities", [])
    if not isinstance(required, list) or not isinstance(preferred, list):
        raise SelectionError("MALFORMED_REQUIREMENTS")
    if len(required) > MAX_REQUIREMENTS or len(preferred) > MAX_CAPABILITIES:
        raise SelectionError("REQUIREMENT_LIMIT")
    def clean(items):
        result = sorted({str(item).strip() for item in items})
        if any(not item or len(item) > MAX_ID or "." not in item for item in result):
            raise SelectionError("INVALID_CAPABILITY_REQUIREMENT")
        return result
    locality = str(value.get("locality", "NEUTRAL")).upper()
    if locality == "LOCAL": locality = "PREFER_LOCAL"
    if locality == "REMOTE": locality = "PREFER_REMOTE"
    if locality not in LOCALITIES:
        raise SelectionError("INVALID_LOCALITY")
    role = value.get("role")
    if role is not None:
        role = str(role).upper().replace("-", "_")
        if role not in ROLES:
            raise SelectionError("INVALID_ROLE_CONSTRAINT")
    preferred_node = value.get("preferred_node_id", "")
    if preferred_node and (not isinstance(preferred_node, str) or len(preferred_node) > MAX_ID):
        raise SelectionError("INVALID_PREFERRED_NODE")
    return {"required_capabilities": clean(required), "preferred_capabilities": clean(preferred),
            "presence_required": bool(value.get("presence_required", False)),
            "locality": locality, "role": role, "preferred_node_id": preferred_node or ""}


def _candidate_ids(candidates: Iterable[str] | None, state_root=None) -> list[str]:
    if candidates is None:
        registry = cluster_security.read_registry(state_root)
        values = list(registry.get("peers", {}).keys())
        local = _local_id()
        if local:
            values.append(local)
    else:
        values = list(candidates)
    clean = sorted({str(item).strip() for item in values if str(item).strip()})
    if len(clean) > MAX_NODES:
        raise SelectionError("CANDIDATE_LIMIT")
    return clean


def _is_local(node_id: str) -> bool:
    return bool(_local_id()) and node_id == _local_id()


def _membership(node_id: str, state_root=None) -> str:
    if _is_local(node_id):
        return "IMPLICIT_LOCAL"
    try:
        return next((item["effective_state"] for item in cluster_membership.list_members(state_root)
                     if item.get("node_id") == node_id), "NOT_MEMBER")
    except cluster_membership.MembershipError:
        return "INVALID_TRUST"


def _trusted(node_id: str, state_root=None) -> bool:
    if _is_local(node_id):
        return True
    peer = cluster_security.read_registry(state_root).get("peers", {}).get(node_id, {})
    return isinstance(peer, dict) and peer.get("trust_state") == cluster_security.TRUSTED


def _reasons_for(node_id: str, requirements: dict, *, state_root=None, registries=None) -> tuple[dict, list[str]]:
    reasons: list[str] = []
    if not _trusted(node_id, state_root):
        return {}, ["NOT_TRUSTED"]
    membership = _membership(node_id, state_root)
    if membership not in {"MEMBER", "IMPLICIT_LOCAL"}:
        reasons.append(membership)
    try:
        registry = (registries or {}).get(node_id) if registries is not None else None
        if registry is not None:
            by_id = {item.get("capability_id"): item for item in registry.get("capabilities", [])}
            missing = [item for item in requirements["required_capabilities"] if item not in by_id]
            unavailable = [item for item in requirements["required_capabilities"]
                           if item in by_id and by_id[item].get("availability") != "AVAILABLE"]
            if requirements["presence_required"] and registry.get("presence_state") != "ONLINE":
                unavailable.append("presence.authenticated")
            evaluation = {"node_id": node_id, "role": registry.get("role", "UNKNOWN"),
                          "capabilities": registry.get("capabilities", []),
                          "missing": missing, "unavailable": unavailable}
        else:
            evaluation = evaluate_requirements(node_id, requirements["required_capabilities"], state_root=state_root,
                                               require_presence=requirements["presence_required"])
    except (CapabilityError, OSError, ValueError, TypeError) as exc:
        return {}, [str(exc)]
    reasons.extend(f"MISSING:{item}" for item in evaluation.get("missing", []))
    reasons.extend(f"UNAVAILABLE:{item}" for item in evaluation.get("unavailable", []))
    role = str(evaluation.get("role", "UNKNOWN")).upper()
    if requirements["role"] and role != requirements["role"]:
        reasons.append("ROLE_MISMATCH")
    return evaluation, sorted(set(reasons))[:MAX_REASONS]


def select(*, requirements: dict | None = None, candidates: Iterable[str] | None = None,
           registries: dict | None = None, state_root=None) -> dict:
    policy = validate_requirements(requirements)
    ids = _candidate_ids(candidates, state_root)
    eligible: list[dict] = []
    rejected: list[dict] = []
    for node_id in ids:
        evaluation, reasons = _reasons_for(node_id, policy, state_root=state_root, registries=registries)
        if reasons:
            rejected.append({"node_id": node_id, "reasons": reasons})
            continue
        caps = {item.get("capability_id") for item in evaluation.get("capabilities", [])}
        preferred_count = sum(item in caps for item in policy["preferred_capabilities"])
        eligible.append({"node_id": node_id, "preferred_count": preferred_count,
                         "local": _is_local(node_id), "role": evaluation.get("role", "UNKNOWN")})
    if not eligible:
        result = {"state": "NO_ELIGIBLE_NODE", "selected_node": None, "eligible_nodes": [],
                  "rejected_nodes": rejected, "selection_policy": ["eligibility", "locality", "preferred_capabilities", "preferred_node_id", "node_id"],
                  "tie_break": "node_id"}
        if len(json.dumps(result, sort_keys=True)) > MAX_RESULT_BYTES:
            raise SelectionError("SELECTION_RESULT_TOO_LARGE")
        return result
    def key(item):
        locality = 0
        if policy["locality"] == "PREFER_LOCAL": locality = 0 if item["local"] else 1
        elif policy["locality"] == "PREFER_REMOTE": locality = 0 if not item["local"] else 1
        preferred = 0 if item["node_id"] == policy["preferred_node_id"] else 1
        return (locality, -item["preferred_count"], preferred, item["node_id"])
    ordered = sorted(eligible, key=key)
    selected = ordered[0]
    result = {"state": "SELECTED", "selected_node": selected["node_id"],
              "eligible_nodes": [item["node_id"] for item in ordered],
              "rejected_nodes": rejected,
              "selection_policy": ["eligibility", "locality", "preferred_capabilities", "preferred_node_id", "node_id"],
              "tie_break": "node_id", "selection_reason": {
                  "locality": policy["locality"], "preferred_capabilities": policy["preferred_capabilities"],
                  "preferred_node_id": policy["preferred_node_id"]}}
    if len(json.dumps(result, sort_keys=True)) > MAX_RESULT_BYTES:
        raise SelectionError("SELECTION_RESULT_TOO_LARGE")
    return result


def render(result: dict) -> str:
    lines = [f"STATE: {result.get('state')}", f"SELECTED: {result.get('selected_node') or 'none'}", "",
             "ELIGIBLE: " + (", ".join(result.get("eligible_nodes", [])) or "none"), "REJECTED:"]
    for item in result.get("rejected_nodes", []):
        lines.append(f"  {item['node_id']}: {', '.join(item['reasons'])}")
    lines += ["", "POLICY: " + " > ".join(result.get("selection_policy", [])),
              "TIE-BREAK: " + result.get("tie_break", "node_id")]
    return "\n".join(lines)
