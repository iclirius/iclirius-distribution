"""Role requirements and evidence-based node health."""
from __future__ import annotations

from enum import Enum


class Health(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    BLOCKED = "BLOCKED"
    OFFLINE = "OFFLINE"
    UNKNOWN = "UNKNOWN"


ROLES = ("INTERFACE", "LOCAL_COMPUTE", "CODE_WORKER", "REMOTE_WORKER", "FULL_NODE")
ROLE_ALIASES = {
    "interface": "INTERFACE", "local-compute": "LOCAL_COMPUTE", "local_compute": "LOCAL_COMPUTE",
    "code-worker": "CODE_WORKER", "code_worker": "CODE_WORKER", "remote-worker": "REMOTE_WORKER",
    "remote_worker": "REMOTE_WORKER", "full": "FULL_NODE", "full-node": "FULL_NODE",
    "full_node": "FULL_NODE", "leader": "FULL_NODE", "worker": "CODE_WORKER",
}

# Values are capability keys used by NodeCapabilityProfile and Doctor.
ROLE_REQUIREMENTS = {
    "INTERFACE": {"required": ("interface", "memory_access"),
                   "recommended": ()},
    "LOCAL_COMPUTE": {"required": ("interface", "local_reasoning", "memory_access"),
                       "recommended": ("version_control",)},
    "CODE_WORKER": {"required": ("interface", "file_access", "code_execution", "memory_access", "version_control"),
                     "recommended": ("network_outbound",)},
    "REMOTE_WORKER": {"required": ("interface", "remote_connectivity"),
                       "recommended": ("file_access", "code_execution")},
    "FULL_NODE": {"required": ("interface", "local_reasoning", "file_access", "code_execution",
                                 "memory_access", "network_outbound", "remote_connectivity"),
                   "recommended": ("version_control", "voice")},
}


def normalize_role(role: str | None) -> str:
    value = str(role or "INTERFACE").strip().lower().replace(" ", "-")
    return ROLE_ALIASES.get(value, value.upper() if value.upper() in ROLES else "INTERFACE")


def evaluate_health(profile: dict, role: str | None = None, *, peer_reachable: bool | None = None) -> dict:
    selected = normalize_role(role or profile.get("current_role") or "INTERFACE")
    requirements = ROLE_REQUIREMENTS[selected]
    caps = profile.get("capabilities", {})
    missing = [name for name in requirements["required"]
               if caps.get(name, {}).get("available") is not True]
    degraded = [name for name in requirements["recommended"]
                 if caps.get(name, {}).get("available") is not True]
    if selected == "REMOTE_WORKER" and peer_reachable is False:
        state = Health.OFFLINE.value
    elif missing:
        state = Health.BLOCKED.value
    elif degraded:
        state = Health.DEGRADED.value
    else:
        state = Health.HEALTHY.value
    return {"health": state, "role": selected, "required_missing": missing,
            "recommended_missing": degraded, "requirements": requirements}
