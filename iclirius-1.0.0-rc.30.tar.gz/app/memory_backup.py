"""
Encrypted snapshots of the canonical state.

A snapshot is a copy. It is never the authority: the active Memory Core is,
and nothing in the answering path ever reads a backup. The Context Engine has
no route here at all, which is deliberate — a stale copy quietly answering a
question would be worse than having no backup.

    Memory Core
        ↓  consistent read, under the same lock a write takes
    ciphertext, verbatim
        ↓
    encrypted snapshot  +  metadata (hashes and sizes, no content)

The state file is already encrypted, so a snapshot copies the ciphertext
rather than decrypting and re-encrypting it. That is not just cheaper: it
means no plaintext version of the memory ever exists on disk, not even for
the moment it takes to write a backup. Validation checks the hash and then
proves the copy still decrypts, without printing or returning what is inside.

Restore is not implemented and is not implicit. Reading a backup back over
live state is a decision that needs its own approval path, so this module can
only create, list, validate and prune.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

from app.config import settings
from app.logger import logger
from app.memory_core import MemoryCore, _write_lock
from app.runtime_events import EventType, Status, emit
from app.secure_storage import SecureStorageError

SCHEMA_VERSION = 1

# Owner-only. A snapshot is the whole memory in one file, so it should be no
# more readable than the state it came from.
SNAPSHOT_MODE = 0o600
DIRECTORY_MODE = 0o700

SNAPSHOT_SUFFIX = ".snapshot.enc"
METADATA_SUFFIX = ".meta.json"
SNAPSHOT_PREFIX = "openclaw-memory-"


class SnapshotError(RuntimeError):
    """A snapshot could not be created or is not usable."""


@dataclass
class SnapshotMetadata:
    """
    What a snapshot is, without any of what it contains.

    Every field here is a hash, a size, an identifier or a timestamp. There is
    deliberately no summary, no task list and no counts of anything personal:
    metadata sits in a plainer file than the snapshot itself, so it must be
    safe to read.
    """

    snapshot_id: str
    created_at: str
    source_state_fingerprint: str
    ciphertext_hash: str
    size_bytes: int
    schema_version: int = SCHEMA_VERSION
    status: str = "COMPLETED"

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "SnapshotMetadata":
        return cls(
            snapshot_id=str(payload.get("snapshot_id", "")),
            created_at=str(payload.get("created_at", "")),
            source_state_fingerprint=str(payload.get("source_state_fingerprint", "")),
            ciphertext_hash=str(payload.get("ciphertext_hash", "")),
            size_bytes=int(payload.get("size_bytes", 0) or 0),
            schema_version=int(payload.get("schema_version", 0) or 0),
            status=str(payload.get("status", "")),
        )

    def safe_summary(self) -> dict:
        """For events and status: a hash prefix is an identifier, not content."""
        return {
            "snapshot_id": self.snapshot_id,
            "bytes": self.size_bytes,
            "hash_prefix": self.ciphertext_hash[:12],
            "schema_version": self.schema_version,
            "status": self.status,
        }


@dataclass
class ValidationReport:
    snapshot_id: str
    valid: bool = False
    hash_matches: bool = False
    size_matches: bool = False
    decryptable: bool = False
    problems: list = field(default_factory=list)
    duration_ms: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


def backup_root() -> Path:
    return Path(settings.memory_backup_root).expanduser().resolve()


def _hash_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _ensure_root() -> Path:
    root = backup_root()
    root.mkdir(parents=True, exist_ok=True)

    try:
        os.chmod(root, DIRECTORY_MODE)
    except OSError:
        # A filesystem that will not take the mode is not a reason to refuse
        # the backup; it is a reason not to pretend the mode was applied.
        logger.info("Could not restrict permissions on the backup directory")

    return root


def _is_snapshot(path: Path) -> bool:
    """
    Strictly ours.

    Pruning deletes files, so the test for whether a file belongs to this
    subsystem has to be exact: our prefix, our suffix, in our directory. A
    loose match here would be a way to delete somebody else's data.
    """
    return (path.is_file()
            and path.name.startswith(SNAPSHOT_PREFIX)
            and path.name.endswith(SNAPSHOT_SUFFIX)
            and path.parent == backup_root())


def _metadata_path(snapshot: Path) -> Path:
    return snapshot.with_name(snapshot.name[:-len(SNAPSHOT_SUFFIX)] + METADATA_SUFFIX)


def create_snapshot(core: MemoryCore | None = None) -> SnapshotMetadata:
    """
    Copy the encrypted state to a snapshot, consistently.

    The read happens under the same lock a write takes, so a snapshot can
    never catch the state file halfway through being replaced. The copy is
    written to a temporary file in the destination directory and renamed, so
    an interrupted run leaves no half-snapshot behind.
    """
    started = time.monotonic()
    core = core or MemoryCore()
    snapshot_id = f"snap_{uuid.uuid4().hex[:12]}"

    emit(EventType.MEMORY_SNAPSHOT_STARTED.value, status=Status.STARTED.value,
         metadata={"snapshot_id": snapshot_id})

    try:
        state_file = core.state_file

        if not state_file.exists():
            raise SnapshotError("No hay estado que respaldar todavía.")

        # Same lock the writer takes: this is what makes the copy consistent
        # rather than merely recent.
        with _write_lock(core.lock_file, settings.memory_lock_timeout):
            ciphertext = state_file.read_bytes()

        if not ciphertext:
            raise SnapshotError("El estado está vacío.")

        root = _ensure_root()
        stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
        target = root / f"{SNAPSHOT_PREFIX}{stamp}-{snapshot_id}{SNAPSHOT_SUFFIX}"

        handle, temp_name = tempfile.mkstemp(dir=str(root))
        os.close(handle)
        temp_path = Path(temp_name)

        try:
            temp_path.write_bytes(ciphertext)
            os.chmod(temp_path, SNAPSHOT_MODE)
            os.replace(temp_path, target)
        finally:
            if temp_path.exists():
                temp_path.unlink(missing_ok=True)

        metadata = SnapshotMetadata(
            snapshot_id=snapshot_id,
            created_at=datetime.now().isoformat(timespec="seconds"),
            # A fingerprint of the ciphertext identifies the source state
            # without saying anything about it.
            source_state_fingerprint=_hash_bytes(ciphertext)[:16],
            ciphertext_hash=_hash_bytes(ciphertext),
            size_bytes=len(ciphertext),
        )

        _write_metadata(_metadata_path(target), metadata)

        duration = int((time.monotonic() - started) * 1000)

        emit(EventType.MEMORY_SNAPSHOT_COMPLETED.value, status=Status.OK.value,
             duration_ms=duration, metadata=metadata.safe_summary())

        logger.info("Memory snapshot created id=%s bytes=%s",
                    snapshot_id, metadata.size_bytes)

        return metadata
    except (SnapshotError, OSError, SecureStorageError, RuntimeError) as exc:
        emit(EventType.MEMORY_SNAPSHOT_FAILED.value, status=Status.FAILED.value,
             metadata={"snapshot_id": snapshot_id, "error": type(exc).__name__})
        raise SnapshotError(str(exc)) from exc


def _write_metadata(path: Path, metadata: SnapshotMetadata) -> None:
    handle, temp_name = tempfile.mkstemp(dir=str(path.parent))
    os.close(handle)
    temp_path = Path(temp_name)

    try:
        temp_path.write_text(json.dumps(metadata.to_dict(), indent=2),
                             encoding="utf-8")
        os.chmod(temp_path, SNAPSHOT_MODE)
        os.replace(temp_path, path)
    finally:
        if temp_path.exists():
            temp_path.unlink(missing_ok=True)


def list_snapshots() -> list[SnapshotMetadata]:
    """Newest first. Read-only, and it never opens a snapshot."""
    root = backup_root()

    if not root.is_dir():
        return []

    found: list[SnapshotMetadata] = []

    for path in sorted(root.iterdir()):
        if not _is_snapshot(path):
            continue

        meta_path = _metadata_path(path)

        if not meta_path.exists():
            continue

        try:
            found.append(SnapshotMetadata.from_dict(
                json.loads(meta_path.read_text(encoding="utf-8"))))
        except (OSError, json.JSONDecodeError):
            logger.info("Unreadable snapshot metadata: %s", meta_path.name)

    return sorted(found, key=lambda item: item.created_at, reverse=True)


def snapshot_path(snapshot_id: str) -> Path | None:
    root = backup_root()

    if not root.is_dir():
        return None

    for path in root.iterdir():
        if _is_snapshot(path) and snapshot_id in path.name:
            return path

    return None


def validate_snapshot(snapshot_id: str, core: MemoryCore | None = None
                      ) -> ValidationReport:
    """
    Check a snapshot without touching the active state.

    Three questions: is it the same bytes, is it the same size, and does it
    still decrypt with the current key. The last one is the only real proof
    that the file is usable, and it is done without returning, printing or
    logging a single character of what came out.
    """
    started = time.monotonic()
    report = ValidationReport(snapshot_id=snapshot_id)

    path = snapshot_path(snapshot_id)

    if path is None:
        report.problems.append("No encuentro ese snapshot.")
        return report

    meta_path = _metadata_path(path)

    if not meta_path.exists():
        report.problems.append("Falta la metadata del snapshot.")
        return report

    try:
        metadata = SnapshotMetadata.from_dict(
            json.loads(meta_path.read_text(encoding="utf-8")))
        ciphertext = path.read_bytes()
    except (OSError, json.JSONDecodeError) as exc:
        report.problems.append(f"No pude leerlo: {type(exc).__name__}")
        return report

    report.size_matches = len(ciphertext) == metadata.size_bytes

    if not report.size_matches:
        report.problems.append(
            f"Tamaño distinto: {len(ciphertext)} frente a {metadata.size_bytes}.")

    report.hash_matches = _hash_bytes(ciphertext) == metadata.ciphertext_hash

    if not report.hash_matches:
        report.problems.append("El hash no coincide: el archivo cambió.")

    core = core or MemoryCore()

    try:
        # Decrypted and discarded. Nothing that comes out of here is returned,
        # logged or kept; the only thing observed is that it decrypted.
        plaintext = core.secure.fernet.decrypt(ciphertext)
        json.loads(plaintext.decode("utf-8"))
        report.decryptable = True
        del plaintext
    except Exception:
        report.problems.append("No se puede descifrar o no es un estado válido.")

    report.valid = report.hash_matches and report.size_matches and report.decryptable
    report.duration_ms = int((time.monotonic() - started) * 1000)

    emit(EventType.MEMORY_SNAPSHOT_VALIDATED.value,
         status=Status.OK.value if report.valid else Status.FAILED.value,
         duration_ms=report.duration_ms,
         metadata={"snapshot_id": snapshot_id, "valid": report.valid,
                   "problems": len(report.problems)})

    return report


def prune_snapshots(keep: int | None = None) -> list[str]:
    """
    Delete the oldest snapshots beyond the retention count.

    Explicit, never automatic: create_snapshot does not call this. Deleting
    files on a schedule nobody asked for is how backups disappear the week
    before they are needed, so the caller decides when.

    Only files this module wrote, only inside the backup directory, and never
    anything to do with the active state.
    """
    keep = settings.memory_backup_retention_count if keep is None else keep

    if keep < 1:
        raise SnapshotError("La retención debe conservar al menos un snapshot.")

    snapshots = list_snapshots()

    if len(snapshots) <= keep:
        return []

    removed: list[str] = []

    for metadata in snapshots[keep:]:
        path = snapshot_path(metadata.snapshot_id)

        if path is None or not _is_snapshot(path):
            continue

        try:
            _metadata_path(path).unlink(missing_ok=True)
            path.unlink()
            removed.append(metadata.snapshot_id)
        except OSError:
            logger.info("Could not remove snapshot %s", metadata.snapshot_id)

    if removed:
        logger.info("Pruned %s old memory snapshots", len(removed))

    return removed


def backup_status() -> dict:
    """
    Compact metadata for the runtime snapshot.

    No paths: the backup directory can sit under a home folder, and a home
    folder carries a person's name.
    """
    try:
        snapshots = list_snapshots()
    except Exception:
        logger.warning("Could not read the backup directory", exc_info=False)
        return {"status": "UNKNOWN", "snapshot_count": 0}

    if not snapshots:
        return {"status": "NONE", "snapshot_count": 0}

    latest = snapshots[0]

    return {
        "status": latest.status,
        "snapshot_count": len(snapshots),
        "last_snapshot_at": latest.created_at,
        "last_snapshot_bytes": latest.size_bytes,
    }
