"""Bounded, identity-scoped conversational references for deterministic results.

This module stores only references to the existing Tool Adapter ResultSet.  It
does not retain paths or create a second query/execution engine.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass

from app.tool_adapter import ToolExecutionContext, result_set_records, get_result_set


@dataclass(frozen=True)
class ReferentResolution:
    status: str
    result_set_id: str | None = None
    record_ids: tuple[str, ...] = ()
    records: tuple = ()
    reason_code: str | None = None


class ReferentManager:
    """Resolve only explicit, recent references in one user/session scope."""

    def __init__(self, *, ttl_seconds: int = 15 * 60):
        self.ttl_seconds = ttl_seconds
        self._recent: dict[tuple[str | None, str, str | None], list[tuple[str, float]]] = {}

    def remember(self, result_set_id: str, *, context: ToolExecutionContext) -> None:
        key = (context.user_id, context.node_id or "", context.session_id)
        now = time.time()
        values = [(rid, stamp) for rid, stamp in self._recent.get(key, []) if now - stamp < self.ttl_seconds]
        values = [(rid, stamp) for rid, stamp in values if rid != result_set_id]
        values.append((result_set_id, now))
        self._recent[key] = values[-8:]

    def _candidates(self, context: ToolExecutionContext):
        key = (context.user_id, context.node_id or "", context.session_id)
        now = time.time()
        candidates = []
        for result_id, stamp in self._recent.get(key, []):
            if now - stamp >= self.ttl_seconds:
                continue
            result, reason = get_result_set(result_id, context)
            if result is not None:
                candidates.append((result_id, result))
        return candidates

    def resolve(self, expression: str, *, context: ToolExecutionContext,
                preferred_result_set_id: str | None = None) -> ReferentResolution:
        text = (expression or "").casefold().strip()
        candidates = self._candidates(context)
        if preferred_result_set_id:
            preferred = [(rid, result) for rid, result in candidates if rid == preferred_result_set_id]
            if preferred:
                candidates = preferred
        if not candidates:
            return ReferentResolution("UNRESOLVED", reason_code="NO_REFERENT")
        continuation = bool(re.search(r"\b(?:siguientes?|anteriores?|de\s+(?:esos|estos)|los\s+(?:siguientes?|anteriores?))\b", text))
        if continuation:
            result_id, result = candidates[-1]
            return ReferentResolution("RESULT_SET", result_set_id=result_id,
                                      reason_code="CONTINUATION")
        ordinal = re.search(r"\b(?:el|la|los|las)?\s*(primero|segundo|tercero|cuarto|first|second|third|fourth)\b", text)
        if ordinal:
            index = {"primero": 0, "first": 0, "segundo": 1, "second": 1,
                     "tercero": 2, "third": 2, "cuarto": 3, "fourth": 3}[ordinal.group(1)]
            result_id, _ = candidates[-1]
            rows, reason = result_set_records(result_id, context=context)
            if rows is None:
                return ReferentResolution("BLOCKED", result_set_id=result_id, reason_code=reason)
            if index >= len(rows):
                return ReferentResolution("UNRESOLVED", result_set_id=result_id, reason_code="ORDINAL_OUT_OF_RANGE")
            row = rows[index]
            return ReferentResolution("RESOLVED", result_set_id=result_id,
                                      record_ids=(row.file_id,), records=(row,))
        if re.search(r"\b(?:este|ese|estos|esos|el\s+anterior|ese\s+(?:pdf|archivo|proyecto))\b", text):
            if len(candidates) > 1 and re.search(r"\b(?:estos|esos|de\s+esos|de\s+estos)\b", text):
                return ReferentResolution("AMBIGUOUS", reason_code="AMBIGUOUS_REFERENT")
            result_id, _ = candidates[-1]
            rows, reason = result_set_records(result_id, context=context)
            if rows is None:
                return ReferentResolution("BLOCKED", result_set_id=result_id, reason_code=reason)
            if not rows:
                return ReferentResolution("UNRESOLVED", result_set_id=result_id, reason_code="EMPTY_RESULT_SET")
            row = rows[0]
            return ReferentResolution("RESOLVED", result_set_id=result_id,
                                      record_ids=(row.file_id,), records=(row,))
        return ReferentResolution("UNRESOLVED", reason_code="NO_EXPLICIT_REFERENT")
