"""
Deciding what work Iclirius needs to do.

    MODEL SUGGESTS INTENT.
    ICLIRIUS VALIDATES OPERATIONS.
    EXECUTORS PERFORM ONLY TYPED ALLOWED OPERATIONS.

The planner turns a request into a small typed plan of read-only operations.
It never produces a shell command, and there is no code path from model output
to a subprocess: a proposal is parsed as JSON, checked against a closed
allowlist, and its target is validated by the existing path policy before any
executor sees it.

Two design choices carry most of the weight:

  - Deterministic first. "muestra git status" needs no model. app.local_planner
    already maps a Spanish sentence to one typed operation, so it is used as
    the deterministic adapter rather than being replaced. The model is asked
    only when the rules genuinely cannot decide.

  - Small plans, grown by evidence. A three step plan that reacts to what it
    found beats a ten step plan written blind: fewer wrong turns, less
    context, fewer tool calls. Budgets are enforced and fail closed.
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum

from app import local_planner
from app.config import settings
from app.local_planner import Operation as ReadOperation
from app.logger import logger
from app.runtime_events import EventType, Status, emit


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class StepStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    SKIPPED = "SKIPPED"


class PlanStatus(str, Enum):
    DRAFT = "DRAFT"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"


class VerificationState(str, Enum):
    """
    How far the evidence has got.

    Reading code that looks wrong is not the same as knowing it is wrong, so
    VERIFIED_READ_ONLY means "confirmed by reading", not "fixed"; VERIFIED
    means a build or a test suite ran and passed.
    """

    NOT_STARTED = "NOT_STARTED"
    EVIDENCE_GATHERING = "EVIDENCE_GATHERING"
    READY_FOR_ACTION = "READY_FOR_ACTION"
    BLOCKED = "BLOCKED"
    VERIFIED_READ_ONLY = "VERIFIED_READ_ONLY"
    # Added in Phase 3.6, when execution became possible. The distinction that
    # matters: a written file is not a working file. MODIFIED_UNVERIFIED is
    # where a change sits until something actually ran, and VERIFIED is only
    # ever reached through a successful execution, never through a model
    # saying the fix looks right.
    MODIFIED_UNVERIFIED = "MODIFIED_UNVERIFIED"
    VERIFICATION_RUNNING = "VERIFICATION_RUNNING"
    VERIFIED = "VERIFIED"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"


# Operations the planner may emit. Read-only by construction: every entry is
# either one of the local read operations or the web search capability.
ALLOWED_OPERATIONS = {member.value for member in ReadOperation} | {
    "WEB_SEARCH",
    "ANALYZE_EVIDENCE",
}

# Named so a rejection is explicit rather than an anonymous "unknown".
FORBIDDEN_OPERATIONS = {
    "RUN_COMMAND", "SHELL", "EXEC", "BASH", "SUDO",
    "WRITE_FILE", "WRITE", "EDIT_FILE", "PATCH", "APPLY_PATCH",
    "DELETE", "DELETE_FILE", "REMOVE", "MOVE", "COPY", "RENAME", "CHMOD",
    "BUILD", "RUN_TESTS", "TEST", "INSTALL", "DEPLOY",
    "GIT_COMMIT", "GIT_PUSH", "GIT_CHECKOUT", "GIT_RESET", "GIT_CLEAN",
}

# Operations that need a filesystem target inside the allowed roots.
PATH_OPERATIONS = {member.value for member in ReadOperation}


class PlanError(ValueError):
    """Raised when a plan or step cannot be accepted."""


class ForbiddenOperationError(PlanError):
    """Raised when something asked for a mutating or shell operation."""


@dataclass
class PlanStep:
    step_id: str
    operation: str
    target: str = ""
    parameters: dict = field(default_factory=dict)
    reason: str = ""
    status: str = StepStatus.PENDING.value
    result_ref: str = ""
    error: str = ""
    created_at: str = field(default_factory=_now)
    started_at: str = ""
    completed_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Plan:
    plan_id: str
    task_id: str | None
    project_id: str | None
    goal: str
    status: str = PlanStatus.DRAFT.value
    verification_state: str = VerificationState.NOT_STARTED.value
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    steps: list[dict] = field(default_factory=list)
    current_step: int = 0
    iterations: int = 0
    tool_calls: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "Plan":
        known = {key: payload[key] for key in cls.__dataclass_fields__ if key in payload}
        return cls(**known)

    # -- step access -------------------------------------------------------

    def pending_steps(self) -> list[dict]:
        return [s for s in self.steps if s.get("status") == StepStatus.PENDING.value]

    def next_step(self) -> dict | None:
        return self.pending_steps()[0] if self.pending_steps() else None

    def find_step(self, step_id: str) -> dict | None:
        return next((s for s in self.steps if s.get("step_id") == step_id), None)

    def add_step(self, step: PlanStep) -> dict:
        if len(self.steps) >= settings.planner_max_steps:
            raise PlanError(
                f"El plan alcanzó el máximo de {settings.planner_max_steps} pasos."
            )

        record = step.to_dict()
        self.steps.append(record)
        self.updated_at = _now()
        return record

    def mark(self, step_id: str, status: str, result_ref: str = "", error: str = "") -> dict:
        step = self.find_step(step_id)

        if step is None:
            return {}

        step["status"] = status
        step["error"] = error[:300] if error else ""

        if result_ref:
            step["result_ref"] = result_ref[:300]

        if status == StepStatus.RUNNING.value:
            step["started_at"] = _now()
        elif status in (StepStatus.COMPLETED.value, StepStatus.FAILED.value,
                        StepStatus.SKIPPED.value, StepStatus.BLOCKED.value):
            step["completed_at"] = _now()

        self.updated_at = _now()
        self._refresh_status()
        return step

    def _refresh_status(self) -> None:
        statuses = [s.get("status") for s in self.steps]

        if not statuses:
            self.status = PlanStatus.DRAFT.value
        elif any(s == StepStatus.BLOCKED.value for s in statuses):
            self.status = PlanStatus.BLOCKED.value
            self.verification_state = VerificationState.BLOCKED.value
        elif all(s in (StepStatus.COMPLETED.value, StepStatus.SKIPPED.value)
                 for s in statuses):
            self.status = PlanStatus.COMPLETED.value
            if self.verification_state == VerificationState.EVIDENCE_GATHERING.value:
                self.verification_state = VerificationState.VERIFIED_READ_ONLY.value
        elif any(s == StepStatus.FAILED.value for s in statuses) and not self.pending_steps():
            self.status = PlanStatus.FAILED.value
        else:
            self.status = PlanStatus.RUNNING.value

    def compact(self) -> str:
        """A short rendering for memory and for the model. Never full results."""
        lines = [f"Plan: {self.goal}", f"Estado: {self.status} ({self.verification_state})"]

        for index, step in enumerate(self.steps, start=1):
            marker = {
                StepStatus.COMPLETED.value: "✔",
                StepStatus.FAILED.value: "✗",
                StepStatus.BLOCKED.value: "⊘",
                StepStatus.RUNNING.value: "▸",
                StepStatus.SKIPPED.value: "–",
            }.get(step.get("status"), "·")

            line = f"{marker} {index}. {step.get('operation')}"

            if step.get("target"):
                line += f" {step['target']}"
            if step.get("result_ref"):
                line += f" → {step['result_ref']}"
            if step.get("error"):
                line += f" ! {step['error'][:80]}"

            lines.append(line)

        return "\n".join(lines)[: settings.planner_max_result_chars]


# --- validation -----------------------------------------------------------


def validate_operation(operation: str) -> str:
    """Allowlist check. Anything not explicitly permitted is refused."""
    name = str(operation or "").strip().upper()

    if not name:
        raise PlanError("La operación está vacía.")

    if name in FORBIDDEN_OPERATIONS:
        raise ForbiddenOperationError(
            f"Operación no permitida en modo solo lectura: {name}"
        )

    if name not in ALLOWED_OPERATIONS:
        raise PlanError(f"Operación desconocida: {name}")

    return name


def validate_step(operation: str, target: str = "", parameters: dict | None = None) -> PlanStep:
    """
    Build a step only if every part of it is acceptable.

    Filesystem targets go through the same path policy the executors use, so a
    model cannot widen its own reach by proposing a path outside the roots.
    """
    name = validate_operation(operation)
    parameters = dict(parameters or {})
    target = str(target or "").strip()

    if name in PATH_OPERATIONS:
        if not target:
            raise PlanError(f"{name} necesita una ruta.")

        from app.file_catalog import validate_safe_path

        try:
            validate_safe_path(target)
        except PermissionError as exc:
            raise PlanError(f"Ruta no permitida para {name}: {exc}") from exc
        except RuntimeError as exc:
            raise PlanError(f"No hay roots configurados: {exc}") from exc

    if name in ("SEARCH_TEXT", "WEB_SEARCH") and not (
        target or parameters.get("query")
    ):
        raise PlanError(f"{name} necesita una consulta.")

    return PlanStep(
        step_id=f"step_{uuid.uuid4().hex[:8]}",
        operation=name,
        target=target,
        parameters={
            str(key)[:40]: str(value)[:200]
            for key, value in list(parameters.items())[:6]
        },
        reason=str(parameters.get("reason", ""))[:200],
    )


# --- model proposals ------------------------------------------------------

PROPOSAL_INSTRUCTIONS = """\
Eres el planificador de Iclirius. Propón UNA operación de solo lectura.

Operaciones permitidas y nada más:
LIST_DIRECTORY, FIND_FILES, SEARCH_TEXT, READ_TEXT_FILE, FILE_STAT,
HASH_FILE, DIRECTORY_SUMMARY, GIT_STATUS, GIT_DIFF, GIT_LOG, WEB_SEARCH,
ANALYZE_EVIDENCE.

Reglas:
- No puedes escribir, borrar, mover ni ejecutar nada.
- No propongas comandos de shell. No existen.
- Usa solo rutas que aparezcan en el contexto.
- Si la evidencia ya alcanza, responde ANALYZE_EVIDENCE.

Responde SOLO con un objeto JSON:
{"operation": "...", "target": "...", "reason": "..."}"""


def parse_proposal(raw: str) -> dict:
    """
    Extract a JSON object from model output.

    Models wrap JSON in prose and fences. Anything unparseable is an error the
    caller handles by falling back, never something to be executed.
    """
    text = (raw or "").strip()

    if not text:
        raise PlanError("El modelo no propuso nada.")

    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidate = fenced.group(1) if fenced else None

    if candidate is None:
        brace = re.search(r"\{.*\}", text, re.DOTALL)
        candidate = brace.group(0) if brace else None

    if candidate is None:
        raise PlanError("La propuesta del modelo no contiene JSON.")

    try:
        payload = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise PlanError(f"JSON inválido en la propuesta: {exc}") from exc

    if not isinstance(payload, dict):
        raise PlanError("La propuesta debe ser un objeto JSON.")

    return payload


def step_from_proposal(raw: str) -> PlanStep:
    """Model text to a validated step, or an exception. Never an execution."""
    payload = parse_proposal(raw)

    parameters = {
        key: value for key, value in payload.items()
        if key not in ("operation", "target")
    }

    return validate_step(
        payload.get("operation", ""),
        payload.get("target", "") or payload.get("path", "") or payload.get("query", ""),
        parameters,
    )


# --- planner --------------------------------------------------------------


class Planner:
    """
    Builds and grows plans.

    Never raises into the agent: planning failures degrade to an empty plan
    and the conversation continues.
    """

    def __init__(self, core=None):
        self.core = core

    # -- deterministic -----------------------------------------------------

    def deterministic_step(self, message: str, default_path: str | None = None) -> PlanStep | None:
        """
        One typed operation from the rules, or None.

        This reuses app.local_planner, which already maps Spanish to a closed
        enum with path validation. Anything it can answer costs no tokens.
        """
        try:
            operation = local_planner.validate(
                local_planner.plan(message, default_path=default_path)
            )
        except local_planner.WriteIntentError:
            raise
        except local_planner.PlanError:
            return None

        parameters = {"reason": operation.reason}

        if operation.query:
            parameters["query"] = operation.query

        try:
            return validate_step(operation.name, operation.path, parameters)
        except PlanError:
            return None

    # -- plan lifecycle ----------------------------------------------------

    def create_plan(self, goal: str, task_id: str | None = None,
                    project_id: str | None = None, interface: str = "") -> Plan:
        plan = Plan(
            plan_id=f"plan_{uuid.uuid4().hex[:10]}",
            task_id=task_id,
            project_id=project_id,
            goal=(goal or "").strip()[: settings.memory_fact_chars],
            verification_state=VerificationState.EVIDENCE_GATHERING.value,
        )

        emit(EventType.PLAN_CREATED.value, status=Status.OK.value, interface=interface,
             plan_id=plan.plan_id, task_id=task_id, project_id=project_id,
             metadata={"goal_chars": len(plan.goal)})

        return plan

    def plan_for(self, message: str, task_id: str | None = None,
                 project_id: str | None = None, default_path: str | None = None,
                 interface: str = "") -> Plan | None:
        """
        A small starting plan.

        Deterministic where possible; otherwise an empty plan the caller may
        grow with a model proposal.
        """
        if not settings.enable_planner:
            return None

        try:
            step = self.deterministic_step(message, default_path=default_path)
        except local_planner.WriteIntentError:
            raise
        except Exception:
            logger.warning("Deterministic planning failed", exc_info=False)
            step = None

        plan = self.create_plan(message, task_id=task_id, project_id=project_id,
                                interface=interface)

        if step is not None:
            plan.add_step(step)
            plan.status = PlanStatus.RUNNING.value

        return plan

    def add_proposed_step(self, plan: Plan, raw_proposal: str,
                          interface: str = "") -> dict | None:
        """
        Accept a model proposal, if and only if it survives validation.

        A refusal is a normal outcome and is recorded as an event so the UI can
        show that the model asked for something it is not allowed to do.
        """
        try:
            step = step_from_proposal(raw_proposal)
        except ForbiddenOperationError as exc:
            logger.warning("Planner refused a forbidden operation: %s", exc)
            emit(EventType.PLAN_UPDATED.value, status=Status.BLOCKED.value,
                 interface=interface, plan_id=plan.plan_id, task_id=plan.task_id,
                 metadata={"refused": "forbidden_operation"})
            return None
        except PlanError as exc:
            logger.info("Planner rejected a proposal: %s", exc)
            emit(EventType.PLAN_UPDATED.value, status=Status.SKIPPED.value,
                 interface=interface, plan_id=plan.plan_id, task_id=plan.task_id,
                 metadata={"refused": "invalid_proposal"})
            return None

        if self._duplicate(plan, step):
            return None

        try:
            record = plan.add_step(step)
        except PlanError as exc:
            logger.info("Planner refused to grow the plan: %s", exc)
            return None

        emit(EventType.PLAN_UPDATED.value, status=Status.OK.value, interface=interface,
             plan_id=plan.plan_id, task_id=plan.task_id, step_id=record["step_id"],
             operation=record["operation"],
             metadata={"steps": len(plan.steps)})

        return record

    @staticmethod
    def _duplicate(plan: Plan, step: PlanStep) -> bool:
        return any(
            existing.get("operation") == step.operation
            and existing.get("target") == step.target
            for existing in plan.steps
        )

    # -- budgets -----------------------------------------------------------

    def can_iterate(self, plan: Plan) -> bool:
        return plan.iterations < settings.planner_max_iterations

    def can_call_tool(self, plan: Plan) -> bool:
        return plan.tool_calls < settings.planner_max_tool_calls

    def budget_state(self, plan: Plan) -> dict:
        return {
            "steps": f"{len(plan.steps)}/{settings.planner_max_steps}",
            "iterations": f"{plan.iterations}/{settings.planner_max_iterations}",
            "tool_calls": f"{plan.tool_calls}/{settings.planner_max_tool_calls}",
        }


# --- evidence analysis ----------------------------------------------------


class Confidence(str, Enum):
    """
    Deliberately coarse.

    Three levels are enough to drive the loop and honest about what we can
    actually tell. Anything finer would be pseudo-precision, and the model's
    own confidence is never taken as truth: it only influences whether we
    gather one more piece of evidence.
    """

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


@dataclass
class EvidenceAnalysis:
    observations: list[str] = field(default_factory=list)
    hypothesis: str = ""
    confidence: str = Confidence.LOW.value
    recommended_next_step: str = ""
    verified_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def is_conclusive(self) -> bool:
        return self.confidence == Confidence.HIGH.value


def analyse_evidence(plan: Plan, evidence: list[str],
                     model_reasoning: str = "") -> EvidenceAnalysis:
    """
    Turn gathered evidence into observations and a hypothesis.

    Structural first: what we actually read is an observation, and how much of
    it we have drives confidence. A model's reasoning, when supplied, becomes
    the hypothesis, never an observation, because a hypothesis is exactly the
    thing that is not yet verified.
    """
    completed = [
        step for step in plan.steps
        if step.get("status") == StepStatus.COMPLETED.value
        and step.get("operation") != "ANALYZE_EVIDENCE"
    ]

    observations = [
        f"{step['operation']} {step.get('target', '')} → {step.get('result_ref', 'sin resultado')}"
        for step in completed
    ]
    observations.extend(item[:200] for item in evidence if item)

    failures = [s for s in plan.steps if s.get("status") == StepStatus.FAILED.value]

    if not completed:
        confidence = Confidence.LOW.value
    elif len(completed) >= 2 and not failures:
        confidence = Confidence.HIGH.value
    else:
        confidence = Confidence.MEDIUM.value

    hypothesis = " ".join((model_reasoning or "").split())[: settings.memory_fact_chars]

    if confidence == Confidence.LOW.value:
        recommended = "reunir más evidencia local"
    elif confidence == Confidence.MEDIUM.value:
        recommended = "una lectura adicional para confirmar"
    else:
        recommended = "evidencia suficiente para proponer un cambio"

    return EvidenceAnalysis(
        observations=observations[:8],
        hypothesis=hypothesis,
        confidence=confidence,
        recommended_next_step=recommended,
        verified_count=len(completed),
    )
