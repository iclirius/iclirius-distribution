from __future__ import annotations

import json
import os
import subprocess

from app.process_env import redacted_environment
import sys
import uuid
from datetime import datetime
from pathlib import Path
from app.config import settings


CATALOG_JOBS_DIR = Path(settings.state_path) / "catalog" / "jobs"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def new_catalog_job_id() -> str:
    return "catalog_" + datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]


def catalog_job_path(job_id: str) -> Path:
    return CATALOG_JOBS_DIR / f"{job_id}.json"


def write_catalog_job(job: dict) -> None:
    CATALOG_JOBS_DIR.mkdir(parents=True, exist_ok=True)
    catalog_job_path(job["id"]).write_text(json.dumps(job, ensure_ascii=False, indent=2))


def read_catalog_job(job_id: str) -> dict | None:
    path = catalog_job_path(job_id)

    if not path.exists():
        return None

    return json.loads(path.read_text())


def format_catalog_status(job: dict | None) -> str:
    if not job:
        return "No encontré ese job de catálogo."

    total_seen = job.get("files_seen", 0)
    dirs_seen = job.get("dirs_seen", 0)
    empty_files = job.get("empty_files", 0)
    failed = job.get("failed", 0)

    lines = [
        f"Job: {job.get('id')}",
        f"Estado: {job.get('status')}",
        f"Ruta: {job.get('root_path')}",
        f"Archivos revisados: {total_seen}",
        f"Carpetas revisadas: {dirs_seen}",
        f"Archivos vacíos: {empty_files}",
        f"Fallidos: {failed}",
    ]

    current = job.get("current_path")
    if current:
        lines.append(f"Actual: {current}")

    last_error = job.get("last_error")
    if last_error:
        lines.append(f"Último error: {last_error}")

    started_at = job.get("started_at")
    finished_at = job.get("finished_at")

    if started_at:
        lines.append(f"Inicio: {started_at}")

    if finished_at:
        lines.append(f"Fin: {finished_at}")

    report_path = job.get("report_path")
    if report_path:
        lines.append(f"Reporte: {report_path}")

    return "\n".join(lines)[:3900]


def list_catalog_jobs(limit: int = 10) -> str:
    CATALOG_JOBS_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(CATALOG_JOBS_DIR.glob("catalog_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    if not files:
        return "No hay jobs de catálogo."

    lines = ["Jobs de catálogo recientes:"]

    for path in files[:limit]:
        try:
            job = json.loads(path.read_text())
            lines.append(
                f"- {job.get('id')} | {job.get('status')} | "
                f"archivos={job.get('files_seen', 0)} | carpetas={job.get('dirs_seen', 0)} | "
                f"{job.get('root_path')}"
            )
        except Exception:
            lines.append(f"- {path.name}")

    return "\n".join(lines)[:3900]


def start_catalog_subprocess(root_path: str, chat_id: int | str, notify_every: int = 1000) -> dict:
    job_id = new_catalog_job_id()

    job = {
        "id": job_id,
        "type": "catalog_folder",
        "status": "queued",
        "root_path": root_path,
        "chat_id": str(chat_id),
        "notify_every": notify_every,
        "created_at": _now(),
        "started_at": None,
        "finished_at": None,
        "pid": None,
        "files_seen": 0,
        "dirs_seen": 0,
        "empty_files": 0,
        "failed": 0,
        "current_path": "",
        "last_error": "",
        "report_path": "",
        "catalog_path": "",
    }

    write_catalog_job(job)

    cmd = [
        sys.executable,
        "-m",
        "app.catalog_worker",
        "--job-id",
        job_id,
        "--root-path",
        root_path,
        "--chat-id",
        str(chat_id),
        "--notify-every",
        str(notify_every),
    ]

    log_path = Path("logs") / f"{job_id}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    out = log_path.open("a")

    process = subprocess.Popen(
        cmd,
        stdout=out,
        stderr=out,
        cwd=str(Path.cwd()),
        start_new_session=True,
        env=redacted_environment(),
    )

    job["status"] = "running"
    job["pid"] = process.pid
    job["started_at"] = _now()
    job["log_path"] = str(log_path)
    write_catalog_job(job)

    return job
