import json
import os
import signal
import subprocess

from app.process_env import redacted_environment
import sys
from datetime import datetime
from pathlib import Path
from app.config import settings
from typing import Any, Dict, List, Optional

from app.config import settings


JOBS_DIR = Path(settings.state_path) / "background_jobs"
LOGS_DIR = Path("logs/background_jobs")

# Each job type reads its default root from configuration at call time. There
# is no built-in fallback path: an unconfigured job fails with a clear error
# rather than walking an arbitrary directory.
SUPPORTED_JOBS = {
    "ingest_books": {
        "module": "app.ingest_worker",
        "root_setting": "LIBRARY_ROOT",
        "notify_every": 25,
    },
    "catalog_drive": {
        "module": "app.catalog_worker",
        "root_setting": "CATALOG_ROOT",
        "notify_every": 1000,
    },
}


def default_root_for(job_type: str) -> Optional[str]:
    """Configured root for a job type, or None when it is not set."""
    setting = SUPPORTED_JOBS[job_type]["root_setting"]

    root = {
        "LIBRARY_ROOT": settings.library_root,
        "CATALOG_ROOT": settings.catalog_root,
    }[setting]

    return str(root) if root is not None else None


TERMINAL_STATUSES = {"completed", "failed", "cancelled", "stopped"}
ACTIVE_STATUSES = {"pending", "running", "interrupted", "paused"}


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def normalize_path(path: str) -> str:
    return str(Path(path).expanduser())


def job_file(job_id: str) -> Path:
    return JOBS_DIR / f"{job_id}.json"


def read_job(job_id: str) -> Optional[Dict[str, Any]]:
    path = job_file(job_id)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def write_job(job: Dict[str, Any]) -> None:
    job["updated_at"] = now()
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    job_file(job["id"]).write_text(
        json.dumps(job, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def list_jobs() -> List[Dict[str, Any]]:
    jobs = []
    for path in sorted(JOBS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            jobs.append(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            continue
    return jobs


def is_pid_alive(pid: Any) -> bool:
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def make_job_id(job_type: str) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rand = os.urandom(3).hex()
    return f"{job_type}_{stamp}_{rand}"


def same_job_scope(job: Dict[str, Any], job_type: str, root_path: str) -> bool:
    return (
        job.get("type") == job_type
        and normalize_path(job.get("root_path", "")) == normalize_path(root_path)
    )


def find_existing_active_job(job_type: str, root_path: str) -> Optional[Dict[str, Any]]:
    for job in list_jobs():
        if not same_job_scope(job, job_type, root_path):
            continue

        status = job.get("status")
        if status in ACTIVE_STATUSES:
            return job

        if status == "running" and is_pid_alive(job.get("pid")):
            return job

    return None


def create_job(
    job_type: str,
    root_path: Optional[str] = None,
    chat_id: str | int = "system",
    notify_every: Optional[int] = None,
    auto_resume: bool = True,
) -> Dict[str, Any]:
    if job_type not in SUPPORTED_JOBS:
        raise ValueError(f"Unsupported background job type: {job_type}")

    spec = SUPPORTED_JOBS[job_type]
    root_path = root_path or default_root_for(job_type)

    if not root_path:
        raise ValueError(
            f"El job '{job_type}' necesita una ruta. "
            f"Define {spec['root_setting']} en .env o pasa root_path explícitamente."
        )

    root_path = normalize_path(root_path)
    notify_every = notify_every or spec["notify_every"]

    existing = find_existing_active_job(job_type, root_path)
    if existing:
        return existing

    job_id = make_job_id(job_type)

    job = {
        "id": job_id,
        "type": job_type,
        "status": "pending",
        "pid": None,
        "root_path": root_path,
        "chat_id": str(chat_id),
        "notify_every": notify_every,
        "auto_resume": auto_resume,
        "created_at": now(),
        "updated_at": now(),
        "started_at": None,
        "finished_at": None,
        "log_path": str(LOGS_DIR / f"{job_id}.log"),
        "last_error": "",
        "last_command": [],
    }

    write_job(job)
    return job


def start_job(job: Dict[str, Any]) -> Dict[str, Any]:
    job_type = job.get("type")
    if job_type not in SUPPORTED_JOBS:
        job["status"] = "failed"
        job["last_error"] = f"Unsupported job type: {job_type}"
        write_job(job)
        return job

    if is_pid_alive(job.get("pid")):
        job["status"] = "running"
        write_job(job)
        return job

    spec = SUPPORTED_JOBS[job_type]
    log_path = Path(job["log_path"])
    log_path.parent.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        "-m",
        spec["module"],
        "--job-id",
        job["id"],
        "--root-path",
        job["root_path"],
        "--chat-id",
        job.get("chat_id", "system"),
        "--notify-every",
        str(job.get("notify_every", spec["notify_every"])),
    ]

    log = log_path.open("a", encoding="utf-8")

    # The child re-reads .env for itself, so it has no reason to inherit the
    # bot token or the worker secret from this process.
    process = subprocess.Popen(
        cmd,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
        env=redacted_environment(),
    )

    job["pid"] = process.pid
    job["status"] = "running"
    job["started_at"] = job.get("started_at") or now()
    job["last_command"] = cmd
    job["last_error"] = ""
    write_job(job)

    return job


def refresh_runtime_state() -> None:
    for job in list_jobs():
        status = job.get("status")
        pid = job.get("pid")

        if status == "running" and not is_pid_alive(pid):
            job["status"] = "interrupted"
            job["last_error"] = "PID no longer alive"
            write_job(job)


def ensure_default_jobs(chat_id: str | int = "system") -> List[Dict[str, Any]]:
    """
    Crea los jobs permanentes si no existen:
    - ingest_books para libros
    - catalog_drive para Drive metadata

    No arranca duplicados.
    """
    jobs = []

    for job_type, spec in SUPPORTED_JOBS.items():
        root_path = default_root_for(job_type)

        # A job type without a configured root is simply not created. Starting
        # the node must not fail because an optional path is unset.
        if not root_path:
            continue

        job = create_job(
            job_type=job_type,
            root_path=root_path,
            chat_id=chat_id,
            notify_every=spec["notify_every"],
            auto_resume=True,
        )
        jobs.append(job)

    return jobs


def resume_jobs(chat_id: str | int = "system") -> List[Dict[str, Any]]:
    """
    Se llama al iniciar iclirius.
    - Marca running muertos como interrupted.
    - Crea jobs permanentes si faltan.
    - Arranca pending/interrupted.
    - No duplica jobs activos.
    """
    refresh_runtime_state()
    ensure_default_jobs(chat_id=chat_id)

    resumed = []

    for job in list_jobs():
        if not job.get("auto_resume", True):
            continue

        if job.get("status") in {"pending", "interrupted"}:
            resumed.append(start_job(job))

        elif job.get("status") == "running" and not is_pid_alive(job.get("pid")):
            job["status"] = "interrupted"
            write_job(job)
            resumed.append(start_job(job))

    return resumed


def stop_job(job_id: str) -> Dict[str, Any]:
    job = read_job(job_id)
    if not job:
        return {"id": job_id, "status": "missing"}

    pid = job.get("pid")
    if is_pid_alive(pid):
        try:
            os.killpg(os.getpgid(int(pid)), signal.SIGTERM)
        except Exception:
            try:
                os.kill(int(pid), signal.SIGTERM)
            except Exception:
                pass

    job["status"] = "stopped"
    job["finished_at"] = now()
    write_job(job)
    return job


def background_status(limit: int = 10) -> str:
    refresh_runtime_state()
    jobs = list_jobs()[:limit]

    if not jobs:
        return "No hay procesos de fondo registrados."

    lines = ["Procesos de fondo:"]

    for job in jobs:
        alive = is_pid_alive(job.get("pid"))
        lines.append("")
        lines.append(f"- {job.get('id')}")
        lines.append(f"  tipo: {job.get('type')}")
        lines.append(f"  estado: {job.get('status')}")
        lines.append(f"  vivo: {alive}")
        lines.append(f"  pid: {job.get('pid')}")
        lines.append(f"  ruta: {job.get('root_path')}")
        lines.append(f"  actualizado: {job.get('updated_at')}")

        if job.get("last_error"):
            lines.append(f"  último error: {job.get('last_error')}")

    return "\n".join(lines)


def answer_background_question(text: str) -> Optional[str]:
    t = (text or "").lower()

    triggers = [
        "como va",
        "cómo va",
        "continua",
        "continúa",
        "sigue",
        "procesando",
        "estado",
        "jobs",
        "procesos",
        "fondo",
        "libros van",
        "cuantos libros van",
        "cuántos libros van",
    ]

    if not any(x in t for x in triggers):
        return None

    return background_status(10)
