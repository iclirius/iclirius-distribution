"""
Legacy plaintext digest. Retired from the active path in Phase 3.9.

This appended up to 1200 characters of raw conversation to
data/memory/summary.md on every turn: unencrypted, unbounded, and growing for
as long as Iclirius ran. Nothing read it back. Its only reader was
app/context_builder.build_context_prompt, whose only caller was a legacy
prompt builder that nothing called, so the file was pure accumulation — a
plaintext transcript of every conversation, sitting next to an encrypted
Memory Core that already held the durable version.

append_digest is kept as a no-op rather than deleted so an old import cannot
crash, and the existing summary.md is left exactly as it is. Removing that
file is a decision for its owner, not for this code; app/memory_tools.py still
reads it, so the history stays visible through the interfaces that showed it
before.

Continuity now lives in the Memory Core (encrypted, atomic, locked) and in the
ConversationSummary that Phase 3.8 introduced.
"""

from __future__ import annotations

from pathlib import Path

from app.logger import logger
from app.config import settings

# Kept for the modules that still read these files. Nothing here writes them.
SUMMARY_PATH = Path(settings.memory_path) / "summary.md"
DIGEST_LOG_PATH = Path(settings.memory_path) / "digest_log.jsonl"

_warned = False


def append_digest(user_message: str, assistant_response: str) -> None:
    """
    Retired. Does nothing, on purpose.

    The signature is unchanged so existing callers keep working while they are
    removed; the plaintext write is gone.
    """
    global _warned

    if not _warned:
        _warned = True
        logger.info(
            "append_digest is retired: conversation state lives in the "
            "encrypted Memory Core, not in summary.md"
        )
