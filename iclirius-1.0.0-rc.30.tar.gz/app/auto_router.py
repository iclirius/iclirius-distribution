from __future__ import annotations

from app.delegation import should_delegate_to_worker
from app.task_queue import add_task, set_task_result
from app.worker_client import ask_worker
from app.logger import logger


def build_worker_task_prompt(message: str, worker_prompt: str | None = None) -> str:
    base_context = worker_prompt or message

    return f"""
Eres iclirius ejecutando una tarea pesada en la Mac worker.

Reglas obligatorias:
- Responde siempre en español.
- No saludes.
- No digas "A new task".
- No digas "estoy listo para ayudarte".
- No cierres con "¿qué necesitas?" ni preguntas genéricas.
- No pidas contexto si ya hay contexto disponible.
- Si falta información, entrega primero un análisis preliminar y al final lista qué información faltaría.
- Sé directo, técnico y útil.
- Entrega hallazgos concretos, riesgos y siguientes pasos accionables.
- No modifiques archivos ni sistemas.
- No inventes acceso a archivos si no se te proporcionó contenido o ruta.

Tarea solicitada por Luis:
{message}

Contexto disponible:
{base_context}

Formato de respuesta:
1. Diagnóstico breve
2. Hallazgos importantes
3. Riesgos
4. Siguientes pasos concretos
""".strip()


def auto_route_message(message: str, worker_prompt: str | None = None) -> tuple[bool, str]:
    """
    Returns:
      (handled, response)

    handled=True means the worker produced a usable answer and the caller
    should return it as-is.

    handled=False means the caller must continue with the normal local
    response path. This is the local-first guarantee: whenever the worker is
    unavailable, times out, errors, reports ok=false or returns an empty or
    otherwise unusable body, the message falls back to the local model rather
    than surfacing an infrastructure failure to the user.

    A failed delegation is still recorded in the task queue so the attempt is
    auditable via /task_result, even though the user gets a local answer.
    """
    message = message.strip()

    if not message:
        return False, ""

    delegate, reason = should_delegate_to_worker(message)

    if not delegate:
        return False, ""

    task = add_task(
        text=message,
        source="auto_router",
        priority="normal",
    )

    task_id = task["id"]

    def _fall_back_to_local(detail: str) -> tuple[bool, str]:
        """Record the failed attempt and hand control back to the local model."""
        try:
            set_task_result(task_id, "failed", detail)
        except Exception:
            logger.exception("Could not record failed worker task task_id=%s", task_id)

        logger.warning(
            "Worker delegation failed task_id=%s reason=%s detail=%s; "
            "falling back to local model",
            task_id,
            reason,
            detail,
        )

        return False, ""

    try:
        logger.info("Auto-routing task to worker task_id=%s reason=%s", task_id, reason)
        set_task_result(task_id, "running", f"Auto-routed to worker. reason={reason}")

        final_prompt = build_worker_task_prompt(message, worker_prompt=worker_prompt)
        result = ask_worker(final_prompt)

    except Exception as exc:
        # Covers connection errors, timeouts, HTTP errors, malformed JSON and
        # the RuntimeError raised by ask_worker when the worker reports ok=false.
        logger.exception("Auto-routed worker task raised task_id=%s", task_id)
        return _fall_back_to_local(str(exc))

    if not isinstance(result, str) or not result.strip():
        return _fall_back_to_local("Worker devolvió una respuesta vacía o inválida.")

    result = result.strip()
    set_task_result(task_id, "done", result)

    response = (
        f"Lo mandé a la worker.\n"
        f"- Task ID: {task_id}\n"
        f"- Motivo: {reason}\n\n"
        f"{result}"
    )

    return True, response[:3900]
