"""
Turning a long conversation into a short one without losing what it decided.

A conversation cannot grow forever, and truncating it is the wrong way to
bound it: the oldest turns are where the task was framed, so cutting from the
front throws away exactly the part that explains the rest.

    turnos recientes en bruto
              ↓
    extracción local determinista        <- estructura, sin modelo
              ↓
    hechos / decisiones / preguntas
              ↓
    ConversationSummary  +  ventana de turnos recientes
              ↓
    ContextPackage

Local first, and mostly local only. A decision, an open question and a
reference to a task are all recognisable structurally, and doing that with a
model would be spending tokens on something a regular expression already
knows. Ollama is asked for one thing — a subject line — and only when the
local pass could not derive one.

Two rules the summariser cannot break:

  - It never raises confidence. Something recorded as a model suggestion is
    still a model suggestion after summarising; passing text through a
    language model is not evidence.
  - It never invents a verified fact. Model output is a summary candidate,
    and canonical structured state always wins over it.

Compaction works inside the existing budgets. It does not introduce a new
threshold that overrides CONTEXT_HISTORY_MAX_CHARS or anything else; it
triggers when the history it is given no longer fits the budget already
configured for history.
"""

from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime

from app.config import settings
from app.logger import logger
from app.runtime_events import EventType, Status, emit

# Provenance labels, mirrored from app.task_engine so the summary can carry
# them without importing the engine into a pure text module.
MODEL_SUGGESTION = "MODEL_SUGGESTION"
LOCAL_VERIFIED = "LOCAL_VERIFIED"
WEB_EVIDENCE = "WEB_EVIDENCE"
USER = "USER"

# Confidence never increases through summarising, so there is no mapping that
# turns any of these into LOCAL_VERIFIED.
PRESERVED_PROVENANCE = frozenset({MODEL_SUGGESTION, LOCAL_VERIFIED, WEB_EVIDENCE, USER})

_GREETING = re.compile(
    r"^\s*(?:hola|buenas|buenos d[íi]as|buenas tardes|buenas noches|qu[ée] tal|"
    r"hey|hi|hello|gracias|de nada|vale|ok|okay|perfecto|genial|adi[óo]s|"
    r"hasta luego|chao)\b[\s!.,¡]*$",
    re.IGNORECASE,
)

_DECISION = re.compile(
    r"\b(?:decid[íi]|decidimos|vamos a|haremos|hagamos|usaremos|usemos|"
    r"quedamos en|acordamos|mejor\s+(?:usar|hacer)|opt[ée] por|"
    r"la soluci[óo]n es|el plan es)\b",
    re.IGNORECASE,
)

_QUESTION = re.compile(r"[¿?]")

_UNRESOLVED = re.compile(
    r"\b(?:no s[ée]|habr[íi]a que (?:mirar|ver|comprobar)|falta (?:por )?"
    r"(?:ver|comprobar|decidir)|pendiente de|queda por|no est[áa] claro|"
    r"hay que investigar)\b",
    re.IGNORECASE,
)

# An absolute path in a summary is a home directory, and a home directory is a
# person's name. The file name is what the summary actually needs.
_ABSOLUTE_PATH = re.compile(r"(?:/[^\s/]+){2,}/([^\s/]+)")

_NOISE = re.compile(
    r"<<<[A-Z_]+>>>|^\s*\[.*\]\s*$|^[-=_]{4,}$|^\s*\d+\s+(?:passed|failed)\b",
    re.MULTILINE,
)


def _clean(text: str) -> str:
    text = _ABSOLUTE_PATH.sub(r"\1", str(text or ""))

    return " ".join(_NOISE.sub(" ", text).split())


@dataclass
class SummaryItem:
    """One retained statement, with the confidence it already had."""

    text: str
    provenance: str = MODEL_SUGGESTION

    def __post_init__(self):
        if self.provenance not in PRESERVED_PROVENANCE:
            self.provenance = MODEL_SUGGESTION

        self.text = _clean(self.text)[:220]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ConversationSummary:
    """
    What a conversation was about, small enough to carry forever.

    Deliberately not a transcript. It keeps subject, intent, decisions,
    unresolved questions and conclusions, plus references to the task and
    project so continuity survives a model change.
    """

    subject: str = ""
    intent: str = ""
    decisions: list = field(default_factory=list)
    open_questions: list = field(default_factory=list)
    conclusions: list = field(default_factory=list)
    task_id: str = ""
    project_id: str = ""
    covered_turns: int = 0
    created_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    def to_dict(self) -> dict:
        return {
            "subject": self.subject,
            "intent": self.intent,
            "decisions": [item.to_dict() if isinstance(item, SummaryItem) else item
                          for item in self.decisions],
            "open_questions": list(self.open_questions),
            "conclusions": [item.to_dict() if isinstance(item, SummaryItem) else item
                            for item in self.conclusions],
            "task_id": self.task_id,
            "project_id": self.project_id,
            "covered_turns": self.covered_turns,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "ConversationSummary":
        if not payload:
            return cls()

        def items(key):
            return [
                SummaryItem(**value) if isinstance(value, dict) else SummaryItem(str(value))
                for value in (payload.get(key) or [])
            ]

        return cls(
            subject=str(payload.get("subject", "")),
            intent=str(payload.get("intent", "")),
            decisions=items("decisions"),
            open_questions=[str(value) for value in (payload.get("open_questions") or [])],
            conclusions=items("conclusions"),
            task_id=str(payload.get("task_id", "")),
            project_id=str(payload.get("project_id", "")),
            covered_turns=int(payload.get("covered_turns", 0) or 0),
            created_at=str(payload.get("created_at", "")),
        )

    def is_empty(self) -> bool:
        return not any((self.subject, self.intent, self.decisions,
                        self.open_questions, self.conclusions))

    def render_compact(self) -> str:
        """
        The summary as the model sees it.

        Provenance is shown, not dropped: a decision that came from a model
        suggestion has to still read as a suggestion after compaction.
        """
        lines = []

        if self.subject:
            lines.append(f"Tema: {self.subject}")

        if self.intent:
            lines.append(f"Intención: {self.intent}")

        if self.decisions:
            lines.append("Decisiones:")
            lines.extend(
                f"- {item.text}" + ("" if item.provenance == LOCAL_VERIFIED
                                    else f" [{item.provenance.lower()}]")
                for item in self.decisions[-4:]
            )

        if self.conclusions:
            lines.append("Conclusiones:")
            lines.extend(
                f"- {item.text}" + ("" if item.provenance == LOCAL_VERIFIED
                                    else f" [{item.provenance.lower()}]")
                for item in self.conclusions[-3:]
            )

        if self.open_questions:
            lines.append("Sin resolver:")
            lines.extend(f"- {question}" for question in self.open_questions[-3:])

        return "\n".join(lines)


# --- trigger --------------------------------------------------------------


def should_compact(history: str, turns: int = 0) -> bool:
    """
    Whether the history has outgrown the budget already configured for it.

    No new threshold. CONTEXT_HISTORY_MAX_CHARS is what history is allowed to
    occupy, so exceeding it is exactly the moment compaction is worth doing —
    the alternative is the Context Engine trimming the oldest turns away,
    which loses the same information without recording anything.
    """
    if not history:
        return False

    if len(history) > settings.context_history_max_chars:
        return True

    # Enough turns to have a thread worth keeping, even if each is short.
    return turns > settings.history_max_turns * 3


# --- local extraction -----------------------------------------------------


def _clean(text: str) -> str:
    text = _ABSOLUTE_PATH.sub(r"\1", str(text or ""))

    return " ".join(_NOISE.sub(" ", text).split())


def is_noise(text: str) -> bool:
    """Greetings and acknowledgements carry no state worth keeping."""
    stripped = _clean(text)

    return not stripped or bool(_GREETING.match(stripped))


def extract_locally(turns: list[dict]) -> ConversationSummary:
    """
    Derive the summary structurally, without a model.

    Everything here is recognisable from the shape of the text, so spending
    tokens on it would be paying for what a regular expression already knows.
    """
    summary = ConversationSummary(covered_turns=len(turns))
    seen: set[str] = set()

    first_real = ""

    for turn in turns:
        asked = _clean(turn.get("user_message", ""))
        answered = _clean(turn.get("assistant_response", ""))
        provenance = str(turn.get("provenance") or MODEL_SUGGESTION)

        if asked and not is_noise(asked):
            if not first_real:
                first_real = asked

            if _QUESTION.search(asked) and _UNRESOLVED.search(answered or ""):
                question = asked[:160]

                if question not in seen:
                    seen.add(question)
                    summary.open_questions.append(question)

        if not answered or is_noise(answered):
            continue

        sentences = re.split(r"(?<=[.!?])\s+", answered)

        for sentence in sentences:
            candidate = sentence.strip()

            if len(candidate) < 12:
                continue

            fingerprint = candidate.lower()[:80]

            if fingerprint in seen:
                continue

            if _DECISION.search(candidate):
                seen.add(fingerprint)
                summary.decisions.append(SummaryItem(candidate, provenance))
            elif _UNRESOLVED.search(candidate) and len(summary.open_questions) < 6:
                seen.add(fingerprint)
                summary.open_questions.append(candidate[:160])

    if first_real:
        summary.intent = first_real[:160]
        summary.subject = first_real[:80]

    # Bounded, like everything else that reaches a prompt.
    summary.decisions = summary.decisions[-6:]
    summary.open_questions = summary.open_questions[-4:]

    return summary


def merge_canonical(summary: ConversationSummary, task: dict | None) -> ConversationSummary:
    """
    Let the canonical task state win over anything derived from text.

    The Memory Core already holds verified facts, the blocker and the
    verification state. Those are authoritative; the summary contributes only
    what the task does not already record, and never overwrites it.
    """
    if not task:
        return summary

    summary.task_id = task.get("task_id", "") or summary.task_id
    summary.project_id = task.get("project_id", "") or summary.project_id

    goal = str(task.get("goal", "") or "").strip()

    if goal:
        summary.subject = goal[:80]

    for fact in (task.get("known_facts") or [])[-3:]:
        summary.conclusions.append(SummaryItem(str(fact), LOCAL_VERIFIED))

    blocker = str(task.get("current_blocker", "") or "").strip()

    if blocker and blocker not in summary.open_questions:
        summary.open_questions.append(blocker[:160])

    summary.conclusions = summary.conclusions[-4:]
    summary.open_questions = summary.open_questions[-4:]

    return summary


SUBJECT_PROMPT = """Resume en UNA frase de menos de 15 palabras de qué trata esta
conversación. Sólo la frase, sin comillas ni preámbulo.

{text}"""


def refine_subject(summary: ConversationSummary, turns: list[dict],
                   generate=None) -> ConversationSummary:
    """
    Ask the model for a subject line, and only that.

    The one place a model genuinely helps: naming what a conversation is
    about is a judgement, not a pattern. Everything else was already derived
    locally. A failure here is not a failure of compaction — the locally
    derived subject stands.
    """
    if generate is None or not turns:
        return summary

    text = "\n".join(
        f"{_clean(turn.get('user_message', ''))[:120]}"
        for turn in turns[-8:]
        if not is_noise(turn.get("user_message", ""))
    )[:1200]

    if not text.strip():
        return summary

    try:
        candidate = _clean(generate(SUBJECT_PROMPT.format(text=text)))
    except Exception:
        logger.info("Subject refinement failed; keeping the local subject",
                    exc_info=False)
        return summary

    # A summary candidate, not a fact: accepted only if it is plausibly a
    # subject line, and it can never introduce anything beyond the subject.
    if candidate and 8 <= len(candidate) <= 120 and "\n" not in candidate:
        summary.subject = candidate

    return summary


# --- the operation --------------------------------------------------------


@dataclass
class CompactionResult:
    summary: ConversationSummary
    before_chars: int = 0
    after_chars: int = 0
    summary_chars: int = 0
    duration_ms: int = 0
    used_model: bool = False

    @property
    def reduction_ratio(self) -> float:
        if not self.before_chars:
            return 0.0

        return max(0.0, 1 - (self.after_chars / self.before_chars))

    def as_event_metadata(self) -> dict:
        """Sizes and ratios. Never a word of the conversation."""
        return {
            "before_chars": self.before_chars,
            "after_chars": self.after_chars,
            "summary_chars": self.summary_chars,
            "reduction_ratio": round(self.reduction_ratio, 3),
            "covered_turns": self.summary.covered_turns,
            "used_model": self.used_model,
            "duration_ms": self.duration_ms,
        }


def compact(turns: list[dict], task: dict | None = None, generate=None,
            history_text: str = "", interface: str = "",
            task_id: str | None = None) -> CompactionResult | None:
    """
    Compact a conversation. Returns None when there was nothing worth doing.

    Never raises: a failed compaction must leave Iclirius answering normally
    with the history it already had.
    """
    started = time.monotonic()
    before = len(history_text or "")

    emit(EventType.COMPACTION_STARTED.value, status=Status.STARTED.value,
         interface=interface, task_id=task_id,
         metadata={"before_chars": before, "turns": len(turns or [])})

    try:
        summary = extract_locally(turns or [])
        summary = merge_canonical(summary, task)

        used_model = False

        if not summary.subject and generate is not None:
            summary = refine_subject(summary, turns or [], generate=generate)
            used_model = bool(summary.subject)

        if summary.is_empty():
            emit(EventType.COMPACTION_FAILED.value, status=Status.SKIPPED.value,
                 interface=interface, task_id=task_id,
                 metadata={"reason": "nothing_to_keep"})
            return None

        rendered = summary.render_compact()

        result = CompactionResult(
            summary=summary,
            before_chars=before,
            after_chars=len(rendered),
            summary_chars=len(rendered),
            duration_ms=int((time.monotonic() - started) * 1000),
            used_model=used_model,
        )

        emit(EventType.COMPACTION_COMPLETED.value, status=Status.OK.value,
             interface=interface, task_id=task_id,
             duration_ms=result.duration_ms,
             metadata=result.as_event_metadata())

        return result
    except Exception:
        logger.warning("Compaction failed; keeping the existing history",
                       exc_info=False)
        emit(EventType.COMPACTION_FAILED.value, status=Status.FAILED.value,
             interface=interface, task_id=task_id)
        return None
