from __future__ import annotations
import argparse
import json
from app.web import WebFetchService, WebSearchService


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius web")
    sub = parser.add_subparsers(dest="command", required=True)
    search = sub.add_parser("search"); search.add_argument("query"); search.add_argument("--max-results", type=int, default=5); search.add_argument("--json", action="store_true")
    fetch = sub.add_parser("fetch"); fetch.add_argument("url"); fetch.add_argument("--json", action="store_true")
    ask = sub.add_parser("ask"); ask.add_argument("question"); ask.add_argument("--json", action="store_true"); ask.add_argument("--explain-sources", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "search":
        result = [item.__dict__ for item in WebSearchService().search(args.query, args.max_results)]
    elif args.command == "fetch":
        result = WebFetchService().fetch(args.url)
    else:
        result = _ask(args.question)
    if getattr(args, "json", False): print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.command == "search":
        for item in result: print(f"{item['rank']}. {item['title']}\n   {item['url']}\n   {item['snippet']}")
    elif args.command == "fetch":
        print(f"{result.get('status_code')} {result.get('title') or result.get('error')}")
        if result.get("text"): print(result["text"][:2000])
    else:
        print(result.get("answer") or result.get("status"))
        print(result.get("sources_text", ""))
        if args.command == "ask" and args.explain_sources:
            print("Selección de evidencia:")
            selection = result.get("selection", {})
            print(
                f"intent={selection.get('intent')} "
                f"candidates={selection.get('candidate_count')} "
                f"selected={selection.get('selected_count')} "
                f"duplicates={selection.get('duplicate_count')} "
                f"rejected={selection.get('rejected_count')}"
            )
            for quality in selection.get("qualities", []):
                print(
                    f"[{quality['evidence_id']}] {quality['selection']} "
                    f"source={quality['source_domain'] or 'unknown'} "
                    f"relevance={quality['relevance']} "
                    f"relationship={quality['source_relationship']} — {quality['reason']}"
                )
            passages = result.get("passage_selection", {})
            print(
                f"passages={passages.get('total_passages')} "
                f"selected_passages={passages.get('selected_passage_count')} "
                f"context_chars={passages.get('context_chars_used')}/"
                f"{passages.get('context_budget_chars')}"
            )
            for passage in passages.get("passages", []):
                print(
                    f"  {passage['passage_id']} {passage['role']} "
                    f"heading={passage.get('heading') or '(none)'!r} "
                    f"relevance={passage['relevance']} — {passage['reason']}"
                )
                if passage.get("preview"):
                    print(f"    {passage['preview']}")
            print("EvidenceAssessment: " + json.dumps(result.get("assessment", {}), ensure_ascii=False))
    return 0 if (not isinstance(result, dict) or not result.get("error")) else 1


def _ask(question: str) -> dict:
    """Search, fetch bounded sources, then ask the local gateway over evidence."""
    from app.web_search import research
    from app.web_grounding import (evidence_for_bundle, build_grounded_context_package,
                                   grounded_answer, render_sources)
    from app.web_selection import select_evidence
    from app.web_passages import select_passages
    from app.web_assessment import assess_evidence
    from app.reasoning import Purpose, ReasoningRequest
    from app.reasoning_gateway import build_default_gateway
    try:
        bundle = research(question)
    except Exception as exc:
        return {"status": "SEARCH_UNAVAILABLE", "answer": "No pude consultar Internet. No hay evidencia suficiente para afirmar una respuesta.", "sources": [], "error": type(exc).__name__}
    candidates = evidence_for_bundle(bundle)
    selection = select_evidence(question, candidates)
    document_evidence = list(selection.selected)
    passages = select_passages(question, document_evidence)
    evidence = list(passages.evidence)
    assessment = assess_evidence(question, selection, passages)
    selection_data = selection.to_dict()
    passage_data = passages.to_dict()
    from app.logger import logger
    logger.info("Web evidence selection intent=%s candidates=%s selected=%s duplicates=%s rejected=%s",
                selection.intent, len(candidates), len(document_evidence), selection.duplicates,
                selection.rejected)
    logger.info("Web passage packing documents=%s passages=%s selected=%s per_evidence=%s context_chars=%s budget=%s truncated=%s",
                len(document_evidence), len(passages.candidates), len(passages.selected),
                passage_data["selected_passages_per_evidence"], passages.context_chars_used,
                passages.context_budget_chars, passage_data["truncated"])
    logger.debug("Web evidence selection details relationships=%s rejection_reasons=%s",
                 {item.evidence_id: item.source_relationship for item in selection.qualities
                  if item.selection == "SELECTED"},
                 {item.evidence_id: item.reason for item in selection.qualities
                  if item.selection == "REJECTED"})
    if assessment.status != "SUPPORTED":
        answer = grounded_answer("", evidence, assessment=assessment)
        return {"status": answer.grounding_status, "answer": answer.text,
                "sources": list(answer.citations), "sources_text": render_sources(answer),
                "evidence_count": len(evidence), "selection": selection_data,
                "candidate_count": len(candidates), "assessment": assessment.to_dict(),
                "evidence_ids": [item.evidence_id for item in evidence],
                "validation": answer.validation.to_dict(),
                "passage_selection": passage_data}
    try:
        response = build_default_gateway().submit(
            ReasoningRequest.from_package(
                build_grounded_context_package(question, evidence, passages, assessment),
                purpose=Purpose.ANALYZE_EVIDENCE.value,
                provider_preference="ollama-local"),
            mode="LOCAL",
        ).response
    except Exception as exc:
        return {"status": "REASONING_UNAVAILABLE", "answer": "", "sources": [],
                "error": type(exc).__name__, "evidence_count": len(evidence),
                "candidate_count": len(candidates), "selection": selection_data,
                "passage_selection": passage_data, "assessment": assessment.to_dict()}
    if response.status != "OK" or not response.content:
        return {"status": "REASONING_UNAVAILABLE", "answer": "", "sources": [],
                "evidence_count": len(evidence), "candidate_count": len(candidates),
                "selection": selection_data, "passage_selection": passage_data,
                "assessment": assessment.to_dict(),
                "provider": response.provider_id,
                "model": response.model_id}
    answer = grounded_answer(response.content, evidence, provider=response.provider_id, model=response.model_id,
                             assessment=assessment)
    invalid_count = (len(answer.validation.invalid) + len(answer.validation.invalid_urls)
                     + len(answer.validation.malformed))
    logger.info("Web grounding evidence_count=%s evidence_ids=%s citations=%s invalid_citations=%s status=%s",
                len(evidence), [item.evidence_id for item in evidence],
                list(answer.validation.cited), invalid_count, answer.grounding_status)
    return {"status": answer.grounding_status, "answer": answer.text,
            "sources": list(answer.citations), "sources_text": render_sources(answer),
            "evidence_count": len(evidence), "evidence_ids": [item.evidence_id for item in evidence],
            "candidate_count": len(candidates), "selection": selection_data,
            "passage_selection": passage_data,
            "assessment": assessment.to_dict(),
            "claim_evidence": list(answer.claim_evidence),
            "truncated": any(item.record.result.get("truncated", False) for item in evidence),
            "validation": answer.validation.to_dict(), "provider": answer.provider, "model": answer.model}
