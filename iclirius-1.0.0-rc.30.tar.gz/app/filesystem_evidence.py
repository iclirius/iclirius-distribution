"""Deterministic, bounded and read-only filesystem metadata evidence."""
from __future__ import annotations

import hashlib
import mimetypes
import os
import re
import stat as stat_module
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from app.config import settings
from app.evidence import Certainty, Coverage, EvidenceRecord, SourceType, certainty_for_coverage
from app.file_roots import RootProvider, detect_provider

UNKNOWN = None
METADATA_UNKNOWN = "UNKNOWN"
METADATA_NOT_APPLICABLE = "NOT_APPLICABLE"
MAX_QUERY_RESULTS = 1000
CPP_EXTENSIONS = {".cpp", ".cc", ".cxx", ".c++", ".hpp", ".hh", ".hxx"}


def canonical_file_type(name: str | Path) -> str:
    """Return one bounded, metadata-only extension classification.

    Classification is based on the final basename component only.  A hidden
    file such as ``.env`` has no extension; compound names use the final
    suffix (``archive.tar.gz`` is ``.gz``).  The value is normalized for
    matching while the original filename remains unchanged on FileRecord.
    """
    basename = Path(str(name)).name
    if not basename or basename in {".", ".."} or basename.startswith("."):
        return ""
    suffix = Path(basename).suffix.casefold()
    if not suffix or len(suffix) > 33 or not re.fullmatch(r"\.[\w-]+", suffix, flags=re.UNICODE):
        return ""
    return suffix


def _utc_stamp(value):
    if value is None:
        return None
    try:
        return datetime.fromtimestamp(float(value), timezone.utc).isoformat(timespec="seconds")
    except (OSError, OverflowError, TypeError, ValueError):
        return None


def _node_id(value=""):
    configured = value or str(getattr(settings, "node_id", "") or "")
    if configured and configured != "unknown-node":
        return configured
    try:
        from app.node_identity import read_node
        return str(read_node().get("node_id") or configured or "unknown-node")
    except Exception:
        return configured or "unknown-node"


def _user_id(value=""):
    value = value or str(getattr(settings, "user_id", "") or "")
    return value.strip() or None


def _canonical(path):
    return Path(path).expanduser().resolve(strict=False)


def _under(path, root):
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _configured_roots():
    roots = []
    for value in getattr(settings, "file_manager_allowed_roots", []) or []:
        try:
            roots.append(_canonical(value))
        except (OSError, RuntimeError, ValueError):
            pass
    return roots


@dataclass(frozen=True)
class FileRoot:
    root_id: str
    path: str
    node_id: str = ""
    user_id: str | None = None
    provider: str = RootProvider.LOCAL.value
    cloud_backed: bool = False
    display_name: str = ""

    @classmethod
    def from_path(cls, path, *, root_id="", node_id="", user_id="", require_allowed=True,
                  provider: str | None = None, cloud_backed: bool | None = None,
                  display_name: str | None = None):
        target = _canonical(path)
        configured = _configured_roots()
        if require_allowed and not configured:
            raise PermissionError("FILE_MANAGER_ALLOWED_ROOTS is not configured")
        if require_allowed and not any(_under(target, root) or target == root for root in configured):
            raise PermissionError(f"root is outside configured allowed roots: {target}")
        identity = root_id or "root_" + hashlib.sha256(str(target).encode()).hexdigest()[:16]
        detected = provider or detect_provider(target).value
        backed = (detected != RootProvider.LOCAL.value) if cloud_backed is None else cloud_backed
        return cls(identity, str(target), _node_id(node_id), _user_id(user_id), detected,
                   bool(backed), display_name or target.name)

    @property
    def path_obj(self):
        return Path(self.path)


@dataclass(frozen=True)
class FileRecord:
    file_id: str
    node_id: str
    root_id: str
    relative_path: str
    absolute_path: str
    name: str
    extension: str
    mime_type: str | None
    size_bytes: int | None
    created_at: str | None
    modified_at: str | None
    is_directory: bool | None
    is_file: bool | None
    is_symlink: bool | None
    is_hidden: bool
    accessible: bool
    observed_at: str
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    classification: str = "unknown"
    metadata_state: dict = field(default_factory=dict)

    def to_dict(self):
        value = asdict(self)
        value["errors"], value["warnings"] = list(self.errors), list(self.warnings)
        value["metadata_state"] = dict(self.metadata_state or {})
        return value


def _file_id(root, relative):
    return "file_" + hashlib.sha256(f"{root.node_id}\0{root.root_id}\0{relative}".encode()).hexdigest()[:24]


def _classification(extension, is_directory, name=""):
    if is_directory:
        return "directory"
    if re.search(r"(?:credential|password|passwd|api[_ -]?key|token|backup|recovery|secret|private[_ -]?key|\.env)", name.casefold()):
        return "sensitive_metadata"
    if extension in CPP_EXTENSIONS:
        return "cpp_related"
    if extension == ".h":
        return "c_cpp_ambiguous"
    return "unknown"


def _record(root, path, observed_at, *, st=None, errors=(), warnings=()):
    relative = "." if path == root.path_obj else path.relative_to(root.path_obj).as_posix()
    name = path.name or root.path_obj.name
    extension = canonical_file_type(name)
    error_tuple, warning_tuple = tuple(errors), list(warnings)
    is_link = bool(st is not None and stat_module.S_ISLNK(st.st_mode)) if st is not None else None
    is_dir = bool(st is not None and stat_module.S_ISDIR(st.st_mode)) if st is not None else None
    is_file = bool(st is not None and stat_module.S_ISREG(st.st_mode)) if st is not None else None
    size = int(st.st_size) if st is not None and is_file else None
    modified = _utc_stamp(getattr(st, "st_mtime", None)) if st is not None else None
    birth = getattr(st, "st_birthtime", None) if st is not None else None
    if st is not None and birth is None:
        warning_tuple.append("created_at_unavailable")
    mime, _ = mimetypes.guess_type(name)
    if mime is None and extension in CPP_EXTENSIONS | {".h"}:
        mime = "text/x-c++src" if extension != ".h" else "text/x-c"
    states = {"mime_type": METADATA_UNKNOWN if mime is None else "KNOWN",
              "size_bytes": METADATA_UNKNOWN if st is None else METADATA_NOT_APPLICABLE if not is_file else "KNOWN",
              "created_at": METADATA_UNKNOWN if st is None or birth is None else "KNOWN",
              "modified_at": METADATA_UNKNOWN if st is None or modified is None else "KNOWN"}
    return FileRecord(_file_id(root, relative), root.node_id, root.root_id, relative, str(path),
                      name, extension, mime, size, _utc_stamp(birth), modified, is_dir,
                      is_file, is_link, name.startswith("."), st is not None, observed_at,
                      error_tuple, tuple(dict.fromkeys(warning_tuple)),
                      _classification(extension, bool(is_dir), name), states)


@dataclass(frozen=True)
class FileScanSpec:
    root: FileRoot
    recursive: bool = True
    include_hidden: bool = True
    max_entries: int = getattr(settings, "file_scan_max_entries", 100_000)
    max_depth: int = getattr(settings, "file_scan_max_depth", 64)
    timeout_seconds: float = getattr(settings, "file_scan_timeout_seconds", 10.0)
    error_budget: int = getattr(settings, "file_scan_error_budget", 100)
    observed_at: str = ""


@dataclass(frozen=True)
class FileScanResult:
    root: FileRoot
    records: tuple[FileRecord, ...]
    files_discovered: int
    directories_discovered: int
    stats_ok: int
    stats_failed: int
    bytes_observed: int
    errors: tuple[dict, ...]
    warnings: tuple[str, ...]
    coverage: str
    duration_ms: int
    started_at: str
    ended_at: str
    recursive: bool
    include_hidden: bool
    max_entries: int
    max_depth: int

    def to_dict(self, *, include_records=True):
        value = asdict(self)
        value["root"] = asdict(self.root)
        value["records"] = [record.to_dict() for record in self.records] if include_records else []
        value["errors"], value["warnings"] = list(self.errors), list(self.warnings)
        return value


def scan(spec: FileScanSpec) -> FileScanResult:
    root, started_mono = spec.root, time.monotonic()
    started = datetime.now(timezone.utc)
    observed_at = spec.observed_at or started.isoformat(timespec="seconds")
    records, errors, warnings = [], [], []
    files = directories = stats_ok = stats_failed = bytes_seen = 0
    bounded = False
    try:
        root_path = root.path_obj
        if not stat_module.S_ISDIR(root_path.stat().st_mode):
            raise NotADirectoryError(root.path)
    except (OSError, ValueError) as exc:
        ended = datetime.now(timezone.utc)
        return FileScanResult(root, (), 0, 0, 0, 1, 0, ({"path": root.path, "reason": type(exc).__name__},), (), "FAILED", 0,
                              started.isoformat(timespec="seconds"), ended.isoformat(timespec="seconds"), spec.recursive, spec.include_hidden, spec.max_entries, spec.max_depth)
    stack = [(root.path_obj, 0)]
    while stack:
        current, depth = stack.pop()
        try:
            entries = sorted(os.scandir(current), key=lambda entry: entry.name.casefold())
        except OSError as exc:
            errors.append({"path": str(current), "reason": type(exc).__name__})
            if len(errors) >= spec.error_budget:
                bounded = True
                break
            continue
        for entry in entries:
            if not spec.include_hidden and entry.name.startswith("."):
                continue
            if len(records) >= max(0, spec.max_entries) or time.monotonic() - started_mono >= max(0.0, spec.timeout_seconds):
                bounded = True
                break
            path = Path(entry.path)
            try:
                st = entry.stat(follow_symlinks=False)
                record = _record(root, path, observed_at, st=st)
                records.append(record)
                stats_ok += 1
                if record.is_file:
                    files += 1
                    bytes_seen += record.size_bytes or 0
                elif record.is_directory:
                    directories += 1
                    if spec.recursive and depth < spec.max_depth and not record.is_symlink:
                        stack.append((path, depth + 1))
                    elif spec.recursive and depth >= spec.max_depth:
                        bounded = True
                elif record.is_symlink:
                    warnings.append("symlink_not_followed")
            except (OSError, ValueError) as exc:
                stats_failed += 1
                errors.append({"path": str(path), "reason": type(exc).__name__})
                records.append(_record(root, path, observed_at, errors=(type(exc).__name__,)))
                if len(errors) >= spec.error_budget:
                    bounded = True
                    break
        if bounded:
            break
    ended = datetime.now(timezone.utc)
    coverage = "FAILED" if errors and stats_ok == 0 else "PARTIAL" if errors or bounded else "COMPLETE"
    return FileScanResult(root, tuple(records), files, directories, stats_ok, stats_failed, bytes_seen,
                          tuple(errors), tuple(dict.fromkeys(warnings)), coverage,
                          int((time.monotonic() - started_mono) * 1000), started.isoformat(timespec="seconds"), ended.isoformat(timespec="seconds"),
                          spec.recursive, spec.include_hidden, spec.max_entries, spec.max_depth)


def _scan_legacy(root, *, recursive=True, include_hidden=True, follow_symlinks=False,
                 max_entries=100_000, max_duration_seconds=10.0, node_id=""):
    file_root = FileRoot.from_path(root, node_id=node_id, require_allowed=False)
    return scan(FileScanSpec(file_root, recursive, include_hidden, max_entries, 64, max_duration_seconds))


def inventory(root, **kwargs):
    if not Path(root).expanduser().exists():
        target = _canonical(root)
        file_root = FileRoot.from_path(target, node_id=kwargs.get("node_id", ""), require_allowed=False)
        coverage = Coverage(complete=True, scanned_items=0)
        return EvidenceRecord(SourceType.FILESYSTEM.value, "inventory", str(target),
                              {"exists": False, "root": str(target), "regular_files": 0, "directories": 0,
                               "symlinks": 0, "other_entries": 0, "total_bytes": 0, "extension_counts": {},
                               "largest_files": [], "oldest_files": [], "newest_files": [], "skipped": []},
                              coverage, Certainty.VERIFIED.value, evidence_id=_file_id(file_root, ".inventory"),
                              node_id=file_root.node_id, tool_id="filesystem_evidence")
    result = _scan_legacy(root, **kwargs)
    extension_counts, candidates = {}, []
    symlinks = other = 0
    for record in result.records:
        if record.is_symlink:
            symlinks += 1
        elif record.is_file:
            extension_counts[record.extension or "[no extension]"] = extension_counts.get(record.extension or "[no extension]", 0) + 1
            candidates.append(record)
        elif not record.is_directory:
            other += 1
    largest = sorted(candidates, key=lambda r: (r.size_bytes or 0, r.relative_path), reverse=True)[:10]
    oldest = sorted(candidates, key=lambda r: (r.modified_at or "", r.relative_path))[:10]
    newest = sorted(candidates, key=lambda r: (r.modified_at or "", r.relative_path), reverse=True)[:10]
    payload = {"exists": Path(result.root.path).exists(), "root": result.root.path, "recursive": result.recursive,
               "hidden_included": result.include_hidden, "follow_symlinks": False, "regular_files": result.files_discovered,
               "directories": result.directories_discovered, "symlinks": symlinks, "other_entries": other,
               "total_bytes": result.bytes_observed, "extension_counts": extension_counts,
               "largest_files": [{"path": r.relative_path, "bytes": r.size_bytes} for r in largest],
               "oldest_files": [{"path": r.relative_path, "timestamp": r.modified_at} for r in oldest],
               "newest_files": [{"path": r.relative_path, "timestamp": r.modified_at} for r in newest],
               "skipped": [e["reason"] for e in result.errors]}
    coverage = Coverage(complete=result.coverage == "COMPLETE", scanned_items=len(result.records), inaccessible_items=result.stats_failed,
                        permission_denied=sum(e["reason"] == "PermissionError" for e in result.errors), errors=len(result.errors), skipped_items=len(result.errors), reason=result.coverage)
    return EvidenceRecord(SourceType.FILESYSTEM.value, "inventory", result.root.path, payload, coverage, certainty_for_coverage(coverage),
                          evidence_id=_file_id(result.root, ".inventory"), observed_at=result.started_at,
                          provenance={"root_id": result.root.root_id, "scope": {"recursive": result.recursive, "include_hidden": result.include_hidden},
                                      "started_at": result.started_at, "ended_at": result.ended_at, "coverage_status": result.coverage},
                          node_id=result.root.node_id, tool_id="filesystem_evidence", duration_ms=result.duration_ms,
                          errors=tuple(e["reason"] for e in result.errors), warnings=result.warnings)


def count_files(root, **kwargs):
    record = inventory(root, **kwargs)
    result = {key: record.result[key] for key in ("root", "regular_files", "directories", "total_bytes", "exists")}
    return EvidenceRecord(record.source_type, "count_files", record.target, result, record.coverage, record.certainty,
                          evidence_id=record.evidence_id, observed_at=record.observed_at, provenance=record.provenance,
                          node_id=record.node_id, tool_id=record.tool_id, duration_ms=record.duration_ms,
                          errors=record.errors, warnings=record.warnings)


@dataclass(frozen=True)
class FileQuery:
    root_id: str | None = None
    path_prefix: str | None = None
    filename: str | None = None
    name_contains: str | None = None
    extension: str | None = None
    size_gt: int | None = None
    size_lt: int | None = None
    modified_before: str | None = None
    modified_after: str | None = None
    classification: str | None = None
    hidden: bool | None = None
    is_file: bool | None = None
    is_directory: bool | None = None
    recursive: bool | None = None
    limit: int = MAX_QUERY_RESULTS


def query(records: Iterable[FileRecord], specification: FileQuery):
    def keep(record):
        if not record.accessible:
            return False
        if specification.root_id is not None and record.root_id != specification.root_id:
            return False
        if specification.path_prefix is not None:
            prefix = specification.path_prefix.strip("/") or "."
            if prefix == ".":
                prefix_match = True
            else:
                prefix_match = record.relative_path == prefix or record.relative_path.startswith(prefix.rstrip("/") + "/")
            if not prefix_match:
                return False
        if specification.hidden is not None and record.is_hidden != specification.hidden:
            return False
        if specification.is_file is not None and record.is_file != specification.is_file:
            return False
        if specification.is_directory is not None and record.is_directory != specification.is_directory:
            return False
        if specification.is_file is None and specification.is_directory is None and not record.is_file:
            return False
        if specification.filename is not None and record.name != specification.filename:
            return False
        if specification.name_contains is not None and specification.name_contains.casefold() not in record.name.casefold():
            return False
        if specification.extension is not None and record.extension != specification.extension.casefold():
            return False
        if specification.classification is not None and record.classification != specification.classification:
            return False
        if specification.size_gt is not None and (record.size_bytes is None or record.size_bytes <= specification.size_gt):
            return False
        if specification.size_lt is not None and (record.size_bytes is None or record.size_bytes >= specification.size_lt):
            return False
        if specification.modified_before is not None and (record.modified_at is None or record.modified_at >= specification.modified_before):
            return False
        if specification.modified_after is not None and (record.modified_at is None or record.modified_at <= specification.modified_after):
            return False
        return True
    return tuple(sorted((record for record in records if keep(record)), key=lambda r: r.relative_path)[:max(0, min(specification.limit, MAX_QUERY_RESULTS))])


def file_summary(records: Iterable[FileRecord], *, limit: int = 10) -> dict:
    """Deterministic metadata aggregates; never opens a file."""
    rows = list(records)
    files = [row for row in rows if row.accessible and row.is_file]
    directories = [row for row in rows if row.accessible and row.is_directory]
    dated = [row for row in files if row.modified_at]
    ordered_size = sorted(files, key=lambda row: (row.size_bytes or 0, row.relative_path))
    ordered_date = sorted(dated, key=lambda row: (row.modified_at, row.relative_path))
    extensions = {}
    for row in files:
        key = row.extension or "[no extension]"
        extensions[key] = extensions.get(key, 0) + 1
    bounded = max(0, min(limit, MAX_QUERY_RESULTS))
    largest = list(reversed(ordered_size[-bounded:])) if bounded else []
    smallest = ordered_size[:bounded] if bounded else []
    oldest = ordered_date[:bounded] if bounded else []
    newest = list(reversed(ordered_date[-bounded:])) if bounded else []
    return {"files": len(files), "directories": len(directories),
            "total_bytes": sum(row.size_bytes or 0 for row in files),
            "extension_counts": dict(sorted(extensions.items())),
            "largest_files": [row.to_dict() for row in largest],
            "smallest_files": [row.to_dict() for row in smallest],
            "oldest_modified": [row.to_dict() for row in oldest],
            "newest_modified": [row.to_dict() for row in newest]}


def age_since_modified(record, *, now):
    if not record.modified_at:
        return None
    try:
        stamp = datetime.fromisoformat(record.modified_at)
        current = now if now.tzinfo else now.replace(tzinfo=timezone.utc)
        return max(0.0, (current - stamp).total_seconds())
    except (TypeError, ValueError):
        return None


def file_scan_evidence(result: FileScanResult):
    coverage = Coverage(complete=result.coverage == "COMPLETE", scanned_items=len(result.records), inaccessible_items=result.stats_failed,
                        permission_denied=sum(e["reason"] == "PermissionError" for e in result.errors), errors=len(result.errors),
                        skipped_items=len(result.errors), reason=result.coverage)
    payload = result.to_dict(include_records=True)
    payload["coverage_status"] = result.coverage
    return EvidenceRecord(SourceType.FILESYSTEM.value, "metadata_inventory", result.root.path, payload, coverage,
                          certainty_for_coverage(coverage), evidence_id="scan_" + hashlib.sha256((result.root.root_id + result.started_at).encode()).hexdigest()[:20],
                          observed_at=result.started_at,
                          provenance={"root_id": result.root.root_id, "node_id": result.root.node_id, "user_id": result.root.user_id,
                                      "scope": {"recursive": result.recursive, "include_hidden": result.include_hidden, "max_entries": result.max_entries, "max_depth": result.max_depth},
                                      "coverage_status": result.coverage}, node_id=result.root.node_id,
                          tool_id="filesystem_inventory", duration_ms=result.duration_ms,
                          errors=tuple(e["reason"] for e in result.errors), warnings=result.warnings)
