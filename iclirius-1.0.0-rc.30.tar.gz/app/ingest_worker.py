from __future__ import annotations

import argparse
import json
import os
import traceback
from datetime import datetime
from pathlib import Path

import requests

from app.file_catalog import validate_safe_path
from app.ingest_jobs import read_job, write_job
from app.file_state import should_skip_file, mark_file
from app.library_ingest import (
    SUPPORTED_EXTENSIONS,
    DIGEST_DIR,
    CHUNKS_DIR,
    SOURCES_PATH,
    extract_text,
    chunk_text,
    _source_id,
    _doc_id,
)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def send_telegram(chat_id: str, text: str) -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

    if not token:
        return

    try:
        requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={
                "chat_id": chat_id,
                "text": text[:3900],
            },
            timeout=20,
        )
    except Exception:
        pass


def append_source(source: dict) -> None:
    SOURCES_PATH.parent.mkdir(parents=True, exist_ok=True)

    existing = SOURCES_PATH.read_text().splitlines() if SOURCES_PATH.exists() else []
    existing_ids = set()

    for line in existing:
        try:
            existing_ids.add(json.loads(line).get("id"))
        except Exception:
            continue

    if source["id"] in existing_ids:
        return

    with SOURCES_PATH.open("a") as f:
        f.write(json.dumps(source, ensure_ascii=False) + "\n")


def update_job(job_id: str, **updates) -> dict:
    job = read_job(job_id)

    if not job:
        raise RuntimeError(f"No encontré job {job_id}")

    job.update(updates)
    job["updated_at"] = _now()
    write_job(job)
    return job


def collect_files(root: Path) -> list[Path]:
    files = []

    for path in root.rglob("*"):
        try:
            path = validate_safe_path(path)

            if not path.is_file():
                continue

            if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            files.append(path)
        except Exception:
            continue

    return files


def run(job_id: str, root_path: str, chat_id: str, notify_every: int) -> None:
    root = validate_safe_path(root_path)

    if not root.exists():
        raise FileNotFoundError(f"No existe la ruta: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"No es carpeta: {root}")

    DIGEST_DIR.mkdir(parents=True, exist_ok=True)
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)

    source_id = _source_id(root)

    append_source({
        "id": source_id,
        "path": str(root),
        "type": "folder",
        "mode": "read_only",
        "created_at": _now(),
    })

    files = collect_files(root)
    total = len(files)

    update_job(
        job_id,
        status="running",
        total_files=total,
        source_id=source_id,
        started_at=_now(),
    )

    send_telegram(
        chat_id,
        f"Ingesta iniciada.\nJob ID: {job_id}\nArchivos detectados: {total}\nRuta: {root}",
    )

    docs = []
    processed = 0
    skipped = 0
    failed = 0

    for index, path in enumerate(files, start=1):
        try:
            update_job(job_id, current_file=str(path))

            text = extract_text(path)

            if not text.strip():
                skipped += 1
                update_job(job_id, skipped=skipped)
                continue

            doc_id = _doc_id(path)
            chunks = chunk_text(text)

            if not chunks:
                skipped += 1
                update_job(job_id, skipped=skipped)
                continue

            chunk_path = CHUNKS_DIR / f"{doc_id}.jsonl"

            with chunk_path.open("w") as f:
                for chunk_index, chunk in enumerate(chunks):
                    row = {
                        "doc_id": doc_id,
                        "source_id": source_id,
                        "chunk_id": f"{doc_id}_{chunk_index}",
                        "path": str(path),
                        "name": path.name,
                        "index": chunk_index,
                        "text": chunk,
                    }
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")

            processed += 1

            docs.append({
                "doc_id": doc_id,
                "path": str(path),
                "name": path.name,
                "extension": path.suffix.lower(),
                "size": path.stat().st_size,
                "chunks": len(chunks),
                "preview": text[:500].replace("\n", " ").strip(),
            })

            update_job(job_id, processed=processed)

            if notify_every > 0 and index % notify_every == 0:
                pct = round(index * 100 / total, 2) if total else 0
                send_telegram(
                    chat_id,
                    f"Ingesta en progreso.\nJob ID: {job_id}\nAvance: {index}/{total} ({pct}%)\nProcesados: {processed}\nOmitidos: {skipped}\nFallidos: {failed}\nÚltimo: {path.name}",
                )

        except Exception as exc:
            failed += 1
            update_job(
                job_id,
                failed=failed,
                last_error=f"{path}: {exc}",
            )

    digest_path = DIGEST_DIR / f"{source_id}.md"

    lines = [
        f"# Digest de fuente {source_id}",
        "",
        f"Ruta original: {root}",
        f"Fecha: {_now()}",
        f"Documentos procesados: {processed}",
        f"Omitidos: {skipped}",
        f"Fallidos: {failed}",
        "",
        "## Documentos",
    ]

    for doc in docs:
        lines.append(f"\n### {doc['name']}")
        lines.append(f"- Ruta: {doc['path']}")
        lines.append(f"- Chunks: {doc['chunks']}")
        lines.append(f"- Vista previa: {doc['preview']}")

    digest_path.write_text("\n".join(lines))

    update_job(
        job_id,
        status="done",
        processed=processed,
        skipped=skipped,
        failed=failed,
        current_file="",
        finished_at=_now(),
        digest_path=str(digest_path),
    )

    send_telegram(
        chat_id,
        f"Ingesta completada.\nJob ID: {job_id}\nTotal detectados: {total}\nProcesados: {processed}\nOmitidos: {skipped}\nFallidos: {failed}\nDigest: {digest_path}",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--root-path", required=True)
    parser.add_argument("--chat-id", required=True)
    parser.add_argument("--notify-every", type=int, default=25)
    args = parser.parse_args()

    try:
        run(args.job_id, args.root_path, args.chat_id, args.notify_every)
        return 0
    except Exception as exc:
        try:
            update_job(
                args.job_id,
                status="failed",
                last_error=str(exc),
                traceback=traceback.format_exc(),
                finished_at=_now(),
            )
        except Exception:
            pass

        send_telegram(
            args.chat_id,
            f"Ingesta falló.\nJob ID: {args.job_id}\nError: {exc}",
        )
        raise


if __name__ == "__main__":
    raise SystemExit(main())
