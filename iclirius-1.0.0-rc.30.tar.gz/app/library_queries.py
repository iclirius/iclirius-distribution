import json
import re
import unicodedata
from pathlib import Path
from app.config import settings
from typing import Dict, List, Optional


from app.config import settings


CHUNKS_DIR = Path(settings.state_path) / "library" / "chunks"


def _norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.lower()
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _clean_title(filename: str) -> str:
    name = filename
    name = re.sub(r"\.epub$", "", name, flags=re.I)
    name = re.sub(r"\.pdf$", "", name, flags=re.I)
    name = re.sub(r"\.mobi$", "", name, flags=re.I)
    name = re.sub(r"\.azw3$", "", name, flags=re.I)
    name = re.sub(r"\.txt$", "", name, flags=re.I)
    name = re.sub(r"\s*-\s*haruki murakami.*$", "", name, flags=re.I)
    name = re.sub(r"^haruki[\s-]+murakami[\s-]*", "", name, flags=re.I)
    name = re.sub(r"\(\d+\)", "", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name


def find_drive_books(author_query: str, books_dir: Path | None = None) -> List[Dict]:
    q = _norm(author_query)
    results = []

    if books_dir is None:
        books_dir = settings.library_root

    # No configured library root means no source folder to search. Returning
    # an empty result keeps the caller working off the local index only.
    if books_dir is None or not books_dir.exists():
        return results

    for path in books_dir.rglob("*"):
        if not path.is_file():
            continue

        if path.suffix.lower() not in {".epub", ".pdf", ".mobi", ".azw3", ".txt"}:
            continue

        haystack = _norm(str(path))
        if q in haystack:
            results.append({
                "name": path.name,
                "title": _clean_title(path.name),
                "path": str(path),
                "source": "drive",
            })

    return sorted(results, key=lambda x: x["name"].lower())


def find_indexed_books(author_query: str, chunks_dir: Path = CHUNKS_DIR) -> List[Dict]:
    q = _norm(author_query)
    seen = {}

    if not chunks_dir.exists():
        return []

    for file in chunks_dir.glob("*.jsonl"):
        try:
            with file.open("r", encoding="utf-8") as f:
                for line in f:
                    try:
                        row = json.loads(line)
                    except Exception:
                        continue

                    path = row.get("path", "")
                    name = row.get("name", "")
                    doc_id = row.get("doc_id", "")
                    haystack = _norm(f"{path} {name}")

                    if q in haystack:
                        seen[path] = {
                            "name": name,
                            "title": _clean_title(name),
                            "path": path,
                            "doc_id": doc_id,
                            "source": "index",
                        }
                        break
        except Exception:
            continue

    return sorted(seen.values(), key=lambda x: x["name"].lower())


def group_unique_titles(items: List[Dict]) -> Dict[str, List[Dict]]:
    groups = {}

    for item in items:
        key = _norm(_clean_title(item.get("name", "")))
        key = re.sub(r"\s+", " ", key).strip()
        groups.setdefault(key, []).append(item)

    return groups


def extract_author_query(text: str) -> Optional[str]:
    t = _norm(text)

    known = {
        "haruki murakami": "murakami",
        "murakami": "murakami",
        "haruki": "haruki",
    }

    for k, v in known.items():
        if k in t:
            return v

    m = re.search(r"(?:de|del autor|autor)\s+([a-záéíóúñü\s]{3,80})", text, flags=re.I)
    if m:
        return m.group(1).strip()

    return None


def is_library_question(text: str) -> bool:
    t = _norm(text)
    triggers = [
        "libro",
        "libros",
        "autor",
        "autores",
        "murakami",
        "haruki",
        "procesado",
        "procesados",
        "aprendido",
        "aprendiste",
        "catalogo",
        "catálogo",
        "biblioteca",
    ]
    return any(x in t for x in triggers)


def answer_library_question(text: str) -> Optional[str]:
    if not is_library_question(text):
        return None

    author = extract_author_query(text)
    t = _norm(text)

    if not author:
        return None

    drive_books = find_drive_books(author)
    indexed_books = find_indexed_books(author)

    drive_groups = group_unique_titles(drive_books)
    indexed_groups = group_unique_titles(indexed_books)

    wants_names = any(x in t for x in [
        "cuales",
        "cuáles",
        "nombres",
        "lista",
        "listame",
        "lí­stame",
        "dime cuales",
        "dime cuáles",
        "que libros",
        "qué libros",
    ])

    wants_count = any(x in t for x in [
        "cuantos",
        "cuántos",
        "cuanto",
        "cuánto",
        "van",
        "conteo",
    ])

    lines = []
    lines.append(f"Encontré esto para: {author}")
    lines.append("")

    if settings.library_root is None:
        lines.append("- Carpeta de origen: NO CONFIGURADA (define LIBRARY_ROOT en .env)")

    lines.append(f"- En Drive: {len(drive_books)} archivos")
    lines.append(f"- Títulos únicos aproximados en Drive: {len(drive_groups)}")
    lines.append(f"- Procesados/indexados: {len(indexed_books)} archivos")
    lines.append(f"- Títulos únicos procesados/indexados: {len(indexed_groups)}")

    if wants_names or not wants_count:
        lines.append("")
        lines.append("Títulos en Drive:")
        for i, key in enumerate(sorted(drive_groups.keys()), 1):
            title = drive_groups[key][0].get("title") or drive_groups[key][0].get("name")
            dupes = len(drive_groups[key])
            suffix = f" ({dupes} archivos)" if dupes > 1 else ""
            lines.append(f"{i}. {title}{suffix}")

        if indexed_books:
            lines.append("")
            lines.append("Ya procesados/indexados:")
            for i, key in enumerate(sorted(indexed_groups.keys()), 1):
                title = indexed_groups[key][0].get("title") or indexed_groups[key][0].get("name")
                lines.append(f"{i}. {title}")

    return "\n".join(lines)
