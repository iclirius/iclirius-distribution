"""Opt-in Telegram active/standby lease primitives.

The provider is injectable.  The bundled file provider is suitable for one
machine and tests; it is intentionally not advertised as a distributed lock
for a synchronized cloud folder.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import threading
import time
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


STATES = ("DISABLED", "STANDBY", "ACQUIRING", "ACTIVE", "DEGRADED", "BLOCKED")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.isoformat(timespec="seconds")


def bot_fingerprint(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:24]


@dataclass(frozen=True)
class TelegramLease:
    lease_id: str
    bot_identity_fingerprint: str
    owner_node_id: str
    owner_user_id: str
    acquired_at: str
    heartbeat_at: str
    expires_at: str
    generation: int
    state: str = "ACTIVE"

    def to_dict(self) -> dict:
        return asdict(self)

    def valid(self, now: datetime | None = None) -> bool:
        try:
            return datetime.fromisoformat(self.expires_at) > (now or _now())
        except ValueError:
            return False


class LeaseBusy(RuntimeError):
    pass


class TelegramLeaseProvider:
    def acquire(self, *, bot_token: str, node_id: str, user_id: str,
                ttl_seconds: int = 30) -> TelegramLease:
        raise NotImplementedError

    def heartbeat(self, lease: TelegramLease, *, ttl_seconds: int = 30) -> TelegramLease:
        raise NotImplementedError

    def release(self, lease: TelegramLease) -> None:
        raise NotImplementedError

    def current(self, bot_token: str) -> TelegramLease | None:
        raise NotImplementedError


class FileTelegramLeaseProvider(TelegramLeaseProvider):
    """Atomic local provider; use a real shared store before multi-host use."""
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()
        self._lock = threading.Lock()

    def _read(self) -> TelegramLease | None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return TelegramLease(**data)
        except (OSError, ValueError, TypeError):
            return None

    @contextmanager
    def _exclusive(self):
        """Serialize writers; the lease file itself remains token-free."""
        import fcntl
        lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        lock_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with lock_path.open("a+") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def current(self, bot_token: str) -> TelegramLease | None:
        lease = self._read()
        return lease if lease and lease.bot_identity_fingerprint == bot_fingerprint(bot_token) and lease.valid() else None

    def acquire(self, *, bot_token: str, node_id: str, user_id: str,
                ttl_seconds: int = 30) -> TelegramLease:
        with self._lock, self._exclusive():
            old = self._read()
            if old and old.valid() and old.owner_node_id != node_id:
                raise LeaseBusy("another node owns the active Telegram lease")
            now = _now()
            generation = (old.generation + 1) if old else 1
            lease = TelegramLease(secrets.token_urlsafe(12), bot_fingerprint(bot_token),
                                  node_id, user_id, _iso(now), _iso(now),
                                  _iso(now + timedelta(seconds=max(5, ttl_seconds))), generation)
            self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            temp = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
            temp.write_text(json.dumps(lease.to_dict(), sort_keys=True), encoding="utf-8")
            os.chmod(temp, 0o600)
            os.replace(temp, self.path)
            return lease

    def heartbeat(self, lease: TelegramLease, *, ttl_seconds: int = 30) -> TelegramLease:
        with self._lock, self._exclusive():
            current = self._read()
            if not current or current.lease_id != lease.lease_id or current.generation != lease.generation:
                raise LeaseBusy("lease fencing token is stale")
            now = _now()
            renewed = TelegramLease(lease.lease_id, lease.bot_identity_fingerprint,
                                    lease.owner_node_id, lease.owner_user_id,
                                    lease.acquired_at, _iso(now),
                                    _iso(now + timedelta(seconds=max(5, ttl_seconds))),
                                    lease.generation)
            temp = self.path.with_name(f".{self.path.name}.{os.getpid()}.tmp")
            temp.write_text(json.dumps(renewed.to_dict(), sort_keys=True), encoding="utf-8")
            os.chmod(temp, 0o600); os.replace(temp, self.path)
            return renewed

    def release(self, lease: TelegramLease) -> None:
        with self._lock, self._exclusive():
            current = self._read()
            if current and current.lease_id == lease.lease_id and current.generation == lease.generation:
                self.path.unlink(missing_ok=True)


class SQLiteTelegramLeaseProvider(TelegramLeaseProvider):
    """Transactional provider for a reliable shared SQLite volume.

    SQLite over consumer cloud-sync folders is explicitly unsupported.  The
    caller must provide a database location with real cross-node locking.
    """
    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with sqlite3.connect(self.path, timeout=5) as db:
            db.execute("CREATE TABLE IF NOT EXISTS telegram_leases (bot TEXT PRIMARY KEY, payload TEXT NOT NULL)")

    def _connect(self):
        return sqlite3.connect(self.path, timeout=5, isolation_level=None)

    def _read(self, db, bot: str) -> TelegramLease | None:
        row = db.execute("SELECT payload FROM telegram_leases WHERE bot=?", (bot,)).fetchone()
        if not row:
            return None
        try:
            return TelegramLease(**json.loads(row[0]))
        except (TypeError, ValueError, json.JSONDecodeError):
            return None

    def current(self, bot_token: str) -> TelegramLease | None:
        bot = bot_fingerprint(bot_token)
        with self._connect() as db:
            lease = self._read(db, bot)
        return lease if lease and lease.state == "ACTIVE" and lease.valid() else None

    def acquire(self, *, bot_token: str, node_id: str, user_id: str,
                ttl_seconds: int = 30) -> TelegramLease:
        bot = bot_fingerprint(bot_token)
        with self._connect() as db:
            try:
                db.execute("BEGIN IMMEDIATE")
                old = self._read(db, bot)
                if old and old.valid() and old.owner_node_id != node_id:
                    raise LeaseBusy("another node owns the active Telegram lease")
                now = _now(); generation = old.generation + 1 if old else 1
                lease = TelegramLease(secrets.token_urlsafe(12), bot, node_id, user_id,
                                      _iso(now), _iso(now),
                                      _iso(now + timedelta(seconds=max(5, ttl_seconds))), generation)
                db.execute("INSERT INTO telegram_leases(bot,payload) VALUES(?,?) "
                           "ON CONFLICT(bot) DO UPDATE SET payload=excluded.payload",
                           (bot, json.dumps(lease.to_dict(), sort_keys=True)))
                db.commit(); return lease
            except Exception:
                db.rollback(); raise

    def heartbeat(self, lease: TelegramLease, *, ttl_seconds: int = 30) -> TelegramLease:
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            current = self._read(db, lease.bot_identity_fingerprint)
            if (not current or current.state != "ACTIVE" or
                    current.lease_id != lease.lease_id or current.generation != lease.generation):
                db.rollback(); raise LeaseBusy("lease fencing token is stale")
            now = _now()
            renewed = TelegramLease(lease.lease_id, lease.bot_identity_fingerprint,
                                    lease.owner_node_id, lease.owner_user_id,
                                    lease.acquired_at, _iso(now),
                                    _iso(now + timedelta(seconds=max(5, ttl_seconds))),
                                    lease.generation)
            db.execute("UPDATE telegram_leases SET payload=? WHERE bot=? AND payload=?",
                       (json.dumps(renewed.to_dict(), sort_keys=True), lease.bot_identity_fingerprint,
                        json.dumps(current.to_dict(), sort_keys=True)))
            db.commit(); return renewed

    def release(self, lease: TelegramLease) -> None:
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            current = self._read(db, lease.bot_identity_fingerprint)
            if current and current.lease_id == lease.lease_id and current.generation == lease.generation:
                released = TelegramLease(current.lease_id, current.bot_identity_fingerprint,
                                         current.owner_node_id, current.owner_user_id,
                                         current.acquired_at, current.heartbeat_at,
                                         _iso(_now()), current.generation, "STANDBY")
                db.execute("UPDATE telegram_leases SET payload=? WHERE bot=?",
                           (json.dumps(released.to_dict(), sort_keys=True),
                            lease.bot_identity_fingerprint))
            db.commit()


def provider_from_config(backend: str, path: str) -> TelegramLeaseProvider:
    if backend.upper() == "SQLITE":
        return SQLiteTelegramLeaseProvider(path)
    return FileTelegramLeaseProvider(path)


def diagnostics(*, mode: str, backend: str, token: str, node_id: str,
                user_id: str, path: str) -> dict:
    if mode.upper() == "SINGLE":
        return {"mode": "SINGLE", "state": "DISABLED", "backend": "none",
                "failover_ready": True, "reason": "single-node compatibility"}
    if not token or not node_id or not user_id:
        return {"mode": "FAILOVER", "state": "BLOCKED", "backend": backend,
                "failover_ready": False, "reason": "IDENTITY_REQUIRED"}
    try:
        provider = provider_from_config(backend, path)
        lease = provider.current(token)
        return {"mode": "FAILOVER", "state": "STANDBY" if lease else "ACQUIRING",
                "backend": backend, "failover_ready": True,
                "active_owner": lease.owner_node_id if lease else "",
                "generation": lease.generation if lease else None,
                "expires_at": lease.expires_at if lease else ""}
    except Exception as exc:
        return {"mode": "FAILOVER", "state": "BLOCKED", "backend": backend,
                "failover_ready": False, "reason": "LEASE_BACKEND_UNAVAILABLE",
                "error_type": type(exc).__name__}


class LeaseGuard:
    def __init__(self, provider: TelegramLeaseProvider, lease: TelegramLease,
                 ttl_seconds: int, on_lost):
        self.provider, self.lease, self.ttl_seconds, self.on_lost = provider, lease, ttl_seconds, on_lost
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, name="telegram-lease", daemon=True)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set(); self._thread.join(timeout=2)
        self.provider.release(self.lease)

    def _run(self) -> None:
        while not self._stop.wait(max(1, self.ttl_seconds // 3)):
            try:
                self.lease = self.provider.heartbeat(self.lease, ttl_seconds=self.ttl_seconds)
            except Exception:
                self.on_lost()
                return
