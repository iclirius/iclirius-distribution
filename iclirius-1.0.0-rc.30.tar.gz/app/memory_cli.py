"""Administrative Memory Home enrollment commands."""

from __future__ import annotations

import argparse
import getpass
import json

from app.config import settings
from app.memory_enrollment import EnrollmentError, prepare, provision_keychain, recover, status
from app.memory_home import load
from app.local_auth import authenticate_interactive


def _home():
    if not settings.memory_home:
        raise EnrollmentError("Iclirius setup must be complete first.")
    return load(settings.memory_home)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius memory enrollment")
    parser.add_argument("command", nargs="?", choices=("prepare", "status"), default="status")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv or [])
    if args.command == "status":
        info = status(settings.memory_home) if settings.memory_home else {"state": "not_configured"}
        print(json.dumps(info, ensure_ascii=False, indent=2, sort_keys=True) if args.json
              else "Cross-device enrollment: " + str(info.get("state", "unknown")))
        return 0 if info.get("state") in {"prepared", "not_prepared"} else 1
    if not settings.setup_complete:
        print("Iclirius setup must be complete first.")
        return 2
    try:
        session = authenticate_interactive()
        if session is None:
            return 2
        home = _home()
        password = getpass.getpass("Recovery passphrase for enrollment: ")
        info = prepare(home, password)
    except (EnrollmentError, OSError, EOFError, KeyboardInterrupt) as exc:
        print(f"Enrollment preparation failed: {exc}")
        return 1
    print("Cross-device enrollment prepared.")
    print(f"Memory Home ID: {info['memory_home_id']}")
    return 0


def enroll_existing(home_path: str, passphrase: str, *, auth_keychain=True) -> dict:
    """Non-interactive core used by setup and isolated tests."""
    home = load(home_path)
    key = recover(home, passphrase)
    if auth_keychain:
        provision_keychain(key)
    return {"home": home, "key": key}
