"""FILE-2 deterministic search, classification, projects, Git and duplicates."""
from __future__ import annotations

import hashlib
import os
import subprocess
import time
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from app.evidence import Certainty, Coverage, EvidenceRecord, SourceType, certainty_for_coverage
from app.filesystem_evidence import FileQuery, FileRecord, FileScanResult, query

MARKERS = {
    ".git": "git_repository", "pyproject.toml": "python_project", "requirements.txt": "python_project",
    "package.json": "javascript_project", "Cargo.toml": "rust_project", "go.mod": "go_project",
    "pom.xml": "java_project", "build.gradle": "java_project", "build.gradle.kts": "java_project",
    "settings.gradle": "java_project", "settings.gradle.kts": "java_project", "CMakeLists.txt": "cpp_project",
    "Makefile": "build_project", "Package.swift": "swift_project",
}
LANGUAGE_BY_EXTENSION = {
    ".c": "C", ".cpp": "C++", ".cc": "C++", ".cxx": "C++", ".c++": "C++", ".hpp": "C++", ".hh": "C++", ".hxx": "C++",
    ".py": "Python", ".java": "Java", ".kt": "Kotlin", ".kts": "Kotlin", ".js": "JavaScript", ".jsx": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript", ".swift": "Swift", ".go": "Go", ".rs": "Rust", ".sh": "Shell",
    ".bash": "Shell", ".zsh": "Shell", ".json": "JSON", ".yaml": "YAML", ".yml": "YAML", ".xml": "XML",
    ".csv": "CSV", ".md": "Markdown", ".markdown": "Markdown", ".pdf": "PDF", ".doc": "Office", ".docx": "Office",
    ".xls": "Office", ".xlsx": "Office", ".png": "Image", ".jpg": "Image", ".jpeg": "Image", ".gif": "Image",
    ".mp3": "Audio", ".wav": "Audio", ".mp4": "Video", ".mov": "Video", ".zip": "Archive", ".tar": "Archive",
    ".gz": "Archive", ".7z": "Archive",
}


def _coverage(scan_result: FileScanResult) -> str:
    return scan_result.coverage


def _id(prefix: str, value: str) -> str:
    return prefix + hashlib.sha256(value.encode()).hexdigest()[:20]


@dataclass(frozen=True)
class FileQueryResult:
    query_id: str
    source_scan_id: str
    query: FileQuery
    node_id: str
    root_id: str
    matched_file_ids: tuple[str, ...]
    matched_count: int
    coverage: str
    observed_at: str
    warnings: tuple[str, ...] = ()
    errors: tuple[dict, ...] = ()

    def to_dict(self):
        return {"query_id": self.query_id, "source_scan_id": self.source_scan_id,
                "query": asdict(self.query), "node_id": self.node_id, "root_id": self.root_id,
                "matched_file_ids": list(self.matched_file_ids), "matched_count": self.matched_count,
                "coverage": self.coverage, "observed_at": self.observed_at,
                "warnings": list(self.warnings), "errors": list(self.errors)}


def search_files(scan_result: FileScanResult, specification: FileQuery) -> FileQueryResult:
    matched = query(scan_result.records, specification)
    source_scan_id = _id("scan_", scan_result.root.root_id + scan_result.started_at)
    query_id = _id("query_", source_scan_id + repr(asdict(specification)))
    return FileQueryResult(query_id, source_scan_id, specification, scan_result.root.node_id,
                           scan_result.root.root_id, tuple(row.file_id for row in matched), len(matched),
                           _coverage(scan_result), scan_result.ended_at,
                           scan_result.warnings, scan_result.errors)


def classification_for(record: FileRecord) -> dict:
    if record.is_directory:
        return {"family": "directory", "state": "KNOWN", "signal": "directory"}
    family = LANGUAGE_BY_EXTENSION.get(record.extension)
    if family:
        return {"family": family, "state": "KNOWN", "signal": record.extension}
    if record.extension == ".h":
        return {"family": "C/C++", "state": "AMBIGUOUS", "signal": ".h"}
    return {"family": "unknown", "state": "UNKNOWN", "signal": "no deterministic extension signal"}


@dataclass(frozen=True)
class GitMetadata:
    available: bool
    repository_root: str | None = None
    branch: str | None = None
    head_commit: str | None = None
    head_timestamp: str | None = None
    last_commit_timestamp: str | None = None
    dirty: bool | None = None
    tracked_file_count: int | None = None
    untracked_file_count: int | None = None
    error: str | None = None

    def to_dict(self):
        return asdict(self)


def git_metadata(path: str | Path, *, timeout: float = 5.0) -> GitMetadata:
    def run(*args):
        return subprocess.run(["git", "-C", str(path), *args], capture_output=True, text=True, timeout=timeout, check=False)
    try:
        root = run("rev-parse", "--show-toplevel")
        if root.returncode != 0:
            return GitMetadata(False, error="not_a_repository")
        repo = root.stdout.strip()
        branch = run("branch", "--show-current").stdout.strip() or None
        head = run("rev-parse", "HEAD").stdout.strip() or None
        stamp = run("show", "-s", "--format=%cI", "HEAD").stdout.strip() or None
        status = run("status", "--porcelain=v1", "--untracked-files=all")
        lines = [line for line in status.stdout.splitlines() if line.strip()]
        tracked = run("ls-files").stdout.splitlines()
        untracked = sum(line.startswith("?? ") for line in lines)
        return GitMetadata(True, repo, branch, head, stamp, stamp, bool(lines), len(tracked), untracked)
    except (OSError, subprocess.SubprocessError) as exc:
        return GitMetadata(False, error=type(exc).__name__)


@dataclass(frozen=True)
class ProjectRecord:
    project_id: str
    node_id: str
    root_id: str
    path: str
    name: str
    markers: tuple[str, ...]
    languages: dict
    file_count: int
    total_size: int
    oldest_modified: str | None
    newest_file_modified: str | None
    files_modified_last_30d: int
    files_modified_last_365d: int
    git_repository: bool
    git: dict
    coverage: str
    observed_at: str
    parent_project_id: str | None = None
    repository_root: str | None = None
    warnings: tuple[str, ...] = ()

    def to_dict(self):
        value = asdict(self)
        value["markers"], value["warnings"] = list(self.markers), list(self.warnings)
        return value


def _under_path(child: str, parent: str) -> bool:
    try:
        Path(child).relative_to(parent)
        return True
    except ValueError:
        return False


def detect_projects(scan_result: FileScanResult, *, now: datetime | None = None, git_timeout: float = 5.0) -> tuple[ProjectRecord, ...]:
    now = now or datetime.now(timezone.utc)
    records = list(scan_result.records)
    files = [row for row in records if row.is_file and row.accessible]
    directories = {row.relative_path: row for row in records if row.is_directory and row.accessible}
    markers_by_dir: dict[str, set[str]] = {}
    for row in files + [item for item in records if item.is_directory]:
        parent = Path(row.relative_path).parent.as_posix()
        marker = row.name if row.name in MARKERS else ".git" if row.name == ".git" else None
        if marker:
            markers_by_dir.setdefault("." if parent == "." else parent, set()).add(marker)
    projects = []
    for relative, markers in sorted(markers_by_dir.items()):
        path = Path(scan_result.root.path) if relative == "." else Path(scan_result.root.path) / relative
        descendants = [row for row in files
                       if (relative == "." or row.relative_path.startswith(relative.rstrip("/") + "/"))
                       and row.relative_path != ".git"
                       and not row.relative_path.startswith(".git/")
                       and not (relative != "." and row.relative_path.startswith(relative.rstrip("/") + "/.git/"))]
        languages = Counter()
        for row in descendants:
            family = classification_for(row)
            if family["state"] == "KNOWN":
                languages[family["family"]] += 1
        dates = [row.modified_at for row in descendants if row.modified_at]
        git = git_metadata(path, timeout=git_timeout) if ".git" in markers else GitMetadata(False, error="no_git_marker")
        parent_id = None
        for candidate in projects:
            if _under_path(str(path), candidate.path) and candidate.path != str(path):
                parent_id = candidate.project_id
        project_id = _id("project_", scan_result.root.node_id + "\0" + scan_result.root.root_id + "\0" + str(path))
        projects.append(ProjectRecord(project_id, scan_result.root.node_id, scan_result.root.root_id, str(path), path.name,
                                      tuple(sorted(markers)), dict(sorted(languages.items())), len(descendants),
                                      sum(row.size_bytes or 0 for row in descendants), min(dates) if dates else None,
                                      max(dates) if dates else None,
                                      sum(bool(row.modified_at and row.modified_at >= (now - timedelta(days=30)).isoformat()) for row in descendants),
                                      sum(bool(row.modified_at and row.modified_at >= (now - timedelta(days=365)).isoformat()) for row in descendants),
                                      git.available, git.to_dict(), scan_result.coverage, scan_result.ended_at, parent_id,
                                      git.repository_root, tuple(scan_result.warnings)))
    return tuple(projects)


@dataclass(frozen=True)
class ProjectQuery:
    contains_language: str | None = None
    newest_modified_before: str | None = None
    last_git_commit_before: str | None = None
    root_id: str | None = None
    git_repository: bool | None = None
    limit: int = 1000


@dataclass(frozen=True)
class ProjectQueryResult:
    query_id: str
    source_scan_id: str
    query: ProjectQuery
    node_id: str
    root_id: str
    matched_project_ids: tuple[str, ...]
    matched_count: int
    coverage: str
    observed_at: str
    warnings: tuple[str, ...] = ()

    def to_dict(self):
        return {"query_id": self.query_id, "source_scan_id": self.source_scan_id, "query": asdict(self.query),
                "node_id": self.node_id, "root_id": self.root_id, "matched_project_ids": list(self.matched_project_ids),
                "matched_count": self.matched_count, "coverage": self.coverage, "observed_at": self.observed_at,
                "warnings": list(self.warnings)}


def search_projects(scan_result: FileScanResult, projects: Iterable[ProjectRecord], specification: ProjectQuery) -> ProjectQueryResult:
    rows = []
    for project in projects:
        if specification.root_id is not None and project.root_id != specification.root_id:
            continue
        if specification.contains_language and not project.languages.get(specification.contains_language):
            continue
        if specification.newest_modified_before and (not project.newest_file_modified or project.newest_file_modified >= specification.newest_modified_before):
            continue
        if specification.last_git_commit_before:
            stamp = project.git.get("last_commit_timestamp")
            if not stamp or stamp >= specification.last_git_commit_before:
                continue
        if specification.git_repository is not None and project.git_repository != specification.git_repository:
            continue
        rows.append(project)
    rows = rows[:max(0, specification.limit)]
    source = _id("scan_", scan_result.root.root_id + scan_result.started_at)
    return ProjectQueryResult(_id("project_query_", source + repr(asdict(specification))), source, specification,
                              scan_result.root.node_id, scan_result.root.root_id, tuple(row.project_id for row in rows), len(rows),
                              scan_result.coverage, scan_result.ended_at, scan_result.warnings)


def file_query_evidence(result: FileQueryResult) -> EvidenceRecord:
    coverage = Coverage(complete=result.coverage == "COMPLETE", scanned_items=result.matched_count,
                        errors=len(result.errors), reason=result.coverage)
    return EvidenceRecord(SourceType.FILESYSTEM.value, "file_query", result.root_id, result.to_dict(), coverage,
                          certainty_for_coverage(coverage), evidence_id=result.query_id, observed_at=result.observed_at,
                          provenance={"source_scan_id": result.source_scan_id, "root_id": result.root_id, "node_id": result.node_id,
                                      "query": asdict(result.query), "coverage_status": result.coverage}, node_id=result.node_id,
                          tool_id="file_analysis")


def project_evidence(result: ProjectQueryResult, projects: Iterable[ProjectRecord]) -> EvidenceRecord:
    selected = [project.to_dict() for project in projects if project.project_id in result.matched_project_ids]
    coverage = Coverage(complete=result.coverage == "COMPLETE", scanned_items=len(selected), reason=result.coverage)
    payload = result.to_dict(); payload["projects"] = selected
    return EvidenceRecord(SourceType.FILESYSTEM.value, "project_query", result.root_id, payload, coverage,
                          certainty_for_coverage(coverage), evidence_id=result.query_id, observed_at=result.observed_at,
                          provenance={"source_scan_id": result.source_scan_id, "query": asdict(result.query),
                                      "coverage_status": result.coverage}, node_id=result.node_id, tool_id="file_analysis")


@dataclass(frozen=True)
class DuplicateGroup:
    status: str
    size_bytes: int
    file_ids: tuple[str, ...]
    digest: str | None = None
    error: str | None = None

    def to_dict(self):
        return asdict(self)


def detect_duplicates(records: Iterable[FileRecord], *, max_file_size=50 * 1024 * 1024,
                      max_candidates=1000, max_bytes_hashed=100 * 1024 * 1024,
                      timeout_seconds=10.0) -> tuple[DuplicateGroup, ...]:
    rows = [row for row in records if row.accessible and row.is_file and row.size_bytes is not None]
    by_size: dict[int, list[FileRecord]] = {}
    for row in rows:
        if row.size_bytes <= max_file_size:
            by_size.setdefault(row.size_bytes, []).append(row)
    candidates = [row for size, group in by_size.items() if len(group) > 1 for row in group][:max_candidates]
    groups, started, bytes_hashed = [], time.monotonic(), 0
    for size, group in sorted(by_size.items()):
        if len(group) < 2 or any(row not in candidates for row in group):
            continue
        digests = {}
        for row in group:
            if bytes_hashed + (row.size_bytes or 0) > max_bytes_hashed or time.monotonic() - started >= timeout_seconds:
                return tuple(groups + [DuplicateGroup("POSSIBLE_DUPLICATE", size, tuple(r.file_id for r in group), error="bound_reached")])
            try:
                with open(row.absolute_path, "rb") as handle:
                    digest = hashlib.sha256(handle.read(max_file_size + 1)).hexdigest()
                bytes_hashed += row.size_bytes or 0
                digests.setdefault(digest, []).append(row.file_id)
            except OSError as exc:
                groups.append(DuplicateGroup("POSSIBLE_DUPLICATE", size, tuple(r.file_id for r in group), error=type(exc).__name__))
                break
        else:
            for digest, ids in digests.items():
                if len(ids) > 1:
                    groups.append(DuplicateGroup("CONFIRMED_DUPLICATE", size, tuple(sorted(ids)), digest))
    return tuple(groups)
