"""Read-only inventory and temporary canonical migration simulation."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any

from app.memory_core import MemoryCore
from app.memory_migration import migrate_legacy


INCIDENT_START = "2026-09-10T09:46:42"
INCIDENT_END = "2026-09-10T09:51:13"

OWNERSHIP_CLASSES = (
    "EXPLICIT", "PROVENANCE_VERIFIED", "STRONG_INFERENCE", "AMBIGUOUS",
    "CONFLICTED", "UNKNOWN",
)


def fingerprint_event(row: dict) -> str:
    """Stable identity: existing event_id first, normalized fields otherwise."""
    if row.get("event_id"):
        return "event:" + str(row["event_id"])
    stable = {key: row.get(key) for key in (
        "timestamp", "user_id", "principal_id", "session_id", "interface",
        "source", "user_message", "assistant_response", "role", "content",
    ) if key in row}
    return "sha256:" + hashlib.sha256(
        json.dumps(stable, sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()


def _read_rows(path: Path, secure) -> tuple[list[dict], int]:
    if not path.exists():
        return [], 0
    text = secure.read_text(path, default="") if path.suffix == ".enc" else path.read_text(encoding="utf-8")
    rows, malformed = [], 0
    for line in text.splitlines():
        if not line.strip():
            continue
        try:
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError
            rows.append(value)
        except (ValueError, json.JSONDecodeError):
            malformed += 1
    return rows, malformed


def _times(rows: list[dict]) -> tuple[str | None, str | None]:
    values = [str(row.get("timestamp")) for row in rows if row.get("timestamp")]
    return (min(values), max(values)) if values else (None, None)


def _hash_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _classify_record(record: dict, *, kind: str, backup_ids: set[str]) -> str:
    encoded = json.dumps(record, ensure_ascii=False, sort_keys=True).lower()
    root = str(record.get("root", "")).lower()
    explicit_test = bool(re.search(r"pytest|/test_|test-[a-z0-9]|tmp_path|pytest-of-", encoded))
    if record.get("project_id") in backup_ids or record.get("task_id") in backup_ids:
        if explicit_test:
            return "AMBIGUOUS"
        return "LIKELY_REAL"
    if explicit_test:
        return "LIKELY_TEST"
    if kind == "project" and root and ("/users/" in root or "/workspace/" in root):
        return "AMBIGUOUS"
    return "AMBIGUOUS"


def inventory_sources(sources: dict[str, Path], secure) -> list[dict]:
    result = []
    for name, path in sources.items():
        if not path.exists():
            result.append({"source": name, "status": "MISSING"})
            continue
        rows, malformed = _read_rows(path, secure) if "jsonl" in path.name else ([], 0)
        if rows:
            oldest, latest = _times(rows)
            count = len(rows)
        else:
            oldest = latest = None
            count = None
            try:
                raw = secure.read_text(path, default="") if path.suffix == ".enc" else path.read_text(encoding="utf-8")
                value = json.loads(raw) if path.suffix.endswith("enc") and raw else None
                count = len(value) if isinstance(value, (dict, list)) else (1 if raw else 0)
            except (ValueError, OSError):
                count = None
        result.append({"source": name, "type": "jsonl" if "jsonl" in path.name else "document",
                       "count": count, "oldest": oldest, "latest": latest,
                       "encrypted": path.suffix == ".enc", "hash": _hash_file(path),
                       "malformed": malformed})
    return result


def reconcile_conversations(legacy_rows: list[dict], canonical_rows: list[dict],
                            backup_rows: list[dict], user_id: str) -> dict:
    legacy_ids = [fingerprint_event(row) for row in legacy_rows]
    canonical_ids = {fingerprint_event(row) for row in canonical_rows}
    backup_ids = {fingerprint_event(row) for row in backup_rows}
    counts = Counter(legacy_ids)
    unknown_owner = sum(1 for row in legacy_rows
                        if row.get("principal_id") not in (None, "", user_id))
    owner_missing = sum(1 for row in legacy_rows if not row.get("principal_id"))
    collisions = sum(1 for values in Counter(row.get("timestamp") for row in legacy_rows).values() if values > 1)
    malformed = sum(not isinstance(row, dict) for row in legacy_rows)
    return {
        "legacy_found": len(legacy_rows),
        "unique": len(counts),
        "already_canonical": sum(1 for value in legacy_ids if value in canonical_ids),
        "would_deduplicate": sum(count - 1 for count in counts.values() if count > 1),
        "conflicts": sum(1 for value in legacy_ids if value in canonical_ids and value not in backup_ids),
        "malformed": malformed,
        "unknown_owner": unknown_owner + owner_missing,
        "owner_missing": owner_missing,
        "canonical_user_events": sum(1 for row in legacy_rows if row.get("principal_id") == user_id),
        "timestamp_collisions": collisions,
        "newer_than_backup": sum(1 for value in legacy_ids if value not in backup_ids),
        "backup_missing_now": sum(1 for value in backup_ids if value not in set(legacy_ids)),
        "would_migrate": sum(1 for value in counts if value not in canonical_ids),
    }


def reconcile_ownership(legacy_rows: list[dict], user_id: str) -> dict:
    """Produce a deterministic, privacy-preserving ownership plan.

    Only authoritative fields and relationships are used.  Missing identity is
    deliberately retained as UNKNOWN; this function never guesses a principal
    from a laptop, timestamp, language, or message content.
    """
    explicit_sessions: dict[str, set[str]] = {}
    explicit_threads: dict[str, set[str]] = {}
    for row in legacy_rows:
        owner = row.get("principal_id") or row.get("user_id")
        if not owner:
            continue
        for key, table in (("session_id", explicit_sessions), ("thread_id", explicit_threads),
                           ("conversation_id", explicit_threads)):
            value = row.get(key)
            if value:
                table.setdefault(str(value), set()).add(str(owner))

    records = []
    counts = Counter()
    pairable = paired = inherited = ambiguous_pairs = 0
    for index, row in enumerate(legacy_rows):
        fingerprint = fingerprint_event(row)
        owners = []
        direct = row.get("principal_id") or row.get("user_id")
        if direct:
            owners.append(str(direct))
        for key, table in (("session_id", explicit_sessions), ("thread_id", explicit_threads),
                           ("conversation_id", explicit_threads)):
            value = row.get(key)
            if value and table.get(str(value)):
                owners.extend(table[str(value)])
        distinct = set(owners)
        if direct == user_id:
            certainty, proposed, rule = "EXPLICIT", user_id, "explicit_principal_id"
            refs = ["principal_id"]
        elif direct and direct != user_id:
            certainty, proposed, rule = "CONFLICTED", None, "non_canonical_principal_id"
            refs = ["principal_id"]
        elif distinct == {user_id}:
            certainty, proposed, rule = "PROVENANCE_VERIFIED", user_id, "explicit_owner_in_same_session_or_thread"
            refs = [key for key in ("session_id", "thread_id", "conversation_id") if row.get(key)]
        elif len(distinct) > 1:
            certainty, proposed, rule = "CONFLICTED", None, "conflicting_group_owners"
            refs = [key for key in ("session_id", "thread_id", "conversation_id") if row.get(key)]
        else:
            certainty, proposed, rule = "UNKNOWN", None, "no_authoritative_identity_signal"
            refs = []
        is_pair = bool(row.get("user_message") and row.get("assistant_response"))
        if is_pair:
            pairable += 1
            if proposed == user_id:
                paired += 1
                if certainty != "EXPLICIT":
                    inherited += 1
        elif row.get("role") == "assistant":
            ambiguous_pairs += 1
        counts[certainty] += 1
        records.append({"event_fingerprint": fingerprint,
                        "index": index,
                        "timestamp": row.get("timestamp"),
                        "event_type": row.get("event_type") or row.get("role") or "turn",
                        "proposed_owner": proposed,
                        "certainty": certainty,
                        "rule_applied": rule,
                        "evidence_refs": refs,
                        "conflict": certainty == "CONFLICTED",
                        "manual_review_required": certainty not in ("EXPLICIT", "PROVENANCE_VERIFIED")})
    safe = counts["EXPLICIT"] + counts["PROVENANCE_VERIFIED"]
    return {"records": records, "counts": {name: counts[name] for name in OWNERSHIP_CLASSES},
            "automatically_safe": safe,
            "manual_review_required": len(legacy_rows) - safe,
            "pairing": {"pairable_turns": pairable, "deterministically_paired": paired,
                         "ownership_inherited": inherited, "ambiguous_pairings": ambiguous_pairs}}


def write_review_artifact(plan: dict, directory: Path | None = None) -> Path:
    """Write only IDs, timestamps and provenance, never message bodies."""
    root = Path(directory or tempfile.mkdtemp(prefix="iclirius-ownership-review-"))
    root.mkdir(parents=True, exist_ok=True)
    path = root / "reconciliation.json"
    payload = {"schema": 1, "records": plan.get("records", []), "counts": plan.get("counts", {}),
               "pairing": plan.get("pairing", {})}
    path.write_text(json.dumps(payload, sort_keys=True, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def classify_records(records: dict[str, dict], backup_records: dict[str, dict]) -> dict:
    backup_ids = set(backup_records)
    counts = Counter(
        _classify_record({**record, "project_id": record.get("project_id", key)},
                         kind="project" if "root" in record else "task",
                         backup_ids=backup_ids)
        for key, record in records.items()
    )
    return {key: counts.get(key, 0) for key in ("LIKELY_REAL", "LIKELY_TEST", "AMBIGUOUS")}


def simulate(canonical_copy: Path, legacy_root: Path, identity_root: Path,
             backup_copy: Path, secure, *, user_id: str) -> dict:
    """Run migration twice in a fresh temp tree and return metadata only."""
    temp = Path(tempfile.mkdtemp(prefix="iclirius-memory-migration-dryrun-"))
    state_path = temp / "core" / "state.json.enc"
    state_path.parent.mkdir(parents=True)
    shutil.copy2(canonical_copy, state_path)
    memory = temp / "memory"; identity = temp / "identity"
    shutil.copytree(legacy_root, memory)
    shutil.copytree(identity_root, identity)
    core = MemoryCore(state_path); core._secure = secure
    before = core._read_state()
    first = migrate_legacy(core, identity_path=identity, memory_path=memory,
                            backup_root=temp / "backups")
    reopened = MemoryCore(state_path); reopened._secure = secure
    state_after = reopened._read_state()
    second = migrate_legacy(reopened, identity_path=identity, memory_path=memory,
                             backup_root=temp / "backups")
    final = MemoryCore(state_path); final._secure = secure
    final_state = final._read_state()
    return {
        "temp_root": str(temp),
        "first": first,
        "second": second,
        "idempotent": second.get("state") == "unchanged",
        "decrypt": final.health(),
        "schema": final_state.get("schema_version"),
        "revision": final_state.get("revision"),
        "journal_monotonic": all(a.get("revision", -1) < b.get("revision", -1)
                                  for a, b in zip(final_state.get("journal", []), final_state.get("journal", [])[1:])),
        "counts": {"conversations": len(final_state.get("conversations", [])),
                   "tasks": len(final_state.get("tasks", {})),
                   "projects": len(final_state.get("projects", {})),
                   "profile": bool(final_state.get("profile")),
                   "summaries": len(final_state.get("summaries", {}))},
        "append_restart": _append_restart(final, secure, user_id),
    }


def _append_restart(core: MemoryCore, secure, user_id: str) -> bool:
    event = {"event_id": "dryrun-temporary-event", "principal_id": user_id,
             "timestamp": "2099-01-01T00:00:00", "user_message": "temporary dry run"}
    core.append_conversation_event(event)
    reopened = MemoryCore(core.state_file); reopened._secure = secure
    return bool(reopened.conversation_history(1, principal_id=user_id))
