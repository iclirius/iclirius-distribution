from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from app.config import settings

from app.logger import logger


# Legacy. Retained so app/memory_tools.py can still show what was recorded
# before Phase 4.1. Nothing writes here any more.
LEARNED_PATH = Path(settings.memory_path) / "learned.jsonl"


SENSITIVE_PATTERNS = [
    r"token",
    r"password",
    r"contraseña",
    r"secret",
    r"api[_-]?key",
    r"TELEGRAM_BOT_TOKEN",
    r"ALLOWED_USER_IDS",
    r"private key",
    r"ssh-rsa",
    r"ed25519",
]


NOISE_PATTERNS = [
    r"^hola\b",
    r"^ok\b",
    r"^listo\b",
    r"^sigamos\b",
    r"^continuemos\b",
    r"^qué sigue\b",
    r"^que sigue\b",
    r"^responde natural",
    r"^dime\b",
    r"^puedes\b",
    r"^ayúdame\b",
    r"^ayudame\b",
]


def _looks_sensitive(text: str) -> bool:
    lowered = text.lower()
    return any(re.search(pattern, lowered, re.I) for pattern in SENSITIVE_PATTERNS)


def _looks_noisy(user_message: str) -> bool:
    msg = user_message.strip().lower()
    return any(re.search(pattern, msg, re.I) for pattern in NOISE_PATTERNS)


def _extract_preference(user_message: str) -> str | None:
    msg = user_message.strip()

    preference_markers = [
        "prefiero",
        "me gusta que",
        "quiero que",
        "de ahora en adelante",
        "para futuras respuestas",
        "cuando estemos debuggeando",
        "cuando estamos debuggeando",
    ]

    if any(marker in msg.lower() for marker in preference_markers):
        return f"Preferencia de Luis: {msg}"

    return None


def _extract_project_fact(user_message: str) -> str | None:
    msg = user_message.strip()
    lower = msg.lower()

    fact_markers = [
        "la worker está",
        "la worker esta",
        "la ruta de la worker",
        "el modelo principal",
        "telegram será",
        "telegram sera",
        "el proyecto se llama",
        "la principal es",
        "la mac principal",
        "openclaw",
        "iclirius",
    ]

    # Solo guardar si parece afirmación, no pregunta casual
    if "?" in msg or lower.startswith(("qué ", "que ", "cuál ", "cual ", "cómo ", "como ")):
        return None

    if any(marker in lower for marker in fact_markers):
        return f"Contexto estable del proyecto: {msg}"

    return None


def extract_learning(user_message: str, assistant_response: str) -> dict | None:
    user_message = user_message.strip()
    assistant_response = assistant_response.strip()

    if not user_message:
        return None

    combined = f"{user_message}\n{assistant_response}"

    if _looks_sensitive(combined):
        return None

    if _looks_noisy(user_message):
        return None

    text = _extract_preference(user_message)
    learning_type = "preference"

    if not text:
        text = _extract_project_fact(user_message)
        learning_type = "project_fact"

    if not text:
        return None

    return {
        "ts": datetime.now().isoformat(timespec="seconds"),
        "type": learning_type,
        "text": text[:800],
        "source": "auto_safe",
    }


def save_learning(learning: dict | None) -> bool:
    """
    Persist one extracted learning, encrypted.

    Phase 4.1 moved this off data/memory/learned.jsonl, which was an
    append-only plaintext file holding the user's stated preferences and
    project facts and growing for as long as Iclirius ran. The Memory Core
    already had encryption, atomic writes and locking, so this uses that
    rather than adding a second store.

    The existing file is left where it is and stays readable through
    app/memory_tools.py; nothing new is written to it.
    """
    if not learning:
        return False

    try:
        from app.memory_core import MemoryCore

        return MemoryCore().add_learning(learning)
    except Exception:
        # Learning is a nicety. It must never break a reply, and it must never
        # fall back to writing plaintext.
        logger.warning("Could not persist a learning", exc_info=False)
        return False


def learn_from_turn(user_message: str, assistant_response: str) -> bool:
    learning = extract_learning(user_message, assistant_response)
    return save_learning(learning)
