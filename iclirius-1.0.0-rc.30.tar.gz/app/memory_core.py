"""
The canonical memory of Iclirius.

Three principles govern this module, and everything else follows from them:

    Local state is authoritative. LLM context is disposable.
    Never resend information that OpenClaw can retrieve, compute, filter,
    summarize or verify locally.
    Interfaces do not own memory. Iclirius owns memory.

Concretely:

  - There is one principal_user. Telegram and the CLI are interfaces onto that
    same identity; neither creates its own. A Telegram user id or a CLI
    session is an *interface reference*, never the identity itself.

  - A task belongs to Iclirius. When cloud providers arrive, a provider
    conversation id may be stored as auxiliary metadata, but it is never the
    authority and the task survives switching provider.

  - Nothing that can be recovered cheaply from disk is memorised. We store
    what we know, why it matters and where to fetch it again: file paths, not
    file contents; claims and source URLs, not HTML.

Storage is a single encrypted document, read-modify-written atomically. It
holds compact task state and the canonical conversation archive.

Memory must never take the interface down. Every public function degrades to a
safe empty value if storage is unavailable, and the caller keeps talking to
Ollama.
"""

from __future__ import annotations

import contextlib
import errno
import fcntl
import json
import os
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from app.config import settings
from app.logger import logger
from app.secure_storage import SecureStorage, SecureStorageError
from app.memory_safety import assert_memory_path_safe

# MEMORY_ROOT is a local filesystem location, potentially a locally available
# synchronized folder. No network client participates in memory operations.
# Files must remain available locally; flock coordinates local processes only.
def _core_dir() -> Path:
    return Path(settings.memory_root or "data/memory/core").expanduser()


CORE_DIR = _core_dir()
STATE_FILE = CORE_DIR / "state.json.enc"

SCHEMA_VERSION = 2

TASK_STATUSES = ("active", "paused", "blocked", "done", "cancelled")


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


class MemoryUnavailable(RuntimeError):
    """Raised internally when the encrypted store cannot be reached."""


class MemoryLockTimeout(MemoryUnavailable):
    """Raised when another process held the write lock for too long."""


@contextlib.contextmanager
def _write_lock(lock_path: Path, timeout: float):
    """
    Advisory exclusive lock around a read-modify-write cycle.

    Telegram and the CLI are separate processes sharing one vault. Without
    this, two interleaved read-modify-writes silently lose one of them: a
    measured run with four writers lost 43 of 61 task creations.

    flock is used rather than a lock library: it is in the standard library,
    works on macOS, and the kernel releases it if the process dies, so a crash
    cannot leave a permanent deadlock. The wait is bounded.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(lock_path, "a+")
    deadline = time.monotonic() + timeout
    waited_ms = 0

    try:
        started = time.monotonic()

        while True:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if exc.errno not in (errno.EAGAIN, errno.EACCES, errno.EWOULDBLOCK):
                    raise

                if time.monotonic() >= deadline:
                    raise MemoryLockTimeout(
                        f"El lock de memoria sigue ocupado tras {timeout}s"
                    ) from exc

                time.sleep(0.02)

        waited_ms = int((time.monotonic() - started) * 1000)
        yield waited_ms
    finally:
        with contextlib.suppress(OSError):
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


# --- records --------------------------------------------------------------


@dataclass
class WebFinding:
    """Evidence gathered from the public web. Never an instruction."""

    claim: str
    source_url: str
    domain: str = ""
    checked_at: str = field(default_factory=_now)
    relevance: str = ""


@dataclass
class Task:
    task_id: str
    project_id: str | None
    goal: str
    status: str = "active"
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    known_facts: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)
    relevant_files: list[str] = field(default_factory=list)
    web_findings: list[dict] = field(default_factory=list)
    current_blocker: str = ""
    next_steps: list[str] = field(default_factory=list)
    verification_state: str = "unverified"
    compact_summary: str = ""
    # Auxiliary only. A provider conversation id may be recorded here for
    # traceability; it is never the identity of the task.
    provider_refs: dict = field(default_factory=dict)

    def touch(self) -> None:
        self.updated_at = _now()

    def render_compact(self) -> str:
        """
        The handoff summary: what a fresh model needs and nothing more.

        Deliberately structured rather than generated, so it stays small and
        cheap and does not require a model call to keep current.
        """
        lines = [f"Objetivo: {self.goal}"]

        if self.known_facts:
            lines.append("Sabemos:")
            lines.extend(f"- {fact}" for fact in self.known_facts[-6:])

        if self.decisions:
            lines.append("Decisiones:")
            lines.extend(f"- {decision}" for decision in self.decisions[-4:])

        if self.relevant_files:
            lines.append("Archivos relevantes: " + ", ".join(self.relevant_files[-8:]))

        if self.web_findings:
            lines.append("Hallazgos web:")
            for finding in self.web_findings[-3:]:
                lines.append(f"- {finding.get('claim', '')} ({finding.get('domain', '')})")

        if self.current_blocker:
            lines.append(f"Bloqueo actual: {self.current_blocker}")

        if self.next_steps:
            lines.append("Siguiente:")
            lines.extend(f"- {step}" for step in self.next_steps[-4:])

        return "\n".join(lines)[: settings.memory_task_summary_chars]


@dataclass
class Project:
    project_id: str
    display_name: str
    root: str = ""
    git_remote_fingerprint: str | None = None
    facts: dict = field(default_factory=dict)
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)

    def render_compact(self) -> str:
        lines = [f"Proyecto: {self.display_name}"]

        if self.facts:
            for key, value in list(self.facts.items())[:8]:
                lines.append(f"- {key}: {value}")

        return "\n".join(lines)[: settings.memory_project_summary_chars]


# --- store ----------------------------------------------------------------


def _empty_state() -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "principal_user": {},
        "projects": {},
        "tasks": {},
        "active": {},
        # Added in Phase 3.8. Separate namespaces on purpose: the assistant's
        # own profile is not a task, and a conversation summary is not a fact.
        "profile": {},
        "summaries": {},
        # Added in Phase 4.1, when the plaintext learned.jsonl stopped being
        # written. Preferences and project facts extracted from conversation.
        "learnings": [],
        # Added in Phase 4.3. Provider usage is metadata only: no prompts,
        # responses or credentials are stored here.
        "provider_usage": {},
        "conversations": [],
        "notes": [],
        "sessions": {},
        "queue_tasks": {},
        "legacy_documents": {},
        "migrations": {},
        "migration_events": {},
        "revision": 0,
        "journal": [],
        "updated_at": _now(),
    }


class MemoryCore:
    """
    The single owner of durable state.

    Every method is defensive: a failure to read or write logs a warning and
    returns an empty result rather than raising into the interface.
    """

    def __init__(self, state_file: Path | None = None):
        self.state_file = Path(state_file) if state_file else _core_dir() / "state.json.enc"
        assert_memory_path_safe(self.state_file, settings.memory_home)
        self.lock_file = self.state_file.with_suffix(self.state_file.suffix + ".lock")
        self._secure: SecureStorage | None = None
        self.available = True
        self.last_lock_wait_ms = 0

    # -- storage plumbing --------------------------------------------------

    @property
    def secure(self) -> SecureStorage:
        if self._secure is None:
            self._secure = SecureStorage()
        return self._secure

    def _read_state(self) -> dict:
        try:
            if not self.state_file.exists():
                return _empty_state()

            raw = self.secure.read_text(self.state_file, default="")

            if not raw.strip():
                raise MemoryUnavailable("Empty encrypted memory state")

            state = json.loads(raw)
        except (SecureStorageError, json.JSONDecodeError, OSError) as exc:
            self.available = False
            logger.warning("Memory core unreadable error=%s", type(exc).__name__)
            raise MemoryUnavailable(str(exc)) from exc

        if not isinstance(state, dict):
            raise MemoryUnavailable("Invalid memory state")

        if state.get("schema_version", 1) not in (1, SCHEMA_VERSION):
            raise MemoryUnavailable("Unsupported memory schema")

        for key, default in _empty_state().items():
            state.setdefault(key, default)

        return state

    def _write_state(self, state: dict) -> None:
        state["schema_version"] = SCHEMA_VERSION
        state["revision"] = int(state.get("revision", 0)) + 1
        state["updated_at"] = _now()
        state.setdefault("journal", []).append({"revision": state["revision"], "at": state["updated_at"]})
        state["journal"] = state["journal"][-100:]

        try:
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(state, ensure_ascii=False)

            # Encrypt to a temporary file in the same directory, then rename,
            # so an interrupted write never truncates the vault.
            handle, temp_name = tempfile.mkstemp(dir=str(self.state_file.parent))
            os.close(handle)
            temp_path = Path(temp_name)

            try:
                self.secure.write_text(temp_path, payload)
                with temp_path.open("rb") as stream:
                    os.fsync(stream.fileno())
                os.replace(temp_path, self.state_file)
            finally:
                temp_path.unlink(missing_ok=True)
            try:
                from app.memory_metadata import bump
                from app.node_identity import read_node
                bump(self.state_file, node_id=str((read_node() or {}).get("node_id", "")))
            except Exception:
                # Revision metadata is observability only; it must never turn
                # a successful encrypted state commit into a failed commit.
                logger.warning("Memory revision metadata update failed", exc_info=False)
        except (SecureStorageError, OSError) as exc:
            self.available = False
            logger.warning("Memory core unwritable error=%s", type(exc).__name__)
            raise MemoryUnavailable(str(exc)) from exc

    def _mutate(self, mutator):
        """
        Read, mutate, write, under an exclusive lock.

        The whole cycle is inside the lock: reading outside it would reopen
        the lost-update window the lock exists to close.
        """
        try:
            with _write_lock(self.lock_file, settings.memory_lock_timeout) as waited_ms:
                self.last_lock_wait_ms = waited_ms
                state = self._read_state()
                result = mutator(state)
                self._write_state(state)
                return result
        except MemoryLockTimeout:
            logger.warning("Memory lock timed out; skipping write")
            return None
        except MemoryUnavailable:
            return None
        except Exception:
            logger.warning("Memory core mutation failed", exc_info=False)
            return None

    def _query(self, reader, default=None):
        try:
            return reader(self._read_state())
        except MemoryUnavailable:
            return default
        except Exception:
            logger.warning("Memory core query failed", exc_info=False)
            return default

    def health(self) -> bool:
        """
        Probe the backend, not just the file.

        Reading a missing state file succeeds trivially, so health has to
        round-trip through secure storage to notice an unreachable vault.
        """
        try:
            self.secure.read_text(self.state_file, default="")
            self._read_state()
            return True
        except Exception:
            return False

    def append_conversation_event(self, event: dict) -> dict:
        """Append once by event_id; preserve supplied identity and timestamps."""
        record = dict(event)
        record.setdefault("event_id", f"event_{uuid.uuid4().hex}")
        record.setdefault("timestamp", _now())

        def mutate(state):
            events = state.setdefault("conversations", [])
            for existing in events:
                if existing.get("event_id") == record["event_id"]:
                    candidate = dict(record)
                    if "timestamp" not in event:
                        candidate["timestamp"] = existing.get("timestamp")
                    if existing != candidate:
                        raise ValueError("Conversation event conflict")
                    return dict(existing)
            events.append(record)
            session_id = record.get("session_id")
            if session_id:
                session = state.setdefault("sessions", {}).setdefault(session_id, {})
                for key in ("principal_id", "user_id", "interface", "project_id"):
                    if key in record:
                        session[key] = record[key]
                session.setdefault("created_at", record["timestamp"])
                session["updated_at"] = record["timestamp"]
            return dict(record)
        return self._mutate(mutate) or {}

    def conversation_history(self, limit=5, principal_id="", session_id="", project_id=""):
        def read(state):
            events = state.get("conversations", [])
            for key, value in (("principal_id", principal_id), ("session_id", session_id),
                               ("project_id", project_id)):
                if value:
                    events = [row for row in events if row.get(key) == value]
            events = sorted(events, key=lambda row: str(row.get("timestamp", "")))
            return [dict(row) for row in events[-limit:]] if limit > 0 else []
        return self._query(read, default=[])

    def forget_last_conversation(self):
        def mutate(state):
            rows = state.get("conversations", [])
            if not rows:
                return False
            latest = max(range(len(rows)), key=lambda index: (str(rows[index].get("timestamp", "")), index))
            rows.pop(latest)
            return True
        return bool(self._mutate(mutate))

    def append_note(self, note):
        record = dict(note)
        record.setdefault("timestamp", _now())
        def mutate(state):
            state.setdefault("notes", []).append(record)
            return dict(record)
        return self._mutate(mutate) or {}

    def notes(self, limit=5):
        return self._query(lambda s: list(s.get("notes", []))[-limit:] if limit > 0 else [], default=[])

    def session_metadata(self, session_id):
        return self._query(lambda s: dict(s.get("sessions", {}).get(session_id, {})), default={})

    def save_session_metadata(self, session_id, values):
        def mutate(sessions):
            record = sessions.setdefault(session_id, {})
            record.update(values)
            return dict(record)
        return self.mutate_namespace("sessions", mutate)

    def diagnostics(self):
        """Allowlisted metadata only; never return content, paths or keys."""
        from app.memory_home import load
        state = self._query(lambda s: s, default=None)
        ready = self.health()
        home_id = ""
        if settings.memory_home:
            try:
                home = load(settings.memory_home)
                if self.state_file.resolve() == (home.core_path / "state.json.enc").resolve():
                    home_id = home.memory_home_id
            except Exception:
                pass
        parent = self.state_file.parent
        while not parent.exists() and parent != parent.parent:
            parent = parent.parent
        return {"memory_backend": "MemoryCore", "memory_home_id": home_id,
                "user_id": (state or {}).get("principal_user", {}).get("user_id", ""),
                "node_id": settings.node_id, "schema_version": (state or {}).get("schema_version", SCHEMA_VERSION),
                "revision": (state or {}).get("revision", 0),
                "writable": bool(ready and os.access(parent, os.W_OK)
                                 and (not self.state_file.exists() or os.access(self.state_file, os.W_OK))),
                "encryption_ready": ready,
                "migration_state": "complete" if (state or {}).get("migrations") else "not_migrated"}

    # -- identity ----------------------------------------------------------

    def principal_user(self) -> dict:
        """
        The one user of this Iclirius.

        Created on first use. It has its own id: no Telegram id, CLI session
        or future provider account is ever the identity.
        """
        def reader(state):
            return dict(state.get("principal_user") or {})

        existing = self._query(reader, default={})

        if existing:
            return existing

        def creator(state):
            if not state.get("principal_user"):
                state["principal_user"] = {
                    "user_id": settings.user_id or f"user_{uuid.uuid4().hex[:12]}",
                    "display_name": settings.principal_user_name or "owner",
                    "created_at": _now(),
                    "interfaces": {},
                }
            return dict(state["principal_user"])

        return self._mutate(creator) or {}

    def link_interface(self, interface: str, reference: str) -> dict:
        """
        Record that an interface belongs to the principal user.

        The reference is a pointer, not an identity: it lets us recognise the
        interface again, and nothing more.
        """
        def mutator(state):
            if not state.get("principal_user"):
                state["principal_user"] = {
                    "user_id": settings.user_id or f"user_{uuid.uuid4().hex[:12]}",
                    "display_name": settings.principal_user_name or "owner",
                    "created_at": _now(),
                    "interfaces": {},
                }

            state["principal_user"].setdefault("interfaces", {})[interface] = {
                "reference": str(reference),
                "last_seen": _now(),
            }
            return dict(state["principal_user"])

        return self._mutate(mutator) or {}

    # -- projects ----------------------------------------------------------

    def upsert_project(self, signal) -> dict:
        def mutator(state):
            projects = state.setdefault("projects", {})
            record = projects.get(signal.project_id)

            if record is None:
                record = asdict(Project(
                    project_id=signal.project_id,
                    display_name=signal.display_name,
                    root=signal.root,
                    git_remote_fingerprint=getattr(signal, "git_remote_fingerprint", None),
                ))
                projects[signal.project_id] = record
            else:
                record["display_name"] = signal.display_name or record.get("display_name", "")
                if signal.root:
                    record["root"] = signal.root
                record["updated_at"] = _now()

            return dict(record)

        return self._mutate(mutator) or {}

    def get_project(self, project_id: str) -> dict:
        return self._query(lambda s: dict(s.get("projects", {}).get(project_id) or {}), default={})

    def list_projects(self) -> dict:
        return self._query(lambda s: dict(s.get("projects", {})), default={})

    def record_project_facts(self, project_id: str, facts: dict) -> dict:
        """
        Store structured facts about a project, never its contents.

        "language=Kotlin, build=Gradle, modules=[app,core]" is worth keeping.
        The 128 files behind it are not: they can be read again in
        milliseconds.
        """
        def mutator(state):
            record = state.setdefault("projects", {}).get(project_id)

            if record is None:
                return {}

            existing = record.setdefault("facts", {})

            for key, value in list(facts.items())[: settings.memory_max_project_facts]:
                existing[str(key)[:60]] = str(value)[: settings.memory_fact_chars]

            record["updated_at"] = _now()
            return dict(record)

        return self._mutate(mutator) or {}

    # -- tasks -------------------------------------------------------------

    def create_task(self, goal: str, project_id: str | None = None) -> dict:
        def mutator(state):
            task = Task(
                task_id=f"task_{uuid.uuid4().hex[:10]}",
                project_id=project_id,
                goal=goal.strip()[: settings.memory_fact_chars],
            )
            task.compact_summary = task.render_compact()

            state.setdefault("tasks", {})[task.task_id] = asdict(task)
            state.setdefault("active", {})["task_id"] = task.task_id

            if project_id:
                state["active"]["project_id"] = project_id

            self._prune(state)
            return asdict(task)

        return self._mutate(mutator) or {}

    def get_task(self, task_id: str) -> dict:
        return self._query(lambda s: dict(s.get("tasks", {}).get(task_id) or {}), default={})

    def update_task(self, task_id: str, **changes) -> dict:
        """
        Apply structured changes. List fields append and stay bounded; scalar
        fields replace. The compact summary is regenerated locally, with no
        model call.
        """
        list_fields = {"known_facts", "decisions", "relevant_files", "next_steps"}
        scalar_fields = {"goal", "status", "current_blocker", "verification_state"}

        def mutator(state):
            record = state.get("tasks", {}).get(task_id)

            if record is None:
                return {}

            for key, value in changes.items():
                if key in list_fields:
                    items = record.setdefault(key, [])
                    new_items = value if isinstance(value, (list, tuple)) else [value]
                    for item in new_items:
                        text = str(item).strip()[: settings.memory_fact_chars]
                        if text and text not in items:
                            items.append(text)
                    record[key] = items[-settings.memory_max_list_items:]
                elif key in scalar_fields:
                    if key == "status" and value not in TASK_STATUSES:
                        continue
                    record[key] = str(value)[: settings.memory_fact_chars]

            record["updated_at"] = _now()
            record["compact_summary"] = Task(**record).render_compact()
            return dict(record)

        return self._mutate(mutator) or {}

    def add_web_findings(self, task_id: str, findings: list[WebFinding]) -> dict:
        """
        Attach web evidence to a task.

        Only the claim, the source and the timestamp are kept. No HTML, no page
        text, no banners. Evidence is data for later reading, never an
        instruction the agent will follow.
        """
        def mutator(state):
            record = state.get("tasks", {}).get(task_id)

            if record is None:
                return {}

            stored = record.setdefault("web_findings", [])

            for finding in findings[: settings.memory_max_web_findings]:
                stored.append({
                    "claim": finding.claim.strip()[: settings.memory_fact_chars],
                    "source_url": finding.source_url.strip()[:400],
                    "domain": finding.domain[:100],
                    "checked_at": finding.checked_at,
                    "relevance": finding.relevance[:200],
                })

            record["web_findings"] = stored[-settings.memory_max_web_findings:]
            record["updated_at"] = _now()
            record["compact_summary"] = Task(**record).render_compact()
            return dict(record)

        return self._mutate(mutator) or {}

    def set_active(self, task_id: str | None = None, project_id: str | None = None) -> dict:
        def mutator(state):
            active = state.setdefault("active", {})
            if task_id is not None:
                active["task_id"] = task_id
            if project_id is not None:
                active["project_id"] = project_id
            active["updated_at"] = _now()
            return dict(active)

        return self._mutate(mutator) or {}

    def active_state(self) -> dict:
        return self._query(lambda s: dict(s.get("active") or {}), default={})

    def find_tasks(
        self,
        project_id: str | None = None,
        status: str | None = None,
        keyword: str | None = None,
        limit: int = 10,
    ) -> list[dict]:
        """
        Selective retrieval by structured attributes.

        No embeddings and no vector database: project, status, keyword and
        recency answer the questions this phase needs.
        """
        def reader(state):
            tasks = list(state.get("tasks", {}).values())

            if project_id:
                tasks = [t for t in tasks if t.get("project_id") == project_id]

            if status:
                tasks = [t for t in tasks if t.get("status") == status]

            if keyword:
                needle = keyword.lower()
                tasks = [
                    t for t in tasks
                    if needle in str(t.get("goal", "")).lower()
                    or needle in str(t.get("compact_summary", "")).lower()
                ]

            tasks.sort(key=lambda t: t.get("updated_at", ""), reverse=True)
            return tasks[:limit]

        return self._query(reader, default=[])

    def active_task_for(self, project_id: str | None) -> dict:
        """Most recently touched open task, preferring the given project."""
        if project_id:
            candidates = self.find_tasks(project_id=project_id, status="active", limit=1)
            if candidates:
                return candidates[0]

        active = self.active_state().get("task_id")

        if active:
            task = self.get_task(active)
            if task and task.get("status") in ("active", "blocked", "paused"):
                return task

        return {}

    # -- housekeeping ------------------------------------------------------

    def _prune(self, state: dict) -> None:
        """Keep the store small. Closed tasks age out; open ones never do."""
        tasks = state.get("tasks", {})
        limit = settings.memory_max_tasks

        if len(tasks) <= limit:
            return

        closed = [
            (record.get("updated_at", ""), task_id)
            for task_id, record in tasks.items()
            if record.get("status") in ("done", "cancelled")
        ]
        closed.sort()

        for _, task_id in closed[: len(tasks) - limit]:
            tasks.pop(task_id, None)

    # -- assistant profile and conversation summaries ----------------------
    #
    # Both live here rather than in a new store: the Memory Core already has
    # encryption, atomic writes and locking, and a second database would mean
    # a second set of all three to get right.

    def get_profile(self) -> dict:
        return self._query(lambda state: dict(state.get("profile") or {}), default={})

    def update_profile(self, section: str, values: dict) -> dict:
        """
        Merge values into one section of the profile.

        Section-scoped so a preference update cannot reach identity or
        behavioural rules by writing a differently named key.
        """
        def mutate(state):
            profile = state.setdefault("profile", {})
            current = dict(profile.get(section) or {})
            current.update(values)
            current["updated_at"] = _now()
            profile[section] = current

            return dict(current)

        return self._mutate(mutate)

    def get_summary(self, key: str) -> dict:
        return self._query(
            lambda state: dict((state.get("summaries") or {}).get(key) or {}),
            default={},
        )

    def get_namespace(self, namespace: str) -> dict:
        """Read a bounded, encrypted application namespace."""
        if not namespace or namespace not in _empty_state():
            return {}
        return self._query(
            lambda state: dict(state.get(namespace) or {}), default={})

    def update_namespace(self, namespace: str, values: dict) -> dict:
        """Atomically merge metadata into an existing encrypted namespace."""
        if not namespace or namespace not in _empty_state() or not isinstance(values, dict):
            return {}

        def mutate(state):
            current = state.setdefault(namespace, {})
            current.update(values)
            return dict(current)

        return self._mutate(mutate) or {}

    def mutate_namespace(self, namespace: str, mutator) -> dict:
        """Run a read-modify-write mutation under Memory Core's file lock."""
        if not namespace or namespace not in _empty_state():
            return {}

        def mutate(state):
            current = state.setdefault(namespace, {})
            result = mutator(current)
            return dict(result if isinstance(result, dict) else current)

        return self._mutate(mutate) or {}

    def save_summary(self, key: str, summary: dict) -> dict:
        """Persist a conversation summary through the existing atomic path."""
        def mutate(state):
            summaries = state.setdefault("summaries", {})
            record = dict(summary)
            record["updated_at"] = _now()
            summaries[key] = record

            # Bounded like everything else here: summaries are per
            # task/interface and old ones stop being interesting.
            if len(summaries) > 40:
                oldest = sorted(summaries.items(),
                                key=lambda item: item[1].get("updated_at", ""))
                for stale_key, _ in oldest[:len(summaries) - 40]:
                    summaries.pop(stale_key, None)

            return dict(record)

        return self._mutate(mutate)

    # -- derived learnings -------------------------------------------------

    def add_learning(self, learning: dict) -> bool:
        """
        Record one extracted preference or project fact.

        Deduplicated by text, bounded, and encrypted like everything else
        here. This replaced an append-only plaintext file that grew forever.
        """
        text = str(learning.get("text", "")).strip()

        if not text:
            return False

        def mutate(state):
            learnings = state.setdefault("learnings", [])

            if any(item.get("text") == text for item in learnings):
                return False

            learnings.append({
                "text": text[:400],
                "type": str(learning.get("type", ""))[:40],
                "source": str(learning.get("source", ""))[:40],
                "ts": str(learning.get("ts") or _now()),
            })

            # Bounded like every other list in the core.
            if len(learnings) > 200:
                del learnings[:len(learnings) - 200]

            return True

        return bool(self._mutate(mutate))

    def learnings(self, limit: int = 30) -> list[dict]:
        return self._query(
            lambda state: list(state.get("learnings") or [])[-limit:], default=[])

    def stats(self) -> dict:
        def reader(state):
            tasks = state.get("tasks", {})
            return {
                "projects": len(state.get("projects", {})),
                "tasks": len(tasks),
                "active_tasks": sum(1 for t in tasks.values() if t.get("status") == "active"),
                "has_principal_user": bool(state.get("principal_user")),
            }

        return self._query(reader, default={
            "projects": 0, "tasks": 0, "active_tasks": 0, "has_principal_user": False,
        })


memory_core = MemoryCore()
