import re
from typing import Optional


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def classify_message(text: str) -> str:
    t = norm(text)

    if not t:
        return "empty"

    if any(x in t for x in [
        "reset",
        "reinicia",
        "reiniciar",
        "resetea",
        "resetear",
        "runtime",
    ]):
        return "reset"

    if any(x in t for x in [
        "cuantos libros van",
        "cuántos libros van",
        "como va",
        "cómo va",
        "estado",
        "progreso",
        "status",
        "queue",
        "worker",
        "tareas",
        "task",
    ]):
        return "status"

    if any(x in t for x in [
        "libro",
        "libros",
        "autor",
        "murakami",
        "haruki",
        "biblioteca",
        "catalogo",
        "catálogo",
        "procesados",
        "procesado",
        "aprendido",
        "aprendiste",
    ]):
        return "library"

    if any(x in t for x in [
        "analiza todo",
        "digest de todo",
        "procesa todos",
        "aprende todos",
        "revisa todo el proyecto",
        "busca errores importantes",
        "tarea pesada",
        "manda al worker",
    ]):
        return "heavy"

    return "chat"


def should_send_processing_message(kind: str) -> bool:
    return kind in {"heavy"}


def processing_message(kind: str) -> Optional[str]:
    if kind == "heavy":
        return "Recibido. Esto sí parece tarea pesada; la mando al worker y te regreso el Task ID."
    return None


def fallback_wait_message(kind: str) -> str:
    if kind == "status":
        return "Revisando estado real."
    if kind == "library":
        return "Consultando catálogo local."
    if kind == "reset":
        return "Ejecutando reset de runtime."
    return "Revisando tu solicitud."
