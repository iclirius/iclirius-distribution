import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv


_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_MACHINE_ROOT = Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()
_MACHINE_CONFIG = Path(os.getenv("ICLIRIUS_CONFIG_PATH", str(_MACHINE_ROOT / "config.env"))).expanduser()
# Development checkouts may keep a local .env. Installed packages do not have
# one, so machine configuration is the canonical source outside a checkout.
_PROJECT_ENV = _PROJECT_ROOT / ".env"
if _PROJECT_ENV.is_file():
    load_dotenv(dotenv_path=_PROJECT_ENV)
load_dotenv(dotenv_path=_MACHINE_CONFIG)
load_dotenv()


def _runtime_path(relative: str) -> str:
    """Resolve shared runtime state independently from the caller's cwd."""
    root = os.getenv("OPENCLAW_RUNTIME_ROOT", "").strip()
    if not root:
        return str(_MACHINE_ROOT / "runtime" / relative)
    return str(Path(root).expanduser() / relative)


def _configured_path(name: str, relative: str) -> str:
    """Resolve .env relative paths against the canonical runtime root."""
    raw = os.getenv(name, "").strip()
    if not raw:
        return _runtime_path(relative)
    path = Path(raw).expanduser()
    if path.is_absolute() or not os.getenv("OPENCLAW_RUNTIME_ROOT", "").strip():
        return str(path)
    return str(Path(os.environ["OPENCLAW_RUNTIME_ROOT"]).expanduser() / path)


def _optional_path(raw: str) -> Path | None:
    """
    Resolve a user-configurable root path.

    Returns None when the setting is empty so callers can fail closed with a
    clear message instead of falling back to somebody's personal directory.
    """
    raw = (raw or "").strip()

    if not raw:
        return None

    return Path(raw).expanduser()


@dataclass
class Settings:
    agent_name: str = os.getenv("AGENT_NAME", "iclirius")

    openclaw_env: str = os.getenv("OPENCLAW_ENV", "local")
    node_id: str = os.getenv("OPENCLAW_NODE_ID", "unknown-node")
    cluster_name: str = os.getenv("OPENCLAW_CLUSTER_NAME", "openclaw-home")
    role: str = os.getenv("OPENCLAW_ROLE", "leader")

    enable_telegram: bool = os.getenv("ENABLE_TELEGRAM", "false").lower() == "true"
    enable_cli: bool = os.getenv("ENABLE_CLI", "false").lower() == "true"

    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    allowed_user_ids_raw: str = os.getenv("ALLOWED_USER_IDS", "")
    owner_user_ids_raw: str = os.getenv("OWNER_USER_IDS", "")
    telegram_mode: str = os.getenv("TELEGRAM_MODE", "SINGLE").upper()
    telegram_lease_backend: str = os.getenv("TELEGRAM_LEASE_BACKEND", "FILE").upper()
    telegram_lease_database: str = os.getenv("TELEGRAM_LEASE_DATABASE", "")
    telegram_lease_path: str = os.getenv("TELEGRAM_LEASE_PATH", "")
    telegram_lease_ttl_seconds: int = int(os.getenv("TELEGRAM_LEASE_TTL_SECONDS", "30"))

    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
    default_model: str = os.getenv("DEFAULT_MODEL", "qwen2.5:14b")
    fast_model: str = os.getenv("FAST_MODEL", "llama3")
    heavy_model: str = os.getenv("HEAVY_MODEL", "gpt-oss:20b")
    embed_model: str = os.getenv("EMBED_MODEL", "nomic-embed-text")

    ollama_timeout: int = int(os.getenv("OLLAMA_TIMEOUT", "120"))
    ollama_max_attempts: int = int(os.getenv("OLLAMA_MAX_ATTEMPTS", "2"))
    ollama_backoff_seconds: float = float(os.getenv("OLLAMA_BACKOFF_SECONDS", "1.0"))
    ollama_num_ctx: int = int(os.getenv("OLLAMA_NUM_CTX", "0"))

    documents_path: str = _configured_path("DOCUMENTS_PATH", "data/documents")
    memory_path: str = _configured_path("MEMORY_PATH", "data/memory")
    identity_path: str = _configured_path("IDENTITY_PATH", "data/identity")
    state_path: str = _configured_path("STATE_PATH", "data/state")
    chroma_path: str = _configured_path("CHROMA_PATH", "data/chroma")
    logs_path: str = _configured_path("LOGS_PATH", "logs")

    permission_mode: str = os.getenv("DEFAULT_PERMISSION_MODE", "ASSISTED")

    worker_url_raw: str = os.getenv("WORKER_URL", "")
    enable_worker_delegation_raw: str = os.getenv("ENABLE_WORKER_DELEGATION", "false")

    worker_ssh_host: str = os.getenv("WORKER_SSH_HOST", "")
    worker_ssh_user: str = os.getenv("WORKER_SSH_USER", "")
    worker_project_dir: str = os.getenv("WORKER_PROJECT_DIR", "~/OpenClaw/openclaw")
    worker_ssh_key: str = os.getenv("WORKER_SSH_KEY", "")

    file_manager_allowed_roots_raw: str = os.getenv("FILE_MANAGER_ALLOWED_ROOTS", "")

    # FILE-1 bounded metadata inventory. These limits never authorize a root.
    file_scan_max_entries: int = int(os.getenv("FILE_SCAN_MAX_ENTRIES", "100000"))
    file_scan_max_depth: int = int(os.getenv("FILE_SCAN_MAX_DEPTH", "64"))
    file_scan_timeout_seconds: float = float(os.getenv("FILE_SCAN_TIMEOUT_SECONDS", "10"))
    file_scan_error_budget: int = int(os.getenv("FILE_SCAN_ERROR_BUDGET", "100"))
    file_content_max_pages: int = int(os.getenv("FILE_CONTENT_MAX_PAGES", "10"))
    file_content_max_characters: int = int(os.getenv("FILE_CONTENT_MAX_CHARACTERS", "20000"))

    # NATIVE-4 bounded local attachment staging. Attachments never become
    # permanent AllowedRoots and are removed after their short TTL.
    attachment_max_bytes: int = int(os.getenv("ATTACHMENT_MAX_BYTES", str(10 * 1024 * 1024)))
    attachment_ttl_seconds: int = int(os.getenv("ATTACHMENT_TTL_SECONDS", "3600"))

    # Let Iclirius inspect its own source tree without hardcoding anyone's
    # path. Only the repository directory is added, never HOME.
    include_project_root_raw: str = os.getenv("INCLUDE_PROJECT_ROOT", "true")

    # Web research. Read-only public search; no cloud LLM is involved.
    enable_web_search_raw: str = os.getenv("ENABLE_WEB_SEARCH", "false")
    web_search_endpoint: str = os.getenv(
        "WEB_SEARCH_ENDPOINT", "https://lite.duckduckgo.com/lite/"
    )
    web_search_max_results: int = int(os.getenv("WEB_SEARCH_MAX_RESULTS", "5"))
    web_max_pages: int = int(os.getenv("WEB_MAX_PAGES", "3"))
    web_connect_timeout: float = float(os.getenv("WEB_CONNECT_TIMEOUT", "5"))
    web_read_timeout: float = float(os.getenv("WEB_READ_TIMEOUT", "12"))
    web_max_redirects: int = int(os.getenv("WEB_MAX_REDIRECTS", "3"))
    web_fetch_max_bytes: int = int(os.getenv("WEB_FETCH_MAX_BYTES", "2000000"))
    web_fetch_max_chars: int = int(os.getenv("WEB_FETCH_MAX_CHARS", "6000"))
    web_evidence_chars_per_source: int = int(
        os.getenv("WEB_EVIDENCE_CHARS_PER_SOURCE", "2500")
    )

    # Memory Core. Local state is authoritative; LLM context is disposable.
    principal_user_name: str = os.getenv("PRINCIPAL_USER_NAME", "")
    user_id: str = os.getenv("ICLIRIUS_USER_ID", "")
    memory_home: str = os.getenv("MEMORY_HOME", "")
    setup_complete_raw: str = os.getenv("ICLIRIUS_SETUP_COMPLETE", "false")
    enable_memory_core_raw: str = os.getenv("ENABLE_MEMORY_CORE", "true")

    memory_lock_timeout: float = float(os.getenv("MEMORY_LOCK_TIMEOUT", "10"))
    memory_max_tasks: int = int(os.getenv("MEMORY_MAX_TASKS", "200"))
    memory_max_list_items: int = int(os.getenv("MEMORY_MAX_LIST_ITEMS", "20"))
    memory_max_web_findings: int = int(os.getenv("MEMORY_MAX_WEB_FINDINGS", "10"))
    memory_max_project_facts: int = int(os.getenv("MEMORY_MAX_PROJECT_FACTS", "20"))
    memory_fact_chars: int = int(os.getenv("MEMORY_FACT_CHARS", "400"))
    memory_task_summary_chars: int = int(os.getenv("MEMORY_TASK_SUMMARY_CHARS", "1200"))
    memory_project_summary_chars: int = int(os.getenv("MEMORY_PROJECT_SUMMARY_CHARS", "600"))

    # Legacy context budget, still used by the original context_builder.
    context_total_chars: int = int(os.getenv("CONTEXT_TOTAL_CHARS", "9000"))
    context_summary_chars: int = int(os.getenv("CONTEXT_SUMMARY_CHARS", "1500"))
    context_history_chars: int = int(os.getenv("CONTEXT_HISTORY_CHARS", "2500"))
    context_learned_chars: int = int(os.getenv("CONTEXT_LEARNED_CHARS", "800"))

    # Task engine.
    enable_task_engine_raw: str = os.getenv("ENABLE_TASK_ENGINE", "true")
    task_duplicate_threshold: float = float(os.getenv("TASK_DUPLICATE_THRESHOLD", "0.6"))

    # Planner. Conservative by default: small plans beat blind ones.
    enable_planner_raw: str = os.getenv("ENABLE_PLANNER", "true")
    planner_max_steps: int = int(os.getenv("PLANNER_MAX_STEPS", "6"))
    planner_max_iterations: int = int(os.getenv("PLANNER_MAX_ITERATIONS", "3"))
    planner_max_tool_calls: int = int(os.getenv("PLANNER_MAX_TOOL_CALLS", "5"))
    planner_max_proposal_attempts: int = int(os.getenv("PLANNER_MAX_PROPOSAL_ATTEMPTS", "2"))
    planner_max_context_chars: int = int(os.getenv("PLANNER_MAX_CONTEXT_CHARS", "3000"))
    planner_max_result_chars: int = int(os.getenv("PLANNER_MAX_RESULT_CHARS", "1200"))

    # Conversation history. Turns are summarised rather than pasted whole.
    history_max_turns: int = int(os.getenv("HISTORY_MAX_TURNS", "4"))
    history_turn_chars: int = int(os.getenv("HISTORY_TURN_CHARS", "160"))

    # Safe write. Off by default: a fresh install reads, has the capability
    # present, and will not write without being asked.
    write_enabled_raw: str = os.getenv("WRITE_ENABLED", "false")
    write_confirm_required_raw: str = os.getenv("WRITE_CONFIRM_REQUIRED", "true")
    write_approval_ttl_seconds: int = int(os.getenv("WRITE_APPROVAL_TTL_SECONDS", "600"))

    write_max_files_per_interaction: int = int(os.getenv("WRITE_MAX_FILES_PER_INTERACTION", "3"))
    write_max_patches_per_file: int = int(os.getenv("WRITE_MAX_PATCHES_PER_FILE", "5"))
    write_max_changed_lines: int = int(os.getenv("WRITE_MAX_CHANGED_LINES", "80"))
    write_max_added_chars: int = int(os.getenv("WRITE_MAX_ADDED_CHARS", "4000"))
    write_max_removed_chars: int = int(os.getenv("WRITE_MAX_REMOVED_CHARS", "4000"))
    write_max_file_bytes: int = int(os.getenv("WRITE_MAX_FILE_BYTES", "300000"))
    write_max_proposals_per_interaction: int = int(
        os.getenv("WRITE_MAX_PROPOSALS_PER_INTERACTION", "1"))
    write_preview_chars: int = int(os.getenv("WRITE_PREVIEW_CHARS", "1200"))

    # Grounded patch generation. The model only ever sees files OpenClaw has
    # already read locally, and only up to this many characters of them.
    patch_model_max_context_chars: int = int(
        os.getenv("PATCH_MODEL_MAX_CONTEXT_CHARS", "12000"))
    patch_model_max_files: int = int(os.getenv("PATCH_MODEL_MAX_FILES", "3"))
    patch_model_max_file_chars: int = int(
        os.getenv("PATCH_MODEL_MAX_FILE_CHARS", "6000"))

    # Safe execute. Off by default and confirm-required when on. The model
    # names a profile; it never supplies a command line.
    execute_enabled_raw: str = os.getenv("EXECUTE_ENABLED", "false")
    execute_confirm_required_raw: str = os.getenv("EXECUTE_CONFIRM_REQUIRED", "true")
    execute_approval_ttl_seconds: int = int(
        os.getenv("EXECUTE_APPROVAL_TTL_SECONDS", "600"))
    execute_timeout_seconds: int = int(os.getenv("EXECUTE_TIMEOUT_SECONDS", "300"))
    execute_max_output_bytes: int = int(os.getenv("EXECUTE_MAX_OUTPUT_BYTES", "200000"))
    execute_max_report_chars: int = int(os.getenv("EXECUTE_MAX_REPORT_CHARS", "2000"))
    execute_allow_project_local_tools_raw: str = os.getenv(
        "EXECUTE_ALLOW_PROJECT_LOCAL_TOOLS", "false")

    # The coding loop: propose, apply, verify. Bounded on every axis.
    coding_max_iterations: int = int(os.getenv("CODING_MAX_ITERATIONS", "3"))
    coding_max_patches: int = int(os.getenv("CODING_MAX_PATCHES", "2"))
    coding_max_executions: int = int(os.getenv("CODING_MAX_EXECUTIONS", "3"))

    # Runtime bridge: local, read-only observability for a future TUI.
    # Unix socket only. There is no TCP option by design.
    enable_runtime_bridge_raw: str = os.getenv("ENABLE_RUNTIME_BRIDGE", "false")
    runtime_socket_path: str = os.getenv(
        "RUNTIME_SOCKET_PATH", "./data/state/iclirius.sock"
    )
    runtime_activity_limit: int = int(os.getenv("RUNTIME_ACTIVITY_LIMIT", "20"))

    # Context engine budgets. Per-section caps plus one hard total.
    context_total_max_chars: int = int(os.getenv("CONTEXT_TOTAL_MAX_CHARS", "6000"))
    context_task_max_chars: int = int(os.getenv("CONTEXT_TASK_MAX_CHARS", "1500"))
    context_project_max_chars: int = int(os.getenv("CONTEXT_PROJECT_MAX_CHARS", "600"))
    context_history_max_chars: int = int(os.getenv("CONTEXT_HISTORY_MAX_CHARS", "1500"))
    context_evidence_max_chars: int = int(os.getenv("CONTEXT_EVIDENCE_MAX_CHARS", "2000"))
    context_global_max_chars: int = int(os.getenv("CONTEXT_GLOBAL_MAX_CHARS", "800"))

    # Active memory uses local filesystem IO, including locally available
    # synchronized folders. Files must remain resident for offline operation.
    memory_root: str = _configured_path("MEMORY_ROOT", "data/memory/core")

    # Encrypted snapshots of the canonical state. Local by default and local
    # only in this phase: no network destination exists, and the snapshot
    # never leaves the machine on its own.
    #
    # On macOS the conventional home for this is
    # ~/Library/Application Support/OpenClaw/backups, but the default stays
    # inside the project so an existing install is not silently relocated.
    memory_backup_root: str = _configured_path(
        "MEMORY_BACKUP_ROOT", "data/backups/memory")
    memory_backup_retention_count: int = int(
        os.getenv("MEMORY_BACKUP_RETENTION_COUNT", "10"))

    # --- Gemini -----------------------------------------------------------
    # The first real cloud provider. Off by default: LOCAL stays the default
    # mode and nothing reaches the network unless this is turned on
    # deliberately.
    gemini_enabled_raw: str = os.getenv("GEMINI_ENABLED", "false")
    gemini_model: str = os.getenv("GEMINI_MODEL", "")
    gemini_account_ref: str = os.getenv("GEMINI_ACCOUNT_REF", "gemini-primary")
    # A reference, never a value. keychain:service/account or env:VARIABLE.
    gemini_credential_ref: str = os.getenv("GEMINI_CREDENTIAL_REF", "")
    gemini_timeout_seconds: int = int(os.getenv("GEMINI_TIMEOUT_SECONDS", "60"))
    gemini_max_context_chars: int = int(
        os.getenv("GEMINI_MAX_CONTEXT_CHARS", "100000"))

    # Several accounts, declared in one place. Pipe-separated so a Keychain
    # reference, which already contains a colon, needs no escaping:
    #   account_ref|credential_ref|priority
    gemini_accounts_raw: str = os.getenv("GEMINI_ACCOUNTS", "")
    gemini_rate_limit_cooldown_seconds: int = int(
        os.getenv("GEMINI_RATE_LIMIT_COOLDOWN_SECONDS", "60"))
    gemini_exhaustion_cooldown_seconds: int = int(
        os.getenv("GEMINI_EXHAUSTION_COOLDOWN_SECONDS", "900"))
    # How many accounts one reasoning request may try. Small on purpose: this
    # bounds a retry storm across a pool, and does not touch Ollama's retries.
    cloud_max_account_attempts: int = int(
        os.getenv("CLOUD_MAX_ACCOUNT_ATTEMPTS", "2"))

    # Per-task cloud budgets. Zero means unlimited, which switches a budget
    # off without deleting it. Conservative defaults: this is metered, and a
    # runaway loop should stop rather than spend.
    cloud_max_requests_per_task: int = int(
        os.getenv("CLOUD_MAX_REQUESTS_PER_TASK", "20"))
    cloud_max_input_tokens_per_task: int = int(
        os.getenv("CLOUD_MAX_INPUT_TOKENS_PER_TASK", "200000"))
    cloud_max_output_tokens_per_task: int = int(
        os.getenv("CLOUD_MAX_OUTPUT_TOKENS_PER_TASK", "50000"))

    # Local Telegram voice. Off keeps the existing text-only behaviour.
    voice_enabled_raw: str = os.getenv("VOICE_ENABLED", "false")
    voice_mode: str = os.getenv("VOICE_MODE", "off").lower()
    voice_name: str = os.getenv("VOICE_NAME", "")
    voice_rate: int = int(os.getenv("VOICE_RATE", "180"))
    voice_max_chars: int = int(os.getenv("VOICE_MAX_CHARS", "2000"))
    voice_input_max_bytes: int = int(os.getenv("VOICE_INPUT_MAX_BYTES", "10000000"))
    voice_input_max_duration: int = int(os.getenv("VOICE_INPUT_MAX_DURATION", "300"))
    voice_tts_timeout: int = int(os.getenv("VOICE_TTS_TIMEOUT", "30"))

    # Local read tools. Read only: no create, edit, move, delete or shell.
    enable_local_read_tools_raw: str = os.getenv("ENABLE_LOCAL_READ_TOOLS", "false")
    local_read_max_results: int = int(os.getenv("LOCAL_READ_MAX_RESULTS", "100"))
    local_read_max_depth: int = int(os.getenv("LOCAL_READ_MAX_DEPTH", "8"))
    local_read_max_bytes: int = int(os.getenv("LOCAL_READ_MAX_BYTES", "500000"))
    local_read_max_lines: int = int(os.getenv("LOCAL_READ_MAX_LINES", "400"))
    local_read_model_chars: int = int(os.getenv("LOCAL_READ_MODEL_CHARS", "6000"))
    local_read_timeout: int = int(os.getenv("LOCAL_READ_TIMEOUT", "30"))

    # User-specific locations. Deliberately empty by default: there is no
    # sensible fallback for somebody else's machine, so operations that need
    # them must fail with a clear message instead of guessing.
    library_root_raw: str = os.getenv("LIBRARY_ROOT", "")
    catalog_root_raw: str = os.getenv("CATALOG_ROOT", "")
    backup_root_raw: str = os.getenv("BACKUP_ROOT", "")

    def _parse_user_ids(self, raw: str) -> set[int]:
        ids = set()

        for item in raw.split(","):
            item = item.strip()
            if item.isdigit():
                ids.add(int(item))

        return ids

    @property
    def allowed_user_ids(self) -> set[int]:
        return self._parse_user_ids(self.allowed_user_ids_raw)

    @property
    def owner_user_ids(self) -> set[int]:
        return self._parse_user_ids(self.owner_user_ids_raw)

    @property
    def worker_url(self) -> str:
        return self.worker_url_raw.strip()

    @property
    def enable_worker_delegation(self) -> bool:
        return self.enable_worker_delegation_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def write_enabled(self) -> bool:
        return self.write_enabled_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def write_confirm_required(self) -> bool:
        """
        Confirmation is the default and the fallback.

        Anything other than an explicit opt-out keeps the confirmation, so a
        typo in configuration cannot silently enable automatic writes.
        """
        return self.write_confirm_required_raw.lower() not in {"0", "false", "no", "off"}

    @property
    def gemini_enabled(self) -> bool:
        """
        Off unless explicitly enabled.

        Same shape as every other capability switch: only an affirmative value
        turns it on, so a typo leaves the cloud disconnected rather than
        connected.
        """
        return self.gemini_enabled_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def execute_enabled(self) -> bool:
        return self.execute_enabled_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def execute_confirm_required(self) -> bool:
        """Same fallback rule as write: only an explicit opt-out disables it."""
        return self.execute_confirm_required_raw.lower() not in {"0", "false", "no", "off"}

    @property
    def execute_allow_project_local_tools(self) -> bool:
        """
        Whether ./gradlew, ./node_modules/.bin and friends may be run.

        These are executables that live in the repository, so running one
        means trusting whoever wrote it. Cloning a hostile repository and
        asking for tests would run their code, which is why this is off unless
        the user turns it on for a project they already trust.
        """
        return self.execute_allow_project_local_tools_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_runtime_bridge(self) -> bool:
        return self.enable_runtime_bridge_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_planner(self) -> bool:
        return self.enable_planner_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_task_engine(self) -> bool:
        return self.enable_task_engine_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_memory_core(self) -> bool:
        return self.enable_memory_core_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def setup_complete(self) -> bool:
        return self.setup_complete_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_local_read_tools(self) -> bool:
        return self.enable_local_read_tools_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def enable_web_search(self) -> bool:
        return self.enable_web_search_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def voice_enabled(self) -> bool:
        return self.voice_enabled_raw.lower() in {"1", "true", "yes", "on"}

    def model_for_tier(self, tier: str) -> str:
        """
        Model name configured for a tier.

        Tiers are the only way model names enter the system; nothing hardcodes
        one. Several tiers may legitimately point at the same model.
        """
        models = {
            "fast": self.fast_model,
            "default": self.default_model,
            "heavy": self.heavy_model,
        }

        if tier not in models:
            raise ValueError(f"Unknown model tier: {tier}")

        return models[tier] or self.default_model

    @property
    def library_root(self) -> Path | None:
        """Folder holding the personal book/document library. None if unset."""
        return _optional_path(self.library_root_raw)

    @property
    def catalog_root(self) -> Path | None:
        """Folder the file catalog walks. None if unset."""
        return _optional_path(self.catalog_root_raw)

    @property
    def backup_root(self) -> Path | None:
        """Destination folder for data snapshots. None if unset."""
        return _optional_path(self.backup_root_raw)

    @property
    def include_project_root(self) -> bool:
        return self.include_project_root_raw.lower() in {"1", "true", "yes", "on"}

    @property
    def project_root(self) -> Path:
        """
        This checkout of OpenClaw, derived from the module location.

        Portable by construction: it follows the installation rather than a
        configured string, so it is correct on any machine and carries no
        personal path in the repository.
        """
        return Path(__file__).resolve().parent.parent

    @property
    def file_manager_allowed_roots(self) -> list[str]:
        roots = [
            item.strip()
            for item in self.file_manager_allowed_roots_raw.split(",")
            if item.strip()
        ]

        # Appended, never substituted: an unset allowlist stays fail-closed
        # for everything except the agent's own source, and HOME is never
        # added wholesale.
        if self.include_project_root:
            own = str(self.project_root)
            if own not in roots:
                roots.append(own)

        return roots


settings = Settings()
