"""Provider account, session, and usage truth models.

Profiles contain safe metadata and credential references only. Provider
adapters validate their own sessions; the model never treats configuration as
proof of validity.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum

from app.config import settings
from app.evidence import Certainty, EvidenceRecord, SourceType
from models.ollama_client import OllamaClient


class AuthMethod(str, Enum):
    LOCAL = "LOCAL"
    API_KEY = "API_KEY"
    OAUTH = "OAUTH"
    SERVICE_ACCOUNT = "SERVICE_ACCOUNT"
    APPLICATION_DEFAULT_CREDENTIALS = "APPLICATION_DEFAULT_CREDENTIALS"
    NONE = "NONE"


class SessionState(str, Enum):
    NOT_CONFIGURED = "NOT_CONFIGURED"
    AUTHENTICATING = "AUTHENTICATING"
    VALID = "VALID"
    REFRESHING = "REFRESHING"
    EXPIRED = "EXPIRED"
    REAUTH_REQUIRED = "REAUTH_REQUIRED"
    RATE_LIMITED = "RATE_LIMITED"
    QUOTA_EXHAUSTED = "QUOTA_EXHAUSTED"
    UNAVAILABLE = "UNAVAILABLE"
    UNKNOWN = "UNKNOWN"


class UsageEvidence(str, Enum):
    MEASURED = "MEASURED"
    PROVIDER_REPORTED = "PROVIDER_REPORTED"
    ESTIMATED = "ESTIMATED"
    UNKNOWN = "UNKNOWN"
    DERIVED = "DERIVED"


class ContextPressure(str, Enum):
    NORMAL = "NORMAL"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"
    EXHAUSTED = "EXHAUSTED"
    UNKNOWN = "UNKNOWN"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def mask_account(value: str) -> str:
    if not value or "@" not in value:
        return value or "local"
    name, domain = value.split("@", 1)
    return f"{name[:1]}***@{domain}"


@dataclass
class AIAccountProfile:
    profile_id: str
    provider_id: str
    display_name: str
    display_account: str = ""
    auth_method: str = AuthMethod.NONE.value
    session_state: str = SessionState.NOT_CONFIGURED.value
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    last_validated_at: str = ""
    credential_ref: str = ""
    node_id: str = ""
    default: bool = False
    access_expires_at: str | None = None
    refresh_available: bool | None = None
    refresh_expires_at: str | None = None
    reauth_required: bool = False

    def to_dict(self) -> dict:
        data = asdict(self)
        data.pop("credential_ref", None)
        data["display_account"] = mask_account(data["display_account"])
        return data


@dataclass
class AIUsageSnapshot:
    provider_id: str
    profile_id: str
    model_id: str
    requests: int | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    context_used: int | None = None
    context_limit: int | None = None
    cost: float | None = None
    currency: str = "USD"
    rate_limit_state: str = "UNKNOWN"
    quota_state: str = "UNKNOWN"
    reset_at: str | None = None
    metric_evidence: dict = field(default_factory=dict)
    context_pressure: str = ContextPressure.UNKNOWN.value
    observed_at: str = field(default_factory=_now)
    node_id: str = ""

    def to_dict(self) -> dict:
        return asdict(self) | {"schema_version": 1}


@dataclass(frozen=True)
class LoginResult:
    success: bool
    provider_id: str
    profile_id: str
    auth_method: str
    session_state: str
    reauth_required: bool = False
    safe_message: str = ""


@dataclass(frozen=True)
class RefreshResult:
    status: str
    provider_id: str
    profile_id: str
    safe_message: str = ""


class ProviderDefinition:
    def __init__(self, provider_id: str, display_name: str, kind: str, auth_methods: tuple[str, ...]):
        self.provider_id, self.display_name, self.kind, self.supported_auth_methods = provider_id, display_name, kind, auth_methods

    def to_dict(self) -> dict:
        return {"provider_id": self.provider_id, "display_name": self.display_name,
                "type": self.kind, "supported_auth_methods": list(self.supported_auth_methods)}


PROVIDERS = (
    ProviderDefinition("ollama-local", "Ollama", "LOCAL", (AuthMethod.LOCAL.value,)),
    ProviderDefinition("gemini", "Gemini", "CLOUD", (AuthMethod.API_KEY.value, AuthMethod.OAUTH.value)),
    ProviderDefinition("openai", "OpenAI", "CLOUD", (AuthMethod.API_KEY.value, AuthMethod.OAUTH.value)),
    ProviderDefinition("anthropic", "Anthropic", "CLOUD", (AuthMethod.API_KEY.value,)),
)


def context_pressure(used: int | None, limit: int | None) -> str:
    if not used or not limit or limit <= 0:
        return ContextPressure.UNKNOWN.value
    ratio = used / limit
    if ratio >= .95: return ContextPressure.EXHAUSTED.value
    if ratio >= .85: return ContextPressure.CRITICAL.value
    if ratio >= .70: return ContextPressure.HIGH.value
    return ContextPressure.NORMAL.value


class OllamaAccountAdapter:
    provider_id = "ollama-local"

    def __init__(self, client: OllamaClient | None = None, node_id: str = ""):
        self.client = client or OllamaClient()
        self.node_id = node_id or str(getattr(settings, "node_id", ""))

    def profile(self) -> AIAccountProfile:
        reachable = bool(self.client.health())
        model = settings.default_model
        models = self.client.installed_models() if reachable else []
        state = SessionState.VALID.value if reachable else SessionState.UNAVAILABLE.value
        return AIAccountProfile("ollama-local:local", self.provider_id, "Ollama local", "local",
                                AuthMethod.LOCAL.value, state, last_validated_at=_now(),
                                node_id=self.node_id, default=True)

    def usage(self) -> AIUsageSnapshot:
        profile = self.profile(); model = settings.default_model
        reachable = profile.session_state == SessionState.VALID.value
        return AIUsageSnapshot(self.provider_id, profile.profile_id, model,
                               requests=None, input_tokens=None, output_tokens=None,
                               total_tokens=None, context_used=None,
                               context_limit=settings.ollama_num_ctx or None,
                               cost=0.0, metric_evidence={"cost": UsageEvidence.MEASURED.value},
                               context_pressure=context_pressure(None, settings.ollama_num_ctx or None),
                               node_id=self.node_id)

    def models(self) -> list[str]:
        return self.client.installed_models()

    def status_evidence(self) -> EvidenceRecord:
        profile = self.profile()
        return EvidenceRecord(SourceType.OLLAMA.value, "health", "local endpoint",
                              {"session_state": profile.session_state, "provider_id": self.provider_id},
                              certainty="VERIFIED" if profile.session_state == SessionState.VALID.value else "OBSERVED",
                              node_id=self.node_id, tool_id="ollama_client")


def provider_definitions() -> list[dict]:
    return [item.to_dict() for item in PROVIDERS]


def status(node_id: str = "") -> dict:
    ollama = OllamaAccountAdapter(node_id=node_id)
    profile = ollama.profile()
    definitions = provider_definitions()
    from app.gemini_auth import gemini_status
    gemini_profiles = gemini_status(node_id)
    providers = [{**item, "session_state": profile.session_state if item["provider_id"] == profile.provider_id else SessionState.NOT_CONFIGURED.value}
                 for item in definitions]
    if gemini_profiles:
        gemini_state = gemini_profiles[0].get("session_state", SessionState.UNKNOWN.value)
        providers = [{**p, "session_state": gemini_state} if p["provider_id"] == "gemini" else p for p in providers]
    return {"schema_version": 1, "active_provider": profile.provider_id,
            "active_profile": profile.profile_id, "accounts": [profile.to_dict()] + gemini_profiles,
            "providers": providers, "gemini_accounts": gemini_profiles, "node_id": node_id}


def usage(node_id: str = "") -> dict:
    snapshots = [OllamaAccountAdapter(node_id=node_id).usage().to_dict()]
    from app.gemini_auth import load_profiles
    for profile in load_profiles():
        snapshots.append(AIUsageSnapshot("gemini", profile.profile_id, "",
                                         metric_evidence={"requests": UsageEvidence.UNKNOWN.value,
                                                          "input_tokens": UsageEvidence.UNKNOWN.value,
                                                          "output_tokens": UsageEvidence.UNKNOWN.value},
                                         node_id=node_id).to_dict())
    return {"schema_version": 1, "snapshots": snapshots}


def models() -> dict:
    adapter = OllamaAccountAdapter()
    from app.gemini_auth import GeminiAccountAdapter, load_profiles
    gemini = []
    for p in load_profiles():
        state, names, _ = GeminiAccountAdapter(p.profile_id.split(":", 1)[1]).models()
        if state == SessionState.VALID.value or state == SessionState.VALID:
            gemini.extend(names)
    return {"schema_version": 1, "provider_id": adapter.provider_id,
            "configured": [settings.default_model, settings.fast_model, settings.heavy_model],
            "installed": adapter.models(), "gemini": sorted(set(gemini))}
