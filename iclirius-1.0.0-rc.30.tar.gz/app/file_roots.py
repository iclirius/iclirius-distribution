"""Authorized FileRoot provider resolution (read-only)."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class RootProvider(str, Enum):
    LOCAL = "LOCAL"
    GOOGLE_DRIVE = "GOOGLE_DRIVE"
    ICLOUD_DRIVE = "ICLOUD_DRIVE"
    DROPBOX = "DROPBOX"
    ONEDRIVE = "ONEDRIVE"
    UNKNOWN_CLOUD = "UNKNOWN_CLOUD"


class RootResolutionStatus(str, Enum):
    RESOLVED = "RESOLVED"
    NOT_CONFIGURED = "NOT_CONFIGURED"
    NOT_AUTHORIZED = "NOT_AUTHORIZED"
    UNAVAILABLE = "UNAVAILABLE"
    AMBIGUOUS = "AMBIGUOUS"
    IDENTITY_REQUIRED = "IDENTITY_REQUIRED"
    WRONG_NODE = "WRONG_NODE"


def canonical_path(value: str | Path) -> Path:
    return Path(value).expanduser().resolve(strict=False)


def detect_provider(path: str | Path, metadata: dict | None = None) -> RootProvider:
    """Prefer explicit metadata, otherwise inspect the configured mount path."""
    explicit = str((metadata or {}).get("provider") or "").upper()
    if explicit in {item.value for item in RootProvider}:
        return RootProvider(explicit)
    parts = canonical_path(path).parts
    cloud_index = next((i for i, part in enumerate(parts) if part == "CloudStorage"), -1)
    if cloud_index >= 0 and cloud_index + 1 < len(parts):
        mount = parts[cloud_index + 1].casefold()
        if mount.startswith("googledrive-"):
            return RootProvider.GOOGLE_DRIVE
        if mount.startswith("icloud"):
            return RootProvider.ICLOUD_DRIVE
        if "dropbox" in mount:
            return RootProvider.DROPBOX
        if "onedrive" in mount:
            return RootProvider.ONEDRIVE
        return RootProvider.UNKNOWN_CLOUD
    return RootProvider.LOCAL


@dataclass(frozen=True)
class ResolvedFileRoot:
    root_id: str
    canonical_path: str
    display_name: str
    node_id: str
    user_id: str | None
    provider: RootProvider
    cloud_backed: bool


@dataclass(frozen=True)
class RootResolution:
    status: RootResolutionStatus
    provider: RootProvider
    root: ResolvedFileRoot | None = None
    candidates: tuple[ResolvedFileRoot, ...] = ()
    reason: str = ""


def _root_for(path: Path, provider: RootProvider, node_id: str, user_id: str | None) -> ResolvedFileRoot:
    root_id = "root_" + hashlib.sha256(f"{node_id}\0{path}".encode()).hexdigest()[:16]
    return ResolvedFileRoot(root_id, str(path), path.name or str(path), node_id,
                            user_id or None, provider, provider != RootProvider.LOCAL)


def resolve_file_root(*, provider: RootProvider, allowed_roots: list[str] | tuple[str, ...],
                      node_id: str, user_id: str | None = None,
                      metadata: dict[str, dict] | None = None) -> RootResolution:
    """Resolve exactly one authorized root; never choose among multiple candidates."""
    if not allowed_roots:
        return RootResolution(RootResolutionStatus.NOT_CONFIGURED, provider, reason="no allowed roots")
    candidates: list[ResolvedFileRoot] = []
    wrong_node = False
    identity_required = False
    for raw in allowed_roots:
        path = canonical_path(raw)
        meta = (metadata or {}).get(str(path), {})
        if meta.get("node_id") and str(meta["node_id"]) != node_id:
            wrong_node = True
            continue
        if meta.get("user_id") and not user_id:
            identity_required = True
            continue
        if meta.get("user_id") and str(meta["user_id"]) != str(user_id):
            continue
        detected = detect_provider(path, meta)
        if detected != provider:
            continue
        root = _root_for(path, detected, node_id, user_id)
        if not path.exists() or not path.is_dir() or not os.access(path, os.R_OK):
            continue
        candidates.append(root)
    if not candidates:
        if wrong_node:
            return RootResolution(RootResolutionStatus.WRONG_NODE, provider, reason="root belongs to another node")
        if identity_required:
            return RootResolution(RootResolutionStatus.IDENTITY_REQUIRED, provider, reason="root identity required")
        configured_provider = any(detect_provider(raw, (metadata or {}).get(str(canonical_path(raw)))) == provider
                                  for raw in allowed_roots)
        status = RootResolutionStatus.UNAVAILABLE if configured_provider else RootResolutionStatus.NOT_AUTHORIZED
        return RootResolution(status, provider, reason="no accessible authorized root")
    if len(candidates) > 1:
        return RootResolution(RootResolutionStatus.AMBIGUOUS, provider,
                              candidates=tuple(candidates), reason="multiple authorized roots")
    return RootResolution(RootResolutionStatus.RESOLVED, provider, root=candidates[0],
                          candidates=tuple(candidates))
