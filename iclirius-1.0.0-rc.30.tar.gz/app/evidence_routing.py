"""Conservative routing for requests with deterministic filesystem answers."""
from __future__ import annotations

import re


DETERMINISTIC_PATTERNS = (
    r"\bhow many files\b", r"\bcu[aá]ntos archivos\b", r"\btotal size\b",
    r"\bcu[aá]nto pesa\b", r"\bfile exists\b", r"\bexiste el archivo\b",
    r"\blargest files?\b", r"\bm[aá]s grandes\b", r"\bmodified today\b",
    r"\bmodificados? hoy\b", r"\bcount files\b",
)
SEARCH_PATTERNS = (r"\bwhich file\b", r"\bqué archivo\b", r"\bmentions?\b", r"\bmenciona\b")


def classify_request(request: str) -> str:
    text = (request or "").lower()
    if any(re.search(pattern, text) for pattern in DETERMINISTIC_PATTERNS):
        return "DETERMINISTIC_FACT"
    if any(re.search(pattern, text) for pattern in SEARCH_PATTERNS):
        return "EVIDENCE_SEARCH"
    return "REASONING_INTERPRETATION"
