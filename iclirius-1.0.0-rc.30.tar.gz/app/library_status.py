import json
from datetime import datetime
from pathlib import Path
from app.config import settings

from app.config import settings
from app.file_state import manifest_summary


CHUNKS_DIR = Path(settings.state_path) / "library" / "chunks"

LIBRARY_ROOT_HINT = "Define LIBRARY_ROOT en .env para contar los archivos de origen."


def library_status() -> str:
    books_dir = settings.library_root

    book_files = []
    if books_dir is not None and books_dir.exists():
        book_files = [
            p for p in books_dir.rglob("*")
            if p.is_file() and p.suffix.lower() in {
                ".epub", ".pdf", ".mobi", ".azw3", ".txt", ".md"
            }
        ]

    indexed_paths = set()
    chunks = 0
    newest = 0
    newest_file = None

    if CHUNKS_DIR.exists():
        for file in CHUNKS_DIR.glob("*.jsonl"):
            try:
                if file.stat().st_mtime > newest:
                    newest = file.stat().st_mtime
                    newest_file = file

                with file.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            row = json.loads(line)
                        except Exception:
                            continue
                        chunks += 1
                        if row.get("path"):
                            indexed_paths.add(row["path"])
            except Exception:
                continue

    total_books = len(book_files)
    indexed = len(indexed_paths)
    pending = max(0, total_books - indexed)

    lines = []
    lines.append("Estado real de librería:")

    if books_dir is None:
        lines.append(f"- Carpeta de origen: NO CONFIGURADA. {LIBRARY_ROOT_HINT}")
    elif not books_dir.exists():
        lines.append(f"- Carpeta de origen: NO ENCONTRADA ({books_dir})")
    else:
        lines.append(f"- Carpeta de origen: {books_dir}")

    lines.append(f"- Archivos soportados en carpeta: {total_books}")
    lines.append(f"- Archivos indexados: {indexed}")
    lines.append(f"- Pendientes aproximados: {pending}")
    lines.append(f"- Chunks totales: {chunks}")

    if newest:
        lines.append(
            f"- Última actividad chunks: "
            f"{datetime.fromtimestamp(newest).isoformat(timespec='seconds')}"
        )
        lines.append(f"- Último chunk file: {newest_file}")

    lines.append("")
    lines.append("Manifest:")
    lines.append(manifest_summary())

    return "\n".join(lines)
