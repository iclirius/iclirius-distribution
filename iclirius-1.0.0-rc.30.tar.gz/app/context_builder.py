"""
Assembly of the prompt that reaches the model.

Two rules, enforced here rather than trusted elsewhere:

    Local state is authoritative. LLM context is disposable.
    Never resend information that OpenClaw can retrieve, compute, filter,
    summarize or verify locally.

So this module selects rather than concatenates. It takes the active project
and the active task from the Memory Core, caps every section, and reports how
many characters each part contributed so the reduction can be measured.
"""

from dataclasses import dataclass, field
from pathlib import Path

from app.config import settings


IDENTITY_PATH = Path(settings.identity_path) / "personality.md"
SUMMARY_PATH = Path(settings.memory_path) / "summary.md"
LEARNED_PATH = Path(settings.memory_path) / "learned.jsonl"
PROJECT_STATUS_PATH = Path(settings.state_path) / "project_status.md"


def _read_text(path: Path, default: str = "") -> str:
    try:
        if path.exists():
            return path.read_text().strip()
    except Exception:
        return default
    return default


def _read_recent_learned(limit: int = 20) -> str:
    if not LEARNED_PATH.exists():
        return ""

    try:
        lines = [line.strip() for line in LEARNED_PATH.read_text().splitlines() if line.strip()]
    except Exception:
        return ""

    if not lines:
        return ""

    return "\n".join(lines[-limit:])


@dataclass
class ContextMetrics:
    """Sizes only. Never content."""

    context_chars: int = 0
    history_chars: int = 0
    memory_chars: int = 0
    task_chars: int = 0
    project_chars: int = 0
    sections: dict = field(default_factory=dict)

    def as_log_fields(self) -> dict:
        return {
            "context_chars": self.context_chars,
            "history_chars": self.history_chars,
            "memory_chars": self.memory_chars,
            "task_chars": self.task_chars,
            "project_chars": self.project_chars,
        }


# Module-level, read through last_metrics(). Importing the name directly
# would bind a snapshot and never see later updates.
_LAST_METRICS = ContextMetrics()


def last_metrics() -> ContextMetrics:
    """Sizes of the most recently assembled prompt."""
    return _LAST_METRICS


def _cap(text: str, limit: int) -> str:
    """Keep the tail: recent context is more useful than ancient context."""
    text = (text or "").strip()

    if len(text) <= limit:
        return text

    return "[...]\n" + text[-limit:]


def build_context_prompt(
    user_message: str,
    recent_history: str = "",
    extra_context: str = "",
    project_summary: str = "",
    task_summary: str = "",
) -> str:
    from app.identity import identity_prompt

    personality = _read_text(IDENTITY_PATH, identity_prompt())

    # summary.md is legacy, plaintext and unbounded. It is capped hard here and
    # is no longer the canonical place for anything new; the Memory Core is.
    summary = _cap(_read_text(SUMMARY_PATH, "Sin resumen vivo todavía."),
                   settings.context_summary_chars)
    learned = _cap(_read_recent_learned(), settings.context_learned_chars)
    project_status = _read_text(PROJECT_STATUS_PATH, "")
    recent_history = _cap(recent_history, settings.context_history_chars)

    sections: list[str] = [
        "## Identidad y estilo",
        personality,
        "",
        "## Resumen vivo",
        summary,
    ]

    if learned:
        sections.extend([
            "",
            "## Aprendizajes útiles recientes",
            learned,
        ])

    if project_status:
        sections.extend([
            "",
            "## Estado operativo del proyecto",
            project_status,
        ])

    # Memory Core sections come before history: the active task is the most
    # relevant thing in the prompt, and history is the most disposable.
    if project_summary:
        sections.extend(["", "## Proyecto activo", project_summary.strip()])

    if task_summary:
        sections.extend(["", "## Tarea activa", task_summary.strip()])

    if recent_history:
        sections.extend([
            "",
            "## Historial reciente relevante",
            recent_history.strip(),
        ])

    if extra_context:
        sections.extend([
            "",
            "## Contexto adicional",
            extra_context.strip(),
        ])

    sections.extend([
        "",
        "## Mensaje actual de Luis",
        user_message.strip(),
        "",
        "## Instrucciones de respuesta",
        "- Responde al mensaje actual usando el contexto solo si ayuda.",
        "- No inventes memoria si no está en el contexto.",
        "- Sé práctico, natural y directo.",
        "- Si das comandos, que sean completos y copiables.",
    ])

    prompt = "\n".join(sections).strip()

    # Final guard: no assembly path may exceed the total budget.
    if len(prompt) > settings.context_total_chars:
        prompt = prompt[: settings.context_total_chars]

    global _LAST_METRICS
    _LAST_METRICS = ContextMetrics(
        context_chars=len(prompt),
        history_chars=len(recent_history),
        memory_chars=len(summary) + len(learned),
        task_chars=len(task_summary or ""),
        project_chars=len(project_summary or ""),
        sections={
            "personality": len(personality),
            "summary": len(summary),
            "learned": len(learned),
            "project_status": len(project_status),
        },
    )

    return prompt
