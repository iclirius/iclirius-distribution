"""Read-only AI account/session/usage commands."""
from __future__ import annotations

import argparse
import json

from app.ai_accounts import models, provider_definitions, status, usage
from app.gemini_auth import GeminiAccountAdapter, configure_client


def _node_id() -> str:
    try:
        from app.node_identity import read_node
        return str((read_node() or {}).get("node_id", ""))
    except Exception:
        return ""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius ai")
    parser.add_argument("command", nargs="?", choices=("status", "accounts", "usage", "providers", "models", "login", "logout", "profiles", "configure"), default="status")
    parser.add_argument("provider", nargs="?")
    parser.add_argument("--profile", default="personal")
    parser.add_argument("--client-config")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv or [])
    if args.command == "status": data = status(_node_id())
    elif args.command in {"accounts", "profiles"}: data = {"schema_version": 1, "accounts": status(_node_id())["accounts"]}
    elif args.command == "usage": data = usage(_node_id())
    elif args.command == "providers": data = {"schema_version": 1, "providers": provider_definitions()}
    elif args.command == "models": data = models()
    elif args.command == "login":
        if args.provider != "gemini":
            print(f"{args.provider or 'provider'} login adapter is not implemented yet.")
            return 0
        result = GeminiAccountAdapter(args.profile).login()
        print(result.safe_message)
        return 0 if result.success else 1
    elif args.command == "logout":
        if args.provider != "gemini":
            print(f"{args.provider or 'provider'} logout adapter is not implemented yet.")
            return 0
        result = GeminiAccountAdapter(args.profile).logout()
        print(result.safe_message)
        return 0
    elif args.command == "configure":
        if args.provider != "gemini" or not args.client_config:
            print("Uso: iclirius ai configure gemini --client-config <archivo>")
            return 2
        try:
            configure_client(args.client_config)
        except Exception as exc:
            print(str(exc)); return 1
        print("Gemini OAuth client configured securely.")
        return 0
    else: data = {}
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    if args.command == "status":
        print("AI STATUS")
        for item in data["providers"]:
            print(f"\n{item['display_name']}\n  type     {item['type']}\n  status   {item['session_state']}\n  auth     {', '.join(item['supported_auth_methods'])}")
    elif args.command in {"accounts", "profiles"}:
        print("AI ACCOUNTS")
        for item in data["accounts"]:
            print(f"\n✓ {item['display_name']}\n  profile  {item['profile_id']}\n  auth     {item['auth_method']}\n  session  {item['session_state']}")
    elif args.command == "usage":
        print("AI USAGE")
        for item in data["snapshots"]:
            print(f"\n{item['provider_id']} / {item['model_id']}\n  Requests       {item['requests'] or 'UNKNOWN'}\n  Input tokens   {item['input_tokens'] or 'UNKNOWN'}\n  Output tokens  {item['output_tokens'] or 'UNKNOWN'}\n  API cost       ${item['cost']:.2f} ({item['metric_evidence'].get('cost', 'UNKNOWN')})")
    elif args.command == "providers":
        print("AI PROVIDERS")
        for item in data["providers"]: print(f"  {item['display_name']:12} {item['type']}")
    elif args.command == "models":
        print("AI MODELS")
        print("  Installed:", ", ".join(data["installed"]) or "UNKNOWN")
        print("  Configured:", ", ".join(data["configured"]))
        if data.get("gemini"):
            print("  Gemini:", ", ".join(data["gemini"]))
    return 0
