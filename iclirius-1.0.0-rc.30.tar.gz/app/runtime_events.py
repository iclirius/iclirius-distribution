"""
Structured runtime events, and the contracts a future terminal UI will draw.

Events are not logs. Logs are prose for a human debugging after the fact;
these are small typed records a UI can subscribe to without parsing text. The
distinction matters because the planned Iclirius TUI should never have to
scrape logs/openclaw.log to know what the agent is doing.

Hard rule for everything in this module: an event carries identifiers, sizes,
statuses and durations. It never carries a prompt, a file body, memory
contents, an API key or a token. `account_ref` is a human-readable label such
as an email address, never a credential; real credentials will live in the
Keychain, not here.

Nothing in this module connects to any provider. The provider and account
fields exist so the UI contract does not have to be redesigned later.
"""

from __future__ import annotations

import platform
import re
import threading
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable

from app.logger import logger


class EventType(str, Enum):
    AUTH_REQUIRED = "AUTH_REQUIRED"
    AUTH_TOUCH_ID_REQUESTED = "AUTH_TOUCH_ID_REQUESTED"
    AUTH_SUCCESS = "AUTH_SUCCESS"
    AUTH_FAILED = "AUTH_FAILED"
    AUTH_CANCELLED = "AUTH_CANCELLED"
    AUTH_FALLBACK_USED = "AUTH_FALLBACK_USED"
    AGENT_READY = "AGENT_READY"
    PROJECT_SELECTED = "PROJECT_SELECTED"
    TASK_CREATED = "TASK_CREATED"
    TASK_RESUMED = "TASK_RESUMED"
    PLAN_CREATED = "PLAN_CREATED"
    PLAN_UPDATED = "PLAN_UPDATED"
    PLAN_COMPLETED = "PLAN_COMPLETED"
    STEP_STARTED = "STEP_STARTED"
    STEP_COMPLETED = "STEP_COMPLETED"
    STEP_FAILED = "STEP_FAILED"
    TOOL_STARTED = "TOOL_STARTED"
    TOOL_COMPLETED = "TOOL_COMPLETED"
    TOOL_FAILED = "TOOL_FAILED"
    MODEL_SELECTED = "MODEL_SELECTED"
    MODEL_STARTED = "MODEL_STARTED"
    MODEL_FINISHED = "MODEL_FINISHED"
    MODEL_FAILED = "MODEL_FAILED"
    NODE_STATUS = "NODE_STATUS"
    CONTEXT_BUILT = "CONTEXT_BUILT"
    ROUTE_CHANGED = "ROUTE_CHANGED"
    # Write lifecycle. Metadata only: a patch event carries counts and a
    # patch_id, never the diff body.
    PATCH_PROPOSED = "PATCH_PROPOSED"
    PATCH_VALIDATED = "PATCH_VALIDATED"
    PATCH_REJECTED = "PATCH_REJECTED"
    PATCH_STALE = "PATCH_STALE"
    WRITE_APPROVAL_REQUIRED = "WRITE_APPROVAL_REQUIRED"
    WRITE_APPROVED = "WRITE_APPROVED"
    WRITE_DENIED = "WRITE_DENIED"
    WRITE_STARTED = "WRITE_STARTED"
    WRITE_COMPLETED = "WRITE_COMPLETED"
    WRITE_FAILED = "WRITE_FAILED"
    DIFF_VERIFIED = "DIFF_VERIFIED"
    # Grounded patch generation. A generation event says how many files were
    # shown to the model and how many changes came back, never their content.
    PATCH_GENERATION_STARTED = "PATCH_GENERATION_STARTED"
    PATCH_GENERATED = "PATCH_GENERATED"
    PATCH_GENERATION_FAILED = "PATCH_GENERATION_FAILED"
    GROUNDING_REFUSED = "GROUNDING_REFUSED"
    # Safe execution. Carries a profile name and an exit code, never output.
    EXECUTION_APPROVAL_REQUIRED = "EXECUTION_APPROVAL_REQUIRED"
    EXECUTION_APPROVED = "EXECUTION_APPROVED"
    EXECUTION_DENIED = "EXECUTION_DENIED"
    EXECUTION_STARTED = "EXECUTION_STARTED"
    EXECUTION_COMPLETED = "EXECUTION_COMPLETED"
    EXECUTION_FAILED = "EXECUTION_FAILED"
    EXECUTION_TIMEOUT = "EXECUTION_TIMEOUT"
    EXECUTION_BLOCKED = "EXECUTION_BLOCKED"
    # Verification and the coding loop.
    VERIFICATION_STARTED = "VERIFICATION_STARTED"
    VERIFICATION_PASSED = "VERIFICATION_PASSED"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    CODING_ITERATION = "CODING_ITERATION"
    CODING_LIMIT_REACHED = "CODING_LIMIT_REACHED"
    # Conversation compaction. Sizes and ratios only, never a word of it.
    COMPACTION_STARTED = "COMPACTION_STARTED"
    COMPACTION_COMPLETED = "COMPACTION_COMPLETED"
    COMPACTION_FAILED = "COMPACTION_FAILED"
    PREFERENCES_UPDATED = "PREFERENCES_UPDATED"
    # Encrypted state snapshots. Hashes, sizes and counts; never state.
    MEMORY_SNAPSHOT_STARTED = "MEMORY_SNAPSHOT_STARTED"
    MEMORY_SNAPSHOT_COMPLETED = "MEMORY_SNAPSHOT_COMPLETED"
    MEMORY_SNAPSHOT_FAILED = "MEMORY_SNAPSHOT_FAILED"
    MEMORY_SNAPSHOT_VALIDATED = "MEMORY_SNAPSHOT_VALIDATED"
    # Reasoning providers. Identifiers, sizes and timings; never a prompt or
    # an answer. A rate-limit event is only emitted if a provider reported one.
    ROUTING_DECISION = "ROUTING_DECISION"
    PROVIDER_REQUEST_STARTED = "PROVIDER_REQUEST_STARTED"
    PROVIDER_REQUEST_COMPLETED = "PROVIDER_REQUEST_COMPLETED"
    PROVIDER_REQUEST_FAILED = "PROVIDER_REQUEST_FAILED"
    PROVIDER_RATE_LIMITED = "PROVIDER_RATE_LIMITED"
    PROVIDER_EXHAUSTED = "PROVIDER_EXHAUSTED"
    PROVIDER_FALLBACK = "PROVIDER_FALLBACK"
    # Account pool and cloud budgets. Labels, counts and limits; no secrets.
    ACCOUNT_SELECTED = "ACCOUNT_SELECTED"
    ACCOUNT_RATE_LIMITED = "ACCOUNT_RATE_LIMITED"
    ACCOUNT_EXHAUSTED = "ACCOUNT_EXHAUSTED"
    ACCOUNT_COOLDOWN = "ACCOUNT_COOLDOWN"
    ACCOUNT_FALLBACK = "ACCOUNT_FALLBACK"
    CLOUD_BUDGET_CHECK = "CLOUD_BUDGET_CHECK"
    CLOUD_BUDGET_DENIED = "CLOUD_BUDGET_DENIED"
    USAGE_RECORDED = "USAGE_RECORDED"
    VOICE_REQUESTED = "VOICE_REQUESTED"
    VOICE_TTS_STARTED = "VOICE_TTS_STARTED"
    VOICE_TTS_COMPLETED = "VOICE_TTS_COMPLETED"
    VOICE_TTS_FAILED = "VOICE_TTS_FAILED"
    VOICE_SENT = "VOICE_SENT"
    VOICE_SEND_FAILED = "VOICE_SEND_FAILED"
    VOICE_RECEIVED = "VOICE_RECEIVED"
    VOICE_AUTHORIZED = "VOICE_AUTHORIZED"
    VOICE_DOWNLOAD_STARTED = "VOICE_DOWNLOAD_STARTED"
    VOICE_DOWNLOAD_COMPLETED = "VOICE_DOWNLOAD_COMPLETED"
    VOICE_DOWNLOAD_FAILED = "VOICE_DOWNLOAD_FAILED"
    VOICE_STT_STARTED = "VOICE_STT_STARTED"
    VOICE_STT_COMPLETED = "VOICE_STT_COMPLETED"
    VOICE_STT_FAILED = "VOICE_STT_FAILED"
    VOICE_AGENT_STARTED = "VOICE_AGENT_STARTED"
    VOICE_AGENT_COMPLETED = "VOICE_AGENT_COMPLETED"
    VOICE_AGENT_FAILED = "VOICE_AGENT_FAILED"
    USER_INPUT_TRANSCRIBED = "USER_INPUT_TRANSCRIBED"
    CLI_SESSION_STARTED = "CLI_SESSION_STARTED"
    CLI_MESSAGE_RECEIVED = "CLI_MESSAGE_RECEIVED"
    CLI_RESPONSE_COMPLETED = "CLI_RESPONSE_COMPLETED"
    CLI_COMMAND = "CLI_COMMAND"
    CLI_SESSION_ENDED = "CLI_SESSION_ENDED"


class Status(str, Enum):
    STARTED = "started"
    OK = "ok"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"
    INFO = "info"


class RuntimeStatus(str, Enum):
    """Lifecycle of a model or runtime, as a UI would show it."""

    AVAILABLE = "AVAILABLE"
    LOADED = "LOADED"
    ACTIVE = "ACTIVE"
    IDLE = "IDLE"
    UNAVAILABLE = "UNAVAILABLE"
    RATE_LIMITED = "RATE_LIMITED"
    EXHAUSTED = "EXHAUSTED"
    DISABLED = "DISABLED"


class NodeStatus(str, Enum):
    ONLINE = "ONLINE"
    OFFLINE = "OFFLINE"
    DEGRADED = "DEGRADED"
    UNKNOWN = "UNKNOWN"


# Anything matching these never reaches an event, whatever the caller passes.
_SECRET_PATTERNS = [
    re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,}"),          # telegram bot token
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY"),
    re.compile(r"\b(?:sk|pk|ghp|gho|xox[baprs])-[A-Za-z0-9_-]{16,}"),
    re.compile(r"\b(?:token|password|secret|api[_-]?key)\b\s*[:=]\s*\S{6,}", re.IGNORECASE),
    re.compile(r"\b[A-Za-z0-9_-]{40,}\b"),
]

_METADATA_MAX_CHARS = 200


def _looks_secret(value: str) -> bool:
    return any(pattern.search(value) for pattern in _SECRET_PATTERNS)


def _sanitise(value: Any) -> Any:
    """
    Keep metadata small and free of secrets and content.

    Only scalars survive. A caller that tries to attach a file body or a
    prompt gets it truncated; a caller that tries to attach a credential gets
    it replaced.
    """
    if value is None or isinstance(value, (bool, int, float)):
        return value

    text = str(value)

    if _looks_secret(text):
        return "[redacted]"

    if len(text) > _METADATA_MAX_CHARS:
        return text[:_METADATA_MAX_CHARS] + "…"

    return text


@dataclass
class RuntimeEvent:
    event_type: str
    status: str = Status.INFO.value
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    interface: str | None = None
    node_id: str | None = None
    project_id: str | None = None
    task_id: str | None = None
    plan_id: str | None = None
    step_id: str | None = None
    patch_id: str | None = None
    execution_id: str | None = None
    operation: str | None = None

    # Reserved for the future provider pool. Only Ollama fills these today.
    provider: str | None = None
    model: str | None = None
    account_ref: str | None = None

    duration_ms: int | None = None
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        self.metadata = {
            str(key)[:40]: _sanitise(value)
            for key, value in list(self.metadata.items())[:12]
        }

        if self.account_ref and _looks_secret(str(self.account_ref)):
            self.account_ref = "[redacted]"

    def to_dict(self) -> dict:
        return {key: value for key, value in asdict(self).items() if value not in (None, {})}


@dataclass
class ModelRuntime:
    """
    One model on one node.

    A node runs several runtimes and a runtime serves several tasks, so this
    is deliberately not keyed by task: the relationship is many-to-many.
    """

    provider: str
    model: str
    node_id: str
    status: str = RuntimeStatus.AVAILABLE.value
    is_local: bool = True
    account_ref: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class NodeInfo:
    """
    A machine, as a UI would draw it.

    Only a display name and capabilities. No IP address, MAC, serial number or
    hardware UUID: a terminal panel does not need them and they are the kind
    of identifier that should not sit in an event stream.
    """

    node_id: str
    display_name: str
    role: str = "leader"
    status: str = NodeStatus.UNKNOWN.value
    is_local: bool = True
    capabilities: list[str] = field(default_factory=list)
    runtimes: list[dict] = field(default_factory=list)
    active_jobs: int = 0
    last_seen: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    def to_dict(self) -> dict:
        return asdict(self)


class EventBus:
    """
    A small in-process bus with a bounded history.

    No sockets and no websockets: a future TUI in the same process can
    subscribe, and one in another process can read a snapshot. A misbehaving
    subscriber must never break the agent, so publish swallows subscriber
    errors and never raises.
    """

    def __init__(self, history: int = 200):
        self._subscribers: list[Callable[[RuntimeEvent], None]] = []
        self._history: deque[RuntimeEvent] = deque(maxlen=history)
        self._lock = threading.Lock()

    def subscribe(self, callback: Callable[[RuntimeEvent], None]) -> Callable[[], None]:
        with self._lock:
            self._subscribers.append(callback)

        def unsubscribe():
            with self._lock:
                if callback in self._subscribers:
                    self._subscribers.remove(callback)

        return unsubscribe

    def publish(self, event: RuntimeEvent) -> RuntimeEvent:
        with self._lock:
            self._history.append(event)
            subscribers = list(self._subscribers)

        for callback in subscribers:
            try:
                callback(event)
            except Exception:
                logger.warning("Runtime event subscriber failed", exc_info=False)

        return event

    def emit(self, event_type: str, **fields) -> RuntimeEvent:
        try:
            event = RuntimeEvent(event_type=str(event_type), **fields)
        except Exception:
            logger.warning("Could not build runtime event type=%s", event_type, exc_info=False)
            return RuntimeEvent(event_type="INVALID", status=Status.FAILED.value)

        return self.publish(event)

    def recent(self, limit: int = 50, event_type: str | None = None) -> list[dict]:
        with self._lock:
            events = list(self._history)

        if event_type:
            events = [event for event in events if event.event_type == event_type]

        return [event.to_dict() for event in events[-limit:]]

    def clear(self) -> None:
        with self._lock:
            self._history.clear()


event_bus = EventBus()


def emit(event_type: str, **fields) -> RuntimeEvent:
    """Publish to the shared bus. Never raises."""
    try:
        return event_bus.emit(event_type, **fields)
    except Exception:
        logger.warning("Event emission failed", exc_info=False)
        return RuntimeEvent(event_type="INVALID", status=Status.FAILED.value)


# --- node snapshot --------------------------------------------------------


def local_node(settings, ollama_healthy: bool | None = None,
               installed_models: list[str] | None = None) -> NodeInfo:
    """
    Describe this machine for a UI.

    The display name prefers the configured node id over the real hostname,
    which can carry a person's name.
    """
    capabilities = ["memory", "task_engine", "context_engine", "planner"]

    if settings.enable_local_read_tools:
        capabilities.append("local_read")
    if settings.enable_web_search:
        capabilities.append("web_search")
    if settings.enable_telegram:
        capabilities.append("telegram")

    runtimes: list[dict] = []

    if ollama_healthy is not None:
        for name in (installed_models or []):
            runtimes.append(ModelRuntime(
                provider="ollama",
                model=name,
                node_id=settings.node_id,
                status=(RuntimeStatus.AVAILABLE.value if ollama_healthy
                        else RuntimeStatus.UNAVAILABLE.value),
                is_local=True,
            ).to_dict())

    status = NodeStatus.UNKNOWN.value
    if ollama_healthy is True:
        status = NodeStatus.ONLINE.value
    elif ollama_healthy is False:
        status = NodeStatus.DEGRADED.value

    return NodeInfo(
        node_id=settings.node_id,
        display_name=settings.node_id or platform.node().split(".")[0],
        role=settings.role,
        status=status,
        is_local=True,
        capabilities=capabilities,
        runtimes=runtimes,
    )
