"""
Which providers exist, and which one answers a given request.

Registration is explicit. There is no plugin discovery, no import-by-string
and no scanning a directory for adapters: a provider is a thing that gets to
see the assembled context, so adding one should be a visible edit rather than
a side effect of dropping a file somewhere.

Routing is deterministic and free. With one provider registered there is
nothing to deliberate, and asking a language model which language model to use
would be absurd — the decision is a table lookup, and the reason it made that
choice is recorded so the UI can show it.

Modes exist for later:

    LOCAL     the only functional mode. Local engines only.
    AUTO      reserved. Would mix local and cloud.
    DEEP      reserved. Would prefer a stronger remote engine.
    COUNCIL   reserved. Would ask several and compare.

Reserved means reserved. Selecting one does not silently fall back to
pretending it worked; it is refused, because a mode that quietly does
something else is worse than a mode that does not exist.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum

from app.logger import logger
from app.reasoning import (
    ProviderStatus,
    ReasoningProvider,
    ReasoningRequest,
)


class RegistryError(RuntimeError):
    """A provider could not be registered."""


class RoutingError(RuntimeError):
    """No provider could serve the request."""


class Mode(str, Enum):
    LOCAL = "LOCAL"
    AUTO = "AUTO"
    DEEP = "DEEP"
    COUNCIL = "COUNCIL"


# Only LOCAL does anything. The rest are declared so the vocabulary is stable.
FUNCTIONAL_MODES = frozenset({Mode.LOCAL})

# A provider in any of these cannot take work right now.
UNUSABLE = frozenset({
    ProviderStatus.UNAVAILABLE.value,
    ProviderStatus.DISABLED.value,
    ProviderStatus.EXHAUSTED.value,
    ProviderStatus.RATE_LIMITED.value,
})


@dataclass
class RoutingDecision:
    """
    Which engine, and why.

    The reason is not decoration. When a future AUTO mode starts choosing
    between local and remote, "why did it go to the cloud" has to be
    answerable from the record rather than reconstructed.
    """

    provider_id: str = ""
    # The family ("ollama"), distinct from the instance id ("ollama-local").
    # RuntimeEvent.provider has meant the family since Phase 3.3, so the two
    # vocabularies stay separate rather than one quietly replacing the other.
    provider_type: str = ""
    account_ref: str = ""
    model_id: str = ""
    purpose: str = ""
    mode: str = Mode.LOCAL.value
    reason: str = ""
    fallback_order: list = field(default_factory=list)
    # Other accounts of the same provider to try, in order. Empty for a local
    # provider, which has no accounts.
    account_order: list = field(default_factory=list)
    local_fallback: str = ""
    estimated_context_tokens: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    def safe_metadata(self) -> dict:
        return {
            "provider_id": self.provider_id,
            "provider_type": self.provider_type,
            "account_ref": self.account_ref,
            "model_id": self.model_id,
            "mode": self.mode,
            "purpose": self.purpose,
            "reason": self.reason,
            "fallbacks": len(self.fallback_order),
            "account_fallbacks": len(self.account_order),
            "local_fallback": self.local_fallback or None,
            "estimated_context_tokens": self.estimated_context_tokens,
        }


class ProviderRegistry:
    """Explicitly registered providers, keyed by id."""

    def __init__(self):
        self._providers: dict[str, ReasoningProvider] = {}
        self._disabled: set[str] = set()
        # Last status a real request observed. Routing reads this instead of
        # probing, so choosing a provider stays free and cannot change the
        # failure semantics of the call it is about to make.
        self._observed: dict[str, str] = {}

    def register(self, provider: ReasoningProvider) -> ReasoningProvider:
        if not isinstance(provider, ReasoningProvider):
            raise RegistryError("Un provider debe implementar ReasoningProvider.")

        if not provider.provider_id:
            raise RegistryError("Un provider necesita provider_id.")

        if provider.provider_id in self._providers:
            raise RegistryError(
                f"Ya hay un provider registrado como '{provider.provider_id}'.")

        self._providers[provider.provider_id] = provider
        logger.info("Reasoning provider registered id=%s type=%s",
                    provider.provider_id, provider.provider_type)

        return provider

    def get(self, provider_id: str) -> ReasoningProvider | None:
        return self._providers.get(provider_id)

    def list(self) -> list[ReasoningProvider]:
        return list(self._providers.values())

    def disable(self, provider_id: str) -> None:
        self._disabled.add(provider_id)

    def enable(self, provider_id: str) -> None:
        self._disabled.discard(provider_id)

    def is_disabled(self, provider_id: str) -> bool:
        return provider_id in self._disabled

    def record_status(self, provider_id: str, status: str) -> None:
        """Remember what a real request just discovered about a provider."""
        self._observed[provider_id] = status

    def known_status(self, provider_id: str) -> str:
        """
        Status without touching the network.

        A live health probe on every request would add a round trip and, worse,
        would let a flaky probe reject a request that would have succeeded. The
        engine's real answer to the real request is the better evidence, so
        routing uses what was last observed and defaults to eligible.
        """
        if provider_id in self._disabled:
            return ProviderStatus.DISABLED.value

        if provider_id not in self._providers:
            return ProviderStatus.UNAVAILABLE.value

        return self._observed.get(provider_id, ProviderStatus.AVAILABLE.value)

    def status(self, provider_id: str) -> str:
        """Live status, by asking the provider. For status views, not routing."""
        if provider_id in self._disabled:
            return ProviderStatus.DISABLED.value

        provider = self._providers.get(provider_id)

        if provider is None:
            return ProviderStatus.UNAVAILABLE.value

        try:
            return provider.health()
        except Exception:
            logger.warning("Provider health check failed id=%s", provider_id,
                           exc_info=False)
            return ProviderStatus.UNAVAILABLE.value

    def describe(self) -> list[dict]:
        """Safe listing for a registry view. No credentials exist to leak."""
        described = []

        for provider in self._providers.values():
            entry = provider.describe()
            entry["status"] = self.status(provider.provider_id)
            entry["models"] = provider.models()
            described.append(entry)

        return described

    def clear(self) -> None:
        self._providers.clear()
        self._disabled.clear()
        self._observed.clear()


class ProviderRouter:
    """Picks a provider and a model. Deterministic, and it costs nothing."""

    def __init__(self, registry: ProviderRegistry, accounts=None):
        self.registry = registry
        # Consulted only for providers that have accounts. A local engine has
        # none, so nothing about this path changes for Ollama.
        self.accounts = accounts

    def route(self, request: ReasoningRequest, mode: str = Mode.LOCAL.value,
              model_chain: list[str] | None = None) -> RoutingDecision:
        """
        Resolve one request to one provider and an ordered list of models.

        model_chain is supplied by the caller when it already knows the tier
        degradation to use. That keeps the existing local fallback behaviour
        exactly as it was rather than reinventing it here.
        """
        try:
            selected_mode = Mode(mode)
        except ValueError:
            raise RoutingError(f"Modo desconocido: {mode}") from None

        if selected_mode not in FUNCTIONAL_MODES:
            raise RoutingError(
                f"El modo {selected_mode.value} está reservado y todavía no "
                f"hace nada. El único modo funcional es {Mode.LOCAL.value}."
            )

        candidates = [
            provider for provider in self.registry.list()
            if self.registry.known_status(provider.provider_id) not in UNUSABLE
        ]

        if not candidates:
            raise RoutingError("No hay ningún proveedor de razonamiento disponible.")

        # An explicit ask overrides the mode's default preference. This is how
        # a cloud provider is reached at all today: somebody named it. There
        # is no automatic escalation, and LOCAL stays what happens when nobody
        # asked for anything.
        if request.provider_preference:
            chosen = next(
                (provider for provider in candidates
                 if provider.provider_id == request.provider_preference), None)

            if chosen is None:
                raise RoutingError(
                    f"El proveedor '{request.provider_preference}' no está "
                    f"registrado o no está disponible ahora mismo."
                )

            return self._decide(chosen, request, selected_mode, model_chain,
                                reason="solicitado explícitamente")

        # LOCAL means local. A provider that needed a network would not be
        # eligible even if one were registered.
        local = [provider for provider in candidates
                 if provider.capabilities().local]

        if not local:
            raise RoutingError("No hay proveedores locales disponibles.")

        reason = ("único proveedor local registrado" if len(local) == 1
                  else "primer proveedor local disponible")

        return self._decide(local[0], request, selected_mode, model_chain,
                            reason=reason)

    def _decide(self, provider, request, selected_mode, model_chain,
                reason: str) -> RoutingDecision:
        """Assemble the decision once, whichever way the provider was chosen."""
        chain = list(model_chain or provider.models())

        if request.model_preference and request.model_preference in chain:
            chain.remove(request.model_preference)
            chain.insert(0, request.model_preference)

        if not chain:
            raise RoutingError(f"{provider.provider_id} no tiene modelos configurados.")

        account_order: list[str] = []
        local_fallback = ""

        if not provider.capabilities().local:
            account_order = self._account_order(provider)
            local_fallback = self._local_fallback()

        return RoutingDecision(
            provider_id=provider.provider_id,
            provider_type=provider.provider_type,
            account_ref=provider.account_ref,
            model_id=chain[0],
            purpose=request.purpose,
            mode=selected_mode.value,
            reason=reason,
            fallback_order=chain[1:],
            account_order=account_order,
            local_fallback=local_fallback,
            estimated_context_tokens=request.estimated_input_tokens(),
        )

    def _account_order(self, provider) -> list[str]:
        """
        Other accounts of the same family to try, in priority order.

        The selected provider is itself an account, so it is excluded from its
        own fallback list.
        """
        if self.accounts is None:
            return []

        try:
            eligible = self.accounts.eligible()
        except Exception:
            return []

        return [account.account_ref for account in eligible
                if account.account_ref != provider.provider_id]

    def _local_fallback(self) -> str:
        """
        A local provider that could take over if every account is spent.

        Recorded, not taken. Silently answering from Ollama when the user
        asked for a cloud would make them believe the cloud replied.
        """
        for candidate in self.registry.list():
            if (candidate.capabilities().local
                    and self.registry.known_status(candidate.provider_id)
                    not in UNUSABLE):
                return candidate.provider_id

        return ""


registry = ProviderRegistry()
router = ProviderRouter(registry)
