"""
URL validation for outbound web reads.

This module exists on its own because it is the security boundary of the web
capability: everything OpenClaw fetches from the internet passes through
validate_url() first, and a mistake here is an SSRF hole into the local
machine and the LAN.

The rule is allowlist, not denylist:

  - only http and https schemes,
  - the host must resolve, and *every* address it resolves to must be a
    public unicast address.

String matching alone is not enough. "localhost", "127.0.0.1",
"0x7f.0.0.1", "2130706433" and a domain whose A record points at 10.0.0.5 all
mean the same thing to a socket, so the check is done on the resolved IPs.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlparse

ALLOWED_SCHEMES = {"http", "https"}

# Hostnames that must never be resolved, as a cheap first gate. The IP check
# below is the real defence; this only produces a clearer error message.
BLOCKED_HOSTNAMES = {
    "localhost",
    "localhost.localdomain",
    "ip6-localhost",
    "ip6-loopback",
    "metadata",
    "metadata.google.internal",
    "metadata.goog",
    "instance-data",
}

# Cloud instance metadata services. These are link-local and already caught by
# the IP rules, but naming them makes the intent explicit.
METADATA_ADDRESSES = {
    "169.254.169.254",
    "fd00:ec2::254",
}


class UnsafeUrlError(ValueError):
    """Raised when a URL must not be fetched."""


@dataclass(frozen=True)
class SafeUrl:
    url: str
    scheme: str
    host: str
    addresses: tuple[str, ...]

    @property
    def domain(self) -> str:
        return self.host.lower().removeprefix("www.")


def _is_public_address(raw: str) -> bool:
    """True only for addresses that are safe to reach from this machine."""
    try:
        ip = ipaddress.ip_address(raw)
    except ValueError:
        return False

    if raw in METADATA_ADDRESSES:
        return False

    # is_private already covers loopback, RFC1918, link-local, unique-local
    # (fc00::/7), 0.0.0.0/8 and the IPv6 equivalents, but the individual
    # checks are spelled out so the intent survives a library change.
    blocked = (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    )

    if blocked:
        return False

    # An IPv4-mapped or 6to4 address can smuggle a private IPv4 through IPv6.
    mapped = getattr(ip, "ipv4_mapped", None)
    if mapped is not None and not _is_public_address(str(mapped)):
        return False

    sixtofour = getattr(ip, "sixtofour", None)
    if sixtofour is not None and not _is_public_address(str(sixtofour)):
        return False

    return True


def _resolve(host: str) -> tuple[str, ...]:
    """All addresses a host resolves to. Raises UnsafeUrlError if it cannot."""
    try:
        infos = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise UnsafeUrlError(f"No pude resolver el host: {host}") from exc

    addresses = {info[4][0] for info in infos}

    if not addresses:
        raise UnsafeUrlError(f"El host no resolvió a ninguna dirección: {host}")

    return tuple(sorted(addresses))


def validate_url(url: str, *, resolver=_resolve) -> SafeUrl:
    """
    Validate a URL for outbound fetching.

    `resolver` is injectable so tests can exercise the address rules without
    depending on real DNS.
    """
    if not url or not isinstance(url, str):
        raise UnsafeUrlError("URL vacía.")

    url = url.strip()
    parsed = urlparse(url)
    scheme = (parsed.scheme or "").lower()

    if scheme not in ALLOWED_SCHEMES:
        raise UnsafeUrlError(f"Esquema no permitido: {scheme or '(ninguno)'}")

    host = (parsed.hostname or "").lower().strip(".")

    if not host:
        raise UnsafeUrlError("La URL no tiene host.")

    if host in BLOCKED_HOSTNAMES:
        raise UnsafeUrlError(f"Host bloqueado: {host}")

    # A bare IP in the URL is validated directly; anything else is resolved.
    try:
        ipaddress.ip_address(host)
        addresses: tuple[str, ...] = (host,)
    except ValueError:
        addresses = resolver(host)

    for address in addresses:
        if not _is_public_address(address):
            raise UnsafeUrlError(
                f"El host {host} apunta a una dirección no pública ({address})."
            )

    return SafeUrl(url=url, scheme=scheme, host=host, addresses=addresses)


def is_safe_url(url: str, *, resolver=_resolve) -> bool:
    """Boolean form of validate_url, for filtering lists of results."""
    try:
        validate_url(url, resolver=resolver)
        return True
    except UnsafeUrlError:
        return False
