"""Small guard for structured machine-observable claims."""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.evidence import Certainty, EvidenceRecord, SourceType


@dataclass(frozen=True)
class GroundingResult:
    accepted: bool
    response: str
    reasons: tuple[str, ...] = ()


def render_filesystem_facts(record: EvidenceRecord) -> str:
    result = record.result
    if result.get("exists") is False:
        return "The requested path does not exist.\n✓ VERIFIED · filesystem"
    prefix = "" if record.certainty == Certainty.VERIFIED.value else "At least "
    lines = [f"{prefix}{result.get('regular_files', 0):,} files",
             f"{result.get('directories', 0):,} directories",
             f"{result.get('total_bytes', 0):,} bytes"]
    if record.certainty == Certainty.PARTIAL:
        lines.append(f"△ PARTIAL · {record.coverage.permission_denied} inaccessible entries")
    else:
        lines.append("✓ VERIFIED · filesystem complete scan")
    return "\n".join(lines)


class GroundingGuard:
    def check(self, candidate: str, evidence: list[EvidenceRecord], *, requested: str = "") -> GroundingResult:
        candidate = candidate or ""
        fs = [item for item in evidence if item.source_type == SourceType.FILESYSTEM.value]
        if not fs:
            if (re.search(r"\b(files?|archivos?|directories|directorios)\b", candidate, re.I)
                    or re.search(r"\b[\w.-]+\.(?:txt|pdf|md|py|docx)\b", candidate, re.I)):
                return GroundingResult(False, "I could not inspect the requested filesystem location.", ("filesystem evidence unavailable",))
            return GroundingResult(True, candidate)
        record = fs[-1]
        if record.certainty in {Certainty.VERIFIED.value, Certainty.PARTIAL.value}:
            expected = str(record.result.get("regular_files", ""))
            numbers = {value.replace(",", "") for value in re.findall(r"\b[\d,]+\b", candidate)}
            if expected and numbers and expected not in numbers and re.search(r"files?|archivos?", candidate, re.I):
                return GroundingResult(False, render_filesystem_facts(record), ("numeric filesystem fact differs from evidence",))
            if re.search(r"\b(?:file|archivo)[\w.-]+\.(?:txt|pdf|md|py|docx)\b", candidate, re.I) and record.operation != "list_entries":
                return GroundingResult(False, render_filesystem_facts(record), ("filenames were not observed",))
        return GroundingResult(True, candidate)
