"""
Intent to typed read operation.

This is a deliberately small planner: it turns a Spanish sentence into one of
a fixed set of read operations, or refuses. It is not the general planner of
later phases.

Two properties matter more than cleverness:

  1. The output is a validated dataclass drawn from a closed enum. There is no
     path from user text, or from model output, to a shell string. Nothing
     here calls eval, exec or subprocess.

  2. Write intent is recognised in order to be refused with a clear message,
     rather than silently falling through to something else.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from app.config import settings


class Operation(str, Enum):
    LIST_DIRECTORY = "LIST_DIRECTORY"
    FIND_FILES = "FIND_FILES"
    SEARCH_TEXT = "SEARCH_TEXT"
    READ_TEXT_FILE = "READ_TEXT_FILE"
    FILE_STAT = "FILE_STAT"
    HASH_FILE = "HASH_FILE"
    DIRECTORY_SUMMARY = "DIRECTORY_SUMMARY"
    GIT_STATUS = "GIT_STATUS"
    GIT_DIFF = "GIT_DIFF"
    GIT_LOG = "GIT_LOG"


@dataclass(frozen=True)
class LocalOperation:
    name: str
    path: str
    query: str | None = None
    reason: str = ""


class PlanError(ValueError):
    """Raised when an intent cannot be turned into a permitted operation."""


class WriteIntentError(PlanError):
    """Raised when the user asked for something that modifies state."""


# Anything that would change the machine. Recognised only to refuse it.
WRITE_MARKERS = [
    r"\bborra\b", r"\belimina\b", r"\bborrar\b", r"\beliminar\b",
    r"\bcrea\b", r"\bcrear\b", r"\bescribe\b", r"\bescribir\b",
    r"\bmodifica\b", r"\bmodificar\b", r"\bedita\b", r"\beditar\b",
    r"\bmueve\b", r"\bmover\b", r"\brenombra\b", r"\brenombrar\b",
    r"\bcopia\b", r"\bcopiar\b", r"\bchmod\b", r"\bsudo\b",
    r"\brm\s+-rf\b", r"\bgit\s+commit\b", r"\bgit\s+checkout\b",
    r"\bgit\s+reset\b", r"\bgit\s+clean\b", r"\bgit\s+push\b",
    r"\binstala\b", r"\bejecuta\b", r"\bcorre el comando\b",
]

# A quoted or bare absolute path. Only absolute paths are accepted: a relative
# one has no meaning without a working directory the user can see.
PATH_PATTERNS = [
    r'"([/~][^"]+)"',
    r"'([/~][^']+)'",
    # Bare paths stop at whitespace. A path containing spaces must be quoted,
    # otherwise "revisa /tmp/proyecto y dime qué tengo" would swallow the rest
    # of the sentence as part of the path.
    r"(?<![\w\"'])((?:/|~/)[^\s,;:]+)",
]

SEARCH_MARKERS = [r"\bbusca\b", r"\bencuentra\b", r"\blocaliza\b", r"\bgrep\b",
                  r"\bd[óo]nde (?:est[áa]|aparece)\b", r"\bqu[ée] archivos? (?:contienen|tienen)\b"]

LIST_MARKERS = [r"\blista\b", r"\blistar\b", r"\bmuestra el contenido\b",
                r"\bqu[ée] hay en\b", r"\bcontenido de\b"]

SUMMARY_MARKERS = [r"\brevisa\b", r"\banaliza\b", r"\bresume\b", r"\bresumen\b",
                   r"\bestructura\b", r"\bqu[ée] tengo\b", r"\bcu[áa]ntos archivos\b",
                   r"\bm[áa]s grandes\b", r"\bestad[íi]sticas\b", r"\binspecciona\b"]

READ_MARKERS = [r"\blee\b", r"\bleer\b", r"\bmu[ée]strame el archivo\b",
                r"\bcontenido del archivo\b", r"\babre el archivo\b"]

HASH_MARKERS = [r"\bhash\b", r"\bsha256\b", r"\bsha-256\b", r"\bduplicad"]

STAT_MARKERS = [r"\bcu[áa]nto pesa\b", r"\btama[ñn]o de\b", r"\bcu[áa]ndo se modific"]

# Intent classification only. Execution still requires a path and passes
# through the existing allowlist and permission checks.
CAPABILITY_MARKERS = [
    r"\bpuedes ver\b", r"\bpuedes revisar\b", r"\bver mis archivos\b",
    r"\bmis archivos\b", r"\bmi laptop\b", r"\ben mi laptop\b",
    r"\bqué tengo en (?:descargas|downloads|documentos|documents|escritorio|desktop)\b",
    r"\blista(?:r)? (?:mis )?(?:archivos|carpetas)\b",
    r"\b(?:busca|encuentra) archivos?\b", r"\bcuántos archivos\b",
    r"\bqué carpetas tengo\b", r"\bcuánto ocupa esta carpeta\b",
    r"\barchivos modificados recientemente\b",
]


def _any(text: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


def looks_like_local_read_intent(message: str) -> bool:
    """Recognise local inspection intent without opening a path."""
    text = (message or "").strip().lower()
    if not text or looks_like_write_request(text):
        return False
    return _any(text, CAPABILITY_MARKERS) or (
        _any(text, SEARCH_MARKERS + LIST_MARKERS + SUMMARY_MARKERS + STAT_MARKERS)
        and _any(text, [r"\barchivo", r"\bcarpeta", r"\bdirectorio", r"\bdescargas", r"\bdownloads", r"\blaptop"])
    )


def looks_like_write_request(message: str) -> bool:
    return _any((message or "").lower(), WRITE_MARKERS)


def extract_path(message: str) -> str | None:
    """First absolute path mentioned in the message, if any."""
    for pattern in PATH_PATTERNS:
        match = re.search(pattern, message)
        if match:
            return match.group(1).rstrip(" .,;:")

    lowered = (message or "").lower()
    for pattern, path in (
        (r"\b(?:descargas|downloads)\b", "~/Downloads"),
        (r"\b(?:documentos|documents)\b", "~/Documents"),
        (r"\b(?:escritorio|desktop)\b", "~/Desktop"),
    ):
        if re.search(pattern, lowered):
            return path
    return None


def extract_quoted_term(message: str) -> str | None:
    """A quoted term, or a CamelCase / snake_case identifier."""
    for pattern in [r'"([^"]{2,80})"', r"'([^']{2,80})'"]:
        match = re.search(pattern, message)
        if match and not match.group(1).startswith(("/", "~")):
            return match.group(1).strip()

    match = re.search(r"\b([A-Z][a-z]+(?:[A-Z][a-z0-9]+)+|[a-z]+_[a-z_]{2,})\b", message)
    if match:
        return match.group(1)

    return None


def _default_root() -> str | None:
    roots = settings.file_manager_allowed_roots
    return roots[0] if len(roots) == 1 else None


def plan(message: str, default_path: str | None = None) -> LocalOperation:
    """
    Turn an intent into one permitted operation.

    Raises WriteIntentError for anything that would modify state, and
    PlanError when the intent or the path cannot be determined.
    """
    text = (message or "").strip()

    if not text:
        raise PlanError("Dime qué quieres que revise.")

    if looks_like_write_request(text):
        raise WriteIntentError(
            "Por ahora solo puedo leer, no modificar. "
            "Crear, editar, mover o borrar archivos llegará en una fase posterior."
        )

    lowered = text.lower()
    path = extract_path(text) or default_path or _default_root()

    if not path:
        raise PlanError(
            "Necesito una ruta absoluta. Por ejemplo: "
            "/localread lista ~/Documents/Proyecto"
        )

    # Git first: these are the most specific intents.
    if re.search(r"\bgit\b", lowered):
        if re.search(r"\bstatus\b|\bestado\b|\bcambios pendientes\b", lowered):
            return LocalOperation(Operation.GIT_STATUS.value, path, reason="git status")
        if re.search(r"\bdiff\b|\bdiferencias\b", lowered):
            return LocalOperation(Operation.GIT_DIFF.value, path, reason="git diff")
        if re.search(r"\blog\b|\bcommits\b|\bhistorial\b", lowered):
            return LocalOperation(Operation.GIT_LOG.value, path, reason="git log")
        return LocalOperation(Operation.GIT_STATUS.value, path, reason="git por defecto")

    if _any(lowered, HASH_MARKERS):
        return LocalOperation(Operation.HASH_FILE.value, path, reason="hash")

    if _any(lowered, SEARCH_MARKERS):
        term = extract_quoted_term(text)
        if term:
            return LocalOperation(Operation.SEARCH_TEXT.value, path, query=term,
                                  reason="búsqueda de texto")

    # "todos los PDF", "archivos .kt", "*.json".
    #
    # The literal dot or asterisk is required. Without it, any short word at
    # the end of the message was read as an extension, so "lista
    # /ruta/STM-COVE" planned a search for "*.cove" instead of a listing.
    extension = re.search(
        r"(?:\*\.|\s\.)([a-z0-9]{1,6})\b"
        r"|\b(pdf|png|jpe?g|json|csv|xlsx|epub|md|py|kt|java|ts|js|txt|xml|yaml|yml)s?\b",
        lowered,
    )
    if extension and _any(lowered, LIST_MARKERS + SEARCH_MARKERS):
        suffix = extension.group(1) or extension.group(2)
        if suffix:
            return LocalOperation(Operation.FIND_FILES.value, path, query=f"*.{suffix}",
                                  reason="búsqueda por extensión")

    if _any(lowered, READ_MARKERS):
        return LocalOperation(Operation.READ_TEXT_FILE.value, path, reason="lectura de archivo")

    if _any(lowered, STAT_MARKERS):
        return LocalOperation(Operation.FILE_STAT.value, path, reason="metadatos")

    if _any(lowered, SUMMARY_MARKERS):
        return LocalOperation(Operation.DIRECTORY_SUMMARY.value, path, reason="resumen de carpeta")

    if _any(lowered, LIST_MARKERS):
        return LocalOperation(Operation.LIST_DIRECTORY.value, path, reason="listado")

    # A bare path is most usefully answered with a summary.
    if Path(path).name:
        return LocalOperation(Operation.DIRECTORY_SUMMARY.value, path,
                              reason="resumen por defecto")

    raise PlanError("No entendí qué operación local quieres. Prueba con /localread lista <ruta>.")


def validate(operation: LocalOperation) -> LocalOperation:
    """Reject anything outside the closed set before it reaches the executor."""
    if operation.name not in {member.value for member in Operation}:
        raise PlanError(f"Operación no permitida: {operation.name}")

    if not operation.path or not isinstance(operation.path, str):
        raise PlanError("La operación necesita una ruta.")

    return operation
