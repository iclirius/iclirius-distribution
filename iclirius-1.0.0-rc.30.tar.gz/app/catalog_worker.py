from __future__ import annotations

import argparse
import json
import mimetypes
import os
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from app.config import settings

import requests

from app.file_catalog import validate_safe_path, classify_file
from app.catalog_jobs import read_catalog_job, write_catalog_job


CATALOG_DIR = Path(settings.state_path) / "catalog"
RUNS_DIR = CATALOG_DIR / "runs"
REPORTS_DIR = CATALOG_DIR / "reports"
GLOBAL_CATALOG_PATH = CATALOG_DIR / "files.jsonl"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def send_telegram(chat_id: str, text: str) -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()

    if not token:
        return

    try:
        requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text[:3900]},
            timeout=20,
        )
    except Exception:
        pass


def update_job(job_id: str, **updates) -> dict:
    job = read_catalog_job(job_id)

    if not job:
        raise RuntimeError(f"No encontré job {job_id}")

    job.update(updates)
    job["updated_at"] = _now()
    write_catalog_job(job)
    return job


def write_jsonl(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("a") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def file_row(path: Path, root: Path) -> dict:
    stat = path.stat()
    mime, _ = mimetypes.guess_type(str(path))

    return {
        "path": str(path),
        "name": path.name,
        "parent": str(path.parent),
        "relative_path": str(path.relative_to(root)),
        "extension": path.suffix.lower(),
        "kind": classify_file(path),
        "mime": mime or "",
        "size": stat.st_size,
        "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat(timespec="seconds"),
        "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
        "cataloged_at": _now(),
        "source_root": str(root),
        "empty": stat.st_size == 0,
    }


def run(job_id: str, root_path: str, chat_id: str, notify_every: int) -> None:
    root = validate_safe_path(root_path)

    if not root.exists():
        raise FileNotFoundError(f"No existe la ruta: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"No es carpeta: {root}")

    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    run_catalog_path = RUNS_DIR / f"{job_id}.jsonl"
    report_path = REPORTS_DIR / f"{job_id}.json"

    files_seen = 0
    dirs_seen = 0
    empty_files = 0
    failed = 0

    by_kind = Counter()
    by_ext = Counter()
    by_parent = Counter()
    largest_files = []
    empty_paths = []

    update_job(
        job_id,
        status="running",
        started_at=_now(),
        catalog_path=str(run_catalog_path),
        report_path=str(report_path),
    )

    send_telegram(
        chat_id,
        f"Catálogo iniciado.\nJob ID: {job_id}\nRuta: {root}\nTe avisaré cada {notify_every} archivos.",
    )

    for item in root.rglob("*"):
        try:
            item = validate_safe_path(item)
            update_job(job_id, current_path=str(item))

            if item.is_dir():
                dirs_seen += 1
                if dirs_seen % 250 == 0:
                    update_job(job_id, dirs_seen=dirs_seen)
                continue

            if not item.is_file():
                continue

            row = file_row(item, root)
            files_seen += 1

            write_jsonl(run_catalog_path, row)
            write_jsonl(GLOBAL_CATALOG_PATH, row)

            by_kind[row["kind"]] += 1
            by_ext[row["extension"] or "no_ext"] += 1
            by_parent[row["parent"]] += row["size"]

            if row["empty"]:
                empty_files += 1
                empty_paths.append(row["path"])

            largest_files.append({
                "path": row["path"],
                "name": row["name"],
                "size": row["size"],
                "kind": row["kind"],
            })

            if len(largest_files) > 200:
                largest_files = sorted(largest_files, key=lambda x: x["size"], reverse=True)[:100]

            if notify_every > 0 and files_seen % notify_every == 0:
                update_job(
                    job_id,
                    files_seen=files_seen,
                    dirs_seen=dirs_seen,
                    empty_files=empty_files,
                    failed=failed,
                )

                send_telegram(
                    chat_id,
                    f"Catálogo en progreso.\n"
                    f"Job ID: {job_id}\n"
                    f"Archivos: {files_seen}\n"
                    f"Carpetas: {dirs_seen}\n"
                    f"Vacíos: {empty_files}\n"
                    f"Fallidos: {failed}\n"
                    f"Último: {row['name']}",
                )

        except Exception as exc:
            failed += 1
            update_job(job_id, failed=failed, last_error=str(exc))

    largest_files = sorted(largest_files, key=lambda x: x["size"], reverse=True)[:100]

    top_folders = [
        {"path": path, "size": size}
        for path, size in by_parent.most_common(100)
    ]

    report = {
        "job_id": job_id,
        "root_path": str(root),
        "created_at": _now(),
        "files_seen": files_seen,
        "dirs_seen": dirs_seen,
        "empty_files": empty_files,
        "failed": failed,
        "by_kind": dict(by_kind),
        "by_extension": dict(by_ext.most_common(100)),
        "largest_files": largest_files,
        "top_folders": top_folders,
        "empty_paths": empty_paths[:1000],
        "catalog_path": str(run_catalog_path),
    }

    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2))

    update_job(
        job_id,
        status="done",
        files_seen=files_seen,
        dirs_seen=dirs_seen,
        empty_files=empty_files,
        failed=failed,
        current_path="",
        finished_at=_now(),
        report_path=str(report_path),
        catalog_path=str(run_catalog_path),
    )

    send_telegram(
        chat_id,
        f"Catálogo completado.\n"
        f"Job ID: {job_id}\n"
        f"Archivos: {files_seen}\n"
        f"Carpetas: {dirs_seen}\n"
        f"Vacíos: {empty_files}\n"
        f"Fallidos: {failed}\n"
        f"Reporte: {report_path}",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--root-path", required=True)
    parser.add_argument("--chat-id", required=True)
    parser.add_argument("--notify-every", type=int, default=1000)
    args = parser.parse_args()

    try:
        run(args.job_id, args.root_path, args.chat_id, args.notify_every)
        return 0
    except Exception as exc:
        try:
            update_job(
                args.job_id,
                status="failed",
                last_error=str(exc),
                finished_at=_now(),
            )
        except Exception:
            pass

        send_telegram(
            args.chat_id,
            f"Catálogo falló.\nJob ID: {args.job_id}\nError: {exc}",
        )
        raise


if __name__ == "__main__":
    raise SystemExit(main())
