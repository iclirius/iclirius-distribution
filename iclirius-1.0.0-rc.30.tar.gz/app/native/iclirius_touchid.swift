import Foundation
import LocalAuthentication

let context = LAContext()
var probeError: NSError?

func status(for error: Error?) -> String {
    guard let error = error as? LAError else { return "system_error" }
    switch error.code {
    case .biometryNotAvailable: return "unavailable"
    case .biometryNotEnrolled: return "not_enrolled"
    case .biometryLockout: return "locked_out"
    case .userCancel, .systemCancel, .appCancel: return "cancelled"
    case .authenticationFailed: return "failed"
    default: return "system_error"
    }
}

if CommandLine.arguments.dropFirst().first == "availability" {
    if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &probeError) {
        print("available")
    } else {
        print(status(for: probeError))
    }
    exit(0)
}

if !context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &probeError) {
    print(status(for: probeError))
    exit(0)
}

let semaphore = DispatchSemaphore(value: 0)
context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                       localizedReason: "Authenticate to access Iclirius") { success, error in
    print(success ? "success" : status(for: error))
    semaphore.signal()
}
semaphore.wait()
