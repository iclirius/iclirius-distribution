"""Bounded, identity-bound and confirmation-gated filesystem actions.

The action engine accepts deterministic FileRecords/CandidateSets only. It never
accepts arbitrary model paths and never exposes permanent deletion or shell.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from app.config import settings
from app.file_catalog import allowed_root_for
from app.filesystem_evidence import FileRecord

TRASH = "TRASH"
MOVE = "MOVE"
RENAME = "RENAME"
COPY = "COPY"
PERMANENT_DELETE = "PERMANENT_DELETE"
PENDING = "PENDING"
CONFIRMED = "CONFIRMED"
EXECUTING = "EXECUTING"
COMPLETED = "COMPLETED"
PARTIAL = "PARTIAL"
FAILED = "FAILED"
CANCELLED = "CANCELLED"
EXPIRED = "EXPIRED"
TERMINAL = {COMPLETED, PARTIAL, FAILED, CANCELLED, EXPIRED}


class ActionError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        super().__init__(message or code)
        self.code = code


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(value: datetime | None = None) -> str:
    return (value or _now()).isoformat(timespec="seconds")


def _id(prefix: str, value: str) -> str:
    return prefix + hashlib.sha256(value.encode()).hexdigest()[:24]


def _canonical(path: str | Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def _under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


@dataclass(frozen=True)
class CandidateTarget:
    file_id: str
    absolute_path: str
    relative_path: str
    root_id: str
    node_id: str
    is_file: bool | None
    is_directory: bool | None
    is_symlink: bool | None
    size_bytes: int | None
    modified_at: str | None


@dataclass(frozen=True)
class CandidateSet:
    candidate_set_id: str
    source_query_id: str
    user_id: str
    node_id: str
    root_id: str
    root_path: str
    file_ids: tuple[str, ...]
    targets: tuple[CandidateTarget, ...]
    created_at: str
    coverage: str
    selection_reason: str
    estimated_bytes: int
    immutable: bool = True

    def to_dict(self):
        value = asdict(self)
        value["file_ids"] = list(self.file_ids)
        value["targets"] = [asdict(target) for target in self.targets]
        return value


@dataclass
class FileActionPlan:
    action_plan_id: str
    action_type: str
    candidate_set_id: str
    user_id: str
    node_id: str
    root_id: str
    root_path: str
    coverage: str
    targets: tuple[CandidateTarget, ...]
    destination: str | None
    created_at: str
    expires_at: str
    risk: str
    warnings: tuple[str, ...]
    target_count: int
    estimated_bytes: int
    requires_confirmation: bool = True
    status: str = PENDING
    session_id: str = ""

    def to_dict(self):
        value = asdict(self)
        value["targets"] = [asdict(target) for target in self.targets]
        value["warnings"] = list(self.warnings)
        return value


@dataclass(frozen=True)
class TargetResult:
    file_id: str
    source: str
    destination: str | None
    status: str
    reason: str = ""
    bytes_affected: int = 0


@dataclass(frozen=True)
class FileActionReceipt:
    receipt_id: str
    action_plan_id: str
    action_type: str
    user_id: str
    node_id: str
    started_at: str
    completed_at: str
    targets_requested: int
    targets_succeeded: int
    targets_failed: int
    bytes_affected: int
    per_target_results: tuple[TargetResult, ...]
    warnings: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    verification: dict = field(default_factory=dict)

    def to_dict(self):
        value = asdict(self)
        value["per_target_results"] = [asdict(item) for item in self.per_target_results]
        value["warnings"], value["errors"] = list(self.warnings), list(self.errors)
        return value


def _target(record: FileRecord) -> CandidateTarget:
    return CandidateTarget(record.file_id, record.absolute_path, record.relative_path, record.root_id,
                           record.node_id, record.is_file, record.is_directory, record.is_symlink,
                           record.size_bytes, record.modified_at)


def create_candidate_set(records: Iterable[FileRecord], *, source_query_id: str, user_id: str,
                         node_id: str, root_id: str, root_path: str, coverage: str,
                         selection_reason: str) -> CandidateSet:
    if not user_id:
        raise ActionError("IDENTITY_REQUIRED", "mutation requires a validated user identity")
    rows = tuple(records)
    if any(row.node_id != node_id or row.root_id != root_id for row in rows):
        raise ActionError("IDENTITY_MISMATCH")
    targets = tuple(_target(row) for row in rows)
    candidate_id = _id("candidates_", user_id + node_id + root_id + source_query_id + "|".join(row.file_id for row in rows))
    return CandidateSet(candidate_id, source_query_id, user_id, node_id, root_id, str(_canonical(root_path)),
                        tuple(row.file_id for row in rows), targets, _stamp(), coverage, selection_reason,
                        sum(row.size_bytes or 0 for row in rows))


class ActionEngine:
    def __init__(self, *, node_id: str, trusted_user_ids: Iterable[str] = (), allowed_roots: Iterable[str] = (),
                 ttl_seconds: int = 600, max_targets: int = 1000, max_directories: int = 100,
                 max_bytes: int = 10 * 1024 * 1024 * 1024, repository_root: str | None = None,
                 memory_home: str | None = None):
        self.node_id = node_id
        self.trusted_user_ids = frozenset(str(value) for value in trusted_user_ids if value)
        configured_roots = tuple(allowed_roots) or tuple(getattr(settings, "file_manager_allowed_roots", ()))
        self.allowed_roots = tuple(_canonical(value) for value in configured_roots)
        self.ttl_seconds = ttl_seconds
        self.max_targets, self.max_directories, self.max_bytes = max_targets, max_directories, max_bytes
        self.repository_root = _canonical(repository_root or Path(__file__).resolve().parents[1])
        self.memory_home = _canonical(memory_home) if memory_home else None
        self._plans: dict[str, FileActionPlan] = {}
        self._receipts: dict[str, FileActionReceipt] = {}
        self._lock = threading.RLock()

    def _identity(self, user_id: str, node_id: str):
        if not user_id or user_id not in self.trusted_user_ids:
            raise ActionError("IDENTITY_REQUIRED")
        if node_id != self.node_id:
            raise ActionError("NODE_MISMATCH")

    def _root_allowed(self, root_path: str) -> Path:
        root = _canonical(root_path)
        if not self.allowed_roots or not any(root == allowed or _under(root, allowed) for allowed in self.allowed_roots):
            raise ActionError("ROOT_NOT_ALLOWED")
        return root

    def _protected(self, path: Path, root: Path) -> str | None:
        path = _canonical(path)
        if path == Path(path.anchor):
            return "filesystem_root"
        home = _canonical(Path.home())
        if path == home or path == self.repository_root or _under(path, self.repository_root):
            return "protected_repository_or_home"
        if self.memory_home and (path == self.memory_home or _under(path, self.memory_home)):
            return "protected_memory_home"
        if ".git" in {part.casefold() for part in path.parts}:
            return "protected_git"
        if path in {_canonical("/System"), _canonical("/bin"), _canonical("/usr"), _canonical("/etc")} or _under(path, _canonical("/System")):
            return "protected_system"
        if path == root:
            return "protected_root"
        return None

    def _validate_target(self, candidate: CandidateTarget, root: Path, *, directory_action: bool = False):
        path = Path(candidate.absolute_path)
        if candidate.root_id == "" or candidate.node_id != self.node_id:
            return "IDENTITY_MISMATCH"
        if ".." in Path(candidate.relative_path).parts:
            return "PATH_TRAVERSAL"
        try:
            resolved = path.resolve(strict=False)
        except OSError:
            return "MALFORMED_PATH"
        if not _under(resolved, root) or resolved != path.absolute().resolve(strict=False):
            return "ROOT_ESCAPE"
        protected = self._protected(resolved, root)
        if protected:
            return protected
        if path.is_symlink() or candidate.is_symlink:
            return "SYMLINK_BLOCKED"
        if not path.exists():
            return "MISSING"
        if directory_action and not path.is_dir():
            return "NOT_DIRECTORY"
        try:
            stat = path.stat()
        except OSError:
            return "STAT_FAILED"
        current_mtime = datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(timespec="seconds")
        if candidate.size_bytes is not None and stat.st_size != candidate.size_bytes:
            return "CHANGED_SINCE_CONFIRMATION"
        if candidate.modified_at and current_mtime != candidate.modified_at:
            return "CHANGED_SINCE_CONFIRMATION"
        if candidate.is_file and not path.is_file():
            return "TYPE_CHANGED"
        return None

    def _validate_destination(self, destination: str, root: Path, *, rename: bool = False, allow_existing_dir: bool = False):
        target = _canonical(destination)
        if not _under(target, root) or self._protected(target, root):
            raise ActionError("DESTINATION_NOT_ALLOWED")
        if ".." in Path(destination).parts or target.name in {"", ".", ".."}:
            raise ActionError("PATH_TRAVERSAL")
        if target.is_symlink() or (target.exists() and not (allow_existing_dir and target.is_dir())):
            raise ActionError("DESTINATION_EXISTS")
        parent = target.parent
        if not parent.exists() or parent.is_symlink() or not parent.is_dir():
            raise ActionError("DESTINATION_PARENT_INVALID")
        return target

    def plan(self, candidate_set: CandidateSet, action_type: str, *, user_id: str, node_id: str,
             session_id: str = "", destination: str | None = None, now: datetime | None = None) -> FileActionPlan:
        with self._lock:
            self._identity(user_id, node_id)
            if candidate_set.user_id != user_id or candidate_set.node_id != node_id:
                raise ActionError("IDENTITY_MISMATCH")
            if action_type == PERMANENT_DELETE:
                raise ActionError("UNSUPPORTED")
            if action_type not in {TRASH, MOVE, RENAME}:
                raise ActionError("UNSUPPORTED")
            root = self._root_allowed(candidate_set.root_path)
            if not candidate_set.targets:
                raise ActionError("EMPTY_CANDIDATE_SET")
            security_reasons = {"IDENTITY_MISMATCH", "PATH_TRAVERSAL", "MALFORMED_PATH", "ROOT_ESCAPE",
                                "protected_repository_or_home", "protected_memory_home", "protected_git",
                                "protected_system", "protected_root", "SYMLINK_BLOCKED"}
            for target in candidate_set.targets:
                reason = self._validate_target(target, root, directory_action=bool(target.is_directory))
                if reason in security_reasons:
                    raise ActionError(reason)
            if len(candidate_set.targets) > self.max_targets:
                raise ActionError("TARGET_LIMIT")
            directories = sum(bool(target.is_directory) for target in candidate_set.targets)
            if directories > self.max_directories:
                raise ActionError("DIRECTORY_LIMIT")
            if candidate_set.estimated_bytes > self.max_bytes:
                raise ActionError("BYTE_LIMIT")
            warnings = []
            if candidate_set.coverage != "COMPLETE":
                warnings.append("selection_coverage_is_partial_candidates_only")
            if action_type == TRASH and directories and candidate_set.coverage != "COMPLETE":
                raise ActionError("PARTIAL_DIRECTORY_COVERAGE")
            if action_type in {MOVE, RENAME}:
                if not destination:
                    raise ActionError("DESTINATION_REQUIRED")
                dest = self._validate_destination(destination, root, rename=action_type == RENAME, allow_existing_dir=action_type == MOVE)
                if action_type == MOVE and not dest.is_dir():
                    raise ActionError("DESTINATION_NOT_DIRECTORY")
                if action_type == RENAME and len(candidate_set.targets) != 1:
                    raise ActionError("RENAME_SINGLE_TARGET")
            else:
                dest = None
            if action_type == TRASH and any(self._protected(Path(target.absolute_path), root) for target in candidate_set.targets):
                raise ActionError("PROTECTED_PATH")
            risk = "HIGH" if directories or len(candidate_set.targets) > 10 or candidate_set.estimated_bytes > 100 * 1024 * 1024 else "MEDIUM"
            created = now or _now()
            plan_id = _id("plan_", candidate_set.candidate_set_id + action_type + user_id + node_id + _stamp(created))
            plan = FileActionPlan(plan_id, action_type, candidate_set.candidate_set_id, user_id, node_id,
                                  candidate_set.root_id, str(root), candidate_set.coverage, candidate_set.targets, str(dest) if dest else None,
                                  _stamp(created), _stamp(created + timedelta(seconds=self.ttl_seconds)), risk,
                                  tuple(warnings), len(candidate_set.targets), candidate_set.estimated_bytes, True, PENDING, session_id)
            self._plans[plan_id] = plan
            return plan

    def preview(self, plan_id: str, *, user_id: str, session_id: str = "") -> dict:
        plan = self._get(plan_id, user_id, session_id, allow_expired=True)
        return {"action": plan.action_type, "selection": plan.candidate_set_id, "user_id": plan.user_id,
                "node_id": plan.node_id, "root": plan.root_path, "coverage": plan.coverage,
                "targets": len(plan.targets), "directories": sum(bool(item.is_directory) for item in plan.targets),
                "bytes": plan.estimated_bytes, "warnings": list(plan.warnings),
                "target_paths": [item.relative_path for item in plan.targets[:20]], "status": plan.status,
                "cloud_backed_warning": "root may be cloud-backed; local action can synchronize" if "Google Drive" in plan.root_path else None}

    def confirm(self, plan_id: str, *, user_id: str, session_id: str = "") -> FileActionPlan:
        with self._lock:
            plan = self._get(plan_id, user_id, session_id)
            if plan.status != PENDING:
                raise ActionError("PLAN_NOT_PENDING")
            plan.status = CONFIRMED
            return plan

    def cancel_action_plan(self, plan_id: str, *, user_id: str, session_id: str = "") -> FileActionPlan:
        with self._lock:
            plan = self._get(plan_id, user_id, session_id, allow_expired=True)
            if plan.status in TERMINAL or plan.status == EXECUTING:
                raise ActionError("PLAN_NOT_CANCELLABLE")
            plan.status = CANCELLED
            return plan

    def _get(self, plan_id: str, user_id: str, session_id: str, *, allow_expired: bool = False) -> FileActionPlan:
        plan = self._plans.get(plan_id)
        if not plan or plan.user_id != user_id or (plan.session_id and plan.session_id != session_id):
            raise ActionError("PLAN_NOT_FOUND")
        if _now() >= datetime.fromisoformat(plan.expires_at):
            if plan.status == PENDING:
                plan.status = EXPIRED
            if not allow_expired:
                raise ActionError("PLAN_EXPIRED")
        return plan

    def _trash_destination(self, source: Path) -> Path:
        if os.uname().sysname != "Darwin":
            raise ActionError("TRASH_UNAVAILABLE")
        trash = Path.home() / ".Trash"
        if not trash.is_dir():
            raise ActionError("TRASH_UNAVAILABLE")
        destination = trash / source.name
        index = 1
        while destination.exists() or destination.is_symlink():
            destination = trash / f"{source.stem} {index}{source.suffix}"
            index += 1
        return destination

    def _verify(self, action: str, source: Path, destination: Path | None) -> bool:
        if action == TRASH:
            return not source.exists() and not source.is_symlink()
        if action in {MOVE, RENAME}:
            return not source.exists() and destination is not None and destination.exists() and not destination.is_symlink()
        return False

    def execute(self, plan_id: str, *, user_id: str, session_id: str = "", dry_run: bool = False) -> FileActionReceipt:
        with self._lock:
            plan = self._get(plan_id, user_id, session_id)
            if not dry_run and plan.status != CONFIRMED:
                raise ActionError("CONFIRMATION_REQUIRED")
            if plan.status in TERMINAL:
                raise ActionError("PLAN_TERMINAL")
            root = self._root_allowed(plan.root_path)
            validation = [(target, self._validate_target(target, root, directory_action=bool(target.is_directory))) for target in plan.targets]
            blocked = [item for item in validation if item[1]]
            if dry_run:
                results = tuple(TargetResult(target.file_id, target.absolute_path, None, "BLOCKED" if reason else "READY", reason or "preconditions_valid", target.size_bytes or 0) for target, reason in validation)
                return FileActionReceipt(_id("receipt_", plan.action_plan_id + "dry"), plan.action_plan_id, plan.action_type, plan.user_id, plan.node_id, _stamp(), _stamp(), len(results), 0, len(blocked), 0, results, tuple(plan.warnings), tuple(reason for _, reason in blocked), {"dry_run": True})
            plan.status = EXECUTING
            started = _stamp()
            results = []
            for target, reason in validation:
                if reason:
                    results.append(TargetResult(target.file_id, target.absolute_path, None, "SKIPPED", reason, 0)); continue
                source = Path(target.absolute_path)
                destination = None
                try:
                    if plan.action_type == TRASH:
                        destination = self._trash_destination(source)
                        os.rename(source, destination)
                    elif plan.action_type == RENAME:
                        destination = Path(str(plan.destination))
                        if destination.parent != source.parent:
                            raise ActionError("RENAME_PARENT_MISMATCH")
                        self._validate_destination(str(destination), root, rename=True)
                        os.rename(source, destination)
                    else:
                        destination = Path(plan.destination or "") / source.name
                        self._validate_destination(str(destination), root)
                        os.rename(source, destination)
                    verified = self._verify(plan.action_type, source, destination)
                    results.append(TargetResult(target.file_id, str(source), str(destination), "SUCCESS" if verified else "FAILED_VERIFICATION", "" if verified else "post_action_verification_failed", target.size_bytes or 0))
                except (OSError, ActionError) as exc:
                    results.append(TargetResult(target.file_id, str(source), str(destination) if destination else None, "FAILED", getattr(exc, "code", type(exc).__name__), 0))
            succeeded = sum(item.status == "SUCCESS" for item in results)
            failed = len(results) - succeeded
            plan.status = COMPLETED if succeeded == len(results) else PARTIAL if succeeded else FAILED
            receipt = FileActionReceipt(_id("receipt_", plan.action_plan_id + started), plan.action_plan_id, plan.action_type, plan.user_id, plan.node_id, started, _stamp(), len(results), succeeded, failed, sum(item.bytes_affected for item in results if item.status == "SUCCESS"), tuple(results), tuple(plan.warnings), tuple(item.reason for item in results if item.reason), {"verified": failed == 0, "stale_evidence": True})
            self._receipts[receipt.receipt_id] = receipt
            return receipt

    def receipt(self, receipt_id: str, *, user_id: str) -> FileActionReceipt:
        receipt = self._receipts.get(receipt_id)
        if not receipt or receipt.user_id != user_id:
            raise ActionError("RECEIPT_NOT_FOUND")
        return receipt

    def plan_for(self, plan_id: str, *, user_id: str, session_id: str = "") -> FileActionPlan:
        return self._get(plan_id, user_id, session_id, allow_expired=True)
