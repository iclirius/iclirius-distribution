def is_stale_book_processing_response(text: str) -> bool:
    t = (text or "").lower()

    stale_phrases = [
        "actualización sobre el procesamiento de libros",
        "hasta ahora he procesado",
        "estoy generando un resumen del contenido",
        "te daré actualizaciones cada 50 archivos",
        "te dare actualizaciones cada 50 archivos",
        "si necesitas una lista específica de los libros procesados",
        "si necesitas una lista especifica de los libros procesados",
    ]

    return any(p in t for p in stale_phrases)


def replace_stale_book_processing_response(response_text: str) -> str:
    if not is_stale_book_processing_response(response_text):
        return response_text

    try:
        from app.library_status import library_status
        return (
            "Bloqueé una respuesta vieja del modelo sobre procesamiento de libros.\n\n"
            + library_status()
        )
    except Exception as exc:
        return (
            "Bloqueé una respuesta vieja del modelo sobre procesamiento de libros.\n\n"
            f"No pude leer el estado real todavía: {exc}"
        )
