"""Dedicated local retro voice talk interface."""

from .state import TalkState, TalkStateMachine

__all__ = ["TalkState", "TalkStateMachine"]
