"""Small deterministic local speech endpoint detector for Talk capture."""
from __future__ import annotations

from collections import deque
from enum import Enum
import math
import struct


class EndpointState(str, Enum):
    IDLE = "IDLE"
    SPEECH_CANDIDATE = "SPEECH_CANDIDATE"
    SPEECH_STARTED = "SPEECH_STARTED"
    SPEECH_CONTINUING = "SPEECH_CONTINUING"
    SILENCE_AFTER_SPEECH = "SILENCE_AFTER_SPEECH"
    UTTERANCE_COMPLETE = "UTTERANCE_COMPLETE"


class SpeechEndpointDetector:
    """Amplitude endpointing over fixed PCM frames (no network or STT)."""
    def __init__(self, *, sample_rate=16000, frame_ms=20, start_ms=160,
                 silence_ms=700, pre_roll_ms=300, max_seconds=45,
                 threshold=0.02, continue_threshold=0.012):
        self.frame_bytes = int(sample_rate * frame_ms / 1000) * 2
        self.start_frames = max(1, round(start_ms / frame_ms))
        self.silence_frames = max(1, round(silence_ms / frame_ms))
        self.pre_roll = deque(maxlen=max(1, round(pre_roll_ms / frame_ms)))
        self.max_frames = max(1, round(max_seconds * 1000 / frame_ms))
        self.start_threshold = float(threshold)
        self.continue_threshold = float(continue_threshold)
        self.noise_floor = 0.0
        self.state = EndpointState.IDLE
        self._speech_run = 0
        self._silence_run = 0
        self.frames = 0
        self.audio = bytearray()
        self.speech_confirmed = False

    @staticmethod
    def level(frame: bytes) -> float:
        if not frame:
            return 0.0
        samples = struct.unpack(f"<{len(frame) // 2}h", frame[:len(frame) - len(frame) % 2])
        return math.sqrt(sum(sample * sample for sample in samples) / max(1, len(samples))) / 32768

    def feed(self, frame: bytes) -> EndpointState:
        if self.state == EndpointState.UTTERANCE_COMPLETE:
            return self.state
        self.frames += 1
        level = self.level(frame)
        was_idle = self.state == EndpointState.IDLE
        if was_idle:
            self.pre_roll.append(frame)
            self.noise_floor = min(self.start_threshold * 0.8,
                                   self.noise_floor * 0.98 + level * 0.02)
            start_threshold = max(self.start_threshold, self.noise_floor * 2.5)
            loud = level >= start_threshold
            self._speech_run = self._speech_run + 1 if loud else 0
            if self._speech_run:
                self.state = EndpointState.SPEECH_CANDIDATE
            else:
                self.state = EndpointState.IDLE
        if self.state == EndpointState.SPEECH_CANDIDATE and not was_idle:
            self.pre_roll.append(frame)
            loud = level >= max(self.start_threshold, self.noise_floor * 2.5)
            self._speech_run = self._speech_run + 1 if loud else 0
            if self._speech_run == 0:
                self.state = EndpointState.IDLE
                self.pre_roll.clear()
            elif self._speech_run >= self.start_frames:
                self.audio = bytearray(b"".join(self.pre_roll))
                self.state = EndpointState.SPEECH_STARTED
                self.speech_confirmed = True
        elif self.state not in (EndpointState.IDLE, EndpointState.SPEECH_CANDIDATE):
            self.audio.extend(frame)
            # Once speech is confirmed, retain every frame. This threshold is
            # used only for endpoint decisions and never gates PCM recording.
            loud = level >= self.continue_threshold
            if loud:
                self._silence_run = 0
                self.state = EndpointState.SPEECH_CONTINUING
            else:
                self._silence_run += 1
                self.state = EndpointState.SILENCE_AFTER_SPEECH
                if self._silence_run >= self.silence_frames or self.frames >= self.max_frames:
                    self.state = EndpointState.UTTERANCE_COMPLETE
        if self.frames >= self.max_frames and self.speech_confirmed:
            self.state = EndpointState.UTTERANCE_COMPLETE
        return self.state

    @property
    def complete(self) -> bool:
        return self.state == EndpointState.UTTERANCE_COMPLETE
