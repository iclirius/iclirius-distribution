from __future__ import annotations

from dataclasses import dataclass

from .logo import color_for, frame, pulse
from .state import TalkState


@dataclass
class LogoAnimator:
    unicode: bool = True
    color: bool = True
    index: int = 0
    amplitude: float = 0.0

    def tick(self, state: TalkState, amplitude: float = 0.0) -> str:
        self.amplitude = pulse(amplitude)
        step = 2 if state in {TalkState.CAPTURING, TalkState.THINKING} else 1
        self.index = (self.index + step) % (4 if self.unicode else 2)
        rendered = frame(self.index, unicode=self.unicode)
        if self.amplitude >= 0.65:
            rendered = rendered.replace("✦", "✹").replace("*", "#")
        return rendered

    def render(self, state: TalkState) -> str:
        return frame(self.index, unicode=self.unicode)

    def markup(self, state: TalkState) -> str:
        colour = color_for(state, color=self.color)
        logo = self.render(state)
        return f"[{colour}]{logo}[/{colour}]" if colour else logo
