"""Terminal-safe Iclirius compass/star frames (no outer ring)."""
from __future__ import annotations

from app.talk.state import TalkState

# The long cardinal spikes and interwoven diagonal spikes are intentionally
# retained in every frame. Frames are small enough for ordinary terminals.
FRAMES = (
    (
        "        ▲        ",
        "    ◢   │   ◣    ",
        "◀───────✦───────▶",
        "    ◥   │   ◤    ",
        "        ▼        ",
    ),
    (
        "      ╱ ▲ ╲      ",
        "   ◢    │    ◣   ",
        "◀───────✦───────▶",
        "   ◥    │    ◤   ",
        "      ╲ ▼ ╱      ",
    ),
    (
        "        ▶        ",
        "    ◥   │   ◣    ",
        "▲───────✦───────▼",
        "    ◤   │   ◢    ",
        "        ◀        ",
    ),
    (
        "      ╲ ▲ ╱      ",
        "   ◥    │    ◣   ",
        "▲───────✦───────▼",
        "   ◤    │    ◢   ",
        "      ╱ ▼ ╲      ",
    ),
)

ASCII_FRAMES = (
    ('        ^        ', '    /   |   \\', '<-------*------->', '    \\   |   /', '        v        '),
    ('      / ^ \\', '   /    |    \\', '<-------*------->', '   \\    |    /', '      \\ v /'),
)


def frame(index: int, *, unicode: bool = True, width: int | None = None) -> str:
    frames = FRAMES if unicode else ASCII_FRAMES
    lines = list(frames[index % len(frames)])
    if width is not None:
        lines = [line[: max(1, width)] for line in lines]
    return "\n".join(lines)


def color_for(state: TalkState, *, color: bool = True) -> str:
    if not color:
        return ""
    return {
        TalkState.LISTENING: "green",
        TalkState.CAPTURING: "bright_green",
        TalkState.TRANSCRIBING: "magenta",
        TalkState.THINKING: "purple",
        TalkState.SPEAKING: "cyan",
        TalkState.ERROR: "red",
        TalkState.STOPPING: "dim",
    }.get(state, "cyan")


def pulse(amplitude: float) -> float:
    return max(0.0, min(1.0, float(amplitude)))
