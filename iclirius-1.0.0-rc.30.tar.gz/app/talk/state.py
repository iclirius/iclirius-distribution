from __future__ import annotations

from enum import Enum


class TalkState(str, Enum):
    INITIALIZING = "INITIALIZING"
    LISTENING = "LISTENING"
    CAPTURING = "CAPTURING"
    TRANSCRIBING = "TRANSCRIBING"
    THINKING = "THINKING"
    SPEAKING = "SPEAKING"
    ERROR = "ERROR"
    STOPPING = "STOPPING"


_ALLOWED = {
    TalkState.INITIALIZING: {TalkState.LISTENING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.LISTENING: {TalkState.CAPTURING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.CAPTURING: {TalkState.TRANSCRIBING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.TRANSCRIBING: {TalkState.THINKING, TalkState.LISTENING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.THINKING: {TalkState.SPEAKING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.SPEAKING: {TalkState.LISTENING, TalkState.ERROR, TalkState.STOPPING},
    TalkState.ERROR: {TalkState.LISTENING, TalkState.STOPPING},
    TalkState.STOPPING: set(),
}


class TalkStateMachine:
    def __init__(self) -> None:
        self.state = TalkState.INITIALIZING
        self.history = [self.state]

    def transition(self, target: TalkState) -> TalkState:
        if target not in _ALLOWED[self.state]:
            raise ValueError(f"invalid Talk transition {self.state.value} -> {target.value}")
        self.state = target
        self.history.append(target)
        return target

    def stop(self) -> TalkState:
        if self.state != TalkState.STOPPING:
            return self.transition(TalkState.STOPPING)
        return self.state
