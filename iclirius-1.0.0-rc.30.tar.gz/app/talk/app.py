"""Retro voice Talk presentation over the canonical agent and VoiceService."""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import sys
import inspect
import wave
from app.talk.endpoint import SpeechEndpointDetector, EndpointState
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from app.talk.animation import LogoAnimator
from app.talk.state import TalkState, TalkStateMachine
from app.voice import VoiceService, compact_for_voice, voice_service


class MicrophoneUnavailable(RuntimeError):
    pass


class MicrophonePermissionError(MicrophoneUnavailable):
    pass


@dataclass
class TalkTurnTrace:
    """Ephemeral diagnostics for one turn; never persisted or sent to an agent."""
    events: list[dict] = field(default_factory=list)
    max_events: int = 32

    def add(self, stage: str, **metadata) -> None:
        self.events.append({"stage": stage, "at": time.time(), **metadata})
        if len(self.events) > self.max_events:
            del self.events[:-self.max_events]


class MicrophoneCapture:
    """Minimal local macOS capture using ffmpeg's AVFoundation input."""
    def __init__(self, *, max_seconds: int = 45):
        self.max_seconds = max(1, int(max_seconds))
        self.ffmpeg = shutil.which("ffmpeg")
        self._process: subprocess.Popen | None = None
        self.last_duration = 0.0
        self.last_bytes = 0
        self.last_audio_ms = 0
        self.last_wait_ms = 0

    def capture(self, stop_event: threading.Event, on_event=None) -> Path | None:
        if not self.ffmpeg:
            raise MicrophoneUnavailable("ffmpeg/microphone unavailable")
        fd, raw = tempfile.mkstemp(prefix="iclirius-talk-", suffix=".wav")
        os.close(fd)
        path = Path(raw)
        started = time.monotonic()
        speech_started_at = None
        detector = SpeechEndpointDetector(max_seconds=self.max_seconds)
        try:
            self._process = subprocess.Popen(
                [self.ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "avfoundation",
                 "-i", ":0", "-ac", "1", "-ar", "16000", "-f", "s16le", "pipe:1"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            assert self._process.stdout is not None
            while not stop_event.is_set() and not detector.complete:
                frame = self._process.stdout.read(detector.frame_bytes)
                if not frame:
                    break
                previous = detector.state
                detector.feed(frame)
                if on_event and detector.state != previous:
                    if detector.state == EndpointState.SPEECH_STARTED:
                        speech_started_at = time.monotonic()
                        self.last_wait_ms = int((speech_started_at - started) * 1000)
                        on_event("speech=start")
                    elif detector.state == EndpointState.SPEECH_CONTINUING:
                        on_event("speech=continuing")
                    elif (detector.state == EndpointState.UTTERANCE_COMPLETE
                          and detector.speech_confirmed):
                        on_event("speech=end", silence_ms=detector.silence_frames * 20)
            if self._process.poll() is None:
                self._process.terminate()
            process = self._process
            if stop_event.is_set():
                self.stop()
                path.unlink(missing_ok=True)
                return None
            stderr = ""
            if process:
                _, stderr = process.communicate(timeout=1)
            if process and process.returncode != 0 and not detector.audio:
                lowered = (stderr or "").lower()
                if any(token in lowered for token in ("not authorized", "permission", "avfoundation")):
                    raise MicrophonePermissionError("microphone access unavailable")
                raise MicrophoneUnavailable("microphone capture failed")
            if not detector.audio:
                raise MicrophoneUnavailable("microphone capture produced empty audio")
            with wave.open(str(path), "wb") as output:
                output.setnchannels(1); output.setsampwidth(2); output.setframerate(16000)
                output.writeframes(detector.audio)
            self.last_audio_ms = int(len(detector.audio) / 2 / 16000 * 1000)
            self.last_duration = max(0.0, time.monotonic() - started)
            self.last_bytes = path.stat().st_size
            return path
        except (OSError, subprocess.TimeoutExpired) as exc:
            path.unlink(missing_ok=True)
            raise MicrophoneUnavailable("microphone access unavailable") from exc
        finally:
            self._process = None

    def stop(self) -> None:
        process = self._process
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                process.kill()
        self._process = None


class TalkController:
    """Stateful continuous loop with microphone suspension during TTS."""
    def __init__(self, agent: Any, *, voice: VoiceService | None = None,
                 microphone: Any | None = None, cooldown: float = 0.35,
                 playback: Any | None = None, debug: bool = False):
        self.agent = agent
        self.voice = voice or voice_service
        self.microphone = microphone or MicrophoneCapture()
        self.cooldown = max(0.0, float(cooldown))
        self.machine = TalkStateMachine()
        self.stop_event = threading.Event()
        self.listening_enabled = False
        self.playback = playback or self._play
        self.last_transcript = ""
        self.last_error = ""
        self.debug = bool(debug)
        self.trace = TalkTurnTrace()

    def _trace(self, event_stage: str, **metadata) -> None:
        self.trace.add(event_stage, **metadata)
        if self.debug:
            details = " ".join(f'{key}={value!r}' for key, value in metadata.items())
            print(f"[TALK] {event_stage}" + (f" {details}" if details else ""), file=sys.stderr, flush=True)

    def debug_source(self) -> str:
        """Return the loaded STT implementation source for diagnostics only."""
        try:
            return inspect.getsourcefile(type(self.voice.stt)) or "unknown"
        except (OSError, TypeError):
            return "unknown"

    @property
    def state(self) -> TalkState:
        return self.machine.state

    def _set(self, state: TalkState) -> None:
        if self.machine.state != state:
            self.machine.transition(state)
            self._trace(f"state={state.value}")

    def initialize(self) -> None:
        self._trace("state=INITIALIZING")
        try:
            if self.voice.stt.capability().value == "UNAVAILABLE":
                raise MicrophoneUnavailable("local STT model unavailable")
            if self.debug:
                self._trace("stt=prewarm-start")
            from app.voice import FasterWhisperSTT
            if isinstance(self.voice.stt, FasterWhisperSTT):
                from app.transcription import warmup_model
                warmup_model(self._trace)
                if self.debug:
                    self._trace("stt=prewarm-done")
            self._set(TalkState.LISTENING)
            self.listening_enabled = True
        except Exception as exc:
            self.last_error = str(exc)
            self._set(TalkState.ERROR)

    def process_audio(self, path: Path) -> str | None:
        """Process one transient recording through STT, agent and local TTS."""
        self.listening_enabled = False
        stage = "turn"
        try:
            if self.machine.state == TalkState.LISTENING:
                self._set(TalkState.CAPTURING)
            audio_ms = 0
            sample_rate = channels = frames = None
            if path.exists():
                try:
                    with wave.open(str(path), "rb") as audio:
                        sample_rate, channels, frames = audio.getframerate(), audio.getnchannels(), audio.getnframes()
                        audio_ms = int(frames * 1000 / sample_rate)
                except (wave.Error, EOFError):
                    pass
            self._trace("capture=done", bytes=path.stat().st_size if path.exists() else 0,
                        audio_ms=audio_ms, sample_rate=sample_rate, channels=channels, frames=frames,
                        wait_ms=getattr(self.microphone, "last_wait_ms", None))
            if not path.exists() or path.stat().st_size == 0:
                raise MicrophoneUnavailable("empty microphone capture")
            self._set(TalkState.TRANSCRIBING)
            stage = "stt"
            self._trace("stt=module", source=self.debug_source())
            self._trace("stt=start")
            stt_started = time.monotonic()
            transcript, _metadata = self.voice.transcribe(path, on_stage=self._trace)
            self._trace("timing=stt", ms=int((time.monotonic() - stt_started) * 1000))
            self.last_transcript = (transcript or "").strip()
            self._trace("stt=done", chars=len(self.last_transcript))
            if self.debug:
                self._trace("transcript", text=self.last_transcript[:200])
            if not self.last_transcript:
                self.last_error = "no speech detected"
                self._trace("stt=empty")
                self._set(TalkState.LISTENING)
                self.listening_enabled = True
                return None
            self._set(TalkState.THINKING)
            stage = "agent"
            self._trace("agent=start")
            agent_started = time.monotonic()
            response = self.agent.respond(self.last_transcript)
            if not (response or "").strip():
                raise RuntimeError("agent response empty")
            self._trace("agent=done", chars=len(response or ""))
            self._trace("timing=agent", ms=int((time.monotonic() - agent_started) * 1000))
            self.agent.record_conversation_turn(self.last_transcript, response, source="talk")
            self._set(TalkState.SPEAKING)
            stage = "tts"
            self._trace("tts=start")
            tts_started = time.monotonic()
            artifact = self.voice.synthesize(compact_for_voice(response))
            self._trace("tts=done", bytes=artifact.bytes)
            self._trace("timing=tts", ms=int((time.monotonic() - tts_started) * 1000))
            try:
                stage = "playback"
                self._trace("playback=start")
                first_audio = time.monotonic()
                self.playback(artifact.path, self.stop_event)
                self._trace("playback=done")
                self._trace("timing=first_audio", ms=int((first_audio - tts_started) * 1000))
            finally:
                Path(artifact.path).unlink(missing_ok=True)
            if self.stop_event.is_set():
                return response
            if self.cooldown:
                self.stop_event.wait(self.cooldown)
            self._set(TalkState.LISTENING)
            self.listening_enabled = True
            return response
        except Exception as exc:
            self.last_error = str(exc) or type(exc).__name__
            self._trace(f"{stage}=error", type=type(exc).__name__,
                        message=" ".join(str(exc).split())[:300],
                        stage_name="segments" if stage == "stt" else stage)
            if self.machine.state != TalkState.STOPPING:
                self._set(TalkState.ERROR)
                self._set(TalkState.LISTENING)
                self.listening_enabled = True
            return None
        finally:
            Path(path).unlink(missing_ok=True)

    def run(self) -> None:
        self.initialize()
        if self.state == TalkState.ERROR:
            return
        try:
            while not self.stop_event.is_set():
                if not self.listening_enabled:
                    self.stop_event.wait(0.05)
                    continue
                self._set(TalkState.CAPTURING)
                self._trace("capture=start", device="default")
                capture_started = time.monotonic()
                path = self.microphone.capture(self.stop_event, on_event=self._trace)
                if path is None:
                    if not self.stop_event.is_set():
                        self._set(TalkState.LISTENING)
                    continue
                self._trace("timing=capture", ms=int((time.monotonic() - capture_started) * 1000))
                self.process_audio(Path(path))
        except KeyboardInterrupt:
            self._trace("state=STOPPING")
            self.stop()
        except MicrophoneUnavailable as exc:
            self.last_error = str(exc)
            self._trace("capture=error", type=type(exc).__name__)
            if not self.stop_event.is_set():
                self._set(TalkState.ERROR)
        finally:
            self.stop()

    def stop(self) -> None:
        if self.machine.state != TalkState.STOPPING:
            self.machine.stop()
        self.stop_event.set()
        self.listening_enabled = False
        try:
            self.microphone.stop()
        except Exception:
            pass

    @staticmethod
    def _play(path: Path, stop_event: threading.Event) -> None:
        player = shutil.which("afplay")
        if not player:
            return
        process = subprocess.Popen([player, str(path)], stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL)
        try:
            while process.poll() is None and not stop_event.wait(0.05):
                pass
            if stop_event.is_set() and process.poll() is None:
                process.terminate()
        finally:
            if process.poll() is None:
                process.wait(timeout=1)
        if process.returncode != 0:
            raise RuntimeError(f"playback failed (exit {process.returncode})")


try:
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.widgets import Static
    _TEXTUAL_AVAILABLE = True
except ImportError:  # pragma: no cover
    App = object  # type: ignore[assignment,misc]
    ComposeResult = object  # type: ignore[assignment]
    Binding = Static = object  # type: ignore[assignment]
    _TEXTUAL_AVAILABLE = False


if _TEXTUAL_AVAILABLE:
    class TalkApp(App[None]):
        CSS = """
        Screen { background: #050a12; color: $text; }
        #title { height: 2; color: cyan; text-style: bold; padding: 0 2; }
        #logo { height: 7; width: 100%; content-align: center middle; text-align: center; }
        #state { height: 2; content-align: center middle; text-align: center; text-style: bold; }
        #debug { height: auto; color: $text-muted; padding: 0 2; border: round $primary-darken-2; }
        #hint { height: 1; color: $text-muted; content-align: center middle; text-align: center; }
        """
        BINDINGS = [Binding("ctrl+c", "stop_talk", "Back", show=False)]

        def __init__(self, controller: TalkController):
            super().__init__()
            self.controller = controller
            self._logo_animator = LogoAnimator()
            self._worker = None

        def compose(self) -> ComposeResult:
            if self.controller.debug:
                print("[TALK-UI] compose", file=sys.stderr, flush=True)
            yield Static("ICLIRIUS :: TALK", id="title")
            yield Static("", id="logo")
            yield Static("INITIALIZING", id="state")
            if self.controller.debug:
                yield Static("", id="debug")
            yield Static("Ctrl+C  Back", id="hint")

        def on_mount(self) -> None:
            if self.controller.debug:
                print("[TALK-UI] mount", file=sys.stderr, flush=True)
            if self.controller.debug:
                self._update_debug()
            self.set_interval(0.12, self._tick)
            if self.controller.debug:
                print("[TALK-UI] controller-start", file=sys.stderr, flush=True)
            self._worker = self.run_worker(self.controller.run, thread=True, exclusive=False)

        def _update_debug(self) -> None:
            widget = self.query_one("#debug", Static)
            latest = {item["stage"]: item for item in self.controller.trace.events}
            fields = {"capture": "idle", "stt": "idle", "agent": "idle",
                      "tts": "idle", "playback": "idle"}
            for key in fields:
                for stage in (f"{key}=done", f"{key}=start", f"{key}=error", f"{key}=empty"):
                    if stage in latest:
                        fields[key] = stage.split("=", 1)[1]
                        break
            history = self.controller.trace.events[-16:]
            events = "\n".join(f"{item['stage']}" for item in history)
            widget.update("DEBUG\nstate: " + self.controller.state.value + "\n"
                          + "\n".join(f"{key}: {value}" for key, value in fields.items())
                          + ("\nEVENTS\n" + events if events else ""))

        def _tick(self) -> None:
            state = self.controller.state
            self._logo_animator.tick(state)
            self.query_one("#logo", Static).update(self._logo_animator.markup(state))
            colour = {TalkState.LISTENING: "green", TalkState.CAPTURING: "bright_green",
                      TalkState.TRANSCRIBING: "magenta", TalkState.THINKING: "purple",
                      TalkState.SPEAKING: "cyan", TalkState.ERROR: "red"}.get(state, "dim")
            self.query_one("#state", Static).update(f"[{colour}]{state.value}[/{colour}]")
            if state == TalkState.ERROR and self.controller.last_error:
                message = self.controller.last_error.upper()
                if "MODEL" in message:
                    message = "STT MODEL UNAVAILABLE"
                elif "MICROPHONE" in message or "ACCESS" in message:
                    message = "MICROPHONE ACCESS REQUIRED"
                self.query_one("#state", Static).update(message[:48])
            if self.controller.debug:
                self._update_debug()

        def action_stop_talk(self) -> None:
            if self.controller.debug:
                print("[TALK-UI] controller-stop", file=sys.stderr, flush=True)
            self.controller.stop()
            if self.controller.debug:
                print("[TALK-UI] app-exit reason=user", file=sys.stderr, flush=True)
            self.exit()

        def on_unmount(self) -> None:
            if self.controller.debug:
                print("[TALK-UI] unmount", file=sys.stderr, flush=True)
            self.controller.stop()
else:  # pragma: no cover
    TalkApp = None


def run_talk(agent: Any, *, controller: TalkController | None = None,
             debug: bool = False, no_ui: bool = False) -> int:
    controller = controller or TalkController(agent, debug=debug)
    if debug and controller is not None and not controller.debug:
        controller.debug = True
    if debug:
        print("[TALK-BOOT] controller created", file=sys.stderr, flush=True)
    if no_ui:
        if debug:
            print("[TALK-BOOT] no-ui diagnostic", file=sys.stderr, flush=True)
        controller.run()
        return 0
    if _TEXTUAL_AVAILABLE:
        try:
            app = TalkApp(controller)
            if debug:
                print("[TALK-BOOT] app created", file=sys.stderr, flush=True)
                print("[TALK-BOOT] entering Textual run", file=sys.stderr, flush=True)
            app.run()
            if debug:
                print("[TALK-BOOT] Textual run returned", file=sys.stderr, flush=True)
            return 0
        except KeyboardInterrupt:
            controller.stop()
            return 0
        except Exception as exc:
            if debug:
                print(f"[TALK-BOOT] startup error: {type(exc).__name__}: {str(exc)[:160]}",
                      file=sys.stderr, flush=True)
            raise
    try:
        controller.run()
    except KeyboardInterrupt:
        controller.stop()
    return 0


def run_one_shot(*, voice: VoiceService | None = None, debug: bool = False,
                 language: str = "es", microphone: MicrophoneCapture | None = None) -> int:
    """Public /talk mode: capture and transcribe exactly one utterance."""
    voice = voice or voice_service
    microphone = microphone or MicrophoneCapture()
    stop_event = threading.Event()
    trace = TalkTurnTrace()

    def trace_event(event_stage: str, **metadata) -> None:
        trace.add(event_stage, **metadata)
        if debug:
            details = " ".join(f"{key}={value!r}" for key, value in metadata.items())
            print(f"[TALK] {event_stage}" + (f" {details}" if details else ""),
                  file=sys.stderr, flush=True)

    print("Iclirius Talk")
    print("Habla ahora...")
    try:
        if debug:
            trace_event("stt=prewarm-start")
        from app.voice import FasterWhisperSTT
        if isinstance(voice.stt, FasterWhisperSTT):
            from app.transcription import warmup_model
            warmup_model(trace_event)
            if debug:
                trace_event("stt=prewarm-done")
        print("● Escuchando...")
        trace_event("listening")
        path = microphone.capture(stop_event, on_event=trace_event)
        if path is None:
            trace_event("exit")
            return 130
        trace_event("capture=done", bytes=path.stat().st_size if path.exists() else 0,
                    audio_ms=getattr(microphone, "last_audio_ms", None))
        try:
            trace_event("state=TRANSCRIBING")
            trace_event("stt=start")
            transcript, _ = voice.transcribe(path, on_stage=trace_event, language=language)
        finally:
            path.unlink(missing_ok=True)
        transcript = (transcript or "").strip()
        trace_event("stt=done", chars=len(transcript))
        if debug:
            trace_event("transcript", text=transcript[:200])
        if not transcript:
            print("No pude detectar voz claramente. Inténtalo de nuevo.")
            trace_event("exit")
            return 1
        print("\n✓ Transcripción\n")
        print(transcript)
        trace_event("exit")
        return 0
    except KeyboardInterrupt:
        stop_event.set()
        microphone.stop()
        trace_event("exit")
        return 130
    except MicrophonePermissionError:
        print("Microphone permission required. Allow access in System Settings → Privacy & Security → Microphone.", file=sys.stderr)
        return 1
    except MicrophoneUnavailable as exc:
        print(f"Microphone unavailable: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        if debug:
            trace_event("stt=error", type=type(exc).__name__, message=" ".join(str(exc).split())[:300])
        else:
            print("Transcription failed.", file=sys.stderr)
        return 1
