from __future__ import annotations

import uuid
from datetime import datetime
from pathlib import Path
from app.config import settings
from app.memory_core import MemoryCore


TASKS_PATH = Path(settings.state_path) / "tasks" / "tasks.jsonl"


VALID_STATUSES = {"pending", "running", "done", "cancelled", "failed"}


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _read_tasks() -> list[dict]:
    return list(MemoryCore().get_namespace("queue_tasks").values())


def _mutate_tasks(mutator):
    return MemoryCore().mutate_namespace("queue_tasks", mutator)


def add_task(text: str, source: str = "manual", priority: str = "normal") -> dict:
    text = text.strip()

    if not text:
        raise ValueError("Task text cannot be empty")

    task = {
        "id": uuid.uuid4().hex[:8],
        "text": text,
        "status": "pending",
        "priority": priority,
        "source": source,
        "created_at": _now(),
        "updated_at": _now(),
        "result": "",
    }

    stored = _mutate_tasks(lambda tasks: tasks.setdefault(task["id"], task))
    if not stored:
        raise RuntimeError("Canonical task memory unavailable")

    return task


def list_tasks(status: str | None = None, limit: int = 20) -> list[dict]:
    tasks = _read_tasks()

    if status:
        tasks = [task for task in tasks if task.get("status") == status]

    return tasks[-limit:]


def update_task_status(task_id: str, status: str, result: str = "") -> dict | None:
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid status: {status}")

    def mutate(tasks):
        task = tasks.get(task_id)
        if task is None:
            return {}
        task["status"] = status
        task["updated_at"] = _now()
        if result:
            task["result"] = result
        return dict(task)
    return _mutate_tasks(mutate) or None


def clear_done_tasks() -> int:
    def mutate(tasks):
        closed = [key for key, task in tasks.items() if task.get("status") in {"done", "cancelled"}]
        for key in closed:
            del tasks[key]
        return {"removed": len(closed)}
    return _mutate_tasks(mutate).get("removed", 0)


def format_tasks(tasks: list[dict]) -> str:
    if not tasks:
        return "No hay tareas."

    lines = ["Tareas:"]

    for task in tasks:
        task_id = task.get("id", "unknown")
        status = task.get("status", "unknown")
        priority = task.get("priority", "normal")
        text = task.get("text", "").strip()
        created = task.get("created_at", "")

        if len(text) > 120:
            text = text[:117] + "..."

        lines.append(f"- [{status}] {task_id} ({priority}) {text}")
        if created:
            lines.append(f"  creado: {created}")

    return "\n".join(lines)


def tasks_text(status: str | None = None, limit: int = 20) -> str:
    return format_tasks(list_tasks(status=status, limit=limit))


def add_task_text(text: str, source: str = "telegram") -> str:
    task = add_task(text, source=source)
    return f"Tarea creada:\n- ID: {task['id']}\n- Estado: {task['status']}\n- Texto: {task['text']}"


def done_task_text(task_id: str) -> str:
    task = update_task_status(task_id, "done")

    if not task:
        return f"No encontré la tarea con ID: {task_id}"

    return f"Tarea marcada como done: {task_id}"


def cancel_task_text(task_id: str) -> str:
    task = update_task_status(task_id, "cancelled")

    if not task:
        return f"No encontré la tarea con ID: {task_id}"

    return f"Tarea cancelada: {task_id}"


def clear_tasks_text() -> str:
    removed = clear_done_tasks()
    return f"Tareas cerradas limpiadas: {removed}"


def get_task(task_id: str) -> dict | None:
    tasks = _read_tasks()

    for task in tasks:
        if task.get("id") == task_id:
            return task

    return None


def set_task_result(task_id: str, status: str, result: str) -> dict | None:
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid status: {status}")

    def mutate(tasks):
        task = tasks.get(task_id)
        if task is None:
            return {}
        task.update(status=status, result=result, updated_at=_now())
        return dict(task)
    return _mutate_tasks(mutate) or None


def task_result_text(task_id: str) -> str:
    task = get_task(task_id)

    if not task:
        return f"No encontré la tarea con ID: {task_id}"

    result = task.get("result", "").strip() or "Sin resultado todavía."

    return (
        f"Tarea {task_id}\n"
        f"- Estado: {task.get('status')}\n"
        f"- Texto: {task.get('text')}\n\n"
        f"Resultado:\n{result}"
    )[:3900]
