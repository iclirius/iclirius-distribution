import re

from app.config import settings


SENSITIVE_PATTERNS = [
    r"\btoken\b",
    r"\bapi[_ -]?key\b",
    r"\bpassword\b",
    r"\bcontraseña\b",
    r"\bsecret\b",
    # A leading \b never matches before a literal dot preceded by whitespace,
    # so "\b\.env\b" silently failed to detect " .env ". The trailing \b is
    # enough to keep "documento.envio" from matching.
    r"\.env\b",
    r"\bprivate[_ -]?key\b",
    r"-----BEGIN",
]


HEAVY_PATTERNS = [
    r"\banaliza\b",
    r"\brevisa\b",
    r"\bresume\b",
    r"\bresumen\b",
    r"\bcompara\b",
    r"\bplan\b",
    r"\bproyecto\b",
    r"\brepositorio\b",
    r"\bcódigo\b",
    r"\bcode\b",
    r"\barchivo\b",
    r"\bdebug\b",
    r"\berror\b",
    r"\btraceback\b",
    r"\blog\b",
    r"\boptimiza\b",
    r"\brefactor\b",
    r"\bgenera\b",
]


def contains_sensitive_content(message: str) -> bool:
    text = message.lower()

    for pattern in SENSITIVE_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return True

    return False


def looks_heavy(message: str) -> bool:
    text = message.lower()

    if len(message) >= 900:
        return True

    line_count = message.count("\n") + 1
    if line_count >= 12:
        return True

    if "traceback" in text or "error:" in text:
        return True

    hits = 0
    for pattern in HEAVY_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            hits += 1

    return hits >= 2


def should_delegate_to_worker(message: str) -> tuple[bool, str]:
    if not getattr(settings, "enable_worker_delegation", False):
        return False, "worker delegation disabled"

    if not getattr(settings, "worker_url", ""):
        return False, "worker url not configured"

    if contains_sensitive_content(message):
        return False, "possible sensitive content"

    if looks_heavy(message):
        return True, "heavy task heuristic"

    return False, "local task"


# --- local model tier selection -------------------------------------------
#
# Purely local, deterministic routing between the three Ollama tiers. It reuses
# looks_heavy() so cost estimation lives in one place. No cloud provider, no
# confidence evaluation, no escalation.

TIER_FAST = "fast"
TIER_DEFAULT = "default"
TIER_HEAVY = "heavy"

TRIVIAL_MAX_CHARS = 120


def looks_trivial(message: str) -> bool:
    """Short, single-line messages with no sign of real work."""
    text = message.strip()

    if not text or len(text) > TRIVIAL_MAX_CHARS:
        return False

    if "\n" in text:
        return False

    return not looks_heavy(text)


def select_model_tier(message: str) -> tuple[str, str]:
    """
    Choose a local tier for a message.

    Returns (tier, reason). Heavy wins over trivial because the heavy
    heuristic already accounts for length and complexity.
    """
    message = (message or "").strip()

    if not message:
        return TIER_FAST, "empty message"

    if looks_heavy(message):
        return TIER_HEAVY, "heavy task heuristic"

    if looks_trivial(message):
        return TIER_FAST, "short simple message"

    return TIER_DEFAULT, "normal task"


# --- web research detection -----------------------------------------------
#
# Deterministic and deliberately conservative. When in doubt this returns
# False: a wrong "yes" sends a network request for an ordinary chat message,
# while a wrong "no" costs nothing because /web is always available.

WEB_EXPLICIT_MARKERS = [
    r"\bbusca\b",
    r"\bb[úu]scame\b",
    r"\bbuscar\b",
    r"\bgoogle[ae]?\b",
    r"\ben internet\b",
    r"\ben la web\b",
    r"\brevisa en internet\b",
]

WEB_RECENCY_MARKERS = [
    r"\bhoy\b",
    r"\bahora\b",
    r"\bactualmente\b",
    r"\bactual(es)?\b",
    r"\breciente(s|mente)?\b",
    r"\b[úu]ltimas noticias\b",
    r"\b[úu]ltima versi[óo]n\b",
    r"\bversi[óo]n estable\b",
    r"\bnoticias\b",
    r"\bprecio\b",
    r"\bcu[áa]nto cuesta\b",
    r"\bhorario\b",
    r"\ba qu[ée] hora\b",
    r"\bqui[ée]n gan[óo]\b",
    r"\bresultado del partido\b",
    r"\bclima\b",
    r"\bpron[óo]stico\b",
    r"\blanzamiento\b",
    r"\bestren[óo]\b",
    r"\b[úu]ltimo\b",
    r"\bqu[ée] pas[óo]\b",
]


def _matches_any(text: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


def asks_for_web_explicitly(message: str) -> bool:
    """The user told us to look it up."""
    return _matches_any((message or "").lower(), WEB_EXPLICIT_MARKERS)


def needs_web_search(message: str) -> tuple[bool, str]:
    """
    Decide whether a plain chat message should consult the web.

    Returns (needs_web, reason). Sensitive text never goes out, mirroring the
    rule that already governs worker delegation.
    """
    message = (message or "").strip()

    if not message:
        return False, "empty message"

    if contains_sensitive_content(message):
        return False, "possible sensitive content"

    if asks_for_web_explicitly(message):
        return True, "explicit web request"

    if _matches_any(message.lower(), WEB_RECENCY_MARKERS):
        return True, "question depends on current information"

    # Public explainers and documentation requests require grounded public
    # evidence even when they do not contain a recency marker.  Personal
    # filesystem questions are resolved earlier by CapabilityRouter and never
    # reach this branch.
    lower = message.lower()
    public_explainer = _matches_any(lower, [
        r"\bc[oó]mo\s+funciona\b", r"\bhow\s+does\b", r"\bwhat\s+is\b",
        r"\bdocumentaci[oó]n\b",
    ]) or (_matches_any(lower, [r"\bqu[eé]\s+es\b"])
           and _matches_any(lower, [r"\b(?:archivo|pdf|git|homebrew|google\s+drive|api|python|openclaw)\b"]))
    if public_explainer:
        return True, "public explanation or documentation"

    return False, "answerable locally"


# --- local read detection -------------------------------------------------
#
# Same conservative rule as the web heuristic: when in doubt, do not touch the
# disk. A wrong "yes" makes ordinary conversation walk the filesystem; a wrong
# "no" costs nothing because /localread is always available.

LOCAL_PATH_PATTERN = r"(?:^|\s|\"|')(?:/|~/)[^\s\"']+"

LOCAL_READ_MARKERS = [
    # Nouns
    r"\bcarpeta\b",
    r"\bdirectorio\b",
    r"\barchivos?\b",
    r"\brepo(sitorio)?\b",
    r"\bproyecto\b",
    r"\bestructura\b",
    r"\bcontenido\b",
    # Verbs of inspection
    r"\brevisa\b",
    r"\banaliza\b",
    r"\binspecciona\b",
    r"\blista\b",
    r"\blistar\b",
    r"\bresume\b",
    r"\bmu[ée]strame\b",
    r"\bbusca\b",
    r"\blee\b",
    # Questions
    r"\bqu[ée] tengo\b",
    r"\bqu[ée] hay\b",
    r"\bcu[áa]ntos archivos\b",
    r"\bm[áa]s grandes\b",
    r"\bcu[áa]nto pesa\b",
    # Git
    r"\bgit\b",
]


def mentions_local_path(message: str) -> bool:
    """True when the message contains an absolute path."""
    return bool(re.search(LOCAL_PATH_PATTERN, message or ""))


def needs_local_read(message: str) -> tuple[bool, str]:
    """
    Decide whether a plain message should inspect the local filesystem.

    Requires an explicit absolute path. Talking *about* files is not enough:
    without a path there is nothing safe to inspect and no way to guess one.
    """
    message = (message or "").strip()

    if not message:
        return False, "empty message"

    if contains_sensitive_content(message):
        return False, "possible sensitive content"

    # Standard user folder aliases (Downloads, Documents, Desktop) are
    # resolved by local_planner and remain subject to the safe-root policy.
    from app.local_planner import extract_path
    if not mentions_local_path(message) and not extract_path(message):
        return False, "no explicit path"

    if _matches_any(message.lower(), LOCAL_READ_MARKERS):
        return True, "path plus filesystem intent"

    return False, "path mentioned without a read intent"
