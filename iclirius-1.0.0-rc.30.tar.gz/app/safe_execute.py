"""
The only component in OpenClaw allowed to start a subprocess for the agent.

Running a build or a test suite is the one way to know whether a change
actually worked, so the capability has to exist. What must not exist is a path
from model output to a command line.

    El modelo sólo puede pedir: operation=RUN_TESTS
    No puede pedir:             command="pytest --whatever"

A profile is a fixed argv held in a table in this file. The model names an
operation; OpenClaw picks the profile by inspecting the project on disk and
runs the argv it wrote itself. There is no field anywhere in this module that
lets a caller contribute a token to a command line.

Everything runs with shell=False. There is no bash -c, no sh -c, no eval, no
exec and no os.system, and the tests assert that at the AST level so a later
edit cannot quietly reintroduce one.

Profiles are read-only by construction: they run tests, builds, linters and
type checkers. Nothing that cleans, resets, installs, uninstalls, publishes,
deploys, migrates or prunes is present, and a guard rejects such a verb even
if someone adds one to the table by mistake.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from app.config import settings
from app.file_catalog import validate_safe_path
from app.logger import logger
from app.process_env import minimal_environment


class ExecutionError(RuntimeError):
    """The execution could not be attempted."""


class ExecutionDisabled(ExecutionError):
    """Safe execute is switched off."""


class Operation(str, Enum):
    RUN_TESTS = "RUN_TESTS"
    RUN_BUILD = "RUN_BUILD"
    RUN_LINT = "RUN_LINT"
    RUN_TYPECHECK = "RUN_TYPECHECK"


# Verbs that must never appear in any profile. This is a guard against future
# edits, not against the current table: nothing below contains one.
FORBIDDEN_TOKENS = {
    "clean", "reset", "deploy", "publish", "install", "uninstall", "migrate",
    "migration", "prune", "rm", "rmdir", "drop", "destroy", "delete", "purge",
    "push", "commit", "release", "upload", "sync", "format", "fix", "--fix",
    "--write", "-i", "--in-place", "sudo", "chmod", "chown", "curl", "wget",
}

# Environment variables the child may keep. Everything else is dropped, which
# is the simplest way to guarantee no token, key or credential is inherited.
_ENV_ALLOWLIST = {
    "PATH", "HOME", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR", "TZ", "TERM",
    "SHELL", "USER", "LOGNAME", "JAVA_HOME", "ANDROID_HOME", "ANDROID_SDK_ROOT",
    "NODE_PATH", "PYTHONPATH", "VIRTUAL_ENV",
}

# Even inside the allowlist, refuse anything that looks like a credential.
# The rule lives in app/process_env.py so the background jobs can share it.


@dataclass(frozen=True)
class ExecutionProfile:
    """
    One fixed way to run one operation for one kind of project.

    argv is complete and literal. project_local marks a profile whose
    executable lives inside the repository, which means running it is running
    code from that repository.
    """

    name: str
    operation: str
    argv: tuple[str, ...]
    detect: tuple[str, ...]
    description: str
    project_local: bool = False
    parser: str = "generic"

    def resolved_argv(self, cwd: Path) -> list[str]:
        """Locate the executable, refusing anything not actually present."""
        head, *rest = self.argv

        if head == "__python__":
            return [sys.executable, *rest]

        if head.startswith("./"):
            candidate = cwd / head[2:]

            if not candidate.is_file() or not os.access(candidate, os.X_OK):
                raise ExecutionError(f"No encuentro {head} en {cwd.name}.")

            return [str(candidate), *rest]

        found = shutil.which(head)

        if not found:
            raise ExecutionError(f"No tengo {head} instalado.")

        return [found, *rest]


# --- the trusted table ----------------------------------------------------
#
# Ordered by specificity: the first profile whose detect markers are all
# present wins.

PROFILES: tuple[ExecutionProfile, ...] = (
    ExecutionProfile(
        name="python-pytest",
        operation=Operation.RUN_TESTS.value,
        argv=("__python__", "-m", "pytest", "-q", "--no-header",
              "-p", "no:cacheprovider"),
        detect=("tests",),
        description="pytest sobre el directorio tests/",
        parser="pytest",
    ),
    ExecutionProfile(
        name="python-ruff",
        operation=Operation.RUN_LINT.value,
        argv=("ruff", "check", "."),
        detect=("pyproject.toml",),
        description="ruff check",
        parser="generic",
    ),
    ExecutionProfile(
        name="python-compileall",
        operation=Operation.RUN_BUILD.value,
        argv=("__python__", "-m", "compileall", "-q", "app"),
        detect=("app",),
        description="compilación de bytecode",
        parser="generic",
    ),
    ExecutionProfile(
        name="python-mypy",
        operation=Operation.RUN_TYPECHECK.value,
        argv=("mypy", "--no-error-summary", "."),
        detect=("mypy.ini",),
        description="mypy",
        parser="generic",
    ),
    ExecutionProfile(
        name="gradle-test",
        operation=Operation.RUN_TESTS.value,
        argv=("./gradlew", "test", "--offline", "--console=plain"),
        detect=("gradlew",),
        description="gradlew test",
        project_local=True,
        parser="gradle",
    ),
    ExecutionProfile(
        name="gradle-build",
        operation=Operation.RUN_BUILD.value,
        argv=("./gradlew", "assembleDebug", "--offline", "--console=plain"),
        detect=("gradlew",),
        description="gradlew assembleDebug",
        project_local=True,
        parser="gradle",
    ),
    ExecutionProfile(
        name="node-test",
        operation=Operation.RUN_TESTS.value,
        argv=("npm", "test", "--silent"),
        detect=("package.json",),
        description="npm test",
        project_local=True,
        parser="node",
    ),
    ExecutionProfile(
        name="node-lint",
        operation=Operation.RUN_LINT.value,
        argv=("npm", "run", "lint", "--silent"),
        detect=("package.json",),
        description="npm run lint",
        project_local=True,
        parser="node",
    ),
    ExecutionProfile(
        name="node-typecheck",
        operation=Operation.RUN_TYPECHECK.value,
        argv=("npx", "--no-install", "tsc", "--noEmit"),
        detect=("tsconfig.json",),
        description="tsc --noEmit",
        project_local=True,
        parser="node",
    ),
)


def _audit_table() -> None:
    """Fail at import time if a destructive verb ever enters the table."""
    for profile in PROFILES:
        for token in profile.argv:
            if token.lower() in FORBIDDEN_TOKENS:
                raise RuntimeError(
                    f"El perfil {profile.name} contiene un verbo prohibido: {token}"
                )


_audit_table()


@dataclass
class ExecutionResult:
    execution_id: str
    profile: str
    operation: str
    exit_code: int
    success: bool
    duration_ms: int
    timed_out: bool = False
    truncated: bool = False
    summary: str = ""
    headline: str = ""
    metrics: dict = field(default_factory=dict)

    def as_event_metadata(self) -> dict:
        """Numbers and statuses. Never program output."""
        return {
            "profile": self.profile,
            "operation": self.operation,
            "exit_code": self.exit_code,
            "success": self.success,
            "duration_ms": self.duration_ms,
            "timed_out": self.timed_out,
            "truncated": self.truncated,
            **{key: value for key, value in self.metrics.items()},
        }


@dataclass
class PendingExecution:
    execution_id: str
    profile: str
    operation: str
    command: str
    cwd: str
    interface: str = ""
    expires_at: float = 0.0

    def is_expired(self, now: float) -> bool:
        return self.expires_at > 0 and now >= self.expires_at


def validate_cwd(path: str | Path) -> Path:
    """A profile only ever runs inside an allowed project root."""
    target = validate_safe_path(path)

    if not target.is_dir():
        raise ExecutionError(f"No es un directorio: {target}")

    return target


def detect_profiles(cwd: Path) -> list[ExecutionProfile]:
    """Which profiles this project actually supports, in table order."""
    available = []

    for profile in PROFILES:
        if all((cwd / marker).exists() for marker in profile.detect):
            available.append(profile)

    return available


def select_profile(operation: str, cwd: Path) -> ExecutionProfile:
    """
    Pick the profile for an operation. The model's only input is the verb.
    """
    try:
        wanted = Operation(operation).value
    except ValueError:
        raise ExecutionError(
            f"Operación de ejecución desconocida: {operation}. "
            f"Sólo existen: {', '.join(item.value for item in Operation)}."
        ) from None

    for profile in detect_profiles(cwd):
        if profile.operation != wanted:
            continue

        if profile.project_local and not settings.execute_allow_project_local_tools:
            raise ExecutionError(
                f"{profile.description} usa un ejecutable del propio "
                f"repositorio. Ejecutarlo es ejecutar código de ese proyecto. "
                f"Actívalo con EXECUTE_ALLOW_PROJECT_LOCAL_TOOLS=true si "
                f"confías en él."
            )

        return profile

    raise ExecutionError(
        f"No sé cómo hacer {wanted} en {cwd.name}: no reconozco el proyecto."
    )


def build_environment() -> dict:
    """
    A minimal environment for the child.

    Built by allowlist rather than by removing known-bad names, so a variable
    nobody thought about is excluded by default instead of inherited.
    """
    env = minimal_environment(_ENV_ALLOWLIST)

    env.setdefault("PATH", "/usr/bin:/bin:/usr/sbin:/sbin")
    # Deterministic, quiet, and no interactive prompts anywhere.
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["CI"] = "1"
    env["NO_COLOR"] = "1"
    env["GIT_TERMINAL_PROMPT"] = "0"

    return env


def _decode(raw: bytes) -> tuple[str, bool]:
    limit = settings.execute_max_output_bytes
    truncated = len(raw) > limit

    return raw[:limit].decode("utf-8", errors="replace"), truncated


def run(operation: str, cwd: str | Path,
        profile: ExecutionProfile | None = None) -> ExecutionResult:
    """
    Run one profile and return a reduced result.

    The output cap, the timeout and the closed stdin are all there for the
    same reason: a build that hangs waiting for input, or one that prints a
    gigabyte, must not be able to take the agent down with it.
    """
    if not settings.execute_enabled:
        raise ExecutionDisabled(
            "La ejecución está desactivada. Actívala con EXECUTE_ENABLED=true en .env."
        )

    target = validate_cwd(cwd)
    profile = profile or select_profile(operation, target)
    argv = profile.resolved_argv(target)
    execution_id = f"exec_{uuid.uuid4().hex[:10]}"

    logger.info(
        "Safe execute id=%s profile=%s cwd=%s",
        execution_id, profile.name, target.name,
    )

    started = time.monotonic()
    timed_out = False

    try:
        process = subprocess.Popen(  # noqa: S603 - fixed argv, shell=False
            argv,
            cwd=str(target),
            env=build_environment(),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            shell=False,
            start_new_session=True,
        )
    except (OSError, ValueError) as exc:
        raise ExecutionError(f"No pude lanzar {profile.description}: {exc}") from exc

    try:
        raw, _ = process.communicate(timeout=settings.execute_timeout_seconds)
    except subprocess.TimeoutExpired:
        timed_out = True
        _terminate(process)
        raw, _ = process.communicate()

    duration_ms = int((time.monotonic() - started) * 1000)
    text, truncated = _decode(raw or b"")
    exit_code = process.returncode if process.returncode is not None else -1
    headline, metrics = summarise(text, profile.parser, exit_code, timed_out)

    return ExecutionResult(
        execution_id=execution_id,
        profile=profile.name,
        operation=profile.operation,
        exit_code=exit_code,
        success=(exit_code == 0 and not timed_out),
        duration_ms=duration_ms,
        timed_out=timed_out,
        truncated=truncated,
        summary=reduce_output(text, profile.parser),
        headline=headline,
        metrics=metrics,
    )


def _terminate(process) -> None:
    """Kill the whole process group: a build spawns children."""
    try:
        os.killpg(os.getpgid(process.pid), 15)
    except (OSError, ProcessLookupError):
        pass

    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(os.getpgid(process.pid), 9)
        except (OSError, ProcessLookupError):
            pass


# --- local output reduction ----------------------------------------------
#
# Reducing here rather than in the model is the whole point: a failing suite
# can print thousands of lines, and only a handful of them say what broke.

_PYTEST_COUNTS = re.compile(
    r"(\d+)\s+(passed|failed|error|errors|skipped|xfailed|warnings?)")
_PYTEST_FAILURE = re.compile(r"^(FAILED|ERROR)\s+(\S+)", re.MULTILINE)
_GRADLE_TASK = re.compile(r"^(?:>\s+Task\s+)?(:\S+)\s+FAILED", re.MULTILINE)
_NODE_FAIL = re.compile(r"^\s*(?:✕|×|✗|FAIL)\s+(.+)$", re.MULTILINE)


def summarise(text: str, parser: str, exit_code: int,
              timed_out: bool) -> tuple[str, dict]:
    """One line a human can read, plus structured counts."""
    if timed_out:
        return "La ejecución superó el tiempo límite.", {"timed_out": True}

    metrics: dict = {}

    if parser == "pytest":
        for count, label in _PYTEST_COUNTS.findall(text):
            metrics[label.rstrip("s")] = int(count)

        failed = metrics.get("failed", 0) + metrics.get("error", 0)
        passed = metrics.get("passed", 0)

        if exit_code == 0:
            return f"{passed} tests pasaron.", metrics

        return f"{failed} fallaron de {passed + failed}.", metrics

    if parser == "gradle":
        tasks = _GRADLE_TASK.findall(text)

        if tasks:
            metrics["failed_tasks"] = len(tasks)

        if "BUILD SUCCESSFUL" in text:
            return "La build terminó correctamente.", metrics

        if tasks:
            return f"Falló la tarea {tasks[0]}.", metrics

        return "La build falló." if exit_code else "La build terminó.", metrics

    if parser == "node":
        failures = _NODE_FAIL.findall(text)

        if failures:
            metrics["failures"] = len(failures)
            return f"{len(failures)} pruebas fallaron.", metrics

        return ("Sin fallos." if exit_code == 0
                else f"Terminó con código {exit_code}."), metrics

    return ("Correcto." if exit_code == 0
            else f"Terminó con código {exit_code}."), metrics


def reduce_output(text: str, parser: str) -> str:
    """
    Keep the lines that explain a failure and drop the rest.

    On success there is nothing worth sending: a green suite says everything
    it needs to say in the headline.
    """
    limit = settings.execute_max_report_chars
    lines = text.splitlines()

    interesting: list[str] = []

    if parser == "pytest":
        interesting = [line for line in lines
                       if _PYTEST_FAILURE.match(line)
                       or line.startswith(("E ", "FAILED", "ERROR"))
                       or " - " in line and line.startswith("FAILED")]
    elif parser == "gradle":
        interesting = [line for line in lines
                       if "FAILED" in line or line.startswith(("* What went wrong",
                                                               "Caused by:", "> "))]
    elif parser == "node":
        interesting = [line for line in lines
                       if _NODE_FAIL.match(line) or "Error:" in line]

    if not interesting:
        # Unrecognised output: the tail is where a failure normally lands.
        interesting = [line for line in lines if line.strip()][-30:]

    report = "\n".join(interesting[:60]).strip()

    if len(report) > limit:
        report = report[:limit] + "\n[...]"

    return report
