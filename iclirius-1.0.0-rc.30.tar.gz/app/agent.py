import re
import time
import uuid
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from pathlib import Path

from models.ollama_client import OllamaClient, OllamaError, OllamaUnavailableError
from app.config import settings
from app.delegation import (
    needs_local_read,
    needs_web_search,
    select_model_tier,
    should_delegate_to_worker,
    TIER_DEFAULT,
    TIER_FAST,
    TIER_HEAVY,
)
from app.logger import logger
from app.memory import MemoryStore
from app.learning import learn_from_turn
from app.auto_router import auto_route_message
from app import compaction as compaction_module
from app.provider_registry import Mode
from app.reasoning import Purpose, ReasoningRequest, ResponseStatus
from app.reasoning_gateway import GatewayError, build_gateway_for
from app import identity as identity_module
from app.assistant_profile import AssistantProfile, ProfileStore
from app import local_planner, local_read, project_identity, web_search
from app.capability_router import RoutingTrace, classify as classify_capability, normalize_query_for_intent
from app.tool_adapter import (ToolExecutionContext, default_registry, resolve_tool_for_message,
                              continue_result_set, attach_result_set_evidence, parse_modified_after)
from app.referents import ReferentManager
from app.attachment_gateway import AttachmentGateway
from app.context_engine import ContextEngine
from app.memory_core import MemoryCore, WebFinding
from app.planner import (
    Confidence,
    ForbiddenOperationError,
    Planner,
    PlanStatus,
    PROPOSAL_INSTRUCTIONS,
    StepStatus,
    VerificationState,
    analyse_evidence,
    validate_step,
)
from app.runtime_events import EventType, Status as EventStatus, emit, local_node
from app.permissions import Capability, Decision, permission_layer
from app.safe_write import (
    Change,
    FileChange,
    PatchStatus,
    PatchValidationError,
    StalePatchError,
    WriteDisabledError,
    WriteError,
    apply_proposal,
    build_proposal,
    validate_proposal,
    validate_write_path,
)
from app.task_engine import (
    Provenance,
    TaskAction,
    TaskEngine,
    WriteIntent,
    detect_execution_intent,
    detect_write_intent,
)
from app import safe_execute
from app.patch_generation import (
    GroundingError,
    GroundingStore,
    PatchGenerationError,
    build_patch_prompt,
    changes_from_payload,
    parse_patch_response,
    select_for_context,
)


def _public_web_recovery_query(query: str) -> str | None:
    """Create one bounded, intent-preserving public search reformulation."""
    cleaned = re.sub(r"[¿?¡!]", " ", query or "")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if not cleaned:
        return None
    lowered = cleaned.casefold()
    if re.search(r"c[oó]mo\s+funciona|how\s+does|documentation|documentaci[oó]n|configur", lowered):
        suffix = " official documentation overview"
    else:
        suffix = " official documentation"
    candidate = f"{cleaned}{suffix}"
    return candidate if candidate.casefold() != cleaned.casefold() else None


@dataclass(frozen=True)
class ActiveFilesystemContext:
    """Authorized identifiers for related filesystem turns only."""
    user_id: str | None
    node_id: str
    session_id: str
    root_id: str | None
    provider: str | None
    root_path: str | None
    root_paths: tuple[str, ...]
    root_resolution_status: str | None


def _recover_public_explainer_assessment(query, selection, passages, assessment):
    """Accept bounded descriptive documentation passages after recovery.

    C5.6 still performs normal selection, fetch safety and assessment.  This
    narrow presentation bridge applies only to an explicit ``cómo funciona``
    explainer after the second, documentation-focused attempt, and requires a
    complete primary fetch with lexical topic overlap.  Factual/current
    assertions continue through the canonical assertion assessor unchanged.
    """
    if assessment.status not in {"INSUFFICIENT", "NO_EVIDENCE"}:
        return assessment
    if selection.intent != "DOCUMENTATION" or not re.search(
            r"\b(?:c[oó]mo\s+funciona|how\s+does)\b", str(query), re.I):
        return assessment
    from app.web_assessment import AssessedStatement
    query_terms = {item.casefold() for item in re.findall(r"[\w]{3,}", str(query))}
    qualities = {item.evidence_id: item for item in selection.qualities}
    records = {item.evidence_id: item for item in passages.evidence}
    rows = []
    for passage in passages.selected:
        quality = qualities.get(passage.evidence_id)
        evidence = records.get(passage.evidence_id)
        result = evidence.record.result if evidence else {}
        if (not quality or quality.source_relationship != "PRIMARY"
                or result.get("retrieval") != "fetched" or result.get("truncated")):
            continue
        sentence = passage.text.strip()
        hits = query_terms & {item.casefold() for item in re.findall(r"[\w]{3,}", sentence)}
        if len(hits & {"google", "drive"}) < 2 or len(sentence) < 20:
            continue
        rows.append(AssessedStatement(
            passage.evidence_id, passage.passage_id, sentence[:500], 0, True,
            f"documentation :: {passage.passage_id}", sentence[:500], True))
    if not rows:
        return assessment
    coverage = dict(assessment.coverage)
    coverage["covered"] = [0]
    coverage["missing"] = []
    sufficiency = dict(assessment.sufficiency)
    sufficiency["status"] = "SUPPORTED"
    sufficiency["policy"] = "bounded primary documentation passage after recovery"
    return replace(assessment, status="SUPPORTED", coverage=coverage,
                   sufficiency=sufficiency, statements=tuple(rows))


class OpenClawAgent:
    def __init__(self, interface: str = "unknown", working_dir: str | None = None):
        self.ollama = OllamaClient()
        self._core = MemoryCore()
        # Reasoning reaches an engine only through the gateway. The agent does
        # not know that Ollama speaks HTTP, which is what lets a second
        # provider arrive without touching any of this.
        self.gateway = build_gateway_for(lambda: self.ollama, core=self._core)
        self.mode = Mode.LOCAL.value
        self.last_reasoning = None
        self.memory = MemoryStore(core=lambda: self.core)
        self.tasks = TaskEngine(self.core)
        self.context = ContextEngine()
        self.planner = Planner(self.core)
        self.active_plan = None
        self.proposals: dict = {}
        self.grounding = GroundingStore()
        self.profile_store = ProfileStore(self.core)
        self.profile: AssistantProfile = self.profile_store.load()
        self.conversation_summary = None
        self.compaction_count = 0
        self.last_reduction_ratio = 0.0
        self.executions: dict = {}
        self.last_execution: dict = {}
        self.interface = interface
        self.session_id = f"session_{uuid.uuid4().hex}"
        self.working_dir = working_dir
        self.last_package = None
        self.last_routing_trace: RoutingTrace | None = None
        self.last_web_search_calls = 0
        self.last_web_recovery_used = False
        self.last_web_failure_reason: str | None = None
        self.request_user_id: str | None = None
        self.attachment_gateway = AttachmentGateway(node_id=str(settings.node_id))
        self.request_attachment_id: str | None = None
        self.last_attachment_id: str | None = None
        self.last_attachment_by_user: dict[str, str] = {}
        self.last_filesystem_result_set_id: str | None = None
        self.last_filesystem_capability = None
        self.filesystem_scope = None
        self.active_filesystem_context: ActiveFilesystemContext | None = None
        self.active_snapshot_id: str | None = None
        self.referents = ReferentManager()
        self.last_tool_result = None
        # Per-interaction budgets. One user message may not turn into an
        # unbounded stream of proposals or subprocesses, however the loop goes.
        self._proposals_made = 0
        self._executions_made = 0
        self._patches_applied = 0

    @property
    def core(self):
        return self._core

    @core.setter
    def core(self, value):
        self._core = value
        gateway = getattr(self, "gateway", None)
        if gateway is not None and hasattr(gateway.governor, "set_core"):
            gateway.governor.set_core(value)

    # -- memory core -------------------------------------------------------
    #
    # Every call here is best effort. Memory must never take the interface
    # down: if the core is unavailable the agent still talks to Ollama.

    def bind_interface(self, reference: str) -> None:
        """Attach this interface to the one principal user."""
        if not settings.enable_memory_core:
            return

        try:
            self.core.link_interface(self.interface, reference)
        except Exception:
            logger.warning("Could not link interface to principal user", exc_info=False)

    def principal_id(self) -> str:
        """Return the encrypted Core identity used to scope conversation history."""
        if not settings.enable_memory_core:
            return ""
        try:
            return str((self.core.principal_user() or {}).get("user_id", ""))
        except Exception:
            return ""

    def record_conversation_turn(self, message: str, response: str,
                                 source: str, user_id: int = 0) -> None:
        """Persist one interface turn in the shared, principal-scoped log."""
        values = {
            "user_id": user_id,
            "user_message": message,
            "assistant_response": response,
            "source": source,
            "principal_id": self.principal_id(),
            "interface": self.interface,
            "session_id": self.session_id,
        }
        try:
            self.memory.add_conversation_turn(**values)
        except TypeError:
            # Test adapters and older local stores may still expose the
            # original five-argument contract; preserve their behavior while
            # the real MemoryStore uses the scoped fields above.
            values.pop("principal_id", None)
            values.pop("interface", None)
            values.pop("session_id", None)
            self.memory.add_conversation_turn(**values)

    def current_project(self) -> dict:
        """Project for this session, from local signals only."""
        if not settings.enable_memory_core or not self.working_dir:
            return {}

        try:
            signal = project_identity.detect(self.working_dir)
            if signal is None:
                return {}
            return self.core.upsert_project(signal)
        except Exception:
            logger.warning("Project detection failed", exc_info=False)
            return {}

    def _memory_context(self, message: str) -> tuple[str, str, dict]:
        """
        Select the project and task summaries worth sending.

        Only the active project and the active task enter the prompt. Other
        projects and other tasks are retrievable locally and are therefore
        never resent.
        """
        if not settings.enable_memory_core:
            return "", "", {}

        try:
            project = self.current_project()
            project_id = project.get("project_id")

            # From Telegram there is no working directory, so a project named
            # in the message is the only signal available.
            if not project_id:
                known = self.core.list_projects()
                for word in re.findall(r"[A-Za-z][A-Za-z0-9._-]{2,}", message or ""):
                    match = project_identity.resolve_by_name(word, known)
                    if match:
                        project = known[match]
                        project_id = match
                        break

            task = self.core.active_task_for(project_id)

            project_summary = ""
            if project:
                from app.memory_core import Project
                project_summary = Project(**{
                    k: v for k, v in project.items()
                    if k in Project.__dataclass_fields__
                }).render_compact()

            task_summary = task.get("compact_summary", "") if task else ""

            return project_summary, task_summary, task
        except Exception:
            logger.warning("Memory context unavailable; continuing without it", exc_info=False)
            return "", "", {}

    def remember_web_findings(self, task_id: str, bundle) -> None:
        """Store web evidence as claims and sources. Never page content."""
        if not settings.enable_memory_core or not task_id:
            return

        try:
            findings = [
                WebFinding(
                    claim=(result.snippet or result.title)[:400],
                    source_url=result.url,
                    domain=result.domain,
                    relevance=f"consulta: {bundle.query[:120]}",
                )
                for result in bundle.results[:5]
            ]
            self.core.add_web_findings(task_id, findings)
        except Exception:
            logger.warning("Could not store web findings", exc_info=False)

    def remember_project_facts(self, project_id: str, result) -> None:
        """Store structured findings from a local read, never file contents."""
        if not settings.enable_memory_core or not project_id:
            return

        try:
            facts = {}
            for line in (result.summary or "").splitlines():
                if line.startswith("- ") and ":" in line:
                    key, _, value = line[2:].partition(":")
                    key = key.strip().lower()
                    if key in ("archivos", "carpetas", "tamaño total",
                               "extensiones principales", "lenguajes",
                               "archivos de build"):
                        facts[key] = value.strip()

            if facts:
                self.core.record_project_facts(project_id, facts)
        except Exception:
            logger.warning("Could not store project facts", exc_info=False)

    def compact_history(self, limit: int | None = None) -> str:
        """
        Recent turns, each reduced to one line.

        Phase 3.2 measured history at 1506 of 1802 prompt characters: the
        largest remaining cost, and the least valuable, because an arbitrarily
        truncated transcript loses the beginning of the very turn it keeps.
        Summarising each turn to its first line keeps the thread of the
        conversation at a fraction of the size; the task's compact summary
        carries the durable state.
        """
        limit = limit or settings.history_max_turns

        try:
            try:
                turns = self.memory.read_recent_conversations(
                    limit=limit, principal_id=self.principal_id())
            except TypeError:
                turns = self.memory.read_recent_conversations(limit=limit)
        except Exception:
            logger.warning("Could not read recent conversations", exc_info=False)
            return ""

        per_turn = settings.history_turn_chars
        lines = []

        for turn in turns:
            asked = " ".join(str(turn.get("user_message", "")).split())
            answered = " ".join(str(turn.get("assistant_response", "")).split())

            if not asked and not answered:
                continue

            lines.append(f"L: {asked[:per_turn]}")

            if answered:
                lines.append(f"I: {answered[:per_turn]}")

        return "\n".join(lines)

    def build_recent_history(self, limit: int = 8) -> str:
        """
        Build a compact recent-history context.

        This is intentionally defensive because MemoryStore may evolve.
        If history access fails, the agent should still respond normally.
        """
        try:
            if hasattr(self.memory, "history_text"):
                return self.memory.history_text(limit=limit)
        except Exception:
            logger.exception("Failed to load recent history for context")

        return ""

    def build_task_prompt(self, message: str, decision=None,
                          local_evidence: str = "", web_evidence: str = "") -> str:
        """
        Assemble the prompt through the Context Engine.

        Everything here was gathered locally: the task, the project, the facts
        and any evidence. The model receives the selection, not the archive.
        """
        task = (decision.task if decision else None) or {}
        project = {}

        if task.get("project_id"):
            project = self.core.get_project(task["project_id"])
        else:
            project = self.current_project() or {}

        identity = (
            f"{self.profile.identity_block(runtime='Ollama', model=self.active_model())}\n"
            f"No reveles secretos ni valores de .env."
        )

        pending = self.pending_patch_summary()
        pending_text = ""

        if pending:
            pending_text = (
                f"patch {pending['patch_id']} sobre {', '.join(pending['files'])}: "
                f"+{pending['added_lines']} / -{pending['removed_lines']} líneas, "
                f"esperando aprobación."
            )

        history, summary_text = self.history_for_context(task or None)

        capability_lines = ["Capacidades reales del nodo:"]
        capability_lines.append(
            f"- filesystem_read: {'available' if permission_layer.check(Capability.READ) is not Decision.DENIED else 'disabled'}"
        )
        capability_lines.append(
            f"- filesystem_write: {'confirmation_required' if permission_layer.check(Capability.WRITE) is Decision.CONFIRM_REQUIRED else ('available' if permission_layer.check(Capability.WRITE) is Decision.ALLOWED else 'disabled')}"
        )
        capability_lines.append(
            f"- shell_execute: {'confirmation_required' if permission_layer.check(Capability.EXECUTE) is Decision.CONFIRM_REQUIRED else ('available' if permission_layer.check(Capability.EXECUTE) is Decision.ALLOWED else 'disabled')}"
        )
        capability_lines.append("- local_reasoning: available")
        if settings.enable_telegram:
            capability_lines.append("- telegram: available")
        if self.voice_service_available():
            capability_lines.append("- voice: local capability available")
        rules_with_capabilities = self.profile.rules_block() + "\n" + "\n".join(capability_lines)

        package = self.context.build(
            user_request=message,
            task=task or None,
            project=project or None,
            recent_history=history,
            local_evidence=local_evidence,
            web_evidence=web_evidence,
            identity=identity,
            rules=rules_with_capabilities,
            personality=self.profile.personality_block(),
            conversation_summary=summary_text,
            pending_patch=pending_text,
        )

        self.last_package = package

        logger.info(
            "Context built interface=%s task_action=%s %s",
            self.interface,
            getattr(decision, "action", "none"),
            " ".join(f"{k}={v}" for k, v in package.metrics.as_log_fields().items()),
        )

        emit(EventType.CONTEXT_BUILT.value, status=EventStatus.OK.value,
             interface=self.interface, node_id=settings.node_id,
             task_id=task.get("task_id"), project_id=project.get("project_id"),
             plan_id=getattr(self.active_plan, "plan_id", None),
             metadata={
                 "context_chars": package.metrics.total_chars,
                 "estimated_tokens": package.metrics.estimated_tokens,
                 "sections": ",".join(package.metrics.included_sections),
                 "truncated": ",".join(package.metrics.truncated_sections) or "-",
                 "fingerprint": package.metrics.context_fingerprint,
             })

        return package.prompt

    def voice_service_available(self) -> bool:
        """Return only a safe capability bit for prompt awareness."""
        try:
            from app.voice import voice_service
            return voice_service.tts.capability().value != "UNAVAILABLE" or voice_service.stt.capability().value != "UNAVAILABLE"
        except Exception:
            return False

    def build_prompt(self, message: str) -> str:
        """
        Canonical prompt assembly.

        Phase 3.2 left two routes; this is now a thin wrapper over the Context
        Engine so there is one place where a prompt is built. The signature is
        kept because the worker path and the local fallback still call it.
        """
        return self.build_task_prompt(message, self.resolve_task(message))

    def _post_response_memory_update(self, message: str, response: str) -> None:
        """
        Auto-learning and digest should never break the main response.
        """
        try:
            learned = learn_from_turn(message, response)
            if learned:
                logger.info("Auto-learning saved from conversation turn")
        except Exception:
            logger.exception("Auto-learning failed")


    ENGINE_DOWN_MESSAGE = (
        "El motor local no está disponible ahora mismo. "
        "Revisa que Ollama esté corriendo (ollama serve) y vuelve a intentarlo."
    )

    def local_model_chain(self, tier: str) -> list[str]:
        """
        Ordered models to try for a tier, best first.

        Degradation stays local: the requested tier, then default, then fast.
        Duplicates are collapsed, so a setup where every tier points at the
        same model simply yields one entry. Cloud is never an option here.
        """
        chain: list[str] = []

        for candidate_tier in (tier, TIER_DEFAULT, TIER_FAST):
            model = settings.model_for_tier(candidate_tier)
            if model and model not in chain:
                chain.append(model)

        return chain

    def generate_local(self, prompt: str, tier: str,
                       purpose: str = Purpose.GENERAL_REASONING.value) -> str:
        """
        Ask for reasoning, through the gateway.

        Every model call in the agent goes through here, so this is the only
        place that needs to know a provider exists at all. The gateway routes,
        tries the tier chain in order and records usage; the exceptions raised
        are unchanged, because nine call sites upstream catch them and their
        behaviour must not shift just because the plumbing moved.
        """
        chain = self.local_model_chain(tier)

        request = ReasoningRequest(
            purpose=purpose,
            prompt=prompt,
            tier=tier,
            task_id=self.active_task_id(),
        )

        try:
            result = self.gateway.submit(
                request, mode=self.mode, model_chain=chain,
                interface=self.interface,
            )
        except GatewayError as exc:
            raise OllamaUnavailableError(str(exc)) from exc

        response = result.response

        if response is None:
            raise OllamaError(f"Ningún modelo local respondió (probados: {chain}).")

        self.last_reasoning = response

        if response.ok:
            return response.content

        # Same distinction as before the gateway: an unreachable engine is a
        # different problem from a model that refused the work, and the
        # callers treat them differently.
        if response.status == ResponseStatus.UNAVAILABLE.value:
            raise OllamaUnavailableError(response.error or "Ollama no está disponible.")

        raise OllamaError(
            f"Ningún modelo local respondió (probados: {chain}): {response.error}")

    WEB_UNAVAILABLE_NOTE = (
        "No pude consultar Internet en este momento. "
        "Te respondo con mi conocimiento local, sin verificar en la web."
    )

    def answer_with_web(self, query: str, explicit: bool = False, *, _recovery_depth: int = 0,
                        _original_query: str | None = None) -> str | None:
        """
        Answer a question using public web evidence, synthesised locally.

        Returns None only when implicit web research is disabled. Missing or
        failed retrieval never authorizes a factual fallback from model memory.
        """
        original_query = _original_query or query
        if _recovery_depth == 0:
            self.last_web_search_calls = 0
            self.last_web_recovery_used = False
            self.last_web_failure_reason = None
        self.last_web_search_calls += 1
        if not settings.enable_web_search:
            if explicit:
                return (
                    "La búsqueda web está desactivada. "
                    "Actívala con ENABLE_WEB_SEARCH=true en .env."
                )
            return None

        try:
            bundle = web_search.research(query)
        except web_search.WebSearchError as exc:
            logger.warning("Web research failed reason=%s", type(exc).__name__)
            self.last_web_failure_reason = "WEB_UNAVAILABLE"
            recovery_query = _public_web_recovery_query(query) if _recovery_depth == 0 else None
            if recovery_query:
                self.last_web_recovery_used = True
                return self.answer_with_web(recovery_query, explicit=explicit, _recovery_depth=1,
                                            _original_query=original_query)
            return "No pude consultar Internet (WEB_UNAVAILABLE). No hay evidencia suficiente para afirmar una respuesta."
        except Exception:
            logger.exception("Unexpected web research failure")
            self.last_web_failure_reason = "SEARCH_FAILED"
            recovery_query = _public_web_recovery_query(query) if _recovery_depth == 0 else None
            if recovery_query:
                self.last_web_recovery_used = True
                return self.answer_with_web(recovery_query, explicit=explicit, _recovery_depth=1,
                                            _original_query=original_query)
            return "No pude consultar Internet (SEARCH_FAILED). No hay evidencia suficiente para afirmar una respuesta."

        if not bundle.ok:
            logger.info("Web research returned no results")
            self.last_web_failure_reason = "NO_RESULTS"
            recovery_query = _public_web_recovery_query(query) if _recovery_depth == 0 else None
            if recovery_query:
                self.last_web_recovery_used = True
                return self.answer_with_web(recovery_query, explicit=explicit, _recovery_depth=1,
                                            _original_query=original_query)
            return "No encontré resultados web. (NO_RESULTS) No hay evidencia suficiente para afirmar una respuesta."

        # Evidence goes to the active task as claims and sources. The pages
        # themselves are not stored: they can be fetched again if needed.
        task_id = self.active_task_id()

        if task_id:
            self.remember_web_findings(task_id, bundle)

        from app.web_grounding import (build_grounded_context_package, evidence_for_bundle,
                                       grounded_answer, render_sources)
        from app.web_selection import select_evidence
        from app.web_passages import select_passages
        from app.web_assessment import assess_evidence
        candidates = evidence_for_bundle(bundle)
        selection = select_evidence(query, candidates)
        document_evidence = list(selection.selected)
        passages = select_passages(query, document_evidence)
        evidence = list(passages.evidence)
        assessment = assess_evidence(original_query, selection, passages)
        if _recovery_depth > 0:
            assessment = _recover_public_explainer_assessment(
                original_query, selection, passages, assessment)
        logger.info("Web evidence assessment status=%s covered=%s missing=%s", assessment.status,
                    assessment.coverage["covered"], assessment.coverage["missing"])
        logger.info("Web evidence selection intent=%s candidates=%s selected=%s duplicates=%s rejected=%s",
                    selection.intent, len(candidates), len(document_evidence), selection.duplicates,
                    selection.rejected)
        logger.info("Web passage packing documents=%s passages=%s selected=%s per_evidence=%s context_chars=%s budget=%s truncated=%s",
                    len(document_evidence), len(passages.candidates), len(passages.selected),
                    passages.to_dict()["selected_passages_per_evidence"],
                    passages.context_chars_used, passages.context_budget_chars,
                    passages.to_dict()["truncated"])
        logger.debug("Web evidence selection details relationships=%s rejection_reasons=%s",
                     {item.evidence_id: item.source_relationship for item in selection.qualities
                      if item.selection == "SELECTED"},
                     {item.evidence_id: item.reason for item in selection.qualities
                      if item.selection == "REJECTED"})
        if assessment.status != "SUPPORTED":
            recovery_query = _public_web_recovery_query(query) if _recovery_depth == 0 else None
            if recovery_query:
                logger.info("Retrying public Web query with bounded reformulation")
                self.last_web_recovery_used = True
                return self.answer_with_web(recovery_query, explicit=explicit, _recovery_depth=1,
                                            _original_query=original_query)
            self.last_web_failure_reason = "INSUFFICIENT_EVIDENCE"
            grounded = grounded_answer("", evidence, assessment=assessment)
            sources = render_sources(grounded)
            return (grounded.text + ("\n" + sources if sources else "")).strip()
        try:
            package = build_grounded_context_package(original_query, evidence, passages, assessment)
        except ValueError:
            return "No hay evidencia suficiente dentro del límite de contexto para afirmar una respuesta."

        try:
            request = ReasoningRequest.from_package(package, purpose=Purpose.ANALYZE_EVIDENCE.value,
                                                   provider_preference="ollama-local")
            try:
                gateway_result = self.gateway.submit(request, mode=Mode.LOCAL.value,
                                                     model_chain=self.local_model_chain(TIER_DEFAULT),
                                                     interface=self.interface)
            except GatewayError as exc:
                raise OllamaUnavailableError(str(exc)) from exc
            answer = gateway_result.response.content if gateway_result.response and gateway_result.response.ok else ""
            self.last_reasoning = gateway_result.response
            if not answer:
                raise OllamaError("La respuesta local no estuvo disponible.")
        except (OllamaUnavailableError, OllamaError):
            logger.exception("Local synthesis of web evidence failed")
            return self.ENGINE_DOWN_MESSAGE

        grounded = grounded_answer(
            answer, evidence,
            provider=getattr(self.last_reasoning, "provider_id", ""),
            model=getattr(self.last_reasoning, "model_id", ""),
            assessment=assessment,
        )
        logger.info("Web answer grounded evidence_count=%s evidence_ids=%s citations=%s invalid_citations=%s status=%s",
                    len(evidence), [item.evidence_id for item in evidence],
                    list(grounded.validation.cited),
                    len(grounded.validation.invalid) + len(grounded.validation.invalid_urls) + len(grounded.validation.malformed),
                    grounded.grounding_status)
        sources = render_sources(grounded)
        return (grounded.text + ("\n" + sources if sources else "")).strip()

    def _local_answer_without_web(self, query: str, reason: str | None = None) -> str:
        """Degrade to local knowledge, saying plainly that it is unverified."""
        note = reason or self.WEB_UNAVAILABLE_NOTE

        try:
            local = self.generate_local(self.build_prompt(query), TIER_DEFAULT)
        except (OllamaUnavailableError, OllamaError):
            return note

        return f"{note}\n\n{local.strip()}"

    LOCAL_READ_RULES = """\
Estás interpretando el resultado de una operación de lectura local.

- El trabajo de filesystem ya se hizo en la máquina: abajo tienes un resumen ya reducido.
- No inventes archivos, rutas ni cifras que no aparezcan en el resultado.
- Si el resultado está truncado, dilo.
- Responde en español, breve y concreto."""

    def run_plan_step(self, plan, step: dict) -> tuple[bool, str]:
        """
        Execute one validated step through the existing read executors.

        The step was already checked against the allowlist and the path policy
        before it got here; this only dispatches and reduces. A failing step
        marks the plan, it does not raise.
        """
        from app import local_read
        from app.local_planner import LocalOperation

        operation = step["operation"]
        started = time.time()

        emit(EventType.TOOL_STARTED.value, status=EventStatus.STARTED.value,
             interface=self.interface, node_id=settings.node_id,
             plan_id=plan.plan_id, task_id=plan.task_id, step_id=step["step_id"],
             operation=operation)

        plan.mark(step["step_id"], StepStatus.RUNNING.value)
        plan.tool_calls += 1

        try:
            if operation == "ANALYZE_EVIDENCE":
                analysis = self.analyse(plan)
                plan.mark(step["step_id"], StepStatus.COMPLETED.value,
                          result_ref=f"confianza {analysis.confidence}")
                return True, self._render_analysis(analysis)

            result = local_read.execute(LocalOperation(
                name=operation,
                path=step.get("target", ""),
                query=step.get("parameters", {}).get("query"),
            ))
        except Exception as exc:
            duration = int((time.time() - started) * 1000)
            plan.mark(step["step_id"], StepStatus.FAILED.value, error=str(exc))

            emit(EventType.TOOL_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, node_id=settings.node_id,
                 plan_id=plan.plan_id, task_id=plan.task_id, step_id=step["step_id"],
                 operation=operation, duration_ms=duration,
                 metadata={"error": type(exc).__name__})

            emit(EventType.STEP_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, plan_id=plan.plan_id,
                 step_id=step["step_id"], operation=operation)

            return False, str(exc)

        duration = int((time.time() - started) * 1000)
        summary = result.as_model_text()

        # A file read here is what later entitles the model to propose a
        # change to it. Directory listings do not count: seeing a name is not
        # having read the file.
        if operation == "READ_TEXT_FILE":
            self.grounding.note_read(step.get("target"))

        plan.mark(step["step_id"], StepStatus.COMPLETED.value,
                  result_ref=f"{result.total_found} resultados")

        emit(EventType.TOOL_COMPLETED.value, status=EventStatus.OK.value,
             interface=self.interface, node_id=settings.node_id,
             plan_id=plan.plan_id, task_id=plan.task_id, step_id=step["step_id"],
             operation=operation, duration_ms=duration,
             metadata={"results": result.total_found,
                       "result_chars": len(summary),
                       "truncated": result.truncated})

        emit(EventType.STEP_COMPLETED.value, status=EventStatus.OK.value,
             interface=self.interface, plan_id=plan.plan_id,
             step_id=step["step_id"], operation=operation)

        # Verified evidence: it came from this machine.
        if plan.task_id:
            self.tasks.record_fact(
                plan.task_id,
                f"{operation} sobre {step.get('target', '')}: {result.total_found} resultados",
                Provenance.LOCAL_VERIFIED,
                source_ref=step.get("target", ""),
            )

        return True, summary[: settings.planner_max_result_chars]

    def analyse(self, plan, model_reasoning: str = ""):
        """
        Reason over the evidence gathered so far, locally.

        Structural analysis is free and always runs. The model is asked for a
        hypothesis only when the evidence is thin enough that a guess might
        point at the next useful read.
        """
        evidence = [
            step.get("result_ref", "")
            for step in plan.steps
            if step.get("status") == StepStatus.COMPLETED.value
        ]

        if not model_reasoning and evidence and settings.enable_planner:
            try:
                model_reasoning = self.generate_local(
                    "Con esta evidencia de solo lectura, propón en una frase la causa más "
                    "probable. Si no hay suficiente, dilo.\n\n"
                    + "\n".join(f"- {item}" for item in evidence[:6]),
                    TIER_FAST,
                    purpose=Purpose.ANALYZE_EVIDENCE.value,
                )
            except (OllamaUnavailableError, OllamaError):
                model_reasoning = ""

        return analyse_evidence(plan, evidence, model_reasoning)

    @staticmethod
    def _render_analysis(analysis) -> str:
        lines = [f"Confianza: {analysis.confidence}"]

        if analysis.observations:
            lines.append("Observaciones:")
            lines.extend(f"- {item}" for item in analysis.observations[:5])

        if analysis.hypothesis:
            # Explicitly marked: a hypothesis is not a verified fact.
            lines.append(f"Hipótesis (no verificada): {analysis.hypothesis}")

        lines.append(f"Siguiente: {analysis.recommended_next_step}")
        return "\n".join(lines)

    def propose_next_step(self, plan, evidence: str) -> dict | None:
        """
        Ask the model for one more operation, then validate it.

        The model never executes anything: its answer is text that must
        survive the schema, the allowlist, the path policy and the budget
        before an executor exists. Attempts are capped so a model that keeps
        producing nonsense cannot spin the loop.
        """
        if not self.planner.can_iterate(plan):
            return None

        allowed_roots = ", ".join(settings.file_manager_allowed_roots[:4])

        prompt = "\n\n".join([
            PROPOSAL_INSTRUCTIONS,
            f"Objetivo: {plan.goal}",
            f"Plan actual:\n{plan.compact()}",
            f"Evidencia reciente:\n{evidence[: settings.planner_max_context_chars]}",
            f"Rutas permitidas: {allowed_roots}",
        ])

        for attempt in range(settings.planner_max_proposal_attempts):
            plan.iterations += 1

            emit(EventType.MODEL_SELECTED.value, status=EventStatus.INFO.value,
                 interface=self.interface, node_id=settings.node_id,
                 plan_id=plan.plan_id, task_id=plan.task_id,
                 provider="ollama", model=settings.model_for_tier(TIER_DEFAULT),
                 metadata={"purpose": "planning", "attempt": attempt + 1})

            started = time.time()
            emit(EventType.MODEL_STARTED.value, status=EventStatus.STARTED.value,
                 interface=self.interface, node_id=settings.node_id,
                 plan_id=plan.plan_id, provider="ollama",
                 model=settings.model_for_tier(TIER_DEFAULT))

            try:
                raw = self.generate_local(prompt, TIER_DEFAULT,
                                          purpose=Purpose.PLANNING.value)
            except (OllamaUnavailableError, OllamaError):
                emit(EventType.MODEL_FAILED.value, status=EventStatus.FAILED.value,
                     interface=self.interface, node_id=settings.node_id,
                     plan_id=plan.plan_id, provider="ollama")
                return None

            emit(EventType.MODEL_FINISHED.value, status=EventStatus.OK.value,
                 interface=self.interface, node_id=settings.node_id,
                 plan_id=plan.plan_id, provider="ollama",
                 model=settings.model_for_tier(TIER_DEFAULT),
                 duration_ms=int((time.time() - started) * 1000),
                 metadata={"response_chars": len(raw)})

            record = self.planner.add_proposed_step(plan, raw, interface=self.interface)

            if record is not None:
                return record

        return None

    def run_agent_loop(self, message: str, decision=None) -> tuple[str, object] | None:
        """
        The planning loop: plan, read, observe, decide, stop.

        Deterministic where it can be, model-assisted only where it must be,
        and bounded everywhere. Returns (report, plan) or None when there is
        nothing to plan, in which case the caller answers conversationally.
        """
        if not settings.enable_planner or not settings.enable_local_read_tools:
            return None

        # Defence in depth. respond() only reaches here for messages that
        # already showed filesystem intent, but this method is public, and
        # local_planner falls back to the only configured root when there is
        # one, which would turn a greeting into a directory scan.
        wants_local, _ = needs_local_read(message)

        if not wants_local and not local_planner.extract_path(message):
            return None

        project = self.current_project() or {}
        default_path = project.get("root") or None

        try:
            plan = self.planner.plan_for(
                message,
                task_id=decision.task_id if decision else None,
                project_id=project.get("project_id"),
                default_path=default_path,
                interface=self.interface,
            )
        except local_planner.WriteIntentError as exc:
            return str(exc), None

        if plan is None or not plan.steps:
            return None

        self.active_plan = plan
        evidence: list[str] = []

        while True:
            step = plan.next_step()

            if step is None:
                break

            if not self.planner.can_call_tool(plan):
                plan.mark(step["step_id"], StepStatus.SKIPPED.value,
                          error="presupuesto de herramientas agotado")
                break

            emit(EventType.STEP_STARTED.value, status=EventStatus.STARTED.value,
                 interface=self.interface, plan_id=plan.plan_id,
                 step_id=step["step_id"], operation=step["operation"])

            ok, output = self.run_plan_step(plan, step)

            if ok and output:
                evidence.append(output[: settings.planner_max_result_chars])

            if not ok:
                # A failed read is information too: stop rather than thrash.
                break

            if plan.next_step() is not None:
                continue

            analysis = self.analyse(plan)

            if analysis.is_conclusive:
                plan.verification_state = VerificationState.READY_FOR_ACTION.value
                break

            if not self.planner.can_iterate(plan) or not self.planner.can_call_tool(plan):
                break

            if self.propose_next_step(plan, "\n".join(evidence)) is None:
                break

        self.persist_plan(plan)

        emit(EventType.PLAN_COMPLETED.value,
             status=EventStatus.OK.value if plan.status == PlanStatus.COMPLETED.value
             else EventStatus.BLOCKED.value,
             interface=self.interface, plan_id=plan.plan_id, task_id=plan.task_id,
             metadata={"steps": len(plan.steps), "tool_calls": plan.tool_calls,
                       "iterations": plan.iterations, "status": plan.status,
                       "verification": plan.verification_state})

        return self._explain_outcome(plan, evidence), plan

    def _narrate(self, message: str, report: str, decision=None) -> str:
        """
        Let the local model turn the plan report into a readable answer.

        Assembled through the Context Engine rather than by hand: the report is
        local evidence, so it gets the same budget and the same metrics as any
        other prompt, and the runtime snapshot can report what was sent.
        """
        prompt = self.build_task_prompt(message, decision, local_evidence=report)
        prompt += (
            "\n\n## Instrucciones\n"
            "- Explica en español, breve y concreto, lo que encontraste.\n"
            "- No inventes archivos ni rutas que no aparezcan en la evidencia.\n"
            "- Si el trabajo quedó bloqueado o incompleto, dilo con claridad."
        )

        try:
            return self.generate_local(
                prompt, TIER_DEFAULT, purpose=Purpose.NARRATION.value).strip()
        except (OllamaUnavailableError, OllamaError):
            # The plan report is already useful on its own.
            return report

    def _explain_outcome(self, plan, evidence: list[str]) -> str:
        """Tell the user where the loop stopped and why."""
        lines = [plan.compact()]

        if plan.verification_state == VerificationState.READY_FOR_ACTION.value:
            lines.append(
                "\nTengo suficiente evidencia para proponer un cambio, "
                "pero la escritura todavía no está habilitada."
            )
        elif plan.status == PlanStatus.BLOCKED.value:
            lines.append("\nEl plan está bloqueado. Necesito que me digas cómo seguir.")
        elif plan.status == PlanStatus.FAILED.value:
            lines.append("\nUn paso falló. Puedo intentar otra vía si me lo indicas.")
        elif plan.tool_calls >= settings.planner_max_tool_calls:
            lines.append("\nAlcancé el límite de operaciones para este turno.")

        return "\n".join(lines)

    def persist_plan(self, plan) -> None:
        """Keep enough of the plan in the task for another interface to resume."""
        if not plan or not plan.task_id:
            return

        try:
            self.core.update_task(plan.task_id, decisions=f"[plan {plan.plan_id}] {plan.compact()}")
        except Exception:
            logger.warning("Could not persist the plan", exc_info=False)

    def answer_with_local_read(self, message: str, explicit: bool = False,
                               default_path: str | None = None) -> str | None:
        """
        Plan a read operation, run it locally, and let the model interpret the
        reduced result. Returns None when the caller should continue normally.
        """
        if not settings.enable_local_read_tools:
            if explicit:
                return (
                    "Las herramientas de lectura local están desactivadas. "
                    "Actívalas con ENABLE_LOCAL_READ_TOOLS=true en .env."
                )
            return None

        try:
            operation = local_planner.validate(local_planner.plan(message, default_path=default_path))
        except local_planner.WriteIntentError as exc:
            return str(exc)
        except local_planner.PlanError as exc:
            return str(exc) if explicit else None

        try:
            result = local_read.execute(operation)
        except PermissionError as exc:
            return f"Esa ruta no está permitida.\n{exc}"
        except local_read.LocalReadDisabled as exc:
            return str(exc)
        except local_read.LocalReadError as exc:
            return f"No pude completar la lectura: {exc}"
        except OSError as exc:
            logger.warning("Local read OS error op=%s error=%s", operation.name, type(exc).__name__)
            return f"Error del sistema de archivos: {type(exc).__name__}"
        except Exception:
            logger.exception("Unexpected local read failure op=%s", operation.name)
            return "Tuve un error inesperado leyendo esa ruta."

        if operation.name == "READ_TEXT_FILE":
            self.grounding.note_read(operation.path)

        # Structured facts about the project are worth keeping; the files
        # behind them are not, because rereading them locally is cheap.
        project = self.current_project() or {}
        if project.get("project_id") and result.operation == "DIRECTORY_SUMMARY":
            self.remember_project_facts(project["project_id"], result)

        prompt = "\n\n".join([
            self.LOCAL_READ_RULES,
            f"## Operación ejecutada\n{operation.name} ({operation.reason})",
        ])

        # Through the Context Engine, like every other prompt: the reduced read
        # result is local evidence, so it gets the same budget and shows up in
        # the runtime metrics instead of being assembled by hand here.
        prompt = self.build_task_prompt(
            message,
            self.resolve_task(message),
            local_evidence=f"{prompt}\n\n{result.as_model_text()}",
        )

        try:
            answer = self.generate_local(prompt, TIER_DEFAULT)
        except (OllamaUnavailableError, OllamaError):
            logger.exception("Local synthesis of read result failed")
            # The raw result is still useful without the model.
            return result.as_model_text()

        # A local read is verified evidence: it came from this machine.
        task_id = self.active_task_id()
        if task_id:
            self.tasks.record_fact(
                task_id,
                f"{operation.name} sobre {operation.path}: {result.total_found} resultados",
                Provenance.LOCAL_VERIFIED,
                source_ref=operation.path,
            )

        return answer.strip()

    def active_task_id(self) -> str | None:
        """
        The task a capability result belongs to.

        A local read or a web search is *part of* whatever we are working on;
        its own request text ("revisa /ruta") is not a task description, so
        re-deriving a task from it would find nothing. The active task is the
        right owner.
        """
        if not settings.enable_memory_core:
            return None

        try:
            project = self.current_project() or {}
            task = self.core.active_task_for(project.get("project_id"))
            return task.get("task_id") if task else None
        except Exception:
            logger.warning("Could not resolve the active task", exc_info=False)
            return None

    # -- safe write --------------------------------------------------------
    #
    # The model produces data; this code decides whether it may become a file
    # change. Nothing here lets model output reach the filesystem directly.

    def propose_patch(self, files: list, reason: str, task_id=None,
                      project_id=None, risk: str = "MEDIUM") -> tuple[object | None, str]:
        """
        Build and validate a patch, then ask for permission.

        Validation runs before the user is asked anything: there is no point
        showing a preview of a change that could never be applied.
        """
        decision = permission_layer.check(Capability.WRITE)

        if decision is Decision.DENIED:
            return None, (
                "La escritura está desactivada. "
                "Actívala con WRITE_ENABLED=true en .env."
            )

        if self._proposals_made >= settings.write_max_proposals_per_interaction:
            return None, (
                f"Ya preparé {self._proposals_made} cambio(s) en esta "
                f"interacción, que es el máximo. Resuelve el pendiente y "
                f"pídemelo de nuevo."
            )

        # The dictionary is a lookup cache for approvals, not a queue. Trim it
        # so a long session cannot grow it without bound.
        while len(self.proposals) >= 8:
            self.proposals.pop(next(iter(self.proposals)), None)

        proposal = build_proposal(files, reason=reason, task_id=task_id,
                                  project_id=project_id, risk=risk)

        emit(EventType.PATCH_PROPOSED.value, status=EventStatus.INFO.value,
             interface=self.interface, node_id=settings.node_id,
             task_id=task_id, patch_id=proposal.patch_id,
             metadata=proposal.summary())

        try:
            validate_proposal(proposal)
        except StalePatchError as exc:
            proposal.mark(PatchStatus.STALE.value, str(exc))
            emit(EventType.PATCH_STALE.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, patch_id=proposal.patch_id)
            return None, f"No apliqué nada: {exc}"
        except (PatchValidationError, WriteDisabledError, WriteError,
                PermissionError, RuntimeError) as exc:
            proposal.mark(PatchStatus.REJECTED.value, str(exc))
            emit(EventType.PATCH_REJECTED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, patch_id=proposal.patch_id,
                 metadata={"reason": type(exc).__name__})
            return None, f"No puedo aplicar ese cambio: {exc}"

        proposal.mark(PatchStatus.VALIDATED.value)
        self.proposals[proposal.patch_id] = proposal
        self._proposals_made += 1

        emit(EventType.PATCH_VALIDATED.value, status=EventStatus.OK.value,
             interface=self.interface, patch_id=proposal.patch_id,
             metadata=proposal.summary())

        if decision is Decision.ALLOWED:
            return proposal, ""

        pending = permission_layer.request_approval(proposal, interface=self.interface)
        proposal.mark(PatchStatus.WAITING_APPROVAL.value)

        emit(EventType.WRITE_APPROVAL_REQUIRED.value, status=EventStatus.BLOCKED.value,
             interface=self.interface, patch_id=proposal.patch_id,
             metadata=proposal.summary())

        names = ", ".join(pending.summary["files"])

        return proposal, (
            f"{proposal.preview()}\n\n"
            f"Preparé un cambio en {names}: "
            f"+{proposal.added_lines} / -{proposal.removed_lines} líneas.\n"
            f"¿Quieres que lo aplique? (responde sí o no)"
        )

    def patch_hints(self) -> list[str]:
        """Files this conversation is actually about, best first."""
        hints: list[str] = []

        plan = self.active_plan

        if plan is not None:
            for step in getattr(plan, "steps", []) or []:
                target = step.get("target") if isinstance(step, dict) else None
                if target and target not in hints:
                    hints.append(target)

        return hints

    def generate_patch(self, message: str, analysis: str = "",
                       task_id=None, project_id=None) -> tuple[object | None, str]:
        """
        Turn a request to change something into a validated proposal.

        This is the step Phase 3.5 was missing: it could apply a patch but
        never built one, so "arréglalo" produced an explanation and nothing
        else. The model contributes the text of the edit and nothing more —
        which files it may touch, whether they were read, whether they still
        match, and whether the result is allowed are all decided here.
        """
        if permission_layer.check(Capability.WRITE) is Decision.DENIED:
            return None, (
                "La escritura está desactivada, así que puedo explicarte el "
                "cambio pero no prepararlo. Actívala con WRITE_ENABLED=true."
            )

        emit(EventType.PATCH_GENERATION_STARTED.value, status=EventStatus.STARTED.value,
             interface=self.interface, node_id=settings.node_id, task_id=task_id)

        files, skipped = select_for_context(self.grounding, self.patch_hints())

        if not files:
            emit(EventType.GROUNDING_REFUSED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, task_id=task_id,
                 metadata={"skipped": len(skipped)})

            detail = f" ({skipped[0]})" if skipped else ""

            return None, (
                "No puedo proponer un cambio todavía: no he leído ningún "
                f"archivo concreto en esta conversación{detail}. "
                "Dime la ruta y lo leo primero."
            )

        prompt = build_patch_prompt(message, files, analysis=analysis)

        emit(EventType.MODEL_STARTED.value, status=EventStatus.STARTED.value,
             interface=self.interface, provider="ollama",
             model=settings.model_for_tier(TIER_HEAVY),
             metadata={"purpose": "patch", "prompt_chars": len(prompt),
                       "files": len(files)})

        try:
            raw = self.generate_local(prompt, TIER_HEAVY,
                                      purpose=Purpose.PATCH_GENERATION.value)
        except (OllamaUnavailableError, OllamaError) as exc:
            emit(EventType.PATCH_GENERATION_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, task_id=task_id,
                 metadata={"error": type(exc).__name__})
            return None, f"No pude generar el cambio: {exc}"

        try:
            payload = parse_patch_response(raw)
            changes = changes_from_payload(payload, self.grounding)
        except GroundingError as exc:
            emit(EventType.GROUNDING_REFUSED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, task_id=task_id,
                 metadata={"reason": "ungrounded_path"})
            return None, str(exc)
        except PatchGenerationError as exc:
            emit(EventType.PATCH_GENERATION_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, task_id=task_id,
                 metadata={"reason": type(exc).__name__})
            return None, f"No preparé ningún cambio: {exc}"

        emit(EventType.PATCH_GENERATED.value, status=EventStatus.OK.value,
             interface=self.interface, task_id=task_id,
             metadata={"files": len(changes),
                       "changes": sum(len(item.changes) for item in changes),
                       "context_chars": len(prompt)})

        return self.propose_patch(
            changes,
            reason=payload.get("reason") or message[:200],
            task_id=task_id,
            project_id=project_id,
            risk=payload.get("risk", "MEDIUM"),
        )

    def _offer_patch(self, message: str, answer: str, analysis: str,
                     decision) -> str:
        """
        Append a concrete proposal to an explanation, when one can be made.

        A failure to generate is not a failure to answer: the analysis stands
        on its own and the reason no patch came out is appended to it, rather
        than replacing a useful reply with an error.
        """
        project = self.current_project() or {}

        try:
            proposal, note = self.generate_patch(
                message,
                analysis=analysis,
                task_id=decision.task_id if decision else None,
                project_id=project.get("project_id"),
            )
        except Exception:
            logger.exception("Patch generation failed")
            return f"{answer}\n\nNo conseguí preparar el cambio."

        if not note:
            return answer

        return f"{answer}\n\n{note}"

    # -- safe execution ----------------------------------------------------
    #
    # The model names an operation. app.safe_execute owns the command line and
    # is the only place in OpenClaw that starts a subprocess for the agent.

    def execution_cwd(self) -> str | None:
        project = self.current_project() or {}
        return project.get("root") or self.working_dir

    def request_execution(self, operation: str, task_id=None) -> str:
        """Ask permission to run a build, a test suite, a linter or a checker."""
        decision = permission_layer.check(Capability.EXECUTE)

        if decision is Decision.DENIED:
            return (
                "La ejecución está desactivada. "
                "Actívala con EXECUTE_ENABLED=true en .env."
            )

        if self._executions_made >= settings.coding_max_executions:
            emit(EventType.CODING_LIMIT_REACHED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, task_id=task_id,
                 metadata={"limit": "executions"})
            return (
                f"Ya ejecuté {self._executions_made} veces en esta interacción, "
                f"que es el máximo."
            )

        cwd = self.execution_cwd()

        if not cwd:
            return "No sé en qué proyecto ejecutarlo."

        try:
            target = safe_execute.validate_cwd(cwd)
            profile = safe_execute.select_profile(operation, target)
        except (safe_execute.ExecutionError, PermissionError, RuntimeError) as exc:
            emit(EventType.EXECUTION_BLOCKED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, task_id=task_id, operation=operation)
            return str(exc)

        if decision is Decision.ALLOWED:
            return self._run_execution(profile, target, task_id=task_id)

        # Asking twice for the same check is one request, not two. Stacking
        # duplicates would make a later "sí" ambiguous between identical
        # things, which is a confusing way to say no.
        for existing in permission_layer.pending_executions(interface=self.interface):
            if existing.profile == profile.name and existing.cwd == str(target):
                return (
                    f"Ya te lo había preguntado: {existing.command} "
                    f"en {target.name}. ¿Lo ejecuto? (responde sí o no)"
                )

        execution_id = f"exec_{uuid.uuid4().hex[:10]}"

        self.executions[execution_id] = (profile, target, task_id)

        pending = permission_layer.request_execution(
            execution_id=execution_id,
            operation=profile.operation,
            profile=profile.name,
            command=profile.description,
            cwd=str(target),
            interface=self.interface,
        )

        emit(EventType.EXECUTION_APPROVAL_REQUIRED.value, status=EventStatus.BLOCKED.value,
             interface=self.interface, task_id=task_id, execution_id=execution_id,
             operation=profile.operation, metadata={"profile": profile.name})

        return (
            f"Para verificarlo necesito ejecutar: {pending.command}\n"
            f"En: {target.name}\n"
            f"Sin red, sin entrada interactiva, con límite de "
            f"{settings.execute_timeout_seconds}s.\n"
            f"¿Lo ejecuto? (responde sí o no)"
        )

    def run_approved_execution(self, execution_id: str | None = None) -> str:
        pending = permission_layer.resolve_execution_target(
            execution_id, interface=self.interface)

        if pending is None:
            waiting = permission_layer.pending_executions(interface=self.interface)

            if len(waiting) > 1:
                options = "\n".join(
                    f"- {item.execution_id}: {item.command}" for item in waiting)
                return (
                    "Tengo varias ejecuciones pendientes y no adivino cuál. "
                    f"Dime el identificador:\n{options}"
                )

            return "No tengo ninguna ejecución pendiente que aprobar."

        approved = permission_layer.approve_execution(pending.execution_id)

        if approved is None:
            self.executions.pop(pending.execution_id, None)
            return (
                "Esa aprobación caducó. Pídemelo otra vez y lo vuelvo a preparar."
            )

        entry = self.executions.pop(approved.execution_id, None)

        if entry is None:
            return "Ya no tengo esa ejecución preparada."

        emit(EventType.EXECUTION_APPROVED.value, status=EventStatus.OK.value,
             interface=self.interface, execution_id=approved.execution_id,
             operation=approved.operation)

        profile, target, task_id = entry

        return self._run_execution(profile, target, task_id=task_id)

    def deny_pending_execution(self, execution_id: str | None = None) -> str:
        pending = permission_layer.resolve_execution_target(
            execution_id, interface=self.interface)

        if pending is None:
            waiting = permission_layer.pending_executions(interface=self.interface)

            if len(waiting) > 1:
                for item in waiting:
                    permission_layer.deny_execution(item.execution_id)
                    self.executions.pop(item.execution_id, None)

                return f"De acuerdo, descarto las {len(waiting)} ejecuciones pendientes."

            return "No tengo ninguna ejecución pendiente."

        permission_layer.deny_execution(pending.execution_id)
        self.executions.pop(pending.execution_id, None)

        emit(EventType.EXECUTION_DENIED.value, status=EventStatus.INFO.value,
             interface=self.interface, execution_id=pending.execution_id,
             operation=pending.operation)

        return f"De acuerdo, no ejecuto {pending.command}."

    def _run_execution(self, profile, target, task_id=None) -> str:
        """Run one profile and report a locally reduced result."""
        self._executions_made += 1

        emit(EventType.EXECUTION_STARTED.value, status=EventStatus.STARTED.value,
             interface=self.interface, node_id=settings.node_id, task_id=task_id,
             operation=profile.operation, metadata={"profile": profile.name})

        try:
            result = safe_execute.run(profile.operation, target, profile=profile)
        except safe_execute.ExecutionDisabled as exc:
            return str(exc)
        except (safe_execute.ExecutionError, PermissionError, RuntimeError, OSError) as exc:
            emit(EventType.EXECUTION_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, task_id=task_id,
                 operation=profile.operation,
                 metadata={"error": type(exc).__name__})
            return f"No pude ejecutarlo: {exc}"

        event = (EventType.EXECUTION_TIMEOUT if result.timed_out
                 else EventType.EXECUTION_COMPLETED if result.success
                 else EventType.EXECUTION_FAILED)

        emit(event.value,
             status=EventStatus.OK.value if result.success else EventStatus.FAILED.value,
             interface=self.interface, task_id=task_id,
             execution_id=result.execution_id, operation=result.operation,
             duration_ms=result.duration_ms,
             metadata=result.as_event_metadata())

        self._record_verification(result, task_id)

        self.last_execution = result.as_event_metadata()

        return self._render_execution(result)

    def _record_verification(self, result, task_id) -> None:
        """
        Write the outcome down with the right provenance.

        An execution result is LOCAL_VERIFIED: it happened on this machine and
        the exit code is a fact. Whatever a model later says the failure means
        is a hypothesis, and is stored as one.
        """
        state = (VerificationState.VERIFIED.value if result.success
                 else VerificationState.VERIFICATION_FAILED.value)

        emit((EventType.VERIFICATION_PASSED if result.success
              else EventType.VERIFICATION_FAILED).value,
             status=EventStatus.OK.value if result.success else EventStatus.FAILED.value,
             interface=self.interface, task_id=task_id,
             execution_id=result.execution_id,
             metadata={"profile": result.profile, "exit_code": result.exit_code})

        if not task_id:
            return

        try:
            self.tasks.record_fact(
                task_id,
                f"{result.profile}: {result.headline} (código {result.exit_code})",
                Provenance.LOCAL_VERIFIED,
                source_ref=result.execution_id,
            )
            self.core.update_task(task_id, verification_state=state)
        except Exception:
            logger.warning("Could not record the execution result", exc_info=False)

    def pending_execution_summary(self) -> dict:
        """What a UI needs to draw the pending execution. No output, no argv."""
        pending = permission_layer.pending_executions(interface=self.interface)

        if not pending:
            return {}

        item = pending[0]

        return {
            "execution_id": item.execution_id,
            "operation": item.operation,
            "profile": item.profile,
            "command": item.command,
            "project": Path(item.cwd).name,
            "requested_at": item.requested_at,
            "waiting": len(pending),
        }

    @staticmethod
    def _render_execution(result) -> str:
        lines = [
            f"Ejecuté {result.profile} ({result.duration_ms} ms): {result.headline}"
        ]

        if result.timed_out:
            lines.append("Lo corté al superar el tiempo límite.")

        if not result.success and result.summary:
            lines.extend(["", result.summary])

        if result.truncated:
            lines.append("[salida recortada]")

        if result.success:
            lines.append("")
            lines.append("Esto sí es verificación: el código se ejecutó y pasó.")

        return "\n".join(lines)

    def apply_approved_patch(self, patch_id: str | None = None) -> str:
        """
        Apply a patch the user just approved.

        The approval is consumed, so the same yes cannot authorise a second
        write, and everything is revalidated because the file may have moved
        on while the question was on screen.
        """
        pending = permission_layer.resolve_target(patch_id, interface=self.interface)

        if pending is None:
            candidates = permission_layer.pending(interface=self.interface)

            if len(candidates) > 1:
                listing = "\n".join(
                    f"- {item.patch_id}: {', '.join(item.summary['files'])}"
                    for item in candidates
                )
                return ("Tengo varios cambios pendientes. Dime cuál aplico:\n" + listing)

            return "No tengo ningún cambio pendiente de aprobación."

        approved = permission_layer.approve(pending.patch_id)

        if approved is None:
            emit(EventType.WRITE_DENIED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, patch_id=pending.patch_id,
                 metadata={"reason": "expired"})
            return ("Esa aprobación expiró. Vuelve a pedirme el cambio y lo "
                    "propongo contra el archivo tal como está ahora.")

        if self._patches_applied >= settings.coding_max_patches:
            emit(EventType.CODING_LIMIT_REACHED.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, metadata={"limit": "patches"})
            return (
                f"Ya apliqué {self._patches_applied} parche(s) en esta "
                f"interacción, que es el máximo."
            )

        proposal = self.proposals.get(approved.patch_id)

        if proposal is None:
            return "Perdí el detalle de ese cambio. Pídemelo otra vez."

        emit(EventType.WRITE_APPROVED.value, status=EventStatus.OK.value,
             interface=self.interface, patch_id=proposal.patch_id)

        started = time.time()

        emit(EventType.WRITE_STARTED.value, status=EventStatus.STARTED.value,
             interface=self.interface, node_id=settings.node_id,
             patch_id=proposal.patch_id, task_id=proposal.task_id,
             metadata=proposal.summary())

        try:
            result = apply_proposal(proposal)
        except StalePatchError as exc:
            proposal.mark(PatchStatus.STALE.value, str(exc))
            emit(EventType.PATCH_STALE.value, status=EventStatus.BLOCKED.value,
                 interface=self.interface, patch_id=proposal.patch_id)
            return f"No apliqué nada: {exc}"
        except (WriteError, PermissionError, RuntimeError) as exc:
            emit(EventType.WRITE_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, patch_id=proposal.patch_id,
                 metadata={"reason": type(exc).__name__})
            return f"El cambio falló y dejé los archivos como estaban: {exc}"
        except Exception as exc:
            logger.exception("Unexpected write failure patch_id=%s", proposal.patch_id)
            emit(EventType.WRITE_FAILED.value, status=EventStatus.FAILED.value,
                 interface=self.interface, patch_id=proposal.patch_id)
            return f"Error inesperado al escribir: {type(exc).__name__}"

        duration = int((time.time() - started) * 1000)

        emit(EventType.WRITE_COMPLETED.value, status=EventStatus.OK.value,
             interface=self.interface, node_id=settings.node_id,
             patch_id=proposal.patch_id, duration_ms=duration,
             metadata={"files": result["applied"]})

        return self._verify_after_write(proposal, result)

    def _verify_after_write(self, proposal, result: dict) -> str:
        """
        Confirm what landed on disk, read-only.

        A verified diff means the bytes changed as intended. It does not mean
        the code works: nothing has been built or tested, so the task is
        marked modified-but-unverified.
        """
        verified = all(item["verified"] for item in result["files"])
        diff_text = ""

        try:
            from app import local_read

            # From the repository root, not the first file's directory: files
            # in a patch can sit at different depths, and a nested folder is
            # not necessarily where the diff should be read from.
            first = Path(result["files"][0]["target"])
            repo_root = project_identity.find_git_root(first) or first.parent
            diff = local_read.git_read(str(repo_root), "GIT_DIFF")
            diff_text = diff.summary
        except Exception:
            logger.info("Could not read a git diff after the write", exc_info=False)

        if verified:
            proposal.mark(PatchStatus.VERIFIED_DIFF.value)
            emit(EventType.DIFF_VERIFIED.value, status=EventStatus.OK.value,
                 interface=self.interface, patch_id=proposal.patch_id,
                 metadata={"files": len(result["files"]),
                           "has_git_diff": bool(diff_text)})
        else:
            proposal.mark(PatchStatus.FAILED.value, "verification mismatch")

        if proposal.task_id:
            try:
                for item in result["files"]:
                    self.tasks.record_fact(
                        proposal.task_id,
                        f"{item['name']} modificado ({item['base_fingerprint']} → "
                        f"{item['new_fingerprint']})",
                        Provenance.LOCAL_VERIFIED,
                        source_ref=item["target"],
                    )

                self.core.update_task(
                    proposal.task_id,
                    relevant_files=[item["name"] for item in result["files"]],
                    verification_state="MODIFIED_UNVERIFIED",
                    next_steps="verificar con build o tests cuando estén habilitados",
                )
            except Exception:
                logger.warning("Could not record the write in memory", exc_info=False)

        names = ", ".join(item["name"] for item in result["files"])

        lines = [
            f"Apliqué el cambio en {names}.",
            f"+{proposal.added_lines} / -{proposal.removed_lines} líneas.",
            "Diff verificado: los bytes cambiaron como esperaba."
            if verified else "No pude verificar el resultado.",
            "",
            # The state is deliberately not VERIFIED. Bytes changing is not
            # code working, and only an execution can tell the difference.
            "Ojo: el archivo cambió, pero eso no significa que el código funcione.",
        ]

        lines.append(self._verification_offer(proposal))

        return "\n".join(line for line in lines if line is not None)

    def _verification_offer(self, proposal) -> str:
        """
        What can be said about verifying the change that was just applied.

        With execution off, this is where the user learns the limit of what
        was proven. With execution on it asks for permission, or runs the
        check directly when confirmation has been disabled.
        """
        decision = permission_layer.check(Capability.EXECUTE)

        if decision is Decision.DENIED:
            return ("Para comprobarlo de verdad haría falta ejecutar tests o "
                    "build: actívalo con EXECUTE_ENABLED=true en .env.")

        self._patches_applied += 1

        return self.request_execution(safe_execute.Operation.RUN_TESTS.value,
                                      task_id=proposal.task_id)

    def deny_pending_patch(self, patch_id: str | None = None) -> str:
        pending = permission_layer.resolve_target(patch_id, interface=self.interface)

        if pending is None:
            return "No tenía ningún cambio pendiente."

        permission_layer.deny(pending.patch_id)
        proposal = self.proposals.pop(pending.patch_id, None)

        if proposal is not None:
            proposal.mark(PatchStatus.DENIED.value)

        emit(EventType.WRITE_DENIED.value, status=EventStatus.BLOCKED.value,
             interface=self.interface, patch_id=pending.patch_id)

        return "Vale, no lo aplico. No cambié nada."

    def pending_patch_summary(self) -> dict:
        """Metadata for the runtime snapshot. Never the diff."""
        candidates = permission_layer.pending(interface=self.interface)

        if not candidates:
            return {}

        latest = candidates[0]

        return {
            **latest.summary,
            "approval_status": "WAITING_APPROVAL",
            "requested_at": latest.requested_at,
        }

    def resolve_task(self, message: str):
        """Decide whether this message is work, and which task it belongs to."""
        if not settings.enable_memory_core:
            return None

        try:
            decision = self.tasks.decide(message, working_project=self.current_project())
            logger.info(
                "Task decision interface=%s action=%s reason=%s task_id=%s",
                self.interface, decision.action, decision.reason, decision.task_id,
            )
            return decision
        except Exception:
            logger.warning("Task resolution failed; continuing", exc_info=False)
            return None

    # -- profile and compaction --------------------------------------------

    def set_preferences(self, updates: dict) -> str:
        """
        The internal API for "prefiero respuestas más cortas".

        Validated, bounded and persisted. It cannot reach a security setting:
        those names are refused outright rather than silently ignored, so a
        preference can never become a way to change the permission posture.
        """
        from app.assistant_profile import PreferenceError

        try:
            applied = self.profile_store.set_preferences(updates)
        except PreferenceError as exc:
            return str(exc)
        except Exception:
            logger.warning("Could not persist preferences", exc_info=False)
            return "No pude guardar esa preferencia."

        self.profile = self.profile_store.load()

        emit(EventType.PREFERENCES_UPDATED.value, status=EventStatus.OK.value,
             interface=self.interface, node_id=settings.node_id,
             metadata={"fields": ",".join(sorted(applied))})

        return "Anotado: " + ", ".join(f"{key}={value}"
                                       for key, value in sorted(applied.items()))

    def summary_key(self, task: dict | None) -> str:
        """Per task when there is one, per interface otherwise."""
        if task and task.get("task_id"):
            return f"task:{task['task_id']}"

        return f"interface:{self.interface}"

    def load_summary(self, task: dict | None):
        """The stored summary for this thread, or an empty one."""
        try:
            stored = self.core.get_summary(self.summary_key(task))
        except Exception:
            logger.warning("Could not read the conversation summary", exc_info=False)
            return None

        if not stored:
            return None

        return compaction_module.ConversationSummary.from_dict(stored)

    def history_for_context(self, task: dict | None) -> tuple[str, str]:
        """
        Recent history plus a summary, compacting first if it has outgrown
        the budget already configured for history.

        Returns (recent_turns_text, summary_text). Both can be empty. On any
        failure this degrades to exactly the Phase 3.2 behaviour: the raw
        compact history and no summary, so a broken summariser costs a little
        context efficiency and nothing else.
        """
        history = self.compact_history()

        try:
            try:
                turns = self.memory.read_recent_conversations(
                    limit=settings.history_max_turns * 4,
                    principal_id=self.principal_id())
            except TypeError:
                turns = self.memory.read_recent_conversations(
                    limit=settings.history_max_turns * 4)
        except Exception:
            turns = []

        existing = self.load_summary(task)

        if not compaction_module.should_compact(history, len(turns)):
            self.conversation_summary = existing

            return history, existing.render_compact() if existing else ""

        # Do not recompact a thread that a recent summary already covers.
        # The full history keeps exceeding its budget by construction, so
        # without this the same conversation would be compacted on every
        # single turn — paying for the same work repeatedly and churning the
        # stored summary for nothing.
        if (existing is not None
                and existing.covered_turns >= len(turns) - settings.history_max_turns):
            self.conversation_summary = existing

            return self.compact_history(limit=2), existing.render_compact()

        result = compaction_module.compact(
            turns,
            task=task,
            generate=self._summary_generator(),
            history_text=history,
            interface=self.interface,
            task_id=(task or {}).get("task_id"),
        )

        if result is None:
            self.conversation_summary = existing

            return history, existing.render_compact() if existing else ""

        self.conversation_summary = result.summary
        self.compaction_count += 1
        self.last_reduction_ratio = result.reduction_ratio

        try:
            self.core.save_summary(self.summary_key(task), result.summary.to_dict())
        except Exception:
            logger.warning("Could not persist the conversation summary",
                           exc_info=False)

        # The window of raw turns kept alongside the summary. Small on
        # purpose: the summary carries the thread, and the recent turns only
        # need to carry the last exchange.
        recent = self.compact_history(limit=2)

        return recent, result.summary.render_compact()

    def _summary_generator(self):
        """A bounded local generator for the one thing worth a model call."""
        def generate(prompt: str) -> str:
            return self.generate_local(prompt, TIER_FAST,
                                       purpose=Purpose.SUMMARIZATION.value)

        return generate

    def reasoning_provenance(self, response=None) -> Provenance:
        """
        How much a model's output is worth.

        Never LOCAL_VERIFIED, whatever the model claims about itself. Cloud
        output is marked separately from local so it is visible afterwards
        that a conclusion left this machine.
        """
        provider = getattr(response, "provider_id", "") if response else ""

        if provider and provider != "ollama-local":
            entry = self.gateway.registry.get(provider)

            if entry is not None and not entry.capabilities().local:
                return Provenance.CLOUD_REASONING

        return Provenance.MODEL_SUGGESTION

    def active_model(self) -> str:
        """Which reasoning engine is in use, for honest reporting."""
        chain = self.local_model_chain(TIER_DEFAULT)

        return chain[0] if chain else ""

    def begin_interaction(self) -> None:
        """
        Start a new interaction and reset the per-interaction budgets.

        One user message is one interaction. The budgets are what stop a
        single request from becoming a stream of proposals or subprocesses,
        so they reset here and nowhere else.
        """
        self._proposals_made = 0
        self._executions_made = 0
        self._patches_applied = 0
        self.last_tool_result = None

    def respond(self, message: str) -> str:
        """Respond and best-effort record actionable capability gaps."""
        ledger = None
        try:
            from app.capability_gap import CapabilityGapLedger, gap_for_result
            from app.capability_gap import is_gap_question, render_summary
            from app.version import VERSION
            from app.config import settings
            ledger = CapabilityGapLedger.from_memory_home(
                getattr(settings, "memory_home", ""),
                node_id=str(getattr(settings, "node_id", "local-node")),
                user_id=self.request_user_id or getattr(settings, "user_id", None),
                version=VERSION,
                install_mode=getattr(settings, "install_mode", None),
                source_commit=getattr(settings, "source_commit", None),
            )
            if ledger and is_gap_question(message):
                self.begin_interaction()
                answer = render_summary(ledger)
                self.last_routing_trace = None
                return answer
        except Exception:
            # Gap telemetry is optional and must never affect the answer.
            pass
        answer = self._respond_impl(message)
        try:
            from app.capability_gap import gap_for_result
            if ledger:
                gap_for_result(summary=message, trace=self.last_routing_trace,
                               result=self.last_tool_result, ledger=ledger,
                               channel=self.interface, response=answer)
        except Exception:
            pass
        return answer

    def _respond_impl(self, message: str) -> str:
        self.begin_interaction()
        intent_message = normalize_query_for_intent(message)
        capability = classify_capability(intent_message, settings.file_manager_allowed_roots)
        if capability is None and self.last_filesystem_result_set_id and re.search(
                r"\b(siguientes?|anteriores?|primero|segundo|tercero|cuarto|estos|esos|de\s+esos|contiene\s+el|sigue)\b|\bmu[eé]strame\s+el\s+resto\b",
                intent_message.casefold()):
            capability = self.last_filesystem_capability
        # A related filesystem turn inherits the last explicitly resolved
        # authorized scope. Public Web turns never use this state.
        explicit_scope = bool(re.search(r"\b(?:google\s+drive|drive|icloud|dropbox|onedrive|mis\s+(?:documentos?|archivos?|carpetas?))\b", intent_message.casefold()))
        active_context_used = False
        if (capability is not None and capability.capability == "FILESYSTEM_LOCAL"
                and self.active_filesystem_context is not None and not explicit_scope):
            active = self.active_filesystem_context
            current_user = self.request_user_id or str(getattr(settings, "user_id", "") or "") or None
            if active.user_id == current_user and active.node_id == str(settings.node_id) and active.session_id == self.session_id:
                scope = active
                capability = replace(capability, provider=scope.provider, root_id=scope.root_id,
                                     root_path=scope.root_path, root_paths=scope.root_paths,
                                     root_resolution_status=scope.root_resolution_status,
                                     available=True, root_selection_reason="ROOT_FROM_SESSION_CONTEXT")
                active_context_used = True
        elif (capability is not None and capability.capability == "FILESYSTEM_LOCAL"
              and self.filesystem_scope is not None and not explicit_scope):
            scope = self.filesystem_scope
            capability = replace(capability, provider=scope.provider, root_id=scope.root_id,
                                 root_path=scope.root_path, root_paths=scope.root_paths,
                                 root_resolution_status=scope.root_resolution_status,
                                 available=scope.available, root_selection_reason="ROOT_FROM_SESSION_CONTEXT")
        self.last_routing_trace = RoutingTrace(
            entrypoint=self.interface, message=message,
            routing_decision="FILESYSTEM_LOCAL" if capability else "UNRESOLVED",
            selected_capability=capability.capability if capability else "NONE",
            evidence_provider=capability.evidence_provider if capability else None,
            context_package="FILESYSTEM_LOCAL" if capability else None,
            stages=["Telegram" if self.interface == "telegram" else "Agent",
                    "routing decision"],
            provider_requested=capability.provider if capability else None,
            root_resolution_status=capability.root_resolution_status if capability else None,
            root_id=capability.root_id if capability else None,
            root_selection_reason=(capability.root_selection_reason if capability else None),
            snapshot_id=self.active_snapshot_id,
            snapshot_reused=bool(self.active_snapshot_id),
        )
        if capability is not None and message.count("?") + message.count("¿") > 2:
            # Decompose only clearly separable, bounded filesystem questions.
            # A malformed or mixed message remains explicit rather than being
            # silently collapsed into the first operation.
            parts = [part.strip() for part in re.split(r"\?(?=\s*(?:¿|[A-ZÁÉÍÓÚÑ]))", message) if part.strip()]
            parts = [part + ("?" if not part.endswith("?") else "") for part in parts]
            if len(parts) >= 4 and all(resolve_tool_for_message(part, "FILESYSTEM_LOCAL") for part in parts):
                previous_result = self.last_filesystem_result_set_id
                answers = []
                subquery_ids = []
                snapshot_context = ToolExecutionContext(
                    user_id=self.request_user_id or str(getattr(settings, "user_id", "") or "") or None,
                    node_id=str(settings.node_id), root_id=capability.root_id,
                    provider=capability.provider, session_id=self.session_id,
                    root_paths=tuple(capability.root_paths or ((capability.root_path,) if capability.root_path else ())))
                snapshot = default_registry.create_filesystem_snapshot(context=snapshot_context,
                                                                       provider=capability.provider)
                self.active_snapshot_id = snapshot.snapshot_id if snapshot else None
                shared_snapshot_id = self.active_snapshot_id
                self.last_routing_trace.snapshot_id = self.active_snapshot_id
                self.last_routing_trace.snapshot_reused = bool(snapshot)
                for part in parts[:8]:
                    self.last_filesystem_result_set_id = None
                    answers.append(self._respond_impl(part))
                    if self.last_routing_trace and self.last_routing_trace.tool_call_id:
                        subquery_ids.append(self.last_routing_trace.tool_call_id)
                self.last_routing_trace.filesystem_operation = "MULTI_INTENT_DECOMPOSED"
                self.last_routing_trace.filters = {"input_subquery_count": len(parts),
                                                   "executed_subquery_count": min(len(parts), 8)}
                self.last_routing_trace.subquery_ids = tuple(subquery_ids)
                self.last_routing_trace.snapshot_id = shared_snapshot_id
                self.last_routing_trace.snapshot_reused = bool(shared_snapshot_id)
                self.last_routing_trace.stages.append("bounded multi-intent decomposition")
                answer = "\n\n".join(f"{index}. {value}" for index, value in enumerate(answers, 1))
                self.last_routing_trace.final_response = answer
                if not self.last_filesystem_result_set_id:
                    self.last_filesystem_result_set_id = previous_result
                self.active_snapshot_id = None
                return answer
            self.last_routing_trace.filesystem_operation = "MULTI_INTENT_REQUIRES_DECOMPOSITION"
            self.last_routing_trace.stages.append("multi-intent guard")
            answer = "Recibí varias consultas filesystem. Envíalas por separado para mantener filtros, cobertura y resultados independientes."
            self.last_routing_trace.final_response = answer
            return answer

        # Installation instructions are versioned project knowledge, not a
        # model-memory answer and never require Web evidence.
        from app.installation_knowledge import is_installation_question, render as render_installation
        if is_installation_question(message):
            answer = render_installation()
            self.last_routing_trace.routing_decision = "INSTALLATION_KNOWLEDGE"
            self.last_routing_trace.selected_capability = "INSTALLATION"
            self.last_routing_trace.evidence_provider = "PROJECT_KNOWLEDGE"
            self.last_routing_trace.execution_path = "DETERMINISTIC"
            self.last_routing_trace.stages.extend(["installation knowledge", "final response"])
            self._post_response_memory_update(message, answer)
            return answer

        # Identity is answered from the local contract, not by hoping the
        # model remembers its instructions. It is the one question where
        # drift is both most likely and most visible.
        identity_answer = identity_module.answer(
            message, runtime="Ollama", model=self.active_model())

        if identity_answer is not None:
            self._post_response_memory_update(message, identity_answer)
            return identity_answer

        # Approval and denial come first: a bare "sí" must resolve the pending
        # change, not start a new piece of work.
        write_intent = detect_write_intent(message)

        if write_intent == WriteIntent.APPROVE.value:
            if permission_layer.pending(interface=self.interface):
                return self.apply_approved_patch()

            if permission_layer.pending_executions(interface=self.interface):
                return self.run_approved_execution()

        if write_intent == WriteIntent.DENY.value:
            if permission_layer.pending(interface=self.interface):
                return self.deny_pending_patch()

            if permission_layer.pending_executions(interface=self.interface):
                return self.deny_pending_execution()

        current_user = self.request_user_id or str(getattr(settings, "user_id", "") or "") or None
        attachment_id = self.request_attachment_id
        if attachment_id is None and current_user and self.last_attachment_by_user.get(str(current_user)) and re.search(
                r"\b(este\s+(?:archivo|pdf|documento)|documento\s+que\s+te\s+mand[eé]|xml\s+anterior|qu[eé]\s+(?:contiene|dice)|resume\s+este|total\s+de\s+esta\s+factura)\b",
                message.casefold()):
            attachment_id = self.last_attachment_by_user.get(str(current_user))
        self.request_attachment_id = None
        if attachment_id:
            user_id = current_user
            result = default_registry.execute(
                "attachment.content",
                context=ToolExecutionContext(user_id=user_id, node_id=str(settings.node_id), session_id=self.session_id),
                gateway=self.attachment_gateway, attachment_id=attachment_id,
            )
            self.last_routing_trace.selected_capability = "FILESYSTEM_LOCAL"
            self.last_routing_trace.routing_decision = "FILESYSTEM_LOCAL"
            self.last_routing_trace.evidence_provider = "FILESYSTEM"
            self.last_routing_trace.selected_tool = "attachment.content"
            self.last_routing_trace.tool_call_id = result.tool_call_id
            self.last_routing_trace.execution_path = "TOOL_ADAPTER"
            self.last_routing_trace.attachment_id = attachment_id
            self.last_routing_trace.attachment_source = "telegram"
            self.last_routing_trace.attachment_status = result.status
            self.last_routing_trace.attachment_tool = "attachment.content"
            self.last_routing_trace.attachment_evidence_ids = result.evidence_ids
            self.last_routing_trace.attachment_coverage = result.coverage
            self.last_routing_trace.evidence_ids = result.evidence_ids
            self.last_routing_trace.coverage = result.coverage
            self.last_routing_trace.tool_chain = ("attachment.content",)
            self.last_routing_trace.stages.extend(["attachment authorization", "FILE-3", "ContextPackage", "final response"])
            if result.status not in {"SUCCESS", "PARTIAL"}:
                answer = "No pude procesar el archivo adjunto: " + ", ".join(result.errors or (result.reason_code or "fallo desconocido",))
            else:
                content = result.payload.get("content", {})
                text = content.get("segments", [])
                excerpt = "\n".join(item.get("text", "") for item in text)[:2500]
                qualifier = " (extracción parcial)" if result.status == "PARTIAL" else ""
                answer = f"Contenido extraído{qualifier}:\n{excerpt or '(sin texto extraíble)'}"
            self.last_routing_trace.final_response = answer
            return answer

        decision = self.resolve_task(message)

        # Two equally plausible open tasks: ask instead of guessing.
        if decision is not None and decision.action == TaskAction.AMBIGUOUS.value:
            options = "\n".join(
                f"{i}. {task.get('goal', '')[:70]}"
                for i, task in enumerate(decision.candidates or [], start=1)
            )
            return (
                "Tengo varias tareas abiertas que encajan. ¿Cuál retomamos?\n" + options
            )

        # A direct request to run something needs no evidence gathering: the
        # user named the operation, so ask permission and run it.
        execution_intent = detect_execution_intent(message)

        if execution_intent:
            logger.info("Execution requested operation=%s", execution_intent)
            answer = self.request_execution(
                execution_intent,
                task_id=decision.task_id if decision else None,
            )
            self._post_response_memory_update(message, answer)
            return answer

        # Personal/local scope is a provider boundary. Resolve it before the
        # generic web heuristic; public web evidence can never prove access to
        # a user's files. The existing local planner/executor remains the one
        # filesystem path, so this does not create a second pipeline.
        if capability is not None:
            self.last_filesystem_capability = capability
            self.last_routing_trace.stages.extend(["selected capability", "evidence provider"])
            if not settings.enable_local_read_tools or not capability.available:
                answer = ("No existe un Google Drive/local filesystem configurado y autorizado "
                          "o accesible en este nodo.")
            else:
                tool_id = resolve_tool_for_message(message, capability.capability)
                lower_message = intent_message.casefold()
                referent_filter_turn = bool(self.last_filesystem_result_set_id and re.search(
                    r"\b(?:de\s+esos|de\s+estos|esos|estos)\b", lower_message))
                if not tool_id and referent_filter_turn:
                    tool_id = "filesystem.search"
                continuation_turn = bool(self.last_filesystem_result_set_id and re.search(
                    r"\b(?:siguientes?|los\s+siguientes|dame\s+los\s+siguientes|sigue)\b|\bmu[eé]strame\s+el\s+resto\b",
                    lower_message))
                if not tool_id and continuation_turn:
                    tool_id = "filesystem.list"
                if not tool_id:
                    answer = "La operación filesystem solicitada aún no está soportada de forma determinística."
                    self.last_routing_trace.filesystem_operation = "UNSUPPORTED"
                else:
                    explicit_limit = re.search(r"\b(?:lista|listar|dame|muestra|mu[ée]strame)\s+(?:los\s+|las\s+)?(\d+)\b", lower_message)
                    limit = max(1, min(int(explicit_limit.group(1)), 100)) if explicit_limit else 20
                    extension_match = re.search(r"(?:\.|\b)(pdf|xml|csv|json|docx|txt|md)\b", lower_message)
                    extension = extension_match.group(1) if extension_match else None
                    kind = ("file" if extension or re.search(r"\b(archivos?|pdfs?)\b", lower_message)
                            else "directory" if re.search(r"\b(carpetas?|directorios?)\b", lower_message)
                            else "both")
                    if tool_id == "filesystem.count" and kind == "both":
                        kind = "file"
                    if tool_id == "filesystem.list" and kind == "both" and re.search(r"ocupan|espacio|grande|peque", lower_message):
                        kind = "file"
                    ordering = ("modified_at ASC" if re.search(r"m[aá]s\s+antigu|oldest", lower_message)
                                else "modified_at DESC" if re.search(r"m[aá]s\s+(?:reciente|nuevo)|newest", lower_message)
                                else "size DESC" if re.search(r"m[aá]s\s+grande|largest|ocupan\s+m[aá]s", lower_message)
                                else "size ASC" if re.search(r"m[aá]s\s+peque|smallest", lower_message)
                                else "name ASC" if re.search(r"orden(?:a|ado).*nombre|alfab", lower_message)
                                else None)
                    aggregation = "SUM_SIZE" if re.search(r"espacio|ocupan|ocupa", lower_message) else "COUNT"
                    group_by = "EXTENSION" if re.search(r"tipos?|cada\s+tipo", lower_message) else None
                    if group_by and not re.search(r"cu[aá]ntos?|cantidad|cada\s+tipo", lower_message):
                        aggregation = "DISTINCT_TYPES"
                    if group_by and aggregation == "COUNT" and not ordering:
                        ordering = "count DESC"
                    if group_by and aggregation == "SUM_SIZE":
                        ordering = "total_size DESC"
                    size_match = re.search(r"(?:mayor(?:es)?\s+de|m[aá]s\s+de|greater\s+than)\s+(\d+(?:\.\d+)?)\s*(kb|mb|gb)", lower_message)
                    size_gt = None
                    if size_match:
                        size_gt = int(float(size_match.group(1)) * {"kb": 1024, "mb": 1024**2, "gb": 1024**3}[size_match.group(2)])
                    modified_after = parse_modified_after(lower_message)
                    exhaustive = bool(re.search(r"\b(todos?|todas?|all|everything)\b", lower_message))
                    recursive = bool(ordering or tool_id == "filesystem.search" or exhaustive)
                    user_id = self.request_user_id or str(getattr(settings, "user_id", "") or "") or None
                    execute_kwargs = {}
                    if tool_id == "filesystem.count":
                        execute_kwargs = {"kind": kind, "extension": extension, "ordering": ordering,
                                          "aggregation": aggregation, "group_by": group_by,
                                          "size_gt": size_gt, "modified_after": modified_after}
                    elif tool_id == "filesystem.list":
                        execute_kwargs = {"kind": kind, "limit": limit, "extension": extension, "recursive": recursive,
                                          "ordering": ordering, "exhaustive": exhaustive}
                    elif tool_id == "filesystem.search":
                        filename_match = re.search(r"\b([\w.-]+\.(?:xml|pdf|json|csv|txt|md|cpp|py))\b", lower_message)
                        execute_kwargs = {"filename": filename_match.group(1) if filename_match else None,
                                          "extension": extension, "is_file": kind == "file", "limit": limit,
                                          "ordering": ordering, "exhaustive": exhaustive,
                                          "size_gt": size_gt, "modified_after": modified_after}
                    elif tool_id == "filesystem.projects":
                        from app.file_analysis import ProjectQuery
                        execute_kwargs = {"query": ProjectQuery(contains_language="C++" if "c++" in lower_message or "cpp" in lower_message else None)}
                    context = ToolExecutionContext(user_id=user_id, node_id=str(settings.node_id),
                                                   root_id=capability.root_id,
                                                   provider=capability.provider,
                                                   session_id=self.session_id,
                                                   snapshot_id=self.active_snapshot_id,
                                                   root_paths=tuple(capability.root_paths or ((capability.root_path,) if capability.root_path else ())))
                    referent = None
                    if self.last_filesystem_result_set_id and re.search(
                            r"\b(?:primero|segundo|tercero|cuarto|este|ese|estos|esos|de\s+esos|de\s+estos)\b", lower_message):
                        referent = self.referents.resolve(
                            message, context=context,
                            preferred_result_set_id=self.last_filesystem_result_set_id)
                        if referent.status == "RESOLVED" and referent.records:
                            referenced = referent.records[0]
                            if tool_id == "filesystem.content":
                                content_match = None
                                execute_kwargs["path"] = referenced.relative_path
                            else:
                                execute_kwargs["name_contains"] = referenced.name
                        elif referent.status == "AMBIGUOUS":
                            result = None
                            answer = "El referente es ambiguo; indica qué resultado o archivo quieres usar."
                            self.last_routing_trace.filesystem_operation = "AMBIGUOUS_REFERENT"
                            self.last_routing_trace.coverage = "FAILED"
                            self.last_routing_trace.final_response = answer
                            return answer
                    content_match = re.search(r"\b([\w.-]+\.(?:xml|pdf|json|csv|txt|md|cpp|py))\b", lower_message)
                    if (referent is not None and referent.status == "RESULT_SET"
                            and referent.result_set_id
                            and re.search(r"\b(?:de\s+esos|de\s+estos|esos|estos)\b", lower_message)):
                        derived_ordering = ordering
                        result = default_registry.filter_result_set(
                            referent.result_set_id, context=context, extension=extension,
                            size_gt=size_gt, ordering=derived_ordering, limit=limit)
                        tool_id = "filesystem.search"
                    elif tool_id == "filesystem.content" and content_match:
                        result = default_registry.execute_content_chain(context=context, filename=content_match.group(1))
                    elif tool_id == "filesystem.content":
                        result = default_registry.execute(tool_id, context=context, path=execute_kwargs.get("path", ""))
                    elif (re.search(r"\b(?:siguientes?|los\s+siguientes|dame\s+los\s+siguientes|sigue)\b", lower_message)
                          or re.search(r"\bmu[eé]strame\s+el\s+resto\b", lower_message)) and self.last_filesystem_result_set_id:
                        result_data, continuation_reason = continue_result_set(
                            self.last_filesystem_result_set_id,
                            context=context if 'context' in locals() else ToolExecutionContext(user_id=user_id, node_id=str(settings.node_id)),
                            page_size=limit,
                        )
                        if result_data is None:
                            result = None
                            self.last_routing_trace.selected_tool = "filesystem.list"
                            self.last_routing_trace.execution_path = "TOOL_ADAPTER"
                            self.last_routing_trace.filesystem_operation = "FILE_SCAN_LIST"
                            self.last_routing_trace.coverage = "FAILED"
                            answer = f"No pude continuar el resultado filesystem: {continuation_reason}."
                        else:
                            result = None
                            self.last_routing_trace.selected_tool = "filesystem.list"
                            self.last_routing_trace.execution_path = "TOOL_ADAPTER"
                            self.last_routing_trace.coverage = result_data["coverage"]
                            self.last_routing_trace.evidence_ids = ()
                            self.last_routing_trace.filesystem_operation = "FILE_SCAN_LIST"
                            self.last_routing_trace.logical_result_set_id = result_data["result_set_id"]
                            self.last_routing_trace.displayed_result_set_id = result_data["result_set_id"]
                            self.last_routing_trace.continuation_target = result_data["result_set_id"]
                            names = [item.get("relative_path", "") for item in result_data["items"]]
                            answer = "Elementos siguientes:\n" + ("\n".join(f"- {name}" for name in names) or "(ninguno)") + "."
                            self.last_filesystem_result_set_id = result_data["result_set_id"]
                    else:
                        result = default_registry.execute(tool_id, context=context, **execute_kwargs)
                    if result is not None:
                        self.last_tool_result = result
                        # Establish/replace the active scope only from an
                        # explicit provider/root decision.  Related turns
                        # must never overwrite a Google Drive scope with the
                        # process default root.
                        if explicit_scope or self.active_filesystem_context is None:
                            self.filesystem_scope = capability
                            self.active_filesystem_context = ActiveFilesystemContext(
                                user_id=user_id, node_id=str(settings.node_id),
                                session_id=self.session_id, root_id=capability.root_id,
                                provider=capability.provider, root_path=capability.root_path,
                                root_paths=tuple(capability.root_paths),
                                root_resolution_status=capability.root_resolution_status)
                        self.last_routing_trace.selected_tool = tool_id
                        self.last_routing_trace.tool_call_id = result.tool_call_id
                        self.last_routing_trace.execution_path = "TOOL_ADAPTER"
                        self.last_routing_trace.identity = user_id
                        self.last_routing_trace.evidence_ids = result.evidence_ids
                        self.last_routing_trace.native_dispatch = "CONTRACT_ONLY_FOR_NOW"
                        self.last_routing_trace.tool_chain = tuple(result.payload.get("chain", (tool_id,)))
                        self.last_routing_trace.filesystem_operation = {
                        "filesystem.count": "FILE_SCAN_COUNT", "filesystem.list": "FILE_SCAN_LIST",
                        }.get(tool_id, tool_id.upper().replace(".", "_"))
                        self.last_routing_trace.coverage = result.coverage
                        self.last_routing_trace.filters = {"kind": kind, "extension": extension, "recursive": recursive,
                                                       "size_gt": size_gt, "modified_after": modified_after,
                                                       "aggregation": aggregation, "group_by": group_by,
                                                       "directories_only": kind == "directory",
                                                       "files_only": kind == "file"}
                        if result.payload.get("parent_result_set_id"):
                            self.last_routing_trace.filters["parent_result_set_id"] = result.payload["parent_result_set_id"]
                            self.last_routing_trace.root_selection_reason = "ROOT_FROM_RESULTSET"
                        self.last_routing_trace.limit = limit if tool_id in {"filesystem.list", "filesystem.search"} else None
                        self.last_routing_trace.stages.append("TOOL_ADAPTER")
                        self.last_filesystem_result_set_id = result.payload.get("result_set_id") or self.last_filesystem_result_set_id
                        if result.payload.get("result_set_id"):
                            self.last_routing_trace.logical_result_set_id = result.payload.get("result_set_id")
                            self.last_routing_trace.displayed_result_set_id = result.payload.get("result_set_id")
                            attach_result_set_evidence(result.payload["result_set_id"], result.evidence_ids)
                            self.referents.remember(result.payload["result_set_id"], context=context)
                        if result.payload.get("parent_result_set_id"):
                            self.last_routing_trace.parent_result_set_id = result.payload["parent_result_set_id"]
                            self.last_routing_trace.continuation_target = result.payload["parent_result_set_id"]
                    if result is not None and result.status in {"SUCCESS", "PARTIAL"}:
                        if tool_id == "filesystem.count":
                            qualifier = "" if result.coverage == "COMPLETE" else " (escaneo parcial)"
                            date_note = f" desde el {modified_after}" if modified_after else ""
                            if group_by:
                                all_groups = result.payload.get("groups", [])
                                shown_groups = all_groups[:12]
                                remainder = (f" Hay {len(all_groups) - len(shown_groups)} tipos más observados"
                                             if len(all_groups) > len(shown_groups) else "")
                                if aggregation == "DISTINCT_TYPES":
                                    names = ", ".join(item["key"] for item in shown_groups)
                                    answer = (f"En el escaneo{qualifier}, observé {len(all_groups)} tipos. "
                                              f"Entre los principales están: {names or '(ninguno)'}.{remainder}")
                                else:
                                    groups = ", ".join(f"{item['key']}: {item['value']}" for item in shown_groups)
                                    answer = (f"En el escaneo{qualifier}, observé por tipo: {groups or '(ninguno)'}{remainder}.")
                            elif aggregation == "SUM_SIZE":
                                total = result.payload.get('total_size', 0)
                                units = (("GiB", 1024**3), ("MiB", 1024**2), ("KiB", 1024))
                                human = next((f"{total / factor:.1f} {unit}" for unit, factor in units if total >= factor), f"{total} bytes")
                                answer = f"Los archivos observados ocupan {human} ({total} bytes){qualifier}{date_note}."
                            else:
                                label = "archivos" if kind == "file" else "carpetas" if kind == "directory" else "elementos"
                                if extension and kind == "file":
                                    label = f"archivos {extension.lstrip('.').upper()}"
                                observed = result.payload.get('matched_count_observed', 0)
                                if observed == 1:
                                    label = label[:-1] if label.endswith("s") else label
                                answer = f"Pude observar {observed} {label}{qualifier}{date_note}."
                        elif tool_id == "filesystem.list":
                            names = [item.get("relative_path", "") for item in result.payload.get("items", [])]
                            more = "" if result.payload.get("matched_count_observed", 0) <= len(names) else f"; hay al menos {result.payload.get('matched_count_observed')} observados"
                            qualifier = "" if result.coverage == "COMPLETE" else " (escaneo parcial)"
                            label = "Carpetas" if kind == "directory" else "Archivos" if kind == "file" else "Elementos"
                            if result.coverage != "COMPLETE":
                                label += " observadas" if kind == "directory" else " observados"
                            suffix = " Te muestro una página acotada." if exhaustive and result.payload.get("next_offset") is not None else ""
                            ordering_note = " Las ordené por fecha de última modificación, de más antigua a más reciente." if ordering == "modified_at ASC" else "" if not ordering else f" Orden: {ordering}."
                            answer = f"{label}{qualifier}:\n" + ("\n".join(f"- {name}" for name in names) or "(ninguno)") + f"{more}.{ordering_note}{suffix}"
                        elif tool_id == "filesystem.search":
                            names = [item.get("relative_path", "") for item in result.payload.get("items", [])]
                            answer = "Coincidencias:\n" + ("\n".join(f"- {name}" for name in names) or "(ninguna)") + "."
                        elif tool_id == "filesystem.projects":
                            projects = result.payload.get("projects", [])
                            answer = "Proyectos observados: " + str(len(projects)) + "."
                        elif tool_id == "filesystem.content":
                            content = result.payload.get("content", [])
                            entries = content if isinstance(content, list) else [content]
                            segments = [segment for entry in entries
                                        for segment in (entry.get("segments", []) if isinstance(entry, dict) else [])]
                            excerpt = "\n".join(item.get("text", "") for item in segments)[:2500]
                            if not excerpt:
                                excerpt = "\n".join(str(entry.get("content", "")) for entry in entries
                                                    if isinstance(entry, dict) and entry.get("content"))[:2500]
                            state = result.payload.get("content_state")
                            if state == "NO_EXTRACTABLE_TEXT":
                                answer = "Identifiqué el archivo, pero no pude extraer texto verificable."
                            elif state == "EMPTY":
                                answer = "El archivo está vacío y no contiene texto extraíble."
                            elif state == "ENCRYPTED":
                                answer = "El archivo parece requerir una contraseña o no permite extracción."
                            elif state == "TOO_LARGE":
                                answer = "Encontré el archivo, pero supera el límite local de extracción configurado."
                            elif state == "UNSUPPORTED_FORMAT":
                                answer = "El formato está identificado, pero este extractor todavía no lo soporta."
                            elif result.reason_code == "EXTRACTION_FAILED":
                                answer = "Encontré el archivo, pero la extracción falló."
                            elif result.coverage == "PARTIAL" and excerpt:
                                answer = ("Pude extraer parcialmente el documento. "
                                          "Contenido verificable disponible:\n" +
                                          excerpt +
                                          "\nLa extracción no cubre todo el archivo.")
                            elif result.coverage == "PARTIAL":
                                answer = "Identifiqué el archivo, pero no pude extraer texto verificable."
                            else:
                                answer = "Contenido extraído:\n" + (excerpt or "(sin texto extraíble)")
                        else:
                            answer = "La operación local terminó correctamente con evidencia autorizada."
                    elif result is not None:
                        if tool_id == "filesystem.content":
                            state = result.payload.get("content_state")
                            messages = {
                                "NO_EXTRACTABLE_TEXT": "Identifiqué el archivo, pero no pude extraer texto verificable.",
                                "EMPTY": "El archivo está vacío y no contiene texto extraíble.",
                                "ENCRYPTED": "El archivo parece requerir una contraseña o no permite extracción.",
                                "TOO_LARGE": "Encontré el archivo, pero supera el límite local de extracción configurado.",
                                "UNSUPPORTED_FORMAT": "El formato está identificado, pero este extractor todavía no lo soporta.",
                            }
                            answer = messages.get(state, "Encontré el archivo, pero la extracción falló.")
                        else:
                            answer = "No pude ejecutar la operación filesystem autorizada: " + ", ".join(result.errors or ("fallo desconocido",))
            self.last_routing_trace.stages.extend(["ContextPackage", "final response"])
            self.last_routing_trace.final_response = answer
            return answer

        local_needed, local_reason = needs_local_read(message)

        # A local capability question without a concrete path should be
        # answered from the runtime contract, rather than denied by the LLM.
        # No filesystem access happens until the user supplies a safe path.
        if self.interface == "cli" and local_planner.looks_like_local_read_intent(message) and not local_needed:
            if not settings.enable_local_read_tools:
                answer = "La inspección de archivos está desactivada en este nodo."
            else:
                answer = (
                    "Sí. Puedo inspeccionar archivos y carpetas dentro de las ubicaciones "
                    "permitidas para este nodo. ¿Qué carpeta quieres revisar?"
                )
            self._post_response_memory_update(message, answer)
            return answer

        if local_needed:
            logger.info("Local read triggered reason=%s", local_reason)

            # A task with a goal deserves a plan; a one-off lookup does not.
            if decision is not None and decision.task_id:
                try:
                    outcome = self.run_agent_loop(message, decision)
                except Exception:
                    logger.exception("Agent loop failed; falling back to a single read")
                    outcome = None

                if outcome is not None:
                    report, plan = outcome
                    answer = self._narrate(message, report, decision)

                    # The distinction that matters: "¿por qué falla?" wants an
                    # explanation, "arréglalo" wants a change. Only the second
                    # turns the analysis into a proposal, and only after the
                    # evidence has actually been read.
                    if write_intent in (WriteIntent.APPLY.value,
                                        WriteIntent.PROPOSE.value):
                        answer = self._offer_patch(message, answer, report, decision)

                    self._post_response_memory_update(message, answer)
                    return answer

            local_answer = self.answer_with_local_read(message)

            if local_answer is not None:
                self._post_response_memory_update(message, local_answer)
                return local_answer

        web_needed, web_reason = needs_web_search(message)

        if web_needed:
            logger.info("Web research triggered reason=%s", web_reason)
            web_answer = self.answer_with_web(message)

            if self.last_routing_trace:
                self.last_routing_trace.routing_decision = "WEB"
                self.last_routing_trace.selected_capability = "PUBLIC_WEB"
                self.last_routing_trace.evidence_provider = "WEB"
                self.last_routing_trace.web_search_calls = self.last_web_search_calls
                self.last_routing_trace.web_evidence_records = 1 if web_answer else 0
                self.last_routing_trace.web_recovery_used = self.last_web_recovery_used
                self.last_routing_trace.web_failure_reason = self.last_web_failure_reason
                self.last_routing_trace.stages.extend(["selected capability", "evidence provider",
                                                       "ContextPackage", "final response"])

            if web_answer is not None:
                self._post_response_memory_update(message, web_answer)
                return web_answer

        try:
            delegate, _ = should_delegate_to_worker(message)
            worker_prompt = self.build_task_prompt(message, decision) if delegate else None
            handled, routed_response = auto_route_message(message, worker_prompt=worker_prompt)
            if handled:
                self._post_response_memory_update(message, routed_response)
                return routed_response
        except Exception:
            logger.exception("Auto-router failed; falling back to local model")

        tier, tier_reason = select_model_tier(message)

        logger.info(
            "Generating locally tier=%s reason=%s chain=%s",
            tier, tier_reason, self.local_model_chain(tier),
        )

        prompt = self.build_task_prompt(message, decision)

        try:
            response = self.generate_local(prompt, tier)
        except OllamaUnavailableError:
            logger.exception("Local engine unreachable")
            return self.ENGINE_DOWN_MESSAGE
        except OllamaError:
            logger.exception("Every local model failed")
            return (
                "El motor local respondió con error en todos los modelos configurados. "
                "Revisa con /health y con: ollama list"
            )
        except Exception:
            logger.exception("Unexpected local generation failure")
            return self.ENGINE_DOWN_MESSAGE

        self._post_response_memory_update(message, response)
        return response
