"""
The Ollama adapter: the current engine, behind the new contract.

This deliberately changes nothing about how Ollama is called. Same client,
same timeouts, same retries, same model names, same tier configuration. The
adapter translates between OllamaClient and the ReasoningProvider contract and
does nothing else, so the answer a user gets today is the answer they got
before the gateway existed.

It imports the Ollama client and the reasoning contracts, and nothing else
from the application. That is enforced by a test: an adapter that could reach
permissions, the Memory Core or an executor would be a way around every
boundary the previous phases established.
"""

from __future__ import annotations

import time

from app.config import settings
from app.reasoning import (
    ProviderCapabilities,
    ProviderStatus,
    ProviderType,
    ReasoningProvider,
    ReasoningRequest,
    ReasoningResponse,
    ResponseStatus,
    estimate_tokens,
)
from models.ollama_client import OllamaClient, OllamaError, OllamaUnavailableError


class OllamaProvider(ReasoningProvider):
    """Local reasoning through Ollama. No network beyond the local engine."""

    provider_type = ProviderType.OLLAMA.value

    def __init__(self, client: OllamaClient | None = None,
                 provider_id: str = "ollama-local",
                 account_ref: str = "local",
                 client_factory=None):
        # Resolved per call rather than captured, so an owner that swaps its
        # client — a test, or a future reconfiguration — is actually honoured
        # instead of being silently bypassed by a stale reference.
        self._client_factory = client_factory
        self._client = client
        self.provider_id = provider_id
        # No credential exists for a local engine, and account_ref is a label
        # rather than a secret in any case.
        self.account_ref = account_ref
        self._active = False

    @property
    def client(self) -> OllamaClient:
        if self._client_factory is not None:
            return self._client_factory()

        if self._client is None:
            self._client = OllamaClient()

        return self._client

    def models(self) -> list[str]:
        """
        Configured models, not merely installed ones.

        Tiers are how model names enter this system; asking the engine what it
        has would answer a different question.
        """
        names: list[str] = []

        for tier in ("fast", "default", "heavy"):
            model = settings.model_for_tier(tier)

            if model and model not in names:
                names.append(model)

        return names

    def health(self) -> str:
        try:
            healthy = self.client.health()
        except Exception:
            return ProviderStatus.UNAVAILABLE.value

        if not healthy:
            return ProviderStatus.UNAVAILABLE.value

        return (ProviderStatus.ACTIVE.value if self._active
                else ProviderStatus.AVAILABLE.value)

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_chars=settings.context_total_max_chars,
            # Ollama has a JSON mode, but this adapter does not use it: patch
            # generation already parses and validates the text itself, and
            # claiming structured output it does not request would be a lie
            # the router could act on.
            structured_output=False,
            supports_system_prompt=True,
            supports_streaming=False,
            local=True,
            network_required=False,
            cost_class="free",
        )

    def generate(self, request: ReasoningRequest, model: str) -> ReasoningResponse:
        """
        One call to one model.

        Model degradation across tiers belongs to the router, which owns the
        fallback order; this asks exactly one engine exactly once and reports
        what happened.
        """
        started = time.monotonic()
        self._active = True

        response = ReasoningResponse(
            request_id=request.request_id,
            provider_id=self.provider_id,
            account_ref=self.account_ref,
            model_id=model,
            input_tokens_estimated=request.estimated_input_tokens(),
            # Local compute costs time and electricity, not tokens.
            cost_estimated=0.0,
        )

        try:
            text = self.client.generate(request.prompt, model=model)
        except OllamaUnavailableError as exc:
            response.status = ResponseStatus.UNAVAILABLE.value
            response.error = str(exc)
        except OllamaError as exc:
            response.status = ResponseStatus.FAILED.value
            response.error = str(exc)
        except Exception as exc:
            response.status = ResponseStatus.FAILED.value
            response.error = f"{type(exc).__name__}: {exc}"
        else:
            response.content = text
            response.output_tokens_estimated = estimate_tokens(text)
        finally:
            self._active = False
            response.latency_ms = int((time.monotonic() - started) * 1000)

        return response
