"""Legacy signatures over MemoryCore; no independent files or state."""
from datetime import datetime

from app.config import settings
from app.memory_core import MemoryCore


class MemoryStore:
    def __init__(self, core=None):
        # A callable lets an agent replace its Core without a stale adapter.
        self._core = core if core is not None else MemoryCore()

    @property
    def core(self):
        return self._core() if callable(self._core) else self._core

    def read_profile(self):
        return self.core.get_profile()

    def read_projects(self):
        return {"projects": self.core.list_projects()}

    def read_preferences(self):
        return {"preferences": self.core.get_profile().get("preferences", {})}

    def add_note(self, text, source="telegram"):
        return self.core.append_note({"timestamp": datetime.now().isoformat(timespec="seconds"),
                                      "source": source, "text": text.strip()})

    def read_recent_notes(self, limit=5):
        return self.core.notes(limit)

    def add_conversation_turn(self, user_id, user_message, assistant_response,
                              source="telegram", principal_id="", interface="",
                              session_id="", project_id=""):
        turn = {"timestamp": datetime.now().isoformat(timespec="seconds"),
                "source": source, "user_id": user_id,
                "user_message": user_message.strip(),
                "assistant_response": assistant_response.strip()}
        for key, value in (("principal_id", principal_id), ("interface", interface),
                           ("session_id", session_id), ("project_id", project_id)):
            if value:
                turn[key] = str(value)
        return self.core.append_conversation_event(turn)

    def read_recent_conversations(self, limit=5, principal_id=""):
        return self.core.conversation_history(limit=limit, principal_id=principal_id)

    def forget_last_conversation(self):
        return self.core.forget_last_conversation()

    def summary(self) -> str:
        profile = self.read_profile()
        projects = self.read_projects()
        preferences = self.read_preferences()
        notes = self.read_recent_notes(limit=5)
        conversations = self.read_recent_conversations(limit=3)

        project_names = list(projects.get("projects", {}).keys())

        lines = [
            f"Agente: {profile.get('agent_name', settings.agent_name)}",
            f"Framework: {profile.get('framework', 'OpenClaw')}",
            f"Owner: {profile.get('owner', 'Luis')}",
            f"Propósito: {profile.get('purpose', 'No definido')}",
            "",
            "Proyectos:",
        ]

        if project_names:
            for name in project_names:
                project = projects["projects"][name]
                lines.append(f"- {project.get('name', name)}: {project.get('status', 'sin estado')}")
        else:
            lines.append("- Sin proyectos registrados")

        lines.append("")
        lines.append("Preferencias:")

        prefs = preferences.get("preferences", {})
        if prefs:
            for key, value in prefs.items():
                lines.append(f"- {key}: {value}")
        else:
            lines.append("- Sin preferencias registradas")

        lines.append("")
        lines.append("Notas explícitas recientes:")

        if notes:
            for note in notes:
                lines.append(f"- {note.get('timestamp')}: {note.get('text')}")
        else:
            lines.append("- Sin notas recientes")

        lines.append("")
        lines.append("Conversaciones recientes:")

        if conversations:
            for turn in conversations:
                user_message = turn.get("user_message", "")
                assistant_response = turn.get("assistant_response", "")
                lines.append(f"- Usuario: {user_message[:180]}")
                lines.append(f"  iclirius: {assistant_response[:180]}")
        else:
            lines.append("- Sin conversaciones recientes")

        return "\n".join(lines)

    def history_text(self, limit: int = 5, principal_id: str = "") -> str:
        conversations = self.read_recent_conversations(
            limit=limit, principal_id=principal_id)

        if not conversations:
            return "No hay historial de conversaciones todavía."

        lines = ["Historial reciente:"]

        for turn in conversations:
            lines.append("")
            lines.append(f"Fecha: {turn.get('timestamp')}")
            lines.append(f"Usuario: {turn.get('user_message')}")
            lines.append(f"iclirius: {turn.get('assistant_response')}")

        return "\n".join(lines)
