"""Small, fail-closed boundary around macOS LocalAuthentication.

The Python process never receives biometric material.  A tiny Swift helper
returns one of the documented operational states and nothing else.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import tempfile
from enum import Enum
from pathlib import Path


class TouchIDStatus(str, Enum):
    AVAILABLE = "available"
    SUCCESS = "success"
    UNAVAILABLE = "unavailable"
    NOT_ENROLLED = "not_enrolled"
    LOCKED_OUT = "locked_out"
    CANCELLED = "cancelled"
    FAILED = "failed"
    SYSTEM_ERROR = "system_error"


_ROOT = Path(__file__).resolve().parents[1]
_SOURCE = Path(__file__).resolve().parent / "native" / "iclirius_touchid.swift"
if not _SOURCE.exists():
    _SOURCE = _ROOT / "native" / "iclirius_touchid.swift"


def helper_path() -> Path:
    return Path(os.getenv("ICLIRIUS_TOUCH_ID_HELPER", "~/.iclirius/bin/iclirius-touchid")).expanduser()


def ensure_helper() -> Path | None:
    """Compile the tiny helper once, without shell evaluation or user data."""
    if platform.system() != "Darwin" or not _SOURCE.exists():
        return None
    target = helper_path()
    if target.is_file() and os.access(target, os.X_OK):
        return target
    swiftc = shutil.which("swiftc")
    if not swiftc:
        return None
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(prefix="iclirius-touchid-", dir=str(target.parent))
    os.close(fd)
    temp = Path(temporary)
    try:
        result = subprocess.run(
            [swiftc, "-framework", "LocalAuthentication", str(_SOURCE), "-o", str(temp)],
            capture_output=True, text=True, timeout=30, check=False,
        )
        if result.returncode != 0:
            return None
        os.chmod(temp, 0o700)
        os.replace(temp, target)
        return target
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def _run(mode: str, *, compile_if_missing: bool = False) -> TouchIDStatus:
    helper = helper_path()
    if compile_if_missing and not helper.is_file():
        helper = ensure_helper() or helper
    if platform.system() != "Darwin" or not helper.is_file():
        return TouchIDStatus.UNAVAILABLE
    try:
        result = subprocess.run([str(helper), mode], capture_output=True, text=True,
                                timeout=65, check=False)
    except (OSError, subprocess.SubprocessError):
        return TouchIDStatus.SYSTEM_ERROR
    value = (result.stdout or "").strip().lower()
    try:
        return TouchIDStatus(value)
    except ValueError:
        return TouchIDStatus.SYSTEM_ERROR


def availability(*, compile_if_missing: bool = False) -> TouchIDStatus:
    return _run("availability", compile_if_missing=compile_if_missing)


def authenticate(*, compile_if_missing: bool = False) -> TouchIDStatus:
    return _run("authenticate", compile_if_missing=compile_if_missing)
