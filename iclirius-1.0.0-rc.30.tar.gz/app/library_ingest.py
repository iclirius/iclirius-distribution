from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from app.config import settings

from app.file_catalog import validate_safe_path


LIBRARY_DIR = Path(settings.state_path) / "library"
SOURCES_PATH = LIBRARY_DIR / "sources" / "sources.jsonl"
DIGEST_DIR = LIBRARY_DIR / "digests"
CHUNKS_DIR = LIBRARY_DIR / "chunks"

SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf", ".epub"}


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _source_id(path: Path) -> str:
    digest = hashlib.sha256(str(path).encode("utf-8")).hexdigest()[:12]
    return f"src_{digest}"


def _doc_id(path: Path) -> str:
    stat = path.stat()
    raw = f"{path}:{stat.st_size}:{stat.st_mtime}"
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return f"doc_{digest}"


def _read_text_file(path: Path) -> str:
    return path.read_text(errors="ignore")


def _read_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except Exception as exc:
        raise RuntimeError("Falta instalar pypdf. Ejecuta: pip install pypdf") from exc

    reader = PdfReader(str(path))
    pages = []

    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            continue

    return "\n\n".join(pages)


def _read_epub(path: Path) -> str:
    try:
        from ebooklib import epub
        from bs4 import BeautifulSoup
    except Exception as exc:
        raise RuntimeError("Falta instalar ebooklib y beautifulsoup4. Ejecuta: pip install ebooklib beautifulsoup4") from exc

    book = epub.read_epub(str(path))
    parts = []

    for item in book.get_items():
        try:
            content = item.get_content()
            soup = BeautifulSoup(content, "html.parser")
            text = soup.get_text(" ", strip=True)
            if text:
                parts.append(text)
        except Exception:
            continue

    return "\n\n".join(parts)


def extract_text(path: Path) -> str:
    ext = path.suffix.lower()

    if ext in {".txt", ".md"}:
        return _read_text_file(path)

    if ext == ".pdf":
        return _read_pdf(path)

    if ext == ".epub":
        return _read_epub(path)

    return ""


def chunk_text(text: str, chunk_size: int = 2500, overlap: int = 300) -> list[str]:
    text = " ".join(text.split())

    if not text:
        return []

    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])

        if end >= len(text):
            break

        start = max(0, end - overlap)

    return chunks


def _append_source(source: dict) -> None:
    SOURCES_PATH.parent.mkdir(parents=True, exist_ok=True)
    existing = SOURCES_PATH.read_text().splitlines() if SOURCES_PATH.exists() else []
    existing_ids = set()

    for line in existing:
        try:
            existing_ids.add(json.loads(line).get("id"))
        except Exception:
            continue

    if source["id"] in existing_ids:
        return

    with SOURCES_PATH.open("a") as f:
        f.write(json.dumps(source, ensure_ascii=False) + "\n")


def learn_folder(root_path: str, max_files: int = 200) -> dict:
    root = validate_safe_path(root_path)

    if not root.exists():
        raise FileNotFoundError(f"No existe la ruta: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"No es carpeta: {root}")

    sid = _source_id(root)

    source = {
        "id": sid,
        "path": str(root),
        "type": "folder",
        "mode": "read_only",
        "created_at": _now(),
    }

    _append_source(source)

    DIGEST_DIR.mkdir(parents=True, exist_ok=True)
    CHUNKS_DIR.mkdir(parents=True, exist_ok=True)

    docs = []
    skipped = []
    files_seen = 0

    for path in root.rglob("*"):
        try:
            path = validate_safe_path(path)

            if not path.is_file():
                continue

            if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            files_seen += 1

            if files_seen > max_files:
                skipped.append({"path": str(path), "reason": "max_files limit reached"})
                break

            text = extract_text(path)

            if not text.strip():
                skipped.append({"path": str(path), "reason": "no text extracted"})
                continue

            did = _doc_id(path)
            chunks = chunk_text(text)

            chunk_path = CHUNKS_DIR / f"{did}.jsonl"
            with chunk_path.open("w") as f:
                for index, chunk in enumerate(chunks):
                    row = {
                        "doc_id": did,
                        "source_id": sid,
                        "chunk_id": f"{did}_{index}",
                        "path": str(path),
                        "name": path.name,
                        "index": index,
                        "text": chunk,
                    }
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")

            preview = text[:2500].replace("\n", " ").strip()

            docs.append({
                "doc_id": did,
                "path": str(path),
                "name": path.name,
                "extension": path.suffix.lower(),
                "size": path.stat().st_size,
                "chunks": len(chunks),
                "preview": preview[:1000],
            })

        except Exception as exc:
            skipped.append({"path": str(path), "reason": str(exc)})

    digest_path = DIGEST_DIR / f"{sid}.md"
    lines = [
        f"# Digest de fuente {sid}",
        "",
        f"Ruta original: {root}",
        f"Fecha: {_now()}",
        f"Documentos procesados: {len(docs)}",
        f"Omitidos: {len(skipped)}",
        "",
        "## Documentos",
    ]

    for doc in docs:
        lines.append(f"\n### {doc['name']}")
        lines.append(f"- Ruta: {doc['path']}")
        lines.append(f"- Chunks: {doc['chunks']}")
        lines.append(f"- Vista previa: {doc['preview'][:500]}")

    digest_path.write_text("\n".join(lines))

    return {
        "source_id": sid,
        "root": str(root),
        "processed": len(docs),
        "skipped": len(skipped),
        "digest_path": str(digest_path),
        "documents": docs[:20],
    }


def learn_folder_text(root_path: str) -> str:
    result = learn_folder(root_path)

    lines = [
        "Ingesta completada.",
        f"Source ID: {result['source_id']}",
        f"Ruta original: {result['root']}",
        f"Documentos procesados: {result['processed']}",
        f"Omitidos: {result['skipped']}",
        f"Digest: {result['digest_path']}",
        "",
        "Primeros documentos:",
    ]

    for doc in result["documents"][:10]:
        lines.append(f"- {doc['name']} | chunks={doc['chunks']}")

    return "\n".join(lines)[:3900]


def library_status_text() -> str:
    sources = []

    if SOURCES_PATH.exists():
        for line in SOURCES_PATH.read_text().splitlines():
            try:
                sources.append(json.loads(line))
            except Exception:
                continue

    chunk_files = list(CHUNKS_DIR.glob("doc_*.jsonl")) if CHUNKS_DIR.exists() else []
    digest_files = list(DIGEST_DIR.glob("src_*.md")) if DIGEST_DIR.exists() else []

    return (
        "Estado de biblioteca:\n"
        f"- Fuentes: {len(sources)}\n"
        f"- Documentos con chunks: {len(chunk_files)}\n"
        f"- Digests: {len(digest_files)}"
    )


def ask_library_text(query: str, limit: int = 5) -> str:
    query = query.strip().lower()

    if not query:
        return "Uso: /ask_library pregunta"

    if not CHUNKS_DIR.exists():
        return "La biblioteca está vacía. Usa /learn_folder ruta primero."

    terms = [term for term in query.split() if len(term) > 2]
    matches = []

    for chunk_file in CHUNKS_DIR.glob("doc_*.jsonl"):
        for line in chunk_file.read_text().splitlines():
            try:
                row = json.loads(line)
            except Exception:
                continue

            text = row.get("text", "")
            lower = text.lower()
            score = sum(1 for term in terms if term in lower)

            if score:
                matches.append((score, row))

    matches.sort(key=lambda item: item[0], reverse=True)

    if not matches:
        return f"No encontré contenido relacionado con: {query}"

    lines = [f"Resultados de biblioteca para: {query}", ""]

    for score, row in matches[:limit]:
        snippet = row.get("text", "")[:700]
        lines.append(f"Documento: {row.get('name')}")
        lines.append(f"Ruta: {row.get('path')}")
        lines.append(f"Coincidencia: {score}")
        lines.append(f"Fragmento: {snippet}")
        lines.append("")

    return "\n".join(lines)[:3900]
