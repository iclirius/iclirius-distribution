"""Small Textual authentication screen; it never constructs the agent."""

from __future__ import annotations

from typing import Callable

from app.local_auth import AuthSession, verify_recovery
from app.touch_id import TouchIDStatus, authenticate as touch_authenticate

try:
    from textual.app import App, ComposeResult
    from textual.containers import Center, Middle, Vertical
    from textual.widgets import Button, Footer, Input, Label, Static
    _AVAILABLE = True
except ImportError:  # pragma: no cover
    _AVAILABLE = False


if _AVAILABLE:
    class AuthGateApp(App[None]):
        CSS = """
        Screen { align: center middle; background: $surface; }
        #card { width: 60; height: auto; padding: 2 4; border: round $accent; }
        #brand { color: $accent; text-style: bold; content-align: center middle; }
        #identity { color: $text-muted; content-align: center middle; margin: 1 0; }
        #status { content-align: center middle; height: 2; }
        #password, #unlock { display: none; margin-top: 1; }
        #hint { color: $text-muted; content-align: center middle; margin-top: 1; }
        """

        def __init__(self, identity: str, user_id: str, *,
                     touch_fn: Callable[[], TouchIDStatus] | None = None) -> None:
            super().__init__()
            self.identity = identity
            self.user_id = user_id
            self.touch_fn = touch_fn or (lambda: touch_authenticate(compile_if_missing=True))
            self.authenticated = False
            self.method = ""

        def compose(self) -> ComposeResult:
            yield Center(Middle(Vertical(
                Label("ICLIRIUS", id="brand"),
                Label(self.identity or "Configured user", id="identity"),
                Label("Authenticate to continue", id="status"),
                Button("Use Touch ID", id="touch"),
                Input(placeholder="Recovery password", password=True, id="password"),
                Button("Unlock", id="unlock"),
                Label("Authentication is required for each process.", id="hint"),
                id="card",
            )))
            yield Footer()

        def on_mount(self) -> None:
            self.query_one("#touch", Button).focus()
            self._emit("AUTH_TOUCH_ID_REQUESTED", "started")
            self.run_worker(self._touch, thread=True, exclusive=True, name="touch-id")

        def _touch(self) -> TouchIDStatus:
            return self.touch_fn()

        def on_worker_state_changed(self, event) -> None:
            if getattr(event.worker, "name", "") != "touch-id" or not event.worker.is_finished:
                return
            try:
                result = event.worker.result
            except Exception:
                result = TouchIDStatus.SYSTEM_ERROR
            if result == TouchIDStatus.SUCCESS:
                self._success("touch_id")
                return
            self._emit("AUTH_FALLBACK_USED", "started", {"method": "recovery_password"})
            self.query_one("#status", Label).update(
                "Touch ID unavailable. Enter your recovery password."
            )
            self.query_one("#password").display = True
            self.query_one("#unlock").display = True
            self.query_one("#password", Input).focus()

        def on_button_pressed(self, event: Button.Pressed) -> None:
            if event.button.id == "touch":
                self.run_worker(self._touch, thread=True, exclusive=True, name="touch-id")
            elif event.button.id == "unlock":
                self._unlock()

        def on_input_submitted(self, event: Input.Submitted) -> None:
            if event.input.id == "password":
                self._unlock()

        def _unlock(self) -> None:
            value = self.query_one("#password", Input).value
            ok, reason = verify_recovery(value)
            self.query_one("#password", Input).value = ""
            if ok:
                self._success("recovery_password")
            else:
                self._emit("AUTH_FAILED", "failed", {"method": "recovery_password", "reason": reason})
                self.query_one("#status", Label).update(
                    "Try again." if reason != "rate_limited" else "Too many attempts. Try again shortly."
                )

        def _success(self, method: str) -> None:
            self.authenticated = True
            self.method = method
            self._emit("AUTH_SUCCESS", "ok", {"method": method})
            self.exit()

        @staticmethod
        def _emit(event_type: str, status: str, metadata: dict | None = None) -> None:
            try:
                from app.runtime_events import emit
                emit(event_type, status=status, interface="cli", metadata=metadata or {})
            except Exception:
                pass


def run_auth_gate(identity: str, user_id: str, *,
                  touch_fn: Callable[[], TouchIDStatus] | None = None) -> AuthSession | None:
    if not _AVAILABLE:
        return None
    app = AuthGateApp(identity, user_id, touch_fn=touch_fn)
    app.run()
    if not app.authenticated:
        return None
    return AuthSession(user_id, identity, app.method)
