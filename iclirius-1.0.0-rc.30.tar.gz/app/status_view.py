"""
One state, two presentations.

The terminal and Telegram show the same thing at different densities, and the
only way to keep that true over time is to give them a single source. So both
read a RuntimeSnapshot, both go through the same semantic layer, and neither
is allowed its own idea of what is happening.

    RuntimeSnapshot
          │
      StatusView          <- semantics: what is true right now
     ╱          ╲
render_terminal  render_telegram   <- presentation only

What the renderers must never do is reconstruct state: no reading logs, no
inspecting processes, no querying the Memory Core, no caching a copy. If
something is not in the snapshot, it is not shown. That is a feature — the
snapshot is already the thing that has been audited for what it may carry.

Rendering is text. It carries no prompts, no file contents, no memory, no
program output and no credentials, because the snapshot carries none of those.
Paths are reduced to names before display, since a full path leaks a home
directory and a person's name with it.
"""

from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

MIN_WIDTH = 32
DEFAULT_WIDTH = 72
MAX_WIDTH = 100

# Degrades to ASCII when the terminal cannot be trusted with anything else.
GLYPHS = {
    "rich": {"node": "▱", "dot": "●", "ok": "✓", "fail": "✗", "wait": "◍",
             "run": "◐", "bar": "─", "pipe": "│", "sep": "·"},
    "plain": {"node": "[]", "dot": "*", "ok": "ok", "fail": "x", "wait": "?",
              "run": ">", "bar": "-", "pipe": "|", "sep": "-"},
}

# Event types worth showing as a line of activity, and the verb to show.
ACTIVITY_VERBS = {
    "TOOL_COMPLETED": "READ", "TOOL_FAILED": "READ", "TOOL_STARTED": "READ",
    "WEB_SEARCH": "WEB",
    "PATCH_GENERATED": "PATCH", "PATCH_PROPOSED": "PATCH",
    "PATCH_VALIDATED": "PATCH", "PATCH_REJECTED": "PATCH",
    "PATCH_GENERATION_FAILED": "PATCH", "GROUNDING_REFUSED": "PATCH",
    "WRITE_COMPLETED": "WRITE", "WRITE_FAILED": "WRITE",
    "WRITE_APPROVAL_REQUIRED": "WRITE", "WRITE_DENIED": "WRITE",
    "EXECUTION_COMPLETED": "TEST", "EXECUTION_FAILED": "TEST",
    "EXECUTION_STARTED": "TEST", "EXECUTION_TIMEOUT": "TEST",
    "EXECUTION_APPROVAL_REQUIRED": "TEST",
    "VERIFICATION_PASSED": "VERIFY", "VERIFICATION_FAILED": "VERIFY",
    "DIFF_VERIFIED": "VERIFY",
    "COMPACTION_COMPLETED": "COMPACT",
}

_OK = {"ok"}
_FAILED = {"failed"}
_BLOCKED = {"blocked"}


@dataclass
class ActivityLine:
    verb: str
    subject: str = ""
    detail: str = ""
    outcome: str = "info"       # ok | failed | waiting | running | info


@dataclass
class StatusView:
    """
    What is true right now, in terms a person cares about.

    Derived purely from the snapshot. Renderers format this; they do not
    interpret the snapshot themselves, so the two interfaces cannot drift.
    """

    assistant: str = ""
    node_name: str = ""
    node_status: str = "UNKNOWN"
    node_role: str = ""
    agent_status: str = "idle"
    nodes: list[dict] = field(default_factory=list)
    runtimes: list[dict] = field(default_factory=list)
    project: str = ""
    task: str = ""
    task_verification: str = ""
    plan_progress: str = ""
    plan_state: str = ""
    activity: list[ActivityLine] = field(default_factory=list)
    waiting_write: dict = field(default_factory=dict)
    waiting_execute: dict = field(default_factory=dict)
    context_chars: int = 0
    context_tokens: int = 0
    context_sections: list[str] = field(default_factory=list)
    compaction_count: int = 0
    compaction_ratio: float = 0.0
    cloud_calls: int = 0
    mode: str = "LOCAL"
    memory_backup: dict = field(default_factory=dict)
    providers: list[dict] = field(default_factory=list)
    provider_usage: dict = field(default_factory=dict)
    provider_accounts: list[dict] = field(default_factory=list)
    cloud_budget: dict = field(default_factory=dict)
    capabilities: dict = field(default_factory=dict)
    voice: dict = field(default_factory=dict)

    @property
    def active_model(self) -> str:
        """The model actually in use, or the first available one."""
        for runtime in self.runtimes:
            if runtime.get("status") in {"ACTIVE", "LOADED"}:
                return runtime.get("model", "")

        return self.runtimes[0].get("model", "") if self.runtimes else ""

    @property
    def is_waiting(self) -> bool:
        return bool(self.waiting_write or self.waiting_execute)


def _safe_name(value: str) -> str:
    """A path becomes a name. A home directory carries a person's name."""
    text = str(value or "").strip()

    if not text:
        return ""

    if "/" in text or "\\" in text:
        return Path(text).name or text.rsplit("/", 1)[-1]

    return text


def _activity_from(event: dict) -> ActivityLine | None:
    verb = ACTIVITY_VERBS.get(event.get("event_type", ""))

    if verb is None:
        return None

    metadata = event.get("metadata") or {}
    status = str(event.get("status", "info")).lower()

    if status in _OK:
        outcome = "ok"
    elif status in _FAILED:
        outcome = "failed"
    elif status in _BLOCKED:
        outcome = "waiting"
    elif status == "started":
        outcome = "running"
    else:
        outcome = "info"

    subject = _safe_name(
        metadata.get("path")
        or metadata.get("profile")
        or (event.get("operation") if verb != "READ" else "")
        or ""
    )

    if verb == "READ" and event.get("operation"):
        subject = str(event["operation"])

    detail = ""

    if "added_lines" in metadata or "removed_lines" in metadata:
        detail = f"+{metadata.get('added_lines', 0)} -{metadata.get('removed_lines', 0)}"
    elif "passed" in metadata or "failed" in metadata:
        detail = f"{metadata.get('passed', 0)}✓ {metadata.get('failed', 0)}✗"
    elif "results" in metadata:
        detail = str(metadata["results"])

    return ActivityLine(verb=verb, subject=subject, detail=detail, outcome=outcome)


def build_view(snapshot, assistant_name: str = "", activity_limit: int = 6
               ) -> StatusView:
    """Turn a snapshot into semantics. The only place that reads snapshot keys."""
    node = snapshot.node or {}
    task = snapshot.task or {}
    plan = snapshot.plan or {}
    metrics = snapshot.context_metrics or {}

    view = StatusView(
        assistant=assistant_name or "",
        node_name=str(node.get("display_name", "") or node.get("node_id", "")),
        node_status=str(node.get("status", "UNKNOWN")),
        node_role=str(node.get("role", "")),
        agent_status=str(snapshot.agent_status or "idle"),
        nodes=list(snapshot.nodes or []),
        runtimes=list(snapshot.runtimes or []),
        project=str((snapshot.project or {}).get("display_name", "")),
        task=str(task.get("goal", "")),
        task_verification=str(task.get("verification_state", "")),
        plan_state=str(plan.get("status", "")),
        context_chars=int(metrics.get("context_chars", 0) or 0),
        context_tokens=int(metrics.get("estimated_tokens", 0) or 0),
        capabilities=dict(snapshot.capabilities or {}),
        voice=dict(getattr(snapshot, "voice", {}) or {}),
        memory_backup=dict(getattr(snapshot, "memory_backup", {}) or {}),
        providers=list(getattr(snapshot, "providers", []) or []),
        provider_usage=dict(getattr(snapshot, "provider_usage", {}) or {}),
        provider_accounts=list(getattr(snapshot, "provider_accounts", []) or []),
        cloud_budget=dict(getattr(snapshot, "cloud_budget", {}) or {}),
        mode=str(getattr(snapshot, "mode", "") or "LOCAL"),
        compaction_count=int(metrics.get("compaction_count", 0) or 0),
        compaction_ratio=float(metrics.get("last_reduction_ratio", 0.0) or 0.0),
    )

    included = metrics.get("included_sections") or ""
    # Cloud is not implemented, so the honest number is what a non-local
    # provider actually served: zero, and computed rather than asserted.
    remote = {
        entry.get("provider_id")
        for entry in view.providers
        if not entry.get("capabilities", {}).get("local", True)
    }
    view.cloud_calls = sum(
        count for name, count in (view.provider_usage.get("providers") or {}).items()
        if name in remote
    )

    view.context_sections = (
        included.split(",") if isinstance(included, str) and included not in ("", "-")
        else list(included) if isinstance(included, list) else []
    )

    if plan.get("total_steps"):
        view.plan_progress = f"{plan.get('completed_steps', 0)}/{plan['total_steps']}"

    for event in reversed(snapshot.recent_activity or []):
        line = _activity_from(event)

        if line is not None:
            view.activity.append(line)

        if len(view.activity) >= activity_limit:
            break

    view.activity.reverse()

    if snapshot.pending_patch:
        view.waiting_write = {
            "patch_id": snapshot.pending_patch.get("patch_id", ""),
            "files": ", ".join(
                _safe_name(name) for name in snapshot.pending_patch.get("files", [])),
            "added": snapshot.pending_patch.get("added_lines", 0),
            "removed": snapshot.pending_patch.get("removed_lines", 0),
        }

    if snapshot.pending_execution:
        view.waiting_execute = {
            "execution_id": snapshot.pending_execution.get("execution_id", ""),
            "command": snapshot.pending_execution.get("command", ""),
            "operation": snapshot.pending_execution.get("operation", ""),
        }

    return view


# --- terminal capability --------------------------------------------------


@dataclass
class Terminal:
    """
    What this terminal can actually do.

    Detected rather than assumed: output is redirected often enough that a
    renderer emitting box drawing into a pipe is a real annoyance, and NO_COLOR
    is a convention worth honouring.
    """

    width: int = DEFAULT_WIDTH
    is_tty: bool = False
    ansi: bool = False
    unicode: bool = False

    @property
    def glyphs(self) -> dict:
        return GLYPHS["rich" if self.unicode else "plain"]

    @property
    def narrow(self) -> bool:
        return self.width < 48


def detect_terminal(stream=None) -> Terminal:
    stream = stream if stream is not None else sys.stdout

    try:
        is_tty = bool(stream.isatty())
    except Exception:
        is_tty = False

    try:
        width = shutil.get_terminal_size((DEFAULT_WIDTH, 24)).columns
    except Exception:
        width = DEFAULT_WIDTH

    width = max(MIN_WIDTH, min(MAX_WIDTH, int(width or DEFAULT_WIDTH)))

    no_color = bool(os.environ.get("NO_COLOR"))
    dumb = os.environ.get("TERM", "").lower() in {"", "dumb"}
    encoding = (getattr(stream, "encoding", "") or "").lower()

    return Terminal(
        width=width,
        is_tty=is_tty,
        ansi=is_tty and not no_color and not dumb,
        # Box drawing in a latin-1 pipe raises; only claim it when it will work.
        unicode=is_tty and ("utf" in encoding or encoding == ""),
    )


# --- renderers ------------------------------------------------------------


def _rule(terminal: Terminal) -> str:
    return terminal.glyphs["bar"] * min(terminal.width, 60)


def _dot(terminal: Terminal, ok: bool) -> str:
    return terminal.glyphs["dot"] if ok else terminal.glyphs["sep"]


_OUTCOME_GLYPH = {"ok": "ok", "failed": "fail", "waiting": "wait", "running": "run"}


def _outcome(terminal: Terminal, outcome: str) -> str:
    key = _OUTCOME_GLYPH.get(outcome)

    return terminal.glyphs[key] if key else ""


def _render_backup(view: StatusView) -> str:
    """
    One line about durable state. Counts and status, never a location.

    Memoria is always encrypted, so it is stated plainly rather than as a
    setting: it is a property of the design, not a toggle.
    """
    backup = view.memory_backup
    count = int(backup.get("snapshot_count", 0) or 0)

    if not count:
        return "Memoria: cifrada · Backup: sin snapshots"

    plural = "snapshot" if count == 1 else "snapshots"

    return f"Memoria: cifrada · Backup: {backup.get('status', '?')} · {count} {plural}"


def render_terminal(view: StatusView, terminal: Terminal | None = None) -> str:
    """The developer-facing status block."""
    terminal = terminal or detect_terminal()
    glyph = terminal.glyphs
    lines: list[str] = []

    header = view.assistant.upper() if view.assistant else "ICLIRIUS"
    lines.append(header)
    lines.append(_rule(terminal))
    if view.voice:
        lines.append(f"Voice: {view.voice.get('mode', 'off').upper()} · "
                     f"{view.voice.get('status', 'UNKNOWN')}")

    online = view.node_status == "ONLINE"
    node_bits = [f"{glyph['node']} {view.node_name or 'nodo local'}"]
    lines.append("  ".join(node_bits))
    lines.append(f"  {_dot(terminal, online)} {view.node_status}"
                 + (f" {glyph['sep']} {view.node_role.upper()}" if view.node_role else ""))

    for other in view.nodes[1:]:
        lines.append(f"  {glyph['node']} {other.get('display_name', '?')} "
                     f"{_dot(terminal, other.get('status') == 'ONLINE')} "
                     f"{other.get('status', 'UNKNOWN')}")

    if view.runtimes:
        lines.append("")
        by_provider: dict[str, list[dict]] = {}

        for runtime in view.runtimes:
            by_provider.setdefault(runtime.get("provider", "?"), []).append(runtime)

        for provider, items in by_provider.items():
            lines.append(provider.capitalize())

            for item in items:
                active = item.get("status") in {"ACTIVE", "LOADED", "AVAILABLE"}
                lines.append(f"  {_dot(terminal, active)} {item.get('model', '?')} "
                             f"{item.get('status', 'UNKNOWN')}")

    if view.project or view.task:
        lines.append("")

        if view.project:
            lines.append(f"Proyecto: {view.project}")

        if view.task:
            limit = max(20, terminal.width - 10)
            lines.append(f"Tarea: {view.task[:limit]}")

        if view.plan_progress:
            state = f" {glyph['sep']} {view.plan_state}" if view.plan_state else ""
            lines.append(f"Plan: {view.plan_progress}{state}")

        if view.task_verification:
            lines.append(f"Verificación: {view.task_verification}")

    if view.activity:
        lines.append("")

        for line in view.activity:
            subject = line.subject[:24] if not terminal.narrow else line.subject[:12]
            detail = line.detail or _outcome(terminal, line.outcome)
            lines.append(f"{line.verb:<8}{subject:<26}{detail:>8}".rstrip()
                         if not terminal.narrow
                         else f"{line.verb} {subject} {detail}".strip())

    if view.waiting_write:
        lines.append("")
        lines.append(f"{glyph['wait']} ESPERANDO APROBACIÓN DE ESCRITURA")
        lines.append(f"  PATCH {view.waiting_write['files']} "
                     f"+{view.waiting_write['added']} -{view.waiting_write['removed']}")

    if view.waiting_execute:
        lines.append("")
        lines.append(f"{glyph['wait']} ESPERANDO APROBACIÓN DE EJECUCIÓN")
        lines.append(f"  {view.waiting_execute['operation']}: "
                     f"{view.waiting_execute['command']}")

    cloud = [entry for entry in view.providers
             if not entry.get("capabilities", {}).get("local", True)]

    if cloud:
        lines.append("")
        families = {entry.get("provider_type", "?").capitalize() for entry in cloud}

        for family in sorted(families):
            lines.append(family)

            for account in (view.provider_accounts
                            or [{"account_ref": entry.get("account_ref"),
                                 "status": entry.get("status")}
                                for entry in cloud]):
                ready = account.get("status") in {"AVAILABLE", "ACTIVE", "IDLE"}
                cooldown = account.get("cooldown_seconds") or 0
                suffix = f" ({cooldown}s)" if cooldown else ""
                lines.append(
                    f"  {_dot(terminal, ready)} {account.get('account_ref', '?'):<18}"
                    f"{account.get('status', 'UNKNOWN')}{suffix}")

    if view.provider_usage.get("requests"):
        usage = view.provider_usage
        lines.append("")
        lines.append(
            f"Razonamiento: modo {view.mode} {glyph['sep']} "
            f"{usage['requests']} peticiones {glyph['sep']} "
            f"~{usage.get('estimated_input_tokens', 0)}/"
            f"{usage.get('estimated_output_tokens', 0)} tokens "
            f"{glyph['sep']} coste {usage.get('cost_estimated', 0)}"
        )

    if view.memory_backup:
        lines.append("")
        lines.append(_render_backup(view))

    if view.context_chars:
        lines.append("")
        lines.append(f"Contexto: {view.context_chars} chars "
                     f"{glyph['sep']} ~{view.context_tokens} tokens")

        if view.context_sections and not terminal.narrow:
            lines.append(f"  Secciones: {', '.join(view.context_sections)}")

        if view.compaction_count:
            lines.append(f"  Compactaciones: {view.compaction_count} "
                         f"{glyph['sep']} última reducción "
                         f"{int(view.compaction_ratio * 100)}%")

    lines.append(_rule(terminal))

    return "\n".join(lines)


def render_footer(view: StatusView, terminal: Terminal | None = None) -> str:
    """
    The one-line status strip.

    Only drawn when there is a TTY wide enough for it to be readable; in a
    pipe it is noise, and truncated it is worse than absent.
    """
    terminal = terminal or detect_terminal()

    if not terminal.is_tty or terminal.narrow:
        return ""

    glyph = terminal.glyphs
    model = view.active_model or "sin modelo"
    node_ok = view.node_status == "ONLINE"

    parts = [
        view.mode,
        f"{model} {_dot(terminal, bool(view.active_model))}",
        f"nodo {_dot(terminal, node_ok)}",
    ]

    if view.context_tokens:
        parts.append(f"ctx ~{view.context_tokens} tok")

    parts.append(f"cloud {view.cloud_calls}")

    if view.task:
        parts.append("tarea activa")

    if view.is_waiting:
        parts.append("esperando aprobación")

    strip = f" {glyph['pipe']} ".join(parts)

    return strip[:terminal.width]


def render_telegram(view: StatusView) -> str:
    """
    The same state, compact enough for a phone.

    Fewer lines, no box drawing, no column alignment: a chat client reflows
    text, so anything positional would arrive broken.
    """
    glyph = GLYPHS["rich"]
    lines = [(view.assistant or "ICLIRIUS").upper(), ""]
    if view.voice:
        lines.append(f"Voice: {view.voice.get('mode', 'off').upper()} · "
                     f"{view.voice.get('status', 'UNKNOWN')}")

    lines.append(f"{glyph['node']} {view.node_name or 'nodo local'}")
    role = f" {glyph['sep']} {view.node_role.upper()}" if view.node_role else ""
    lines.append(f"{_dot(Terminal(unicode=True), view.node_status == 'ONLINE')} "
                 f"{view.node_status}{role}")

    if view.runtimes:
        lines.append("")

        for runtime in view.runtimes[:4]:
            active = runtime.get("status") in {"ACTIVE", "LOADED", "AVAILABLE"}
            lines.append(f"{runtime.get('provider', '?').capitalize()}: "
                         f"{'●' if active else '·'} {runtime.get('model', '?')} "
                         f"{runtime.get('status', 'UNKNOWN')}")

    if view.project:
        lines.append("")
        lines.append(f"Proyecto: {view.project}")

    if view.task:
        lines.append(f"Tarea: {view.task[:70]}")

    if view.plan_progress:
        lines.append(f"Plan: {view.plan_progress}")

    if view.task_verification:
        lines.append(f"Verificación: {view.task_verification}")

    if view.activity:
        lines.append("")

        for line in view.activity[-5:]:
            mark = {"ok": "✓", "failed": "✗", "waiting": "◍",
                    "running": "◐"}.get(line.outcome, "·")
            detail = f" {line.detail}" if line.detail else ""
            lines.append(f"{line.verb} {line.subject}{detail} {mark}".replace("  ", " "))

    if view.waiting_write:
        lines.append("")
        lines.append(f"◍ Esperando aprobación de escritura: "
                     f"{view.waiting_write['files']} "
                     f"+{view.waiting_write['added']} -{view.waiting_write['removed']}")

    if view.waiting_execute:
        lines.append("")
        lines.append(f"◍ Esperando aprobación de ejecución: "
                     f"{view.waiting_execute['command']}")

    lines.append(f"Modo: {view.mode}")
    voice = view.voice
    if voice:
        lines.append(f"Voice: {voice.get('tts_provider', 'local')} · "
                     f"{voice.get('mode', 'off').upper()}")

    remote = [entry for entry in view.providers
              if not entry.get("capabilities", {}).get("local", True)]

    if remote:
        family = remote[0].get("provider_type", "?").capitalize()
        lines.append("")
        lines.append(f"{family}:")

        accounts = view.provider_accounts or [
            {"account_ref": entry.get("account_ref"), "status": entry.get("status")}
            for entry in remote
        ]

        for account in accounts:
            ready = account.get("status") in {"AVAILABLE", "ACTIVE", "IDLE"}
            cooldown = account.get("cooldown_seconds") or 0
            suffix = f" ({cooldown}s)" if cooldown else ""
            lines.append(f"{'●' if ready else '⚠'} {account.get('account_ref', '?')} "
                         f"{account.get('status', 'UNKNOWN').lower()}{suffix}")

    if view.provider_usage.get("requests"):
        lines.append(f"Peticiones: {view.provider_usage['requests']}")

    if view.memory_backup:
        lines.append("")
        lines.append(_render_backup(view))

    if view.context_chars:
        lines.append("")
        lines.append(f"Contexto: ~{view.context_tokens} tokens")

        if view.compaction_count:
            lines.append(f"Compactación: {int(view.compaction_ratio * 100)}% reducido")

    budget = view.cloud_budget
    cloud_line = f"Cloud: {view.cloud_calls}"

    if budget.get("cloud_input_tokens") or budget.get("cloud_output_tokens"):
        total = (budget.get("cloud_input_tokens", 0)
                 + budget.get("cloud_output_tokens", 0))
        cloud_line += f" · {total} tok"

    if budget.get("cloud_denials"):
        cloud_line += f" · {budget['cloud_denials']} denegadas"

    lines.append(cloud_line)

    return "\n".join(lines)
