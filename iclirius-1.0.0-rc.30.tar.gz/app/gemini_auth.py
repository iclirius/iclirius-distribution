"""Official Gemini OAuth account lifecycle.

This module deliberately keeps OAuth tokens in Keychain only.  Profile files
contain references and validation metadata, never credential payloads.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.ai_accounts import AIAccountProfile, AuthMethod, LoginResult, RefreshResult, SessionState, mask_account
from app.credentials import AuthType, CredentialError, CredentialRef, credential_store
from app.evidence import EvidenceRecord
from app.node_identity import read_node

SCOPES = ("https://www.googleapis.com/auth/generative-language.retriever",)
PROFILE_SCHEMA_VERSION = 1
CLIENT_CONFIG_REF = "keychain:iclirius.ai.gemini/client-config"
TOKEN_SERVICE = "iclirius.ai.gemini"
API_URL = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiAuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class GeminiOAuthClientConfig:
    client_id: str
    client_secret: str = ""
    project_id: str = ""
    scopes: tuple[str, ...] = SCOPES

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GeminiOAuthClientConfig":
        root = data.get("installed") or data.get("web") or data
        cid, secret = str(root.get("client_id", "")), str(root.get("client_secret", ""))
        if not cid:
            raise GeminiAuthError("El cliente OAuth de Gemini no contiene client_id.")
        return cls(cid, secret, str(root.get("project_id", "")), tuple(root.get("scopes") or SCOPES))

    def to_client_config(self) -> dict:
        return {"installed": {"client_id": self.client_id, "client_secret": self.client_secret,
                               "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                               "token_uri": "https://oauth2.googleapis.com/token",
                               "redirect_uris": ["http://localhost"]}}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _node_id() -> str:
    return str((read_node() or {}).get("node_id", ""))


def _state_root() -> Path:
    return Path(os.environ.get("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def profiles_path() -> Path:
    return _state_root() / "ai_accounts.json"


def _token_ref(profile: str) -> CredentialRef:
    safe = "".join(c for c in profile if c.isalnum() or c in "._-") or "personal"
    return CredentialRef("gemini", safe, f"keychain:{TOKEN_SERVICE}/{safe}", AuthType.OAUTH.value)


def _config_ref() -> CredentialRef:
    return CredentialRef("gemini", "client-config", CLIENT_CONFIG_REF, AuthType.OAUTH.value)


def load_profiles() -> list[AIAccountProfile]:
    try:
        raw = json.loads(profiles_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    out = []
    for item in raw.get("profiles", []) if isinstance(raw, dict) else []:
        if isinstance(item, dict) and item.get("provider_id") == "gemini":
            out.append(AIAccountProfile(**{k: v for k, v in item.items() if k in AIAccountProfile.__dataclass_fields__}))
    return out


def save_profiles(profiles: list[AIAccountProfile]) -> None:
    root = profiles_path().parent
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    payload = {"schema_version": PROFILE_SCHEMA_VERSION, "profiles": [asdict(p) for p in profiles]}
    tmp = profiles_path().with_name(f".{profiles_path().name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, profiles_path())


def configure_client(path: str) -> None:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        config = GeminiOAuthClientConfig.from_dict(data)
        credential_store.store(_config_ref(), json.dumps({"installed": {
            "client_id": config.client_id, "client_secret": config.client_secret,
            "project_id": config.project_id}}, separators=(",", ":")))
    except (OSError, ValueError, CredentialError) as exc:
        raise GeminiAuthError("No se pudo configurar el cliente OAuth de Gemini.") from None


def _client_config() -> GeminiOAuthClientConfig:
    env_path = os.environ.get("GEMINI_OAUTH_CLIENT_CONFIG", "").strip()
    if env_path:
        try:
            return GeminiOAuthClientConfig.from_dict(json.loads(Path(env_path).read_text(encoding="utf-8")))
        except (OSError, ValueError, GeminiAuthError):
            raise GeminiAuthError("La configuración OAuth indicada no es válida.") from None
    try:
        raw = credential_store.resolve(_config_ref())
        return GeminiOAuthClientConfig.from_dict(json.loads(raw))
    except (CredentialError, ValueError, GeminiAuthError):
        raise GeminiAuthError("Gemini OAuth no está configurado. Usa --client-config con un cliente Desktop de Google.") from None


def _credentials(raw: str):
    try:
        from google.oauth2.credentials import Credentials
        return Credentials.from_authorized_user_info(json.loads(raw), SCOPES)
    except (ImportError, ValueError, TypeError) as exc:
        raise GeminiAuthError("Las bibliotecas OAuth de Google no están instaladas o la credencial es inválida.") from None


def _validate_credentials(creds) -> tuple[SessionState, str, list[str]]:
    try:
        if getattr(creds, "expired", False) and getattr(creds, "refresh_token", None):
            from google.auth.transport.requests import Request
            creds.refresh(Request())
        from google.auth.transport.requests import AuthorizedSession
        response = AuthorizedSession(creds).get(API_URL, timeout=10)
        if response.status_code in (401, 403):
            return SessionState.REAUTH_REQUIRED, "Gemini rechazó la credencial.", []
        if response.status_code >= 400:
            return SessionState.UNAVAILABLE, f"Gemini respondió HTTP {response.status_code}.", []
        body = response.json()
        names = [str(m.get("name", "")) for m in body.get("models", []) if m.get("name")]
        return SessionState.VALID, "Gemini API validada.", names
    except Exception as exc:
        name = type(exc).__name__.lower()
        if "refresh" in name or "invalidgrant" in name:
            return SessionState.REAUTH_REQUIRED, "La sesión requiere volver a autorizar.", []
        return SessionState.UNAVAILABLE, "Gemini no está disponible en este momento.", []


class GeminiAccountAdapter:
    provider_id = "gemini"

    def __init__(self, profile: str = "personal", node_id: str = ""):
        self.profile_name = profile or "personal"
        self.node_id = node_id or _node_id()

    @property
    def profile_id(self) -> str:
        return f"gemini:{self.profile_name}"

    def validate_session(self) -> tuple[SessionState, str, list[str]]:
        try:
            raw = credential_store.resolve(_token_ref(self.profile_name))
            creds = _credentials(raw)
            result = _validate_credentials(creds)
            if result[0] == SessionState.VALID and getattr(creds, "refresh_token", None):
                # Persist a newly refreshed access token only after API validation.
                try:
                    credential_store.store(_token_ref(self.profile_name), creds.to_json())
                except CredentialError:
                    return SessionState.UNAVAILABLE, "No se pudo actualizar la credencial segura.", []
            return result
        except GeminiAuthError as exc:
            return SessionState.NOT_CONFIGURED, str(exc), []
        except CredentialError:
            return SessionState.NOT_CONFIGURED, "Gemini no está configurado para este perfil.", []

    def validation_evidence(self) -> EvidenceRecord:
        state, message, models = self.validate_session()
        certainty = "VERIFIED" if state == SessionState.VALID else "OBSERVED"
        return EvidenceRecord("provider", "validate_session", "gemini",
                              {"profile_id": self.profile_id, "session_state": state.value,
                               "models_count": len(models), "message": message},
                              certainty=certainty, node_id=self.node_id, tool_id="gemini_api")

    def profile(self) -> AIAccountProfile:
        existing = next((p for p in load_profiles() if p.profile_id == self.profile_id), None)
        state, message, _ = self.validate_session()
        if existing:
            existing.session_state, existing.updated_at = state.value, _now()
            if state == SessionState.VALID: existing.last_validated_at = _now()
            existing.reauth_required = state == SessionState.REAUTH_REQUIRED
            return existing
        return AIAccountProfile(self.profile_id, self.provider_id, "Gemini", "Google account",
                                AuthMethod.OAUTH.value, state.value, credential_ref=_token_ref(self.profile_name).credential_ref,
                                node_id=self.node_id, refresh_available=None, reauth_required=state == SessionState.REAUTH_REQUIRED)

    def login(self) -> LoginResult:
        try:
            config = _client_config()
        except GeminiAuthError as exc:
            return LoginResult(False, self.provider_id, self.profile_id, AuthMethod.OAUTH.value,
                               SessionState.NOT_CONFIGURED.value, safe_message=str(exc))
        try:
            from google_auth_oauthlib.flow import InstalledAppFlow
        except ImportError:
            return LoginResult(False, self.provider_id, self.profile_id, AuthMethod.OAUTH.value,
                               SessionState.UNAVAILABLE.value, safe_message="Instala google-auth-oauthlib para Gemini OAuth.")
        try:
            flow = InstalledAppFlow.from_client_config(config.to_client_config(), list(config.scopes))
            creds = flow.run_local_server(host="127.0.0.1", port=0, open_browser=True,
                                          access_type="offline", prompt="consent")
            state, msg, _ = _validate_credentials(creds)
            if state != SessionState.VALID:
                return LoginResult(False, self.provider_id, self.profile_id, AuthMethod.OAUTH.value, state.value, safe_message=msg)
            credential_store.store(_token_ref(self.profile_name), creds.to_json())
            existing = [p for p in load_profiles() if p.profile_id != self.profile_id]
            existing.append(AIAccountProfile(self.profile_id, self.provider_id, "Gemini", "Google account",
                                             AuthMethod.OAUTH.value, SessionState.VALID.value, last_validated_at=_now(),
                                             credential_ref=_token_ref(self.profile_name).credential_ref,
                                             node_id=self.node_id, refresh_available=bool(getattr(creds, "refresh_token", None))))
            save_profiles(existing)
            return LoginResult(True, self.provider_id, self.profile_id, AuthMethod.OAUTH.value, SessionState.VALID.value,
                               safe_message="Google authorization received; Gemini API validated.")
        except KeyboardInterrupt:
            return LoginResult(False, self.provider_id, self.profile_id, AuthMethod.OAUTH.value, SessionState.NOT_CONFIGURED.value, safe_message="Autenticación cancelada.")
        except Exception:
            return LoginResult(False, self.provider_id, self.profile_id, AuthMethod.OAUTH.value, SessionState.UNKNOWN.value, safe_message="No se pudo completar la autenticación de Gemini.")

    def logout(self) -> LoginResult:
        try: credential_store.delete(_token_ref(self.profile_name))
        except CredentialError: pass
        save_profiles([p for p in load_profiles() if p.profile_id != self.profile_id])
        return LoginResult(True, self.provider_id, self.profile_id, AuthMethod.OAUTH.value, SessionState.NOT_CONFIGURED.value,
                           safe_message="Credenciales locales de Gemini eliminadas; el acceso remoto no fue revocado.")

    def refresh_session(self) -> RefreshResult:
        state, message, _ = self.validate_session()
        if state == SessionState.VALID:
            return RefreshResult("VALID", self.provider_id, self.profile_id, message)
        if state == SessionState.REAUTH_REQUIRED:
            return RefreshResult("REAUTH_REQUIRED", self.provider_id, self.profile_id, message)
        return RefreshResult("UNAVAILABLE", self.provider_id, self.profile_id, message)

    def models(self) -> tuple[SessionState, list[str], str]:
        state, msg, names = self.validate_session()
        return state, names, msg

    def list_models(self) -> tuple[SessionState, list[str], str]:
        return self.models()


def gemini_status(node_id: str = "") -> list[dict]:
    profiles = load_profiles()
    if not profiles:
        return []
    out = []
    for p in profiles:
        adapter = GeminiAccountAdapter(p.profile_id.split(":", 1)[1], node_id)
        live = adapter.profile()
        out.append(live.to_dict())
    return out
