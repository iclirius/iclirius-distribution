from pathlib import Path
from typing import Callable
import os

from faster_whisper import WhisperModel


_MODEL = None
MODEL_NAME = "base"
DEVICE = "cpu"
COMPUTE_TYPE = "int8"


def _notify(callback: Callable[..., None] | None, event_stage: str, **metadata) -> None:
    if callback:
        callback(event_stage, **metadata)


def _safe_error(exc: Exception) -> str:
    return " ".join(str(exc).split())[:300] or type(exc).__name__


def model_cache_path() -> Path:
    root = Path(os.getenv("HF_HOME", Path.home() / ".cache" / "huggingface"))
    return root / "hub" / "models--Systran--faster-whisper-base"


def model_available() -> bool:
    root = model_cache_path()
    snapshots = root / "snapshots"
    return any((snapshot / "model.bin").is_file() and (snapshot / "config.json").is_file()
               for snapshot in snapshots.glob("*") if snapshot.is_dir())


def get_transcription_model(on_stage: Callable[..., None] | None = None):
    global _MODEL

    if _MODEL is None:
        # Opciones:
        # tiny  = más rápido, menos preciso
        # base  = buen balance inicial
        # small = mejor, más lento
        if not model_available():
            raise RuntimeError("STT MODEL UNAVAILABLE")
        _notify(on_stage, "stt=model-load-start", model=MODEL_NAME,
                device=DEVICE, compute_type=COMPUTE_TYPE)
        _MODEL = WhisperModel(
            MODEL_NAME,
            device=DEVICE,
            compute_type=COMPUTE_TYPE,
            # Telegram handling must never turn a missing model into an
            # implicit network download. The caller reports this as a local
            # STT failure and keeps the bot responsive.
            local_files_only=True,
        )
        _notify(on_stage, "stt=model-load-done")

    return _MODEL


def warmup_model(on_stage: Callable[..., None] | None = None) -> bool:
    """Load the already-installed model without permitting a download."""
    get_transcription_model(on_stage)
    return True


def transcribe_audio(audio_path: str | Path, on_stage: Callable[..., None] | None = None,
                     language: str = "es") -> str:
    audio_path = Path(audio_path)

    if not audio_path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    _notify(on_stage, "stt=model-check", available=model_available())
    model = get_transcription_model(on_stage)

    _notify(on_stage, "stt=transcribe-start", format=audio_path.suffix.lower() or "unknown")
    try:
        segments, info = model.transcribe(
            str(audio_path), language=language or "es", beam_size=5, vad_filter=True)
    except Exception as exc:
        _notify(on_stage, "stt=error", stage="transcribe", type=type(exc).__name__,
                message=_safe_error(exc))
        raise

    text_parts = []

    _notify(on_stage, "stt=segments-start")
    try:
        for segment in segments:
            if segment.text:
                text_parts.append(segment.text.strip())
    except Exception as exc:
        _notify(on_stage, "stt=error", stage="segments", type=type(exc).__name__,
                message=_safe_error(exc))
        raise

    _notify(on_stage, "stt=segments-done", segments=len(text_parts))
    return " ".join(text_parts).strip()
