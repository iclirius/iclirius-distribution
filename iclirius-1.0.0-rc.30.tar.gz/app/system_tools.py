import json
import os
import subprocess
from datetime import datetime
from app.config import settings
from models.ollama_client import OllamaClient
from app.version import VERSION


def run_command(command: list[str], timeout: int = 20) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        output = (result.stdout + result.stderr).strip()
        return result.returncode == 0, output
    except Exception as exc:
        return False, str(exc)


def get_version_text() -> str:
    ok, commit = run_command(["git", "rev-parse", "--short", "HEAD"])
    commit_text = commit if ok else "unknown"

    ok, branch = run_command(["git", "branch", "--show-current"])
    branch_text = branch if ok else "unknown"

    return (
        f"{settings.agent_name} {VERSION} version info:\n"
        f"- Agent: {settings.agent_name}\n"
        f"- Framework: OpenClaw\n"
        f"- Node ID: {settings.node_id}\n"
        f"- Role: {settings.role}\n"
        f"- Environment: {settings.openclaw_env}\n"
        f"- Model: {settings.default_model}\n"
        f"- Git branch: {branch_text}\n"
        f"- Git commit: {commit_text}"
    )


def get_git_status_text() -> str:
    ok, output = run_command(["git", "status", "--short"])

    if not ok:
        return f"Git status error:\n{output}"

    if not output:
        return "Git status: working tree clean."

    return f"Git status:\n{output}"


def get_health_text() -> str:
    lines = [
        f"{settings.agent_name} health check:",
        f"- Node ID: {settings.node_id}",
        f"- Role: {settings.role}",
        f"- Telegram enabled: {settings.enable_telegram}",
        f"- Model: {settings.default_model}",
    ]

    env_status = "OK" if os.path.exists(".env") else "MISSING"
    venv_status = "OK" if os.path.isdir(".venv") else "MISSING"

    lines.append(f"- .env: {env_status}")
    lines.append(f"- .venv: {venv_status}")

    ollama = OllamaClient()
    lines.append(f"- Ollama: {'OK' if ollama.health() else 'NOT AVAILABLE'}")

    ok, models = run_command(["ollama", "list"])
    if ok and settings.default_model in models:
        lines.append(f"- Required model: OK")
    else:
        lines.append(f"- Required model: MISSING OR UNKNOWN")

    lock_path = os.path.join(settings.state_path, "iclirius.lock")
    lines.append(f"- Lock file: {'present' if os.path.exists(lock_path) else 'not present'}")

    ok, git_output = run_command(["git", "status", "--short"])
    if ok:
        lines.append(f"- Git: {'clean' if not git_output else 'has changes'}")
    else:
        lines.append("- Git: error")

    return "\n".join(lines)


def write_node_status() -> dict:
    os.makedirs(settings.state_path, exist_ok=True)

    status = {
        "agent_name": settings.agent_name,
        "framework": "OpenClaw",
        "node_id": settings.node_id,
        "cluster": settings.cluster_name,
        "role": settings.role,
        "environment": settings.openclaw_env,
        "default_model": settings.default_model,
        "telegram_enabled": settings.enable_telegram,
        "updated_at": datetime.now().isoformat(timespec="seconds")
    }

    path = os.path.join(settings.state_path, "node_status.json")

    with open(path, "w", encoding="utf-8") as file:
        json.dump(status, file, ensure_ascii=False, indent=2)

    return status


def run_backup_text() -> str:
    ok, output = run_command(["./scripts/backup_to_drive.sh"], timeout=120)

    if ok:
        write_node_status()
        return "Backup completed successfully."

    return f"Backup failed:\n{output[-1500:]}"


def get_backup_status_text() -> str:
    configured_root = settings.backup_root

    if configured_root is None:
        return (
            "Backup status:\n"
            "- BACKUP_ROOT no está configurado en .env.\n"
            "- Define BACKUP_ROOT con la carpeta destino de los snapshots."
        )

    backup_root = str(configured_root)
    snapshots_dir = os.path.join(backup_root, "snapshots")
    auto_backup_log = os.path.join(settings.logs_path, "auto_backup.log")

    lines = [
        "Backup status:",
        f"- Backup root: {backup_root}",
    ]

    if not os.path.isdir(backup_root):
        lines.append("- Backup folder: MISSING")
        return "\n".join(lines)

    lines.append("- Backup folder: OK")

    if not os.path.isdir(snapshots_dir):
        lines.append("- Snapshots folder: MISSING")
        return "\n".join(lines)

    snapshots = [
        os.path.join(snapshots_dir, name)
        for name in os.listdir(snapshots_dir)
        if name.startswith("iclirius-data-") and name.endswith(".tar.gz")
    ]

    snapshots.sort(key=lambda path: os.path.getmtime(path), reverse=True)

    if not snapshots:
        lines.append("- Latest snapshot: none found")
        return "\n".join(lines)

    latest = snapshots[0]
    latest_name = os.path.basename(latest)
    latest_size_mb = os.path.getsize(latest) / (1024 * 1024)
    latest_mtime = datetime.fromtimestamp(
        os.path.getmtime(latest)
    ).isoformat(timespec="seconds")

    lines.append(f"- Latest snapshot: {latest_name}")
    lines.append(f"- Snapshot time: {latest_mtime}")
    lines.append(f"- Snapshot size: {latest_size_mb:.2f} MB")
    lines.append(f"- Total snapshots: {len(snapshots)}")

    if os.path.exists(auto_backup_log):
        try:
            with open(auto_backup_log, "r", encoding="utf-8") as file:
                log_text = file.read()

            if "Backup completed successfully" in log_text:
                lines.append("- Auto backup log: OK")
            else:
                lines.append("- Auto backup log: exists, no success marker found")
        except Exception:
            lines.append("- Auto backup log: unreadable")
    else:
        lines.append("- Auto backup log: not found")

    return "\n".join(lines)


def get_recent_logs_text(lines_count: int = 30) -> str:
    log_path = os.path.join(settings.logs_path, "openclaw.log")

    if not os.path.exists(log_path):
        return "No log file found."

    try:
        with open(log_path, "r", encoding="utf-8") as file:
            lines = file.readlines()

        recent = lines[-lines_count:]
        text = "".join(recent).strip()

        if not text:
            return "Log file exists, but it is empty."

        if len(text) > 3500:
            text = text[-3500:]

        return f"Recent logs:\n{text}"

    except Exception as exc:
        return f"Could not read logs: {exc}"
