"""Local-first capability gap ledger.

The ledger is deliberately separate from logs, RuntimeTrace and personal
memory.  It stores small, redacted engineering facts and never stores prompt
or document content.  Events are append-only per node so two nodes can write
without corrupting one shared JSON document; aggregates are derived from the
events and may be rebuilt at any time.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Iterable


OPEN = "OPEN"
FIXED = "FIXED"
REGRESSION = "REGRESSION"
WONT_FIX = "WONT_FIX"

_SECRET = re.compile(
    r"(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|\b\d{8,10}:[A-Za-z0-9_-]{30,}|"
    r"\b(?:sk|pk|ghp|gho|xox[baprs])-[A-Za-z0-9_-]{16,}|"
    r"\b(?:password|secret|token|api[_-]?key)\b\s*[:=]\s*\S+)", re.I
)
_SENSITIVE_NAME = re.compile(
    r"(?:password|passwd|secret|credential|token|api[_-]?key|recovery|backup[_-]?code|"
    r"private[_-]?key|\.env(?:\.|$))", re.I
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe(value: object, *, limit: int = 180) -> str:
    text = " ".join(str(value or "").split())
    if _SECRET.search(text):
        return "[redacted]"
    if _SENSITIVE_NAME.search(text):
        return "[sensitive metadata redacted]"
    return text[:limit] + ("…" if len(text) > limit else "")


def _json_safe(value: object):
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value[:20]]
    if isinstance(value, dict):
        return {str(k)[:40]: _json_safe(v) for k, v in list(value.items())[:20]}
    return _safe(value)


def request_fingerprint(*, normalized_intent: str = "", capability: str = "",
                        operation: str = "", filters: object = None,
                        failure_category: str = "", reason_code: str = "") -> str:
    payload = {
        "intent": _safe(normalized_intent, limit=120).casefold(),
        "capability": _safe(capability, limit=80).upper(),
        "operation": _safe(operation, limit=80).upper(),
        "filters": _json_safe(filters) if filters is not None else {},
        "category": _safe(failure_category, limit=80).upper(),
        "reason": _safe(reason_code, limit=80).upper(),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=True).encode()).hexdigest()[:24]


@dataclass(frozen=True)
class CapabilityGapEvent:
    event_id: str
    timestamp: str
    user_id: str | None
    node_id: str
    session_id: str | None
    channel: str
    request_fingerprint: str
    safe_request_summary: str
    normalized_intent: str
    requested_capability: str | None
    routing_decision: str | None
    selected_tool: str | None
    tool_call_id: str | None
    tool_status: str | None
    reason_code: str | None
    coverage: str | None
    evidence_ids: tuple[str, ...]
    response_outcome: str
    failure_category: str
    missing_capability: str | None
    iclirius_version: str
    install_mode: str | None
    source_commit: str | None
    sensitivity: str = "NORMAL"
    severity: str = "MEDIUM"

    def to_dict(self) -> dict:
        result = asdict(self)
        result["evidence_ids"] = list(self.evidence_ids)
        return result


@dataclass(frozen=True)
class CapabilityGapAggregate:
    gap_id: str
    fingerprint: str
    category: str
    capability: str | None
    status: str
    first_seen: str
    last_seen: str
    occurrences: int
    representative_summary: str
    latest_event_id: str
    latest_reason_code: str | None
    severity: str
    verification: str = "UNVERIFIED"

    def to_dict(self) -> dict:
        return asdict(self)


def _atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
            stream.write("\n")
            stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        try: os.unlink(name)
        except FileNotFoundError: pass


class CapabilityGapLedger:
    """Append-only events with deterministic, rebuildable aggregates."""
    def __init__(self, root: str | Path, *, node_id: str = "local-node",
                 user_id: str | None = None, version: str = "unknown",
                 install_mode: str | None = None, source_commit: str | None = None):
        self.root = Path(root).expanduser().resolve()
        self.node_id = _safe(node_id, limit=80) or "unknown-node"
        self.user_id = _safe(user_id, limit=120) or None
        self.version = _safe(version, limit=80) or "unknown"
        self.install_mode = _safe(install_mode, limit=80) or None
        self.source_commit = _safe(source_commit, limit=80) or None
        self.events_dir = self.root / "events"
        self.aggregate_path = self.root / "aggregates.json"

    @classmethod
    def from_memory_home(cls, memory_home: str | Path | None, **kwargs):
        if not memory_home:
            return None
        return cls(Path(memory_home) / "telemetry" / "capability_gaps", **kwargs)

    def _event_path(self) -> Path:
        safe_node = re.sub(r"[^A-Za-z0-9_.-]", "_", self.node_id)[:80] or "node"
        return self.events_dir / f"{safe_node}.jsonl"

    def record(self, *, summary: str, normalized_intent: str = "", capability: str | None = None,
               routing_decision: str | None = None, selected_tool: str | None = None,
               tool_call_id: str | None = None, tool_status: str | None = None,
               reason_code: str | None = None, coverage: str | None = None,
               evidence_ids: Iterable[str] = (), response_outcome: str = "FAILED",
               failure_category: str = "UNKNOWN", missing_capability: str | None = None,
               operation: str = "", filters: object = None, session_id: str | None = None,
               channel: str = "unknown", severity: str | None = None,
               fingerprint_override: str | None = None) -> CapabilityGapEvent:
        category = _safe(failure_category, limit=80).upper() or "UNKNOWN"
        reason = _safe(reason_code, limit=80).upper() or None
        fingerprint = fingerprint_override or request_fingerprint(normalized_intent=normalized_intent,
                                          capability=capability or "", operation=operation,
                                          filters=filters, failure_category=category,
                                          reason_code=reason or "")
        event = CapabilityGapEvent(
            event_id="gap_evt_" + uuid.uuid4().hex,
            timestamp=_now(), user_id=self.user_id, node_id=self.node_id,
            session_id=_safe(session_id, limit=120) or None,
            channel=_safe(channel, limit=40) or "unknown", request_fingerprint=fingerprint,
            safe_request_summary=_safe(summary), normalized_intent=_safe(normalized_intent, limit=180),
            requested_capability=_safe(capability, limit=80) or None,
            routing_decision=_safe(routing_decision, limit=80) or None,
            selected_tool=_safe(selected_tool, limit=100) or None,
            tool_call_id=_safe(tool_call_id, limit=100) or None,
            tool_status=_safe(tool_status, limit=40) or None, reason_code=reason,
            coverage=_safe(coverage, limit=40) or None,
            evidence_ids=tuple(_safe(v, limit=100) for v in list(evidence_ids)[:20]),
            response_outcome=_safe(response_outcome, limit=40).upper() or "FAILED",
            failure_category=category, missing_capability=_safe(missing_capability, limit=80) or None,
            iclirius_version=self.version, install_mode=self.install_mode,
            source_commit=self.source_commit, sensitivity="SENSITIVE_METADATA" if _SENSITIVE_NAME.search(summary) else "NORMAL",
            severity=severity or ("HIGH" if category in {"FALSE_ACCESS_DENIAL", "ROUTING_FAILURE", "SECURITY_INVARIANT"} else "MEDIUM"),
        )
        try:
            self.events_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
            with self._event_path().open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(event.to_dict(), ensure_ascii=False, sort_keys=True) + "\n")
                stream.flush(); os.fsync(stream.fileno())
            self.rebuild_aggregates()
        except OSError:
            # Observability must never break the user response.
            pass
        return event

    def events(self, *, since: str | None = None) -> list[CapabilityGapEvent]:
        result = []
        if not self.events_dir.exists(): return result
        for path in sorted(self.events_dir.glob("*.jsonl")):
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError: continue
            for line in lines:
                try:
                    data = json.loads(line)
                    if not isinstance(data, dict): continue
                    if since and str(data.get("timestamp", "")) < since: continue
                    data["evidence_ids"] = tuple(data.get("evidence_ids") or ())
                    result.append(CapabilityGapEvent(**data))
                except (ValueError, TypeError, json.JSONDecodeError):
                    continue
        return sorted(result, key=lambda item: item.timestamp)

    def aggregates(self, *, status: str | None = None, capability: str | None = None) -> list[CapabilityGapAggregate]:
        groups = {}
        for event in self.events():
            group = groups.setdefault(event.request_fingerprint, [])
            group.append(event)
        result = []
        for fingerprint, events in groups.items():
            latest = events[-1]
            status_value = latest.response_outcome if latest.response_outcome in {OPEN, FIXED, REGRESSION, WONT_FIX} else OPEN
            # An explicit lifecycle update can be represented by response_outcome.
            if status and status_value != status: continue
            if capability and (latest.requested_capability or "").casefold() != capability.casefold(): continue
            result.append(CapabilityGapAggregate(
                gap_id="gap_" + fingerprint, fingerprint=fingerprint,
                category=latest.failure_category, capability=latest.requested_capability,
                status=status_value, first_seen=events[0].timestamp, last_seen=latest.timestamp,
                occurrences=len(events), representative_summary=latest.safe_request_summary,
                latest_event_id=latest.event_id, latest_reason_code=latest.reason_code,
                severity=latest.severity))
        return sorted(result, key=lambda item: item.last_seen, reverse=True)

    def rebuild_aggregates(self) -> None:
        data = [item.to_dict() for item in self.aggregates()]
        try: _atomic_json(self.aggregate_path, data)
        except OSError: pass

    def show(self, gap_id: str) -> CapabilityGapAggregate | None:
        return next((item for item in self.aggregates() if item.gap_id == gap_id), None)

    def mark(self, gap_id: str, status: str, *, verification: str = "UNVERIFIED") -> bool:
        if status not in {OPEN, FIXED, REGRESSION, WONT_FIX}: raise ValueError("invalid gap status")
        target = self.show(gap_id)
        if not target: return False
        self.record(summary=target.representative_summary, normalized_intent=target.representative_summary,
                    capability=target.capability, reason_code=target.latest_reason_code,
                    failure_category=target.category, response_outcome=status,
                    channel="ledger", severity=target.severity,
                    fingerprint_override=target.fingerprint)
        return True


def gap_for_result(*, summary: str, trace=None, result=None, channel: str = "unknown",
                   ledger: CapabilityGapLedger | None = None, response: str = ""):
    """Record only actionable failures; return None when no gap is warranted."""
    if ledger is None: return None
    status = getattr(result, "status", None)
    reason = getattr(result, "reason_code", None) or getattr(trace, "web_failure_reason", None)
    capability = getattr(trace, "selected_capability", None)
    if status in {"SUCCESS"} and not ("no tengo acceso" in response.casefold() or "no puedo acceder" in response.casefold()):
        return None
    category = "UNKNOWN"
    if "no tengo acceso" in response.casefold() or "no puedo acceder" in response.casefold():
        if getattr(trace, "root_resolution_status", None) == "RESOLVED": category = "FALSE_ACCESS_DENIAL"
        else: return None
    elif reason in {"NO_TEXT", "FILE_TOO_LARGE", "UNSUPPORTED_FORMAT"}:
        category = "FILE_NO_TEXT" if reason == "NO_TEXT" else "FILE_EXTRACTION_FAILED"
    elif reason in {"WEB_UNAVAILABLE", "SEARCH_FAILED", "NO_RESULTS", "INSUFFICIENT_EVIDENCE"}:
        category = "WEB_" + reason.removeprefix("WEB_") if reason != "INSUFFICIENT_EVIDENCE" else "WEB_INSUFFICIENT_EVIDENCE"
    elif reason in {"UNSUPPORTED_FILTER", "UNSUPPORTED_AGGREGATION", "UNSUPPORTED_GROUPING", "UNSUPPORTED_DATE_RANGE"}:
        category = "UNSUPPORTED_QUERY"
    elif status == "BLOCKED": category = "AUTHORIZATION_BLOCK"
    elif status == "FAILED": category = "TOOL_FAILURE"
    elif status == "UNSUPPORTED": category = "UNSUPPORTED_CAPABILITY"
    else: category = "NO_EVIDENCE" if "no hay evidencia" in response.casefold() else "UNKNOWN"
    if category == "UNKNOWN": return None
    return ledger.record(summary=summary, normalized_intent=summary,
                         capability=capability, routing_decision=getattr(trace, "routing_decision", None),
                         selected_tool=getattr(trace, "selected_tool", None), tool_call_id=getattr(trace, "tool_call_id", None),
                         tool_status=status, reason_code=reason, coverage=getattr(trace, "coverage", None),
                         evidence_ids=getattr(trace, "evidence_ids", ()), response_outcome="FALSE_DENIAL" if category == "FALSE_ACCESS_DENIAL" else "FAILED",
                         failure_category=category, channel=channel)


def is_gap_question(message: str) -> bool:
    text = (message or "").casefold()
    return bool(re.search(r"(?:qu[eé]\s+(?:cosas|preguntas)|qu[eé]\s+no\s+sabes|qu[eé]\s+fall[oó]|"
                         r"qu[eé]\s+capacidades\s+te\s+faltan|what\s+failed|capability\s+gaps?)", text))


def render_summary(ledger: CapabilityGapLedger, *, limit: int = 8) -> str:
    items = ledger.aggregates(status=OPEN)[:limit]
    if not items:
        return "No hay fallos de capacidad abiertos registrados."
    lines = [f"Hay {len(ledger.aggregates(status=OPEN))} gaps de capacidad abiertos:"]
    lines.extend(f"- {item.category}: {item.representative_summary}" for item in items)
    return "\n".join(lines)
