"""Official lightweight Iclirius CLI entrypoint."""

from __future__ import annotations

import sys
import json
from app.version import VERSION


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    debug = "--debug" in args
    plain = "--plain" in args
    no_ui = "--no-ui" in args
    if debug:
        args = [arg for arg in args if arg != "--debug"]
    if plain:
        args = [arg for arg in args if arg != "--plain"]
    if no_ui:
        args = [arg for arg in args if arg != "--no-ui"]
    if args in (["--version"], ["-V"]):
        print(f"Iclirius {VERSION}")
        return 0
    if args in (["--version", "--details"], ["-V", "--details"]):
        from app.build_identity import collect
        print(f"Iclirius {VERSION}")
        print(json.dumps(collect(), ensure_ascii=False, sort_keys=True))
        return 0

    if args and args[0].lower() in {"/talk", "talk"}:
        if debug:
            print("[TALK-BOOT] cli dispatch", file=sys.stderr, flush=True)
        from app.talk.app import run_one_shot
        from app.logger import configure_cli_logging
        configure_cli_logging(debug=debug)
        language = "es"
        if "--language" in args:
            index = args.index("--language")
            if index + 1 < len(args):
                language = args[index + 1]
                args = args[:index] + args[index + 2:]
        return run_one_shot(debug=debug, language=language)

    if args and args[0].lower() == "doctor":
        from app.doctor import main as doctor_main
        return doctor_main(args[1:])

    if args and args[0].lower() == "setup":
        from app.setup import main as setup_main
        return setup_main(args[1:])

    if args and args[0].lower() == "auth":
        from app.auth_cli import main as auth_main
        return auth_main(args[1:])

    if args and args[0].lower() == "recovery":
        from app.auth_cli import main as auth_main
        # Recovery status intentionally exposes only existence/state, never
        # the verifier or secret material.
        if len(args) == 1 or args[1].lower() == "status":
            return auth_main(["status"])
        print("Usage: iclirius recovery status")
        return 2

    if args and args[0].lower() == "node":
        from app.node_cli import main as node_main
        return node_main(args[1:])

    # Cluster-2 keeps the compact top-level discovery view as a convenience;
    # all state and authorization remains implemented by node_cli.
    if args and args[0].lower() == "nodes":
        from app.node_cli import main as node_main
        return node_main(["nodes", *args[1:]])

    if args and args[0].lower() == "telegram":
        from app.telegram_cli import main as telegram_main
        return telegram_main(args[1:])

    if args and args[0].lower() == "repair":
        from app.repair import main as repair_main
        return repair_main(args[1:])

    if args and args[0].lower() in {"installation", "install-guide"}:
        from app.installation_cli import main as installation_main
        return installation_main(args[1:])

    if args and args[0].lower() == "ai":
        from app.ai_cli import main as ai_main
        return ai_main(args[1:])

    if args and args[0].lower() == "web":
        from app.web_cli import main as web_main
        return web_main(args[1:])

    if args and args[0].lower() in {"gaps", "capability-gaps"}:
        from app.gap_cli import main as gaps_main
        return gaps_main(args[1:])

    if args and args[0].lower() == "files":
        from app.file_content_cli import main as files_main
        return files_main(args[1:])

    if len(args) >= 2 and args[0].lower() == "memory" and args[1].lower() == "enrollment":
        from app.memory_cli import main as memory_main
        return memory_main(args[2:])

    from app.logger import configure_cli_logging
    configure_cli_logging(debug=debug)
    from app.config import settings
    if not args and not settings.setup_complete and sys.stdin.isatty() and sys.stdout.isatty():
        print("Iclirius is not configured on this machine.")
        print("Run: iclirius setup")
        return 2
    if sys.stdin.isatty() and sys.stdout.isatty():
        from app.local_auth import authenticate_interactive, status as get_auth_status
        from app.runtime_events import EventType, Status, emit
        # Phase 5 installations predate local-auth enrollment. Preserve their
        # existing interactive behavior until the user explicitly runs
        # `iclirius auth setup`; enrolled machines are always gated.
        if get_auth_status().get("enrolled"):
            try:
                emit(EventType.AUTH_REQUIRED, status=Status.STARTED, interface="cli")
            except Exception:
                pass
            if not plain:
                from app.auth_ui import run_auth_gate
                session = run_auth_gate(settings.principal_user_name, settings.user_id)
            else:
                session = authenticate_interactive()
            if session is None:
                return 2
    # Import the agent only after CLI logging has been configured.  Agent
    # construction registers providers and must never leak those diagnostics
    # into the normal conversation stream.
    from interfaces.cli_chat import _agent

    if not args:
        if not plain:
            from app.tui import IcliriusTUI
            if IcliriusTUI.compatible():
                while True:
                    result = IcliriusTUI(_agent).run()
                    if result != 42:
                        return result
                    from app.talk.app import run_talk
                    run_talk(_agent())
        from app.cli_session import InteractiveCLISession
        return InteractiveCLISession(_agent).run()

    # Preserve the established administrative/coding commands while making
    # the no-argument invocation the canonical interactive session.
    from interfaces.cli import main as legacy_main
    previous = sys.argv
    try:
        sys.argv = ["iclirius", *args]
        return int(legacy_main() or 0)
    finally:
        sys.argv = previous


if __name__ == "__main__":
    raise SystemExit(main())
