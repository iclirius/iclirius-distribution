"""Versioned, local installation instructions used by CLI and conversations."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from app.version import VERSION
import re


@dataclass(frozen=True)
class InstallationGuide:
    version: str
    supported_os: tuple[str, ...]
    profiles: tuple[str, ...]
    brew_install: tuple[str, ...]
    setup: tuple[str, ...]
    doctor: tuple[str, ...]
    update: tuple[str, ...]
    uninstall: tuple[str, ...]
    node_service: tuple[str, ...]
    telegram_failover: tuple[str, ...]
    safety: tuple[str, ...]

    def to_dict(self) -> dict:
        return asdict(self) | {key: list(value) for key, value in asdict(self).items()
                               if isinstance(value, tuple)}


def current_guide() -> InstallationGuide:
    return InstallationGuide(
        VERSION, ("macOS",),
        ("INTERFACE", "LOCAL_COMPUTE", "CODE_WORKER", "REMOTE_WORKER", "FULL_NODE"),
        ("brew tap iclirius/tap", "brew install iclirius/tap/iclirius"),
        ("iclirius setup", "Selecciona el perfil de nodo durante la configuración."),
        ("iclirius doctor", "iclirius doctor --fix"),
        ("brew update", "brew upgrade iclirius/tap/iclirius", "iclirius doctor"),
        ("brew uninstall iclirius/tap/iclirius",),
        ("iclirius node install", "iclirius node start", "iclirius node status",
         "iclirius node stop", "iclirius node restart", "iclirius node uninstall"),
        ("TELEGRAM_MODE=FAILOVER requiere un backend compartido confiable.",
         "iclirius telegram failover-status", "No uses una carpeta sincronizada como lock distribuido."),
        ("La instalación no requiere clonar el repositorio.",
         "Memory Home, identidad, credenciales y AllowedRoots nunca se borran automáticamente.",
         "Git y Ollama dependen del perfil seleccionado."),
    )


def render(profile: str | None = None) -> str:
    guide = current_guide()
    selected = profile.upper() if profile else "INTERFACE"
    lines = [f"Iclirius {guide.version} — instalación de nodo {selected}", "",
             "En una Mac nueva:", *guide.brew_install, *guide.setup, *guide.doctor,
             "", "Perfiles: " + ", ".join(guide.profiles),
             "", "Actualización:", *guide.update,
             "", "Servicio del nodo:", *guide.node_service,
             "", "Failover de Telegram:", *guide.telegram_failover,
             "", "Seguridad:", *guide.safety]
    return "\n".join(lines)


def is_installation_question(message: str) -> bool:
    text = (message or "").casefold()
    return bool(re.search(r"\b(instal(?:ar|aci[oó]n)|otra\s+mac|otro\s+nodo|nodo\s+de\s+c[oó]mputo|failover|doctor\s+--fix)\b", text))
