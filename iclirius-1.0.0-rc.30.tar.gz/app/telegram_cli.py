from __future__ import annotations
import argparse
import json
from pathlib import Path
from app.config import settings
from app.telegram_lease import LeaseBusy, diagnostics, provider_from_config


def _path() -> str:
    return settings.telegram_lease_database or settings.telegram_lease_path or str(
        Path.home() / ".iclirius" / "telegram-lease.json")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius telegram")
    parser.add_argument("command", nargs="?", default="status",
                        choices=("status", "failover-status", "activate", "standby"))
    parser.add_argument("--yes", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv or [])
    if args.command in {"status", "failover-status"}:
        data = diagnostics(mode=settings.telegram_mode, backend=settings.telegram_lease_backend,
                           token=settings.telegram_bot_token, node_id=settings.node_id,
                           user_id=settings.user_id, path=_path())
        print(json.dumps(data, indent=2, sort_keys=True) if args.json else
              "TELEGRAM\n" + "\n".join(f"  {k}: {v}" for k, v in data.items()))
        return 0
    if not settings.telegram_bot_token or not settings.user_id:
        print("Telegram activation blocked: identity or bot configuration is missing.")
        return 2
    if not args.yes:
        print("Explicit confirmation required; no Telegram lease change was made.")
        return 2
    provider = provider_from_config(settings.telegram_lease_backend, _path())
    try:
        if args.command == "activate":
            lease = provider.acquire(bot_token=settings.telegram_bot_token,
                                     node_id=settings.node_id, user_id=settings.user_id,
                                     ttl_seconds=settings.telegram_lease_ttl_seconds)
            print(json.dumps({"state": "ACTIVE", "generation": lease.generation}, sort_keys=True))
        else:
            current = provider.current(settings.telegram_bot_token)
            if current and current.owner_node_id == settings.node_id:
                provider.release(current)
            print(json.dumps({"state": "STANDBY"}, sort_keys=True))
        return 0
    except LeaseBusy:
        print("Telegram activation blocked: another healthy node owns the lease.")
        return 1
