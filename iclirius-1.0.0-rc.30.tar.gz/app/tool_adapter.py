"""Iclirius tool/capability boundary.

The native OpenClaw runtime is a separate Node process/package.  This module
keeps the Iclirius contract explicit and deterministic while exposing a
stable mapping point for a future native registry adapter.
"""
from __future__ import annotations

import re
import subprocess
import time
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

from app.config import settings
from app.evidence import Certainty, Coverage, EvidenceRecord, SourceType, certainty_for_coverage
from app.file_analysis import (ProjectQuery, detect_projects, file_query_evidence,
                               project_evidence, search_files, search_projects)
from app.file_content import FileContentRequest, FileContentService
from app.file_roots import RootProvider, RootResolutionStatus, resolve_file_root
from app.filesystem_evidence import FileRoot, FileScanSpec, scan
from app.web import WebFetchService, WebSearchService


INTEGRATION_MODE = "CONTRACT_ONLY_FOR_NOW"
READ = "READ"
WRITE = "WRITE"


@dataclass(frozen=True)
class IcliriusToolDescriptor:
    tool_id: str
    capability: str
    operation: str
    mode: str
    required_identity: bool
    required_node: bool
    required_root: bool
    confirmation_required: bool
    evidence_type: str | None
    implementation: str
    native_tool_mapping: str | None = None


@dataclass(frozen=True)
class ToolExecutionContext:
    user_id: str | None = None
    node_id: str | None = None
    root_id: str | None = None
    provider: str | None = None
    root_paths: tuple[str, ...] = ()
    session_id: str | None = None
    snapshot_id: str | None = None


@dataclass(frozen=True)
class FilesystemSnapshot:
    snapshot_id: str
    user_id: str | None
    node_id: str
    provider: str | None
    root_id: str | None
    started_at: str
    completed_at: str
    coverage: str
    scans: tuple
    observed_files: int
    observed_directories: int
    observed_bytes: int
    warnings: tuple[str, ...] = ()
    errors: tuple = ()
    max_entries: int | None = None
    expires_at: str = ""


@dataclass(frozen=True)
class ListToolArguments:
    provider: str | None = None
    root_id: str | None = None
    kind: str = "both"
    extension: str | None = None
    limit: int = 20
    recursive: bool = False


@dataclass(frozen=True)
class SearchToolArguments:
    provider: str | None = None
    root_id: str | None = None
    filename: str | None = None
    extension: str | None = None
    classification: str | None = None
    modified_before: str | None = None
    modified_after: str | None = None
    size_gt: int | None = None
    size_lt: int | None = None
    limit: int = 100


@dataclass(frozen=True)
class ProjectToolArguments:
    provider: str | None = None
    root_id: str | None = None
    language: str | None = None
    newest_modified_before: str | None = None
    last_git_commit_before: str | None = None
    limit: int = 1000


@dataclass(frozen=True)
class FilesystemQueryPlan:
    scope: str = "PERSONAL"
    provider: str | None = None
    root_id: str | None = None
    resource_kind: str = "both"
    operation: str = "LIST"
    filters: dict = field(default_factory=dict)
    aggregation: str | None = None
    group_by: str | None = None
    ordering: str | None = None
    direction: str | None = None
    limit: int = 20
    recursive: bool = False
    exhaustive: bool = False


@dataclass(frozen=True)
class ResultSet:
    result_set_id: str
    tool_call_id: str
    user_id: str | None
    node_id: str
    root_id: str | None
    query_plan: dict
    record_ids: tuple[str, ...]
    ordering: str | None
    coverage: str | None
    observed_count: int
    page_size: int
    created_at: str
    expires_at: str
    session_id: str | None = None
    evidence_ids: tuple[str, ...] = ()
    parent_result_set_id: str | None = None


_RESULT_SETS: dict[str, ResultSet] = {}
_RESULT_RECORDS: dict[str, tuple] = {}
_RESULT_VISIBLE_RECORDS: dict[str, tuple] = {}
_SNAPSHOTS: dict[str, FilesystemSnapshot] = {}
RESULT_SET_TTL_SECONDS = 15 * 60


def _new_result_set(call_id, context, plan, records, coverage, page_size, *, parent_result_set_id=None,
                    visible_records=None):
    now = time.time()
    result_id = f"result_{uuid.uuid4().hex}"
    visible = tuple(records if visible_records is None else visible_records)
    result = ResultSet(result_id, call_id, context.user_id, context.node_id or settings.node_id,
                       context.root_id, asdict(plan) if isinstance(plan, FilesystemQueryPlan) else dict(plan),
                       tuple(item.file_id for item in visible), plan.ordering if isinstance(plan, FilesystemQueryPlan) else plan.get("ordering"),
                       coverage, len(records), page_size, _stamp(),
                       datetime.fromtimestamp(now + RESULT_SET_TTL_SECONDS, timezone.utc).isoformat(timespec="seconds"),
                       context.session_id, (), parent_result_set_id)
    _RESULT_SETS[result_id] = result
    _RESULT_RECORDS[result_id] = tuple(records)
    _RESULT_VISIBLE_RECORDS[result_id] = visible
    return result


def get_result_set(result_set_id, context):
    result = _RESULT_SETS.get(result_set_id)
    if result is None or result.expires_at < _stamp():
        _RESULT_SETS.pop(result_set_id, None)
        _RESULT_RECORDS.pop(result_set_id, None)
        _RESULT_VISIBLE_RECORDS.pop(result_set_id, None)
        return None, "RESULT_SET_EXPIRED"
    if (result.user_id != context.user_id or result.node_id != (context.node_id or settings.node_id)
            or result.root_id != context.root_id
            or (context.session_id is not None and result.session_id != context.session_id)):
        return None, "RESULT_SET_SCOPE_MISMATCH"
    return result, None


def continue_result_set(result_set_id: str, *, context: ToolExecutionContext, page_size: int = 20):
    result, reason = get_result_set(result_set_id, context)
    if result is None:
        return None, reason
    rows = _RESULT_RECORDS.get(result_set_id, ())
    offset = result.page_size
    shown = rows[offset:offset + max(1, min(int(page_size), 100))]
    _RESULT_SETS[result_set_id] = replace(result, page_size=offset + len(shown))
    return {"result_set_id": result_set_id, "items": [row.to_dict() for row in shown],
            "offset": offset, "next_offset": offset + len(shown) if offset + len(shown) < len(rows) else None,
            "observed_count": result.observed_count, "coverage": result.coverage,
            "ordering": result.ordering}, None


def result_set_records(result_set_id: str, *, context: ToolExecutionContext):
    """Return the bounded records owned by a result set after scope checks."""
    result, reason = get_result_set(result_set_id, context)
    if result is None:
        return None, reason
    return tuple(_RESULT_VISIBLE_RECORDS.get(result_set_id, _RESULT_RECORDS.get(result_set_id, ()))), None


def attach_result_set_evidence(result_set_id: str, evidence_ids: tuple[str, ...]) -> None:
    result = _RESULT_SETS.get(result_set_id)
    if result is not None:
        _RESULT_SETS[result_set_id] = replace(result, evidence_ids=tuple(evidence_ids))


def _matching_records(scans, *, kind="both", extension=None, modified_before=None, modified_after=None,
                      size_gt=None, size_lt=None, ordering=None):
    ext = ("." + str(extension).casefold().lstrip(".")) if extension else None
    rows = []
    for item in scans:
        for record in item.records:
            if not record.accessible:
                continue
            if kind == "file" and not record.is_file or kind == "directory" and not record.is_directory:
                continue
            if kind == "both" and not (record.is_file or record.is_directory):
                continue
            if ext and record.extension != ext:
                continue
            if modified_before and (not record.modified_at or record.modified_at >= modified_before):
                continue
            if modified_after and (not record.modified_at or record.modified_at <= modified_after):
                continue
            if size_gt is not None and (record.size_bytes is None or record.size_bytes <= size_gt):
                continue
            if size_lt is not None and (record.size_bytes is None or record.size_bytes >= size_lt):
                continue
            rows.append(record)
    key = lambda row: ((row.modified_at or "9999"), row.relative_path)
    if ordering == "modified_at ASC": rows.sort(key=key)
    elif ordering == "modified_at DESC": rows.sort(key=lambda row: ((row.modified_at or ""), row.relative_path), reverse=True)
    elif ordering == "size ASC": rows.sort(key=lambda row: ((row.size_bytes if row.size_bytes is not None else 0), row.relative_path))
    elif ordering == "size DESC": rows.sort(key=lambda row: ((row.size_bytes if row.size_bytes is not None else 0), row.relative_path), reverse=True)
    elif ordering == "name ASC": rows.sort(key=lambda row: (row.name.casefold(), row.relative_path.casefold()))
    elif ordering == "name DESC": rows.sort(key=lambda row: (row.name.casefold(), row.relative_path.casefold()), reverse=True)
    else: rows.sort(key=lambda row: row.relative_path.casefold())
    return rows


@dataclass(frozen=True)
class ToolResult:
    tool_call_id: str
    tool_id: str
    capability: str
    status: str
    node_id: str
    user_id: str | None
    started_at: str
    finished_at: str
    duration_ms: int
    coverage: str | None = None
    evidence_ids: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    payload: dict = field(default_factory=dict)
    reason_code: str | None = None
    evidence_records: tuple[EvidenceRecord, ...] = field(default=(), repr=False)

    def to_dict(self) -> dict:
        value = asdict(self)
        value.pop("evidence_records", None)
        value["evidence_ids"] = list(self.evidence_ids)
        value["warnings"] = list(self.warnings)
        value["errors"] = list(self.errors)
        return value


def _stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _descriptors() -> tuple[IcliriusToolDescriptor, ...]:
    impl = {
        "filesystem.capability": "file_roots.resolve_file_root",
        "filesystem.count": "filesystem_evidence.scan",
        "filesystem.list": "filesystem_evidence.scan",
        "filesystem.search": "file_analysis.search_files",
        "filesystem.content": "file_content.FileContentService",
        "filesystem.projects": "file_analysis.detect_projects",
        "attachment.content": "attachment_gateway.AttachmentGateway + FILE-3",
        "web.search": "web.WebSearchService (C5.6)",
        "web.fetch": "web.WebFetchService (C5.6)",
        "git.status": "file_analysis.git_metadata",
        "git.history": "fixed-argument git log adapter",
    }
    rows = []
    for tool_id, capability, operation, native in (
        ("filesystem.capability", "FILESYSTEM_LOCAL", "CAPABILITY_CHECK", "filesystem.capability"),
        ("filesystem.count", "FILESYSTEM_LOCAL", "COUNT", "filesystem.count"),
        ("filesystem.list", "FILESYSTEM_LOCAL", "LIST", "filesystem.list"),
        ("filesystem.search", "FILESYSTEM_LOCAL", "SEARCH", "filesystem.search"),
        ("filesystem.content", "FILESYSTEM_LOCAL", "CONTENT", "filesystem.content"),
        ("filesystem.projects", "FILESYSTEM_LOCAL", "PROJECTS", "filesystem.projects"),
        ("attachment.content", "FILESYSTEM_LOCAL", "CONTENT", "attachment.content"),
        ("web.search", "WEB_PUBLIC", "SEARCH", "web.search"),
        ("web.fetch", "WEB_PUBLIC", "FETCH", "web.fetch"),
        ("git.status", "FILESYSTEM_LOCAL", "STATUS", "git.status"),
        ("git.history", "FILESYSTEM_LOCAL", "HISTORY", "git.history"),
    ):
        rows.append(IcliriusToolDescriptor(tool_id, capability, operation, READ,
                                           capability != "WEB_PUBLIC",
                                           tool_id.startswith(("filesystem.", "git.")),
                                           tool_id.startswith("filesystem."), False,
                                           "EvidenceRecord", impl[tool_id], native))
    for tool_id, operation in (("filesystem.trash", "TRASH"), ("filesystem.move", "MOVE"),
                               ("filesystem.rename", "RENAME")):
        rows.append(IcliriusToolDescriptor(tool_id, "FILESYSTEM_LOCAL", operation, WRITE, True, True,
                                           True, True, "ActionReceipt", "file_actions.ActionEngine", tool_id))
    return tuple(rows)


class IcliriusToolRegistry:
    """Deterministic registry and policy gate for Iclirius-facing tools."""

    def __init__(self, descriptors: tuple[IcliriusToolDescriptor, ...] | None = None):
        self._tools: dict[str, IcliriusToolDescriptor] = {}
        self._handlers: dict[str, Callable[..., ToolResult]] = {
            "filesystem.capability": self._filesystem_capability,
            "filesystem.count": self._filesystem_count,
            "filesystem.list": self._filesystem_list,
            "filesystem.search": self._filesystem_search,
            "filesystem.content": self._filesystem_content,
            "filesystem.projects": self._filesystem_projects,
            "attachment.content": self._attachment_content,
            "web.search": self._web_search,
            "web.fetch": self._web_fetch,
            "git.status": self._git_status,
            "git.history": self._git_history,
        }
        for descriptor in descriptors or _descriptors():
            self.register(descriptor)

    def register(self, descriptor: IcliriusToolDescriptor) -> None:
        if descriptor.tool_id in self._tools:
            raise ValueError(f"duplicate tool registration: {descriptor.tool_id}")
        if descriptor.mode not in {READ, WRITE}:
            raise ValueError("invalid tool mode")
        self._tools[descriptor.tool_id] = descriptor

    def descriptors(self) -> tuple[IcliriusToolDescriptor, ...]:
        return tuple(self._tools.values())

    def get(self, tool_id: str) -> IcliriusToolDescriptor | None:
        return self._tools.get(tool_id)

    def execute_content_chain(self, *, context: ToolExecutionContext, filename: str,
                              query: str = "", max_depth: int = 2) -> ToolResult:
        """Bounded deterministic search→content chain; never recurses autonomously."""
        if max_depth < 2:
            return self.execute("filesystem.content", context=context, path="")
        found = self.execute("filesystem.search", context=context, filename=filename, is_file=True, limit=2)
        chain = ["filesystem.search"]
        if found.status not in {"SUCCESS", "PARTIAL"} or not found.payload.get("items"):
            return replace(found, tool_id="filesystem.content", payload={"chain": chain, **found.payload},
                           reason_code=found.reason_code or "NO_MATCHES")
        if len(found.payload["items"]) > 1:
            return replace(found, tool_id="filesystem.content", payload={"chain": chain, **found.payload},
                           status="UNSUPPORTED", reason_code="AMBIGUOUS_RESOURCE")
        content = self.execute("filesystem.content", context=context,
                               path=found.payload["items"][0]["relative_path"], query=query)
        chain.append("filesystem.content")
        return replace(content, payload={"chain": chain, "resolved_file_id": found.payload["items"][0]["file_id"],
                                         **content.payload}, evidence_records=found.evidence_records + content.evidence_records,
                       evidence_ids=found.evidence_ids + content.evidence_ids)

    def create_filesystem_snapshot(self, *, context: ToolExecutionContext,
                                   provider: str | None = None) -> FilesystemSnapshot | None:
        """Perform one bounded authorized scan for a group of derived queries."""
        resolution, roots = self._roots(context, provider)
        if not roots:
            return None
        scans = tuple(scan(FileScanSpec(FileRoot.from_path(path, provider=_provider_value(resolution.provider),
                                                           user_id=context.user_id, require_allowed=True),
                                      recursive=True)) for path in roots)
        now = time.time(); snapshot_id = f"snapshot_{uuid.uuid4().hex}"
        coverage = "COMPLETE" if all(item.coverage == "COMPLETE" for item in scans) else (
            "FAILED" if all(item.coverage == "FAILED" for item in scans) else "PARTIAL")
        snapshot = FilesystemSnapshot(
            snapshot_id=snapshot_id, user_id=context.user_id,
            node_id=context.node_id or settings.node_id, provider=_provider_value(resolution.provider),
            root_id=context.root_id or (resolution.root.root_id if resolution.root else None),
            started_at=min((item.started_at for item in scans), default=_stamp()),
            completed_at=max((item.ended_at for item in scans), default=_stamp()),
            coverage=coverage, scans=scans,
            observed_files=sum(item.files_discovered for item in scans),
            observed_directories=sum(item.directories_discovered for item in scans),
            observed_bytes=sum(item.bytes_observed for item in scans),
            warnings=tuple(w for item in scans for w in item.warnings),
            errors=tuple(e for item in scans for e in item.errors),
            max_entries=max((item.max_entries for item in scans), default=None),
            expires_at=datetime.fromtimestamp(now + RESULT_SET_TTL_SECONDS, timezone.utc).isoformat(timespec="seconds"),
        )
        _SNAPSHOTS[snapshot_id] = snapshot
        return snapshot

    def execute(self, tool_id: str, *, context: ToolExecutionContext | None = None,
                **arguments: Any) -> ToolResult:
        context = context or ToolExecutionContext()
        descriptor = self._tools.get(tool_id)
        started = time.monotonic()
        start_stamp = _stamp()
        call_id = f"call_{uuid.uuid4().hex}"
        if descriptor is None:
            return self._blocked(call_id, tool_id, "TOOL_NOT_AVAILABLE", context, start_stamp, started)
        if descriptor.mode == WRITE:
            return self._blocked(call_id, tool_id, "WRITE_REQUIRES_FILE4_ACTION_ENGINE", context, start_stamp, started,
                                 capability=descriptor.capability)
        if descriptor.required_identity and not context.user_id:
            return self._blocked(call_id, tool_id, "IDENTITY_REQUIRED", context, start_stamp, started,
                                 capability=descriptor.capability)
        if descriptor.required_node and not (context.node_id or settings.node_id):
            return self._blocked(call_id, tool_id, "NODE_REQUIRED", context, start_stamp, started,
                                 capability=descriptor.capability)
        if descriptor.required_root and not context.root_paths:
            return self._blocked(call_id, tool_id, "ROOT_REQUIRED", context, start_stamp, started,
                                 capability=descriptor.capability)
        handler = self._handlers.get(tool_id)
        if handler is None:
            return self._blocked(call_id, tool_id, "UNSUPPORTED", context, start_stamp, started,
                                 capability=descriptor.capability)
        try:
            validation = _validate_arguments(tool_id, arguments)
            if validation:
                return self._blocked(call_id, tool_id, validation, context, start_stamp, started,
                                     capability=descriptor.capability)
            return handler(call_id, context, start_stamp, started, **arguments)
        except PermissionError as exc:
            return self._blocked(call_id, tool_id, str(exc), context, start_stamp, started,
                                 capability=descriptor.capability)
        except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
            return self._failed(call_id, tool_id, type(exc).__name__, context, start_stamp, started,
                                capability=descriptor.capability)

    def filter_result_set(self, result_set_id: str, *, context: ToolExecutionContext,
                          extension: str | None = None, size_gt: int | None = None,
                          size_lt: int | None = None, ordering: str | None = None,
                          limit: int = 20) -> ToolResult:
        """Derive a bounded result without rescanning a filesystem root."""
        started = time.monotonic(); stamp = _stamp(); call_id = f"call_{uuid.uuid4().hex}"
        parent, reason = get_result_set(result_set_id, context)
        if parent is None:
            return self._failed(call_id, "filesystem.search", reason or "RESULT_SET_SCOPE_MISMATCH",
                                context, stamp, started, capability="FILESYSTEM_LOCAL")
        # Derived conversational queries operate on the visible page, never
        # on records hidden behind pagination.
        rows = list(_RESULT_VISIBLE_RECORDS.get(result_set_id, _RESULT_RECORDS.get(result_set_id, ())))
        # Derived queries are strict in-memory transformations.  The parent
        # scope is authoritative; a caller cannot substitute another root or
        # cause a fresh filesystem scan.
        if parent.root_id != context.root_id or parent.user_id != context.user_id \
                or parent.node_id != (context.node_id or settings.node_id) \
                or (parent.session_id and parent.session_id != context.session_id):
            return self._failed(call_id, "filesystem.search", "RESULTSET_SCOPE_MISMATCH",
                                context, stamp, started, capability="FILESYSTEM_LOCAL")
        ext = ("." + extension.casefold().lstrip(".")) if extension else None
        rows = [row for row in rows if (not ext or row.extension == ext)
                and (size_gt is None or (row.size_bytes is not None and row.size_bytes > size_gt))
                and (size_lt is None or (row.size_bytes is not None and row.size_bytes < size_lt))]
        if ordering == "modified_at ASC": rows.sort(key=lambda row: (row.modified_at or "9999", row.relative_path))
        elif ordering == "modified_at DESC": rows.sort(key=lambda row: (row.modified_at or "", row.relative_path), reverse=True)
        elif ordering == "size DESC": rows.sort(key=lambda row: (row.size_bytes or 0, row.relative_path), reverse=True)
        elif ordering == "size ASC": rows.sort(key=lambda row: (row.size_bytes or 0, row.relative_path))
        plan_data = dict(parent.query_plan); filters = dict(plan_data.get("filters") or {})
        if extension: filters["extension"] = ext
        if size_gt is not None: filters["size_gt"] = size_gt
        if size_lt is not None: filters["size_lt"] = size_lt
        plan_data.update(filters=filters, ordering=ordering or parent.ordering,
                         limit=max(1, min(int(limit), 100)))
        page_size = max(1, min(int(limit), 100))
        shown = rows[:page_size]
        derived = _new_result_set(call_id, context, plan_data, rows, parent.coverage,
                                  page_size, parent_result_set_id=result_set_id,
                                  visible_records=shown)
        _RESULT_SETS[derived.result_set_id] = replace(derived, evidence_ids=parent.evidence_ids)
        payload = {"items": [row.to_dict() for row in shown], "matched_count": len(rows),
                   "matched_count_observed": len(rows), "result_set_id": derived.result_set_id,
                   "displayed_record_ids": [row.file_id for row in shown],
                   "parent_result_set_id": result_set_id, "ordering": ordering or parent.ordering,
                   "coverage": parent.coverage, "filters": filters}
        derived_result = self._base(call_id, "filesystem.search", "FILESYSTEM_LOCAL",
                                    "SUCCESS" if parent.coverage == "COMPLETE" else "PARTIAL",
                                    context, stamp, started, coverage=parent.coverage, payload=payload,
                                    reason_code="NO_MATCHES" if not rows else None)
        return replace(derived_result, evidence_ids=parent.evidence_ids)

    def _base(self, call_id, tool_id, capability, status, context, start_stamp, started, *,
              coverage=None, payload=None, evidence=(), warnings=(), errors=(), reason_code=None):
        records = tuple(evidence)
        return ToolResult(call_id, tool_id, capability, status, context.node_id or settings.node_id,
                          context.user_id, start_stamp, _stamp(), int((time.monotonic() - started) * 1000),
                          coverage, tuple(item.evidence_id for item in records), tuple(warnings), tuple(errors),
                          payload or {}, reason_code or _reason_code(errors), records)

    def _blocked(self, call_id, tool_id, error, context, start_stamp, started, *, capability=""):
        return self._base(call_id, tool_id, capability, "BLOCKED", context, start_stamp, started, errors=(error,))

    def _failed(self, call_id, tool_id, error, context, start_stamp, started, *, capability=""):
        return self._base(call_id, tool_id, capability, "FAILED", context, start_stamp, started, errors=(error,))

    def _roots(self, context: ToolExecutionContext, provider: str | None = None):
        requested = RootProvider(provider or context.provider or RootProvider.LOCAL.value)
        resolution = resolve_file_root(provider=requested, allowed_roots=context.root_paths,
                                       node_id=context.node_id or settings.node_id, user_id=context.user_id)
        if resolution.status == RootResolutionStatus.AMBIGUOUS:
            roots = tuple(item.canonical_path for item in resolution.candidates)
        elif resolution.root:
            roots = (resolution.root.canonical_path,)
        else:
            roots = ()
        return resolution, roots

    def _authorized_path(self, context: ToolExecutionContext, value: str) -> Path:
        target = Path(value).expanduser().resolve(strict=False)
        roots = [Path(root).expanduser().resolve(strict=False) for root in context.root_paths]
        if not roots or not any(target == root or root in target.parents for root in roots):
            raise PermissionError("ROOT_NOT_AUTHORIZED")
        return target

    def _scan(self, context, *, recursive=True, provider=None):
        if context.snapshot_id:
            snapshot = _SNAPSHOTS.get(context.snapshot_id)
            if snapshot is not None and snapshot.expires_at >= _stamp():
                if (snapshot.user_id == context.user_id
                        and snapshot.node_id == (context.node_id or settings.node_id)
                        and snapshot.provider == (provider or context.provider or snapshot.provider)
                        and (not context.root_id or snapshot.root_id == context.root_id)):
                    resolution = resolve_file_root(provider=provider or context.provider or snapshot.provider,
                                                   allowed_roots=context.root_paths,
                                                   node_id=context.node_id or settings.node_id,
                                                   user_id=context.user_id)
                    return resolution, snapshot.scans
            # A supplied snapshot is an authority boundary. Never silently
            # fall back to a fresh scan for a different scope or expired ID.
            resolution, _ = self._roots(context, provider)
            return resolution, ()
        resolution, roots = self._roots(context, provider)
        if resolution.status not in {RootResolutionStatus.RESOLVED, RootResolutionStatus.AMBIGUOUS}:
            return resolution, ()
        scans = tuple(scan(FileScanSpec(FileRoot.from_path(path, provider=_provider_value(resolution.provider),
                                                           user_id=context.user_id, require_allowed=True),
                                      recursive=recursive)) for path in roots)
        return resolution, scans

    def _filesystem_capability(self, call_id, context, start_stamp, started, *, provider=None, **_):
        resolution, _ = self._roots(context, provider)
        payload = {"provider": _provider_value(resolution.provider), "resolution_status": resolution.status.value,
                   "accessible": resolution.status in {RootResolutionStatus.RESOLVED, RootResolutionStatus.AMBIGUOUS},
                   "authorized": resolution.status in {RootResolutionStatus.RESOLVED, RootResolutionStatus.AMBIGUOUS},
                   "node_id": context.node_id or settings.node_id, "display_name": resolution.root.display_name if resolution.root else None}
        status = "SUCCESS" if payload["accessible"] else "FAILED"
        return self._base(call_id, "filesystem.capability", "FILESYSTEM_LOCAL", status, context, start_stamp, started,
                          coverage="COMPLETE", payload=payload)

    def _filesystem_count(self, call_id, context, start_stamp, started, *, provider=None, kind="both",
                          extension=None, modified_before=None, modified_after=None, size_gt=None, size_lt=None,
                          ordering=None, aggregation="COUNT", group_by=None, **_):
        resolution, scans = self._scan(context, recursive=True, provider=provider)
        if not scans:
            return self._base(call_id, "filesystem.count", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage=resolution.status.value, errors=(_resolution_reason(resolution.status),))
        coverage = "COMPLETE" if all(item.coverage == "COMPLETE" for item in scans) else "PARTIAL"
        rows = _matching_records(scans, kind=kind, extension=extension, modified_before=modified_before,
                                 modified_after=modified_after, size_gt=size_gt, size_lt=size_lt, ordering=ordering)
        plan = FilesystemQueryPlan(provider=_provider_value(resolution.provider), resource_kind=kind, operation="COUNT",
                                   filters={"extension": extension, "modified_before": modified_before,
                                            "modified_after": modified_after, "size_gt": size_gt, "size_lt": size_lt},
                                   aggregation=aggregation, group_by=group_by, ordering=ordering, limit=0, recursive=True)
        result_set = _new_result_set(call_id, context, plan, rows, coverage, 0)
        grouped = {}
        if group_by == "EXTENSION":
            for row in rows:
                key = row.extension or "[sin extensión]"
                contribution = (row.size_bytes or 0) if aggregation == "SUM_SIZE" else 1
                grouped[key] = grouped.get(key, 0) + contribution
        if aggregation == "DISTINCT_TYPES":
            # Keep the distinct set lossless, but order the presentation by
            # observed frequency so human responses start with useful types.
            groups = [{"key": key, "observed_count": value}
                      for key, value in grouped.items()]
            groups.sort(key=lambda item: (-item["observed_count"], item["key"]))
        else:
            groups = [{"key": key, "value": value} for key, value in grouped.items()]
        if ordering in {"count DESC", "total_size DESC"}:
            groups.sort(key=lambda item: item["value"], reverse=True)
        elif ordering in {"count ASC", "total_size ASC"}:
            groups.sort(key=lambda item: item["value"])
        payload = {"snapshot_id": context.snapshot_id,
                   "files_observed": sum(1 for row in rows if row.is_file),
                   "directories_observed": sum(1 for row in rows if row.is_directory),
                   "matched_count_observed": len(rows), "bytes_observed": sum(row.size_bytes or 0 for row in rows if row.is_file),
                   "coverage": coverage, "provider": _provider_value(resolution.provider), "result_set_id": result_set.result_set_id,
                   "filters": plan.filters, "aggregation": aggregation, "group_by": group_by,
                   "groups": groups[:100], "total_size": sum(row.size_bytes or 0 for row in rows if row.is_file)}
        records = tuple(_scan_evidence(item, "filesystem.count", payload) for item in scans)
        attach_result_set_evidence(result_set.result_set_id, tuple(item.evidence_id for item in records))
        return self._base(call_id, "filesystem.count", "FILESYSTEM_LOCAL", "SUCCESS" if coverage == "COMPLETE" else "PARTIAL",
                          context, start_stamp, started, coverage=coverage, payload=payload, evidence=records)

    def _filesystem_list(self, call_id, context, start_stamp, started, *, provider=None, kind="both",
                         extension=None, limit=20, recursive=False, ordering=None, offset=0, exhaustive=False, **_):
        resolution, scans = self._scan(context, recursive=recursive, provider=provider)
        if not scans:
            return self._base(call_id, "filesystem.list", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage=resolution.status.value, errors=(_resolution_reason(resolution.status),))
        limit = max(1, min(int(limit), 100))
        rows = _matching_records(scans, kind=kind, extension=extension, ordering=ordering)
        shown = rows[max(0, int(offset)):max(0, int(offset)) + limit]
        plan = FilesystemQueryPlan(provider=_provider_value(resolution.provider), resource_kind=kind, operation="LIST",
                                   filters={"extension": extension}, ordering=ordering, limit=limit,
                                   recursive=recursive, exhaustive=exhaustive)
        coverage = "COMPLETE" if all(item.coverage == "COMPLETE" for item in scans) else "PARTIAL"
        result_set = _new_result_set(call_id, context, plan, rows, coverage, limit,
                                     visible_records=shown)
        payload = {"snapshot_id": context.snapshot_id, "items": [row.to_dict() for row in shown], "matched_count_observed": len(rows),
                   "limit": limit, "offset": offset, "next_offset": int(offset) + len(shown) if int(offset) + len(shown) < len(rows) else None,
                   "kind": kind, "extension": extension, "ordering": ordering, "coverage": coverage,
                   "result_set_id": result_set.result_set_id, "displayed_record_ids": [row.file_id for row in shown],
                   "exhaustive": exhaustive}
        records = tuple(_scan_evidence(item, "filesystem.list", payload) for item in scans)
        attach_result_set_evidence(result_set.result_set_id, tuple(item.evidence_id for item in records))
        return self._base(call_id, "filesystem.list", "FILESYSTEM_LOCAL", "SUCCESS" if coverage == "COMPLETE" else "PARTIAL",
                          context, start_stamp, started, coverage=coverage, payload=payload, evidence=records,
                          reason_code="NO_MATCHES" if not rows and coverage == "COMPLETE" else None)

    def _filesystem_search(self, call_id, context, start_stamp, started, *, provider=None, ordering=None,
                           offset=0, exhaustive=False, **filters):
        resolution, scans = self._scan(context, recursive=True, provider=provider)
        if not scans:
            return self._base(call_id, "filesystem.search", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage=resolution.status.value, errors=(_resolution_reason(resolution.status),))
        from app.filesystem_evidence import FileQuery
        requested_extension = filters.get("extension")
        normalized_extension = (
            ("." + str(requested_extension).casefold().lstrip("."))
            if requested_extension else None
        )
        spec = FileQuery(root_id=context.root_id, filename=filters.get("filename"), name_contains=filters.get("name_contains"),
                         extension=normalized_extension, classification=filters.get("classification"),
                         modified_before=filters.get("modified_before"), modified_after=filters.get("modified_after"),
                         size_gt=filters.get("size_gt"), size_lt=filters.get("size_lt"),
                         is_file=filters.get("is_file"), is_directory=filters.get("is_directory"),
                         limit=max(1, min(int(filters.get("limit", 100)), 1000)))
        rows = _matching_records(scans, kind="file" if filters.get("is_file") else "directory" if filters.get("is_directory") else "both",
                                 extension=normalized_extension, modified_before=filters.get("modified_before"),
                                 modified_after=filters.get("modified_after"), size_gt=filters.get("size_gt"),
                                 size_lt=filters.get("size_lt"), ordering=ordering)
        if filters.get("filename"):
            rows = [row for row in rows if row.name == filters["filename"]]
        if filters.get("name_contains"):
            rows = [row for row in rows if filters["name_contains"].casefold() in row.name.casefold()]
        if filters.get("classification"):
            rows = [row for row in rows if row.classification == filters["classification"]]
        shown = rows[max(0, int(offset)):max(0, int(offset)) + int(filters.get("limit", 100))]
        matched_ids = [row.file_id for row in rows]
        record_map = {row.file_id: row.to_dict() for item in scans for row in item.records}
        coverage = "COMPLETE" if all(item.coverage == "COMPLETE" for item in scans) else "PARTIAL"
        records = tuple(file_query_evidence(search_files(item, spec)) for item in scans)
        plan = FilesystemQueryPlan(provider=_provider_value(resolution.provider), resource_kind="file", operation="SEARCH",
                                   filters={key: filters.get(key) for key in ("filename", "extension", "classification", "modified_before", "modified_after", "size_gt", "size_lt")},
                                   ordering=ordering, limit=int(filters.get("limit", 100)), recursive=True, exhaustive=exhaustive)
        result_set = _new_result_set(call_id, context, plan, rows, coverage, int(filters.get("limit", 100)),
                                     visible_records=shown)
        # Search evidence is attached after the bounded result set is created,
        # preserving provenance for derived referents.
        attach_result_set_evidence(result_set.result_set_id, tuple(item.evidence_id for item in records))
        return self._base(call_id, "filesystem.search", "FILESYSTEM_LOCAL", "SUCCESS" if coverage == "COMPLETE" else "PARTIAL",
                          context, start_stamp, started, coverage=coverage,
                          payload={"snapshot_id": context.snapshot_id, "matched_file_ids": matched_ids, "matched_count": len(matched_ids),
                                   "items": [record_map[row.file_id] for row in shown], "next_offset": int(offset) + len(shown) if int(offset) + len(shown) < len(rows) else None,
                                   "result_set_id": result_set.result_set_id, "displayed_record_ids": [row.file_id for row in shown],
                                   "query": asdict(spec), "ordering": ordering, "exhaustive": exhaustive}, evidence=records,
                          reason_code="NO_MATCHES" if not matched_ids and coverage == "COMPLETE" else None)

    def _filesystem_content(self, call_id, context, start_stamp, started, *, path, query="", **_):
        resolution, roots = self._roots(context)
        if resolution.status != RootResolutionStatus.RESOLVED or not roots:
            return self._base(call_id, "filesystem.content", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage=resolution.status.value, errors=(_resolution_reason(resolution.status),))
        service = FileContentService(roots[0])
        # Authorized filesystem referents may use bounded large-PDF reading;
        # the attachment gateway keeps its conservative default separately.
        request = FileContentRequest(path, query,
                                     max_chars=int(getattr(settings, "file_content_max_characters", 20000)),
                                     max_pages=int(getattr(settings, "file_content_max_pages", 10)),
                                     allow_large_pdf=True)
        evidence = service.search(request) if query else [service.extract(request)]
        records = tuple(item.evidence for item in evidence if item.evidence)
        states = tuple(item.state for item in evidence)
        usable = any(item.state in {"READABLE", "PARTIAL"} and item.content for item in evidence)
        if usable and all(item.state == "READABLE" and not item.truncated for item in evidence):
            status, coverage, reason = "SUCCESS", "COMPLETE", None
        elif usable:
            status, coverage, reason = "PARTIAL", "PARTIAL", "PARTIAL_TEXT"
        elif any(item.state == "NO_EXTRACTABLE_TEXT" for item in evidence):
            status, coverage, reason = "UNSUPPORTED", "NO_TEXT", "NO_TEXT"
        elif any(item.state == "EMPTY" for item in evidence):
            status, coverage, reason = "SUCCESS", "COMPLETE", "EMPTY"
        elif any(item.state == "ENCRYPTED" for item in evidence):
            status, coverage, reason = "UNSUPPORTED", "ENCRYPTED", "ENCRYPTED"
        elif any(item.state == "TOO_LARGE" for item in evidence):
            status, coverage, reason = "UNSUPPORTED", "UNSUPPORTED", "FILE_TOO_LARGE"
        elif any(item.state == "UNSUPPORTED_FORMAT" for item in evidence):
            status, coverage, reason = "UNSUPPORTED", "UNSUPPORTED", "UNSUPPORTED_FORMAT"
        else:
            status, coverage, reason = "FAILED", "FAILED", "EXTRACTION_FAILED"
        return self._base(call_id, "filesystem.content", "FILESYSTEM_LOCAL", status, context, start_stamp, started,
                          coverage=coverage, payload={"content": [item.to_dict() for item in evidence],
                          "content_state": states[0] if len(set(states)) == 1 and states else None,
                          "usable_text": usable}, evidence=records, reason_code=reason)

    def _filesystem_projects(self, call_id, context, start_stamp, started, *, provider=None, query=None, **_):
        resolution, scans = self._scan(context, recursive=True, provider=provider)
        if not scans:
            return self._base(call_id, "filesystem.projects", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage=resolution.status.value, errors=(_resolution_reason(resolution.status),))
        projects = tuple(project for item in scans for project in detect_projects(item))
        spec = query if isinstance(query, ProjectQuery) else ProjectQuery()
        results = [search_projects(item, detect_projects(item), spec) for item in scans]
        records = tuple(project_evidence(item, projects) for item in results)
        coverage = "COMPLETE" if all(item.coverage == "COMPLETE" for item in scans) else "PARTIAL"
        matched_ids = [i for result in results for i in result.matched_project_ids]
        selected = [p.to_dict() for p in projects if p.project_id in set(matched_ids)]
        return self._base(call_id, "filesystem.projects", "FILESYSTEM_LOCAL", "SUCCESS" if coverage == "COMPLETE" else "PARTIAL",
                          context, start_stamp, started, coverage=coverage, payload={"projects": selected,
                          "matched_project_ids": matched_ids, "matched_count": len(matched_ids)}, evidence=records,
                          reason_code="NO_MATCHES" if not matched_ids and coverage == "COMPLETE" else None)

    def _attachment_content(self, call_id, context, start_stamp, started, *, gateway, attachment_id, query="", **_):
        if not context.user_id:
            return self._blocked(call_id, "attachment.content", "IDENTITY_REQUIRED", context, start_stamp, started,
                                 capability="FILESYSTEM_LOCAL")
        try:
            file_record, content, evidence = gateway.extract(attachment_id, user_id=context.user_id,
                                                              node_id=context.node_id or settings.node_id, query=query)
        except PermissionError as exc:
            return self._blocked(call_id, "attachment.content", str(exc), context, start_stamp, started,
                                 capability="FILESYSTEM_LOCAL")
        except (OSError, ValueError) as exc:
            return self._failed(call_id, "attachment.content", type(exc).__name__, context, start_stamp, started,
                                capability="FILESYSTEM_LOCAL")
        status = "SUCCESS" if content.state in {"EXTRACTED", "EMPTY"} else "PARTIAL" if content.state == "PARTIALLY_EXTRACTED" else "FAILED"
        reason = None if status in {"SUCCESS", "PARTIAL"} else "CONTENT_EXTRACTION_FAILED"
        return self._base(call_id, "attachment.content", "FILESYSTEM_LOCAL", status, context, start_stamp, started,
                          coverage=content.state, payload={"attachment_id": attachment_id,
                          "file_id": file_record.file_id, "content": content.to_dict()}, evidence=(evidence,),
                          reason_code=reason)

    def _web_search(self, call_id, context, start_stamp, started, *, query, max_results=5, **_):
        record = WebSearchService().evidence(query, max_results)
        return self._base(call_id, "web.search", "WEB_PUBLIC", "SUCCESS" if record.coverage.complete else "PARTIAL",
                          context, start_stamp, started, coverage="COMPLETE" if record.coverage.complete else "PARTIAL",
                          payload=record.result, evidence=(record,))

    def _web_fetch(self, call_id, context, start_stamp, started, *, url, **_):
        record = WebFetchService().evidence(url)
        return self._base(call_id, "web.fetch", "WEB_PUBLIC", "SUCCESS" if record.coverage.complete else "PARTIAL",
                          context, start_stamp, started, coverage="COMPLETE" if record.coverage.complete else "PARTIAL",
                          payload=record.result, evidence=(record,))

    def _git_status(self, call_id, context, start_stamp, started, *, path, **_):
        from app.file_analysis import git_metadata
        self._authorized_path(context, path)
        metadata = git_metadata(path)
        record = EvidenceRecord(SourceType.GIT.value, "git.status", str(path), metadata.to_dict(),
                                Coverage(complete=metadata.available), Certainty.VERIFIED.value if metadata.available else Certainty.UNVERIFIED.value,
                                tool_id="git.status", node_id=context.node_id or settings.node_id)
        return self._base(call_id, "git.status", "FILESYSTEM_LOCAL", "SUCCESS" if metadata.available else "FAILED",
                          context, start_stamp, started, coverage="COMPLETE" if metadata.available else "FAILED",
                          payload=metadata.to_dict(), evidence=(record,))

    def _git_history(self, call_id, context, start_stamp, started, *, path, limit=20, **_):
        self._authorized_path(context, path)
        command = ["git", "-C", str(path), "log", "-n", str(max(1, min(int(limit), 100))), "--format=%H%x09%cI%x09%s"]
        result = subprocess.run(command, capture_output=True, text=True, timeout=5, check=False)
        if result.returncode != 0:
            return self._base(call_id, "git.history", "FILESYSTEM_LOCAL", "FAILED", context, start_stamp, started,
                              coverage="FAILED", errors=("NOT_A_REPOSITORY",))
        rows = [dict(zip(("commit", "timestamp", "subject"), line.split("\t", 2))) for line in result.stdout.splitlines() if line.strip()]
        record = EvidenceRecord(SourceType.GIT.value, "git.history", str(path), {"commits": rows}, Coverage(complete=True),
                                Certainty.VERIFIED.value, tool_id="git.history", node_id=context.node_id or settings.node_id)
        return self._base(call_id, "git.history", "FILESYSTEM_LOCAL", "SUCCESS", context, start_stamp, started,
                          coverage="COMPLETE", payload={"commits": rows}, evidence=(record,))


def _scan_evidence(result, operation, payload) -> EvidenceRecord:
    coverage = Coverage(complete=result.coverage == "COMPLETE", scanned_items=len(result.records),
                        inaccessible_items=result.stats_failed, errors=len(result.errors), reason=result.coverage)
    return EvidenceRecord(SourceType.FILESYSTEM.value, operation, result.root.root_id, {
        "scan": result.to_dict(include_records=False), "payload": payload}, coverage,
        certainty_for_coverage(coverage), observed_at=result.started_at,
        provenance={"root_id": result.root.root_id, "node_id": result.root.node_id,
                    "provider": result.root.provider, "coverage_status": result.coverage,
                    **({"snapshot_id": payload.get("snapshot_id")} if payload.get("snapshot_id") else {})},
        node_id=result.root.node_id, tool_id=operation, duration_ms=result.duration_ms,
        errors=tuple(item.get("reason", "error") for item in result.errors), warnings=result.warnings)


def resolve_tool_for_message(message: str, capability: str, *, operation: str | None = None) -> str | None:
    """Deterministic operation resolver; phrase semantics stay composable."""
    from app.capability_router import normalize_query_for_intent
    text = normalize_query_for_intent(message).casefold()
    if capability == "FILESYSTEM_LOCAL":
        if re.search(r"\b(cu[aá]les?|m[aá]s\s+grandes?|m[aá]s\s+peque)\b", text) and re.search(r"\b(ocupan?|espacio|archivos?)\b", text): return "filesystem.list"
        if (re.search(r"\b(cu[aá]ntos?|cantidad|tipos?|espacio|ocupan)\b", text)
                and re.search(r"\b(archivos?|pdfs?|xml|csv|json|docx|carpetas?|directorios?|tipos?|espacio)\b", text)): return "filesystem.count"
        if re.search(r"\b(cu[aá]ntos?|cantidad)\b", text): return "filesystem.count"
        if re.search(r"\b(lista|listar|dame|nombres?|mu[eé]strame|qu[eé]\s+carpetas?|m[aá]s\s+(?:antigu|reciente|nuevo|grande|peque)|todos?|todas?)\b", text): return "filesystem.list"
        if re.search(r"\b(busca|buscar|encuentra|d[oó]nde)\b", text): return "filesystem.search"
        if re.search(r"\b(qu[eé]\s+contiene|qu[eé]\s+dice|resume|resumen)\b", text): return "filesystem.content"
        if re.search(r"\b(proyectos?|actividad)\b", text): return "filesystem.projects"
        if re.search(r"\b(puedes\s+ver|acceso|accesible)\b", text): return "filesystem.capability"
    if capability == "WEB_PUBLIC":
        return "web.search" if operation != "FETCH" else "web.fetch"
    return None


def build_filesystem_query_plan(message: str, *, provider: str | None = None,
                                root_id: str | None = None) -> FilesystemQueryPlan:
    """Compose independent metadata signals into one deterministic plan.

    This helper is interface-neutral; Telegram and CLI callers use the same
    plan before dispatch.  It intentionally returns a plan even when a later
    execution layer marks one dimension unsupported.
    """
    from app.capability_router import normalize_query_for_intent
    text = normalize_query_for_intent(message).casefold()
    extension_match = re.search(r"(?:\.|\b)(pdf|xml|csv|json|docx|txt|md)\b", text)
    extension = "." + extension_match.group(1) if extension_match else None
    kind = "file" if extension or re.search(r"\b(archivos?|pdfs?)\b", text) else (
        "directory" if re.search(r"\b(carpetas?|directorios?)\b", text) else "both")
    if re.search(r"\b(cu[aá]ntos?|cantidad)\b", text): operation, aggregation = "COUNT", "COUNT"
    elif re.search(r"\b(cu[aá]nto|espacio|ocupan?)\b", text): operation, aggregation = "COUNT", "SUM_SIZE"
    elif re.search(r"\b(proyectos?|actividad)\b", text): operation, aggregation = "PROJECTS", None
    elif re.search(r"\b(busca|buscar|encuentra)\b", text): operation, aggregation = "SEARCH", None
    else: operation, aggregation = "LIST", None
    group_by = "EXTENSION" if re.search(r"tipos?|cada\s+tipo|de\s+qu[eé]\s+tipo", text) else None
    if group_by and not re.search(r"cu[aá]ntos?|cantidad|cada\s+tipo", text):
        aggregation = "DISTINCT_TYPES"
    ordering = None
    if re.search(r"m[aá]s\s+antigu|m[aá]s\s+viejo|oldest", text): ordering = "modified_at ASC"
    elif re.search(r"m[aá]s\s+(?:reciente|nuevo)|newest", text): ordering = "modified_at DESC"
    elif re.search(r"m[aá]s\s+grande|m[aá]s\s+pesado|ocupan\s+m[aá]s|largest", text): ordering = "size DESC"
    elif re.search(r"m[aá]s\s+peque|smallest", text): ordering = "size ASC"
    elif re.search(r"orden.*nombre|alfab", text): ordering = "name ASC"
    if group_by and aggregation == "COUNT": ordering = ordering or "count DESC"
    if group_by and aggregation == "SUM_SIZE": ordering = ordering or "total_size DESC"
    size = re.search(r"(?:mayor(?:es)?\s+de|m[aá]s\s+de|greater\s+than)\s+(\d+(?:\.\d+)?)\s*(kb|mb|gb)", text)
    size_gt = int(float(size.group(1)) * {"kb": 1024, "mb": 1024**2, "gb": 1024**3}[size.group(2)]) if size else None
    limit_match = re.search(r"\b(?:lista|listar|dame|muestra|mu[eé]strame)\s+(?:los\s+|las\s+)?(\d+)\b", text)
    limit = max(1, min(int(limit_match.group(1)), 100)) if limit_match else 20
    return FilesystemQueryPlan(provider=provider, root_id=root_id, resource_kind=kind,
                               operation=operation, aggregation=aggregation, group_by=group_by,
                               ordering=ordering, direction=(ordering.split()[-1] if ordering else None),
                               filters={"extension": extension, "size_gt": size_gt,
                                        "modified_after": parse_modified_after(text)},
                               limit=limit, recursive=operation in {"SEARCH", "PROJECTS"} or bool(ordering),
                               exhaustive=bool(re.search(r"\b(todos?|todas?|all|everything)\b", text)))


def parse_modified_after(text: str, *, now: datetime | None = None) -> str | None:
    """Resolve supported calendar phrases without model interpretation."""
    value = (text or "").casefold()
    local_now = (now or datetime.now().astimezone())
    year_match = re.search(r"desde\s+enero(?:\s+de)?\s+(\d{4})", value)
    if year_match:
        return f"{int(year_match.group(1)):04d}-01-01"
    if re.search(r"desde\s+enero|este\s+año|este\s+ano", value):
        return f"{local_now.year:04d}-01-01"
    days_match = re.search(r"(?:[uú]ltimos?|last)\s+(\d+)\s+d[ií]as?", value)
    if days_match:
        return (local_now - timedelta(days=int(days_match.group(1)))).date().isoformat()
    return None


default_registry = IcliriusToolRegistry()


def _reason_code(errors) -> str | None:
    return errors[0] if errors else None


def _resolution_reason(status: RootResolutionStatus) -> str:
    return {
        RootResolutionStatus.AMBIGUOUS: "AMBIGUOUS_ROOT",
        RootResolutionStatus.UNAVAILABLE: "ROOT_UNAVAILABLE",
        RootResolutionStatus.NOT_AUTHORIZED: "ROOT_NOT_AUTHORIZED",
        RootResolutionStatus.NOT_CONFIGURED: "ROOT_NOT_CONFIGURED",
        RootResolutionStatus.IDENTITY_REQUIRED: "IDENTITY_REQUIRED",
        RootResolutionStatus.WRONG_NODE: "WRONG_NODE",
    }.get(status, status.value)


def _provider_value(provider) -> str:
    return provider.value if hasattr(provider, "value") else str(provider)


def _validate_arguments(tool_id: str, arguments: dict) -> str | None:
    if tool_id == "filesystem.list":
        if arguments.get("kind", "both") not in {"file", "directory", "both"}:
            return "INVALID_KIND"
        if not isinstance(arguments.get("limit", 20), int) or not 1 <= arguments.get("limit", 20) <= 100:
            return "INVALID_LIMIT"
        if not isinstance(arguments.get("recursive", False), bool):
            return "INVALID_RECURSIVE"
    elif tool_id == "filesystem.search":
        if not isinstance(arguments.get("limit", 100), int) or not 1 <= arguments.get("limit", 100) <= 1000:
            return "INVALID_LIMIT"
        for key in ("is_file", "is_directory"):
            if arguments.get(key) is not None and not isinstance(arguments[key], bool):
                return "INVALID_FILE_KIND"
    elif tool_id == "filesystem.content":
        if not isinstance(arguments.get("path"), str) or not arguments.get("path"):
            return "PATH_REQUIRED"
    elif tool_id in {"git.status", "git.history"}:
        if not isinstance(arguments.get("path"), str) or not arguments.get("path"):
            return "PATH_REQUIRED"
    elif tool_id == "attachment.content":
        if not arguments.get("attachment_id") or arguments.get("gateway") is None:
            return "ATTACHMENT_REQUIRED"
    return None


def validate_tool_arguments(tool_id: str, arguments: dict) -> tuple[bool, str | None]:
    """Machine-readable validation entrypoint for callers and tests."""
    reason = _validate_arguments(tool_id, arguments)
    return reason is None, reason
