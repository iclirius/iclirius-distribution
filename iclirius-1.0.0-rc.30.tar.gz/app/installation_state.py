"""Profile-relative installation readiness.

This module only interprets Doctor evidence.  It does not probe or repair the
machine and deliberately keeps optional capabilities separate from blockers.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from app.node_health import ROLE_REQUIREMENTS, normalize_role


STATES = ("COMPLETE", "DEGRADED", "INCOMPLETE", "BLOCKED")


@dataclass(frozen=True)
class InstallationAssessment:
    profile: str
    state: str
    required: tuple[str, ...]
    missing_required: tuple[str, ...]
    optional_missing: tuple[str, ...]
    repairable: tuple[str, ...]
    manual: tuple[str, ...]
    generated_at: str

    def to_dict(self) -> dict:
        return asdict(self) | {"required": list(self.required),
                               "missing_required": list(self.missing_required),
                               "optional_missing": list(self.optional_missing),
                               "repairable": list(self.repairable),
                               "manual": list(self.manual)}


def assess(report: dict, profile: str | None = None) -> InstallationAssessment:
    selected = normalize_role(profile or report.get("current_role") or
                              report.get("node_role") or "INTERFACE")
    requirements = ROLE_REQUIREMENTS[selected]
    caps = report.get("capability_profile", {}).get("capabilities", {})
    if not caps:
        caps = {item.get("id", ""): item for item in
                report.get("capability_audit", {}).get("capabilities", [])}
    # NodeCapabilityProfile uses operational names; the capability audit uses
    # ids.  The profile is authoritative when available.
    missing = tuple(name for name in requirements["required"]
                    if caps.get(name, {}).get("available") is not True)
    optional = tuple(name for name in requirements.get("recommended", ())
                     if caps.get(name, {}).get("available") is not True)
    explicit_degraded = tuple(str(item) for item in report.get("degraded_capabilities", ()))
    # Setup-owned identity and Memory Home require user choices and are never
    # silently repaired by Doctor.  Runtime dependencies may be proposed by
    # the existing RepairPlanner after setup is complete.
    repairable_ids = {"local_reasoning", "version_control", "voice"}
    repairable = tuple(name for name in missing if name in repairable_ids)
    manual = tuple(name for name in missing if name not in repairable_ids)
    if not missing:
        # Recommended/optional capabilities are reported separately and do not
        # block installation completion for the selected profile.
        state = "DEGRADED" if explicit_degraded else "COMPLETE"
    elif repairable:
        state = "INCOMPLETE"
    else:
        state = "BLOCKED"
    return InstallationAssessment(
        selected, state, tuple(requirements["required"]), missing, optional,
        repairable, manual, datetime.now(timezone.utc).isoformat(timespec="seconds"))


def render(assessment: InstallationAssessment) -> str:
    lines = ["INSTALLATION", f"Profile: {assessment.profile}",
             f"Status: {assessment.state}"]
    if assessment.missing_required:
        lines.append("Required missing: " + ", ".join(assessment.missing_required))
    if assessment.optional_missing:
        lines.append("Optional missing: " + ", ".join(assessment.optional_missing))
    if assessment.repairable:
        lines.append("Repairable: " + ", ".join(assessment.repairable))
    if assessment.manual:
        lines.append("Manual intervention: " + ", ".join(assessment.manual))
    return "\n".join(lines)
