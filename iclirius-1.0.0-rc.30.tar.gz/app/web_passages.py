"""Bounded, deterministic query-centered passage selection for web evidence."""
from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass

from app.config import settings
from app.web_grounding import GroundedEvidence

MAX_PASSAGE_CHARS = 1200
MAX_PASSAGES_PER_DOCUMENT = 40
MAX_CANDIDATE_PASSAGES = 160
MAX_SELECTED_PASSAGES = 8
MAX_SELECTED_PER_DOCUMENT = 3
MAX_PASSAGE_PREVIEW_CHARS = 180
_WORD = re.compile(r"(?:\d+(?:\.\d+)+|[\w]{2,})", re.UNICODE)
_SENTENCE = re.compile(r".+?(?:[.!?](?=\s|$)|$)", re.DOTALL)
_STOP = set("a an and are as at be by can do for from how in into is it of on or the this to was what when where which who why with about according busca cuál que como del los las una uno para por según es son fue changed change improve improvements in".split())
_ALIASES = {
    "repl": {"interactive", "interpreter", "shell"},
    "interpreter": {"repl", "interactive"},
    "shell": {"repl", "interactive", "interpreter"},
}


@dataclass(frozen=True)
class EvidencePassage:
    passage_id: str
    evidence_id: str
    text: str
    heading: str
    start_offset: int
    end_offset: int
    relevance: str
    reason: str
    role: str = "DIRECT"
    truncated: bool = False
    duplicate_of: str = ""
    source_metadata: dict | None = None

    def to_dict(self, *, include_text: bool = False) -> dict:
        value = asdict(self)
        metadata = dict(value.get("source_metadata") or {})
        value["source_metadata"] = metadata
        value["text_chars"] = len(self.text)
        value["preview"] = self.text[:MAX_PASSAGE_PREVIEW_CHARS]
        if not include_text:
            value.pop("text", None)
        return value


@dataclass(frozen=True)
class PassageSelection:
    intent: str
    candidates: tuple[EvidencePassage, ...]
    generated_passage_count: int
    selected: tuple[EvidencePassage, ...]
    evidence: tuple[GroundedEvidence, ...]
    packed_context: str
    context_budget_chars: int
    rejected: tuple[dict, ...] = ()

    @property
    def context_chars_used(self) -> int:
        return len(self.packed_context)

    @property
    def context_budget_remaining(self) -> int:
        return max(0, self.context_budget_chars - self.context_chars_used)

    def to_dict(self) -> dict:
        counts: dict[str, int] = {}
        for item in self.selected:
            counts[item.evidence_id] = counts.get(item.evidence_id, 0) + 1
        context_limited = any("context budget" in item.get("reason", "")
                              for item in self.rejected)
        return {
            "intent": self.intent,
            "document_count": len(self.evidence),
            "total_passages": self.generated_passage_count,
            "unique_passages": len(self.candidates),
            "duplicate_passage_count": max(0, self.generated_passage_count - len(self.candidates)),
            "selected_passage_count": len(self.selected),
            "rejected_passage_count": len(self.rejected),
            "selected_passages_per_evidence": counts,
            "context_chars_used": self.context_chars_used,
            "context_budget_chars": self.context_budget_chars,
            "context_budget_remaining": self.context_budget_remaining,
            "truncated": any(item.truncated for item in self.candidates),
            "context_budget_limited": context_limited,
            "passages": [item.to_dict() for item in self.selected],
            "rejected": list(self.rejected[:MAX_CANDIDATE_PASSAGES]),
        }


def _tokens(text: str) -> set[str]:
    return {token.lower() for token in _WORD.findall(text or "") if token.lower() not in _STOP}


def _blocks(item: GroundedEvidence) -> list[tuple[int, int, str, str, str]]:
    """Return (start,end,text,heading,kind) blocks with offsets into record content."""
    content = str(item.record.result.get("content", ""))
    structured = item.record.result.get("sections") or []
    blocks = []
    if isinstance(structured, list):
        for section in structured[:128]:
            if not isinstance(section, dict):
                continue
            try:
                start = max(0, int(section.get("start_offset", 0)))
                end = min(len(content), int(section.get("end_offset", len(content))))
            except (TypeError, ValueError):
                continue
            if end <= start:
                continue
            text = content[start:end].strip()
            if text:
                # Trimming is reflected in offsets, not guessed later.
                leading = len(content[start:end]) - len(content[start:end].lstrip())
                actual_start = start + leading
                blocks.append((actual_start, actual_start + len(text), text,
                               str(section.get("heading", ""))[:300],
                               str(section.get("kind", "CONTENT"))))
    if blocks:
        return blocks

    heading = ""
    for match in re.finditer(r"[^\n]+(?:\n+|$)", content):
        raw = match.group(0)
        line = raw.strip()
        if not line:
            continue
        markdown = re.match(r"^#{1,6}\s+(.+)$", line)
        if markdown:
            heading = markdown.group(1).strip()[:300]
            continue
        start = match.start() + len(raw) - len(raw.lstrip())
        end = match.start() + len(raw.rstrip())
        blocks.append((start, end, content[start:end], heading, "CONTENT"))
    if blocks:
        return blocks
    if content.strip():
        start = len(content) - len(content.lstrip())
        end = len(content.rstrip())
        return [(start, end, content[start:end], "", "CONTENT")]
    return []


def _split_block(start: int, end: int, text: str, heading: str, kind: str,
                 evidence: GroundedEvidence, max_chars: int) -> list[EvidencePassage]:
    if kind.upper() == "HEADING":
        return []
    chunks: list[tuple[int, int]] = []
    if len(text) <= max_chars:
        chunks.append((0, len(text)))
    else:
        sentence_spans = [match.span() for match in _SENTENCE.finditer(text)
                          if match.group(0).strip()]
        cursor = 0
        for s_start, s_end in sentence_spans:
            if s_end - cursor > max_chars and s_start > cursor:
                chunks.append((cursor, s_start))
                cursor = s_start
            while s_end - cursor > max_chars:
                chunks.append((cursor, cursor + max_chars))
                cursor += max_chars - 120
            if s_end - cursor >= max_chars:
                continue
        if cursor < len(text):
            chunks.append((cursor, len(text)))
        if not chunks:
            cursor = 0
            while cursor < len(text):
                end_at = min(len(text), cursor + max_chars)
                chunks.append((cursor, end_at))
                if end_at == len(text):
                    break
                cursor = end_at - 120

    result = evidence.record.result
    source_metadata = {
        "title": str(result.get("title", ""))[:300],
        "url": evidence.record.target,
        "content_type": str(result.get("content_type", "")),
        "retrieval": str(result.get("retrieval", "")),
        "document_truncated": bool(result.get("truncated", False)),
    }
    passages = []
    for chunk_index, (left, right) in enumerate(chunks[:12], start=1):
        body = text[left:right].strip()
        if not body:
            continue
        trim = len(text[left:right]) - len(text[left:right].lstrip())
        absolute_start = start + left + trim
        absolute_end = min(end, absolute_start + len(body))
        passages.append(EvidencePassage(
            passage_id=f"{evidence.evidence_id}:P{chunk_index}",
            evidence_id=evidence.evidence_id, text=body, heading=heading[:300],
            start_offset=absolute_start, end_offset=absolute_end,
            relevance="LOW", reason="not ranked", truncated=bool(result.get("truncated", False)) or
            (right - left < len(text) and len(chunks) > 1), source_metadata=source_metadata,
        ))
    return passages


def segment_evidence(evidence: list[GroundedEvidence], *,
                     max_passage_chars: int = MAX_PASSAGE_CHARS) -> tuple[EvidencePassage, ...]:
    """Segment a bounded set of selected evidence documents into passages."""
    output = []
    for item in evidence[:10]:
        document_count = 0
        for start, end, text, heading, kind in _blocks(item):
            pieces = _split_block(start, end, text, heading, kind, item,
                                  max(200, min(MAX_PASSAGE_CHARS, max_passage_chars)))
            for passage in pieces:
                document_count += 1
                # IDs are stable in source order even when relevance later changes.
                output.append(EvidencePassage(
                    passage_id=f"{item.evidence_id}:P{document_count}",
                    evidence_id=passage.evidence_id, text=passage.text, heading=passage.heading,
                    start_offset=passage.start_offset, end_offset=passage.end_offset,
                    relevance=passage.relevance, reason=passage.reason,
                    truncated=passage.truncated, source_metadata=passage.source_metadata,
                ))
                if document_count >= MAX_PASSAGES_PER_DOCUMENT or len(output) >= MAX_CANDIDATE_PASSAGES:
                    break
            if document_count >= MAX_PASSAGES_PER_DOCUMENT or len(output) >= MAX_CANDIDATE_PASSAGES:
                break
        if len(output) >= MAX_CANDIDATE_PASSAGES:
            break
    return tuple(output)


def _query_terms(query: str) -> tuple[set[str], set[str], str]:
    terms = _tokens(query)
    expanded = set(terms)
    for term in tuple(terms):
        expanded.update(_ALIASES.get(term, ()))
    sequence = [token.lower() for token in _WORD.findall(query or "") if token.lower() not in _STOP]
    return terms, expanded, " ".join(sequence[:32])


def _rank_passages(query: str, passages: tuple[EvidencePassage, ...], intent: str) -> tuple[EvidencePassage, ...]:
    terms, expanded, phrase = _query_terms(query)
    document_frequency: dict[str, int] = {}
    token_sets = []
    for passage in passages:
        tokens = _tokens(passage.text)
        token_sets.append(tokens)
        for token in tokens:
            document_frequency[token] = document_frequency.get(token, 0) + 1
    ranked = []
    for index, passage in enumerate(passages):
        text_tokens = token_sets[index]
        heading_tokens = _tokens(passage.heading)
        body_hits = terms & text_tokens
        heading_hits = terms & heading_tokens
        alias_hits = (expanded - terms) & (text_tokens | heading_tokens)
        denominator = max(1, len(terms))
        coverage = len(body_hits) / denominator
        phrase_match = len(terms) > 1 and phrase in " ".join(_WORD.findall(passage.text.lower()))
        score = 0.0
        for token in body_hits:
            # Rare query words within this bounded candidate set weigh more.
            score += 1.0 + (len(passages) - document_frequency.get(token, len(passages))) / max(1, len(passages))
        score += 2.5 * len(heading_hits) + 0.65 * len(alias_hits)
        if phrase_match:
            score += 4.0
        if bool(passage.source_metadata and passage.source_metadata.get("document_truncated")):
            score -= 0.2
        relevance = "HIGH" if phrase_match or (heading_hits and coverage >= 0.20) or coverage >= 0.60 else "MEDIUM" if coverage >= 0.25 or (heading_hits and alias_hits) else "LOW"
        if phrase_match:
            reason = "query phrase match"
        elif heading_hits and alias_hits:
            reason = "heading and deterministic synonym match"
        elif heading_hits:
            reason = "heading/query term overlap"
        elif alias_hits and coverage:
            reason = "query terms with bounded alias match"
        elif body_hits:
            reason = "query token overlap"
        else:
            reason = "no meaningful query overlap"
        ranked.append((score, index, EvidencePassage(
            passage_id=passage.passage_id, evidence_id=passage.evidence_id, text=passage.text,
            heading=passage.heading, start_offset=passage.start_offset, end_offset=passage.end_offset,
            relevance=relevance, reason=reason, role="DIRECT", truncated=passage.truncated,
            source_metadata=passage.source_metadata,
        )))
    ranked.sort(key=lambda row: (-row[0], row[1]))
    return tuple(row[2] for row in ranked)


def _duplicate(left: EvidencePassage, right: EvidencePassage) -> bool:
    a = re.sub(r"\s+", " ", left.text).strip().casefold()
    b = re.sub(r"\s+", " ", right.text).strip().casefold()
    if a == b:
        return True
    if left.evidence_id == right.evidence_id:
        overlap = max(0, min(left.end_offset, right.end_offset) - max(left.start_offset, right.start_offset))
        shorter = min(left.end_offset - left.start_offset, right.end_offset - right.start_offset)
        if shorter and overlap / shorter >= 0.75:
            return True
    return False


def _format_passage(passage: EvidencePassage) -> str:
    metadata = passage.source_metadata or {}
    # All source-controlled strings are enclosed with the untrusted evidence.
    return (
        "<<<UNTRUSTED WEB PASSAGE BEGIN — UNTRUSTED DATA>>>\n"
        f"Citation evidence ID: [{passage.evidence_id}]\n"
        f"Internal passage ID: {passage.passage_id}\n"
        f"Source title: {metadata.get('title', '')}\n"
        f"Source URL: {metadata.get('url', '')}\n"
        f"Heading: {passage.heading}\n"
        f"Passage role: {passage.role}; selection reason: {passage.reason}\n"
        f"Offsets in extracted source text: {passage.start_offset}-{passage.end_offset}\n"
        f"Content:\n{passage.text}\n"
        "<<<UNTRUSTED WEB PASSAGE END>>>"
    )


def select_passages(query: str, evidence: list[GroundedEvidence], *,
                    context_budget_chars: int | None = None) -> PassageSelection:
    from app.web_selection import classify_query_intent

    budget = max(0, min(32_000, context_budget_chars if context_budget_chars is not None
                         else settings.context_evidence_max_chars))
    raw = segment_evidence(evidence)
    ranked = _rank_passages(query, raw, classify_query_intent(query))
    unique = []
    rejected: list[dict] = []
    for passage in ranked:
        prior = next((item for item in unique if _duplicate(item, passage)), None)
        if prior:
            rejected.append({"passage_id": passage.passage_id, "evidence_id": passage.evidence_id,
                             "reason": f"duplicate passage of {prior.passage_id}"})
        else:
            unique.append(passage)
    # Evidence IDs from C5.6-C retain their input order for round-robin packing.
    doc_order = {item.evidence_id: index for index, item in enumerate(evidence)}
    relevant = [item for item in unique if item.relevance != "LOW"]
    by_doc: dict[str, list[EvidencePassage]] = {}
    for passage in relevant:
        by_doc.setdefault(passage.evidence_id, []).append(passage)
    selected: list[EvidencePassage] = []
    selected_ids: set[str] = set()
    used = 0
    for passage in unique:
        if passage.relevance == "LOW":
            rejected.append({"passage_id": passage.passage_id,
                             "evidence_id": passage.evidence_id,
                             "reason": "no relevant passage match"})
    intent = classify_query_intent(query)
    if intent in {"DOCUMENTATION", "NAVIGATION"}:
        packing_order = [item for item in unique if item.relevance != "LOW"]
    else:
        packing_order = []
        doc_ids = sorted(by_doc, key=lambda key: doc_order.get(key, 999))
        depth = 0
        while any(depth < len(by_doc[key]) for key in doc_ids):
            for evidence_id in doc_ids:
                if depth < len(by_doc[evidence_id]):
                    packing_order.append(by_doc[evidence_id][depth])
            depth += 1
    for passage in packing_order:
        if len(selected) >= MAX_SELECTED_PASSAGES:
            rejected.append({"passage_id": passage.passage_id,
                             "evidence_id": passage.evidence_id,
                             "reason": "selected passage limit"})
            continue
        evidence_id = passage.evidence_id
        if sum(item.evidence_id == evidence_id and item.role == "DIRECT" for item in selected) >= MAX_SELECTED_PER_DOCUMENT:
            rejected.append({"passage_id": passage.passage_id, "evidence_id": evidence_id,
                             "reason": "passages per document limit"})
            continue
        formatted = _format_passage(passage)
        separator_chars = 2 if selected else 0
        if used + len(formatted) + separator_chars > budget:
            rejected.append({"passage_id": passage.passage_id, "evidence_id": evidence_id,
                             "reason": "context budget"})
            continue
        selected.append(passage)
        selected_ids.add(passage.passage_id)
        used += len(formatted) + separator_chars

    # Add at most one neighboring content block per selected direct match,
    # and only within the same heading/section to avoid unrelated page spill.
    direct = list(selected)
    for passage in direct:
        if len(selected) >= MAX_SELECTED_PASSAGES:
            break
        source_passages = [item for item in raw if item.evidence_id == passage.evidence_id]
        source_passages.sort(key=lambda item: item.start_offset)
        index = next((i for i, item in enumerate(source_passages) if item.passage_id == passage.passage_id), -1)
        if index < 0:
            continue
        neighbors = []
        for neighbor_index in (index - 1, index + 1):
            if not 0 <= neighbor_index < len(source_passages):
                continue
            neighbor = source_passages[neighbor_index]
            if neighbor.heading != passage.heading or neighbor.passage_id in selected_ids or len(neighbor.text) > 600:
                continue
            neighbors.append(neighbor)
        for neighbor in neighbors[:1]:
            contextual = EvidencePassage(
                passage_id=neighbor.passage_id, evidence_id=neighbor.evidence_id,
                text=neighbor.text, heading=neighbor.heading, start_offset=neighbor.start_offset,
                end_offset=neighbor.end_offset, relevance=neighbor.relevance,
                reason="adjacent context for " + passage.passage_id, role="CONTEXT",
                truncated=neighbor.truncated, source_metadata=neighbor.source_metadata,
            )
            cost = len(_format_passage(contextual)) + 2
            if used + cost <= budget:
                selected.append(contextual)
                selected_ids.add(contextual.passage_id)
                used += cost
            else:
                rejected.append({"passage_id": contextual.passage_id,
                                 "evidence_id": contextual.evidence_id,
                                 "reason": "context budget for neighboring passage"})

    selected_evidence_ids = {item.evidence_id for item in selected}
    selected_evidence = tuple(item for item in evidence if item.evidence_id in selected_evidence_ids)
    # Keep passage order grouped by source then source offset for readable context.
    selected.sort(key=lambda item: (doc_order.get(item.evidence_id, 999), item.start_offset,
                                    item.role != "DIRECT"))
    packed = "\n\n".join(_format_passage(item) for item in selected)
    return PassageSelection(intent, tuple(unique), len(raw), tuple(selected),
                            selected_evidence, packed, budget, tuple(rejected[:MAX_CANDIDATE_PASSAGES]))
