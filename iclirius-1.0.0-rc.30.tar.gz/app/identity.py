"""
Who Iclirius is, independently of whatever model is doing the thinking.

Three things get confused constantly, and the confusion is what makes a local
assistant answer "soy Qwen":

    Iclirius      the assistant and orchestrator the user talks to
    Ollama        the runtime that hosts a model
    qwen2.5:14b   the reasoning engine currently in use

They are not equivalent. The model is a resource Iclirius uses, the way a
person uses a calculator without becoming one. Swapping qwen for something
else changes which engine reasons; it does not change who the user is talking
to, because continuity, memory, state and decisions live here, not in the
model's weights.

So identity is answered locally. Direct identity questions never depend on a
model remembering its instructions — a small local model will eventually
forget them, and the answer would then be wrong in the one case where being
wrong is most visible. The identity block still goes into every prompt for
everything else.

Nothing here contains anything about the user. Identity is the assistant's,
not the person's.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.config import settings

# Providers and model families a hosted model may mistake itself for. Used
# only to recognise the question, never to state anything about them.
KNOWN_PROVIDERS = (
    "qwen", "alibaba", "ollama", "llama", "meta", "mistral", "deepseek",
    "gemini", "google", "claude", "anthropic", "openai", "gpt", "chatgpt",
    "kimi", "moonshot", "grok", "xai", "cohere", "phi", "microsoft",
)


@dataclass(frozen=True)
class Identity:
    """The canonical contract. Small on purpose: it ships in every prompt."""

    name: str
    role: str
    framework: str = "OpenClaw"
    principles: tuple[str, ...] = field(default_factory=tuple)

    def prompt_block(self, runtime: str = "", model: str = "") -> str:
        """
        The identity a reasoning model is given.

        Kept to a few lines because it is paid for on every single request.
        The engine is named explicitly so the model can answer honestly about
        which one is running without confusing that for who it is.
        """
        lines = [
            f"Eres {self.name}, {self.role}.",
            f"{self.name} es quien habla con la persona usuaria; "
            f"el modelo de lenguaje activo es un motor de razonamiento que "
            f"{self.name} usa.",
        ]

        if model:
            engine = f"{runtime}/{model}" if runtime else model
            lines.append(
                f"Motor activo ahora mismo: {engine}. "
                f"Puedes decirlo si te lo preguntan, pero no eres ese modelo."
            )

        lines.append(
            f"No te identifiques como Qwen, Ollama, Alibaba, Gemini, Google, "
            f"Claude, Anthropic, OpenAI, Kimi ni ningún otro proveedor o "
            f"modelo: son motores, no identidades."
        )

        return "\n".join(lines)

    def summary(self) -> str:
        return f"{self.name} — {self.role}"


IDENTITY = Identity(
    name="Iclirius",
    role="asistente y orquestador personal local-first",
    principles=(
        "Iclirius conserva la continuidad; los modelos sólo razonan.",
        "El proveedor y el modelo no definen la identidad.",
        "El estado local es la fuente de verdad.",
        "El contexto del modelo es desechable.",
    ),
)


def display_name() -> str:
    """
    The name to show.

    settings.agent_name stays authoritative so an existing configuration is
    not overridden, but it is presented properly capitalised rather than as
    the lowercase identifier it is stored as.
    """
    configured = (settings.agent_name or "").strip()

    if not configured or configured.lower() == IDENTITY.name.lower():
        return IDENTITY.name

    return configured


def identity_prompt(runtime: str = "", model: str = "") -> str:
    return IDENTITY.prompt_block(runtime=runtime, model=model)


# --- recognising an identity question -------------------------------------

_WHO = re.compile(
    r"\b(?:qui[ée]n\s+eres|c[óo]mo\s+te\s+llamas|qu[ée]\s+eres|"
    r"who\s+are\s+you|preséntate|presentate)\b", re.IGNORECASE)

_ARE_YOU_MODEL = re.compile(
    r"\b(?:eres|sos|are\s+you)\b[^?]{0,40}\b(?:" + "|".join(KNOWN_PROVIDERS) + r")\b",
    re.IGNORECASE)

_WHICH_MODEL = re.compile(
    r"\b(?:qu[ée]|cu[áa]l)\b[^?]{0,40}\b(?:modelo|motor|llm|runtime)\b"
    r"|\bwhich\s+model\b|\bqu[ée]\s+modelo\s+(?:eres|usas|est[áa]s)\b",
    re.IGNORECASE)

_WHO_MADE = re.compile(
    r"\b(?:qui[ée]n\s+te\s+(?:cre[óo]|hizo|program[óo]|desarroll[óo])|"
    r"who\s+(?:made|created|built)\s+you|de\s+qui[ée]n\s+eres)\b", re.IGNORECASE)


class IdentityQuestion:
    WHO = "who"
    IS_MODEL = "is_model"
    WHICH_MODEL = "which_model"
    WHO_MADE = "who_made"


def classify(message: str) -> str | None:
    """
    Which identity question this is, if any.

    Order matters. "¿Eres Qwen?" also contains "eres", so the more specific
    provider question is checked before the generic one.
    """
    text = (message or "").strip()

    if not text:
        return None

    if _WHICH_MODEL.search(text):
        return IdentityQuestion.WHICH_MODEL

    if _WHO_MADE.search(text):
        return IdentityQuestion.WHO_MADE

    if _ARE_YOU_MODEL.search(text):
        return IdentityQuestion.IS_MODEL

    if _WHO.search(text):
        return IdentityQuestion.WHO

    return None


def named_provider(message: str) -> str | None:
    """Which provider the user asked about, for a specific answer."""
    lowered = (message or "").lower()

    for provider in KNOWN_PROVIDERS:
        if re.search(rf"\b{re.escape(provider)}\b", lowered):
            return provider

    return None


def answer(message: str, runtime: str = "", model: str = "") -> str | None:
    """
    Answer an identity question locally, or return None to answer normally.

    Deterministic because this is the one question where a model drifting from
    its instructions is both most likely and most visible. It costs no tokens
    and cannot regress when the engine is swapped.
    """
    kind = classify(message)

    if kind is None:
        return None

    name = display_name()
    engine = f"{runtime}/{model}" if runtime and model else (model or "")

    if kind == IdentityQuestion.WHICH_MODEL:
        if not engine:
            return (
                f"Soy {name}. Ahora mismo no tengo un motor de razonamiento "
                f"activo que reportar."
            )

        return (
            f"El motor de razonamiento activo es {engine}.\n"
            f"Yo soy {name}: ese modelo es la herramienta con la que pienso, "
            f"no quien soy. Si mañana cambia el motor, sigo siendo {name}."
        )

    if kind == IdentityQuestion.IS_MODEL:
        provider = named_provider(message) or "ese modelo"
        answer_lines = [f"No, soy {name}, {IDENTITY.role}."]

        if engine and provider.lower() in engine.lower():
            answer_lines.append(
                f"Lo que sí es cierto: {engine} es el motor de razonamiento "
                f"que estoy usando ahora. Es una herramienta mía, no mi identidad."
            )
        elif engine:
            answer_lines.append(
                f"Mi motor activo es {engine}, no {provider}. "
                f"Y en cualquier caso el motor no define quién soy."
            )
        else:
            answer_lines.append(
                f"{provider.capitalize()} sería como mucho un motor de "
                f"razonamiento, no mi identidad."
            )

        return "\n".join(answer_lines)

    if kind == IdentityQuestion.WHO_MADE:
        lines = [
            f"Soy {name}, construido sobre {IDENTITY.framework}, el framework "
            f"que corre en esta máquina.",
            "No tengo registrada una autoría concreta, así que no me la invento.",
        ]

        if engine:
            lines.append(
                f"Cosa distinta es el motor que uso para razonar ({engine}): "
                f"ese lo entrenó quien lo entrenara, y no es quien me hizo a mí."
            )

        return "\n".join(lines)

    # WHO
    lines = [f"Soy {name}, {IDENTITY.role}."]

    if engine:
        lines.append(f"Pienso con {engine}, en local.")

    lines.append(IDENTITY.principles[0])

    return "\n".join(lines)
