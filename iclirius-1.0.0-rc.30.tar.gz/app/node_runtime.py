"""Packaged node entrypoint used by the managed LaunchAgent."""
from __future__ import annotations

import signal
import threading
import os


_stop = threading.Event()
_lifecycle = "STOPPED"


def _start_secure_channel():
    """Start the CLUSTER-3 listener only when explicitly enabled.

    Keeping this opt-in preserves RC18 and the separate CLUSTER-2 enrollment
    listener until the operator has completed physical trust acceptance.
    """
    from app.secure_channel import configured
    config = configured()
    if not config.get("enabled"):
        return None
    try:
        from app.secure_channel import SecureNodeServer, DEFAULT_SECURE_PORT
        server = SecureNodeServer(bind=str(config.get("bind", "0.0.0.0")),
                                  port=int(config.get("port", DEFAULT_SECURE_PORT)))
        thread = threading.Thread(target=server.serve, daemon=True, name="iclirius-secure-channel")
        thread.start()
        return server
    except OSError:
        # Keep a safe machine-local diagnostic so status/Doctor can distinguish
        # a bind conflict from a merely disabled listener.  No secrets or peer
        # data are written here.
        from app.secure_channel import _state_root, SECURE_RUNTIME_FILE
        root = _state_root(); root.mkdir(mode=0o700, parents=True, exist_ok=True)
        marker = root / SECURE_RUNTIME_FILE
        marker.write_text('{"listener_live": false, "state": "PORT_CONFLICT", "port": 18891}', encoding="utf-8")
        os.chmod(marker, 0o600)
        return None
    except Exception:
        return None


def _request_stop(_signum, _frame) -> None:
    global _lifecycle
    _lifecycle = "STOPPING"
    _stop.set()


def _install_signal_handlers() -> None:
    signal.signal(signal.SIGTERM, _request_stop)
    signal.signal(signal.SIGINT, _request_stop)

def main() -> int:
    global _lifecycle
    from app.config import settings
    _install_signal_handlers()
    _lifecycle = "STARTING"
    secure_server = _start_secure_channel()
    if settings.enable_telegram:
        from interfaces.telegram_bot import run_telegram_bot
        _lifecycle = "RUNNING"
        try:
            run_telegram_bot()
        except (KeyboardInterrupt, SystemExit):
            _request_stop(signal.SIGINT, None)
    else:
        _lifecycle = "RUNNING"
        # A condition wait is the persistent node lifecycle.  It consumes no
        # busy-loop CPU and exits only after an explicit termination signal.
        _stop.wait()
    if secure_server:
        secure_server.stop()
    _lifecycle = "STOPPED"
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
