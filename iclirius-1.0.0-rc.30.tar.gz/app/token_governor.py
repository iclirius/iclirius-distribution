"""
Whether a cloud request is allowed to happen, decided before it happens.

This is a conservative first version on purpose. It does not decide *when* to
escalate to a cloud — nothing escalates automatically, and AUTO is still
reserved. It answers one narrower question about a call somebody already asked
for: is this task still within budget?

    estimate the request
        ↓
    check the task's cloud budget
        ↓
    ALLOW → the request goes out
    DENY  → no network call happens at all

A denial has to happen before the request, because a budget enforced after the
fact is not a budget. So the estimate is made from the ContextPackage the
Context Engine already assembled, and once the provider reports real token
counts the estimate is replaced rather than added to.

Budgets are per task and cloud-only. Ollama is never counted, never limited
and never affected: local compute is the thing this system prefers, and
metering it would push behaviour the wrong way.
"""

from __future__ import annotations

import threading
from collections import defaultdict
from dataclasses import asdict, dataclass, field

from app.config import settings
from app.logger import logger
from app.reasoning import ReasoningRequest, ReasoningResponse, estimate_tokens
from app.runtime_events import EventType, Status, emit
from app.memory_core import MemoryCore, memory_core


ALLOW = "ALLOW"
DENY = "DENY"


@dataclass
class BudgetVerdict:
    """Why a request was allowed or refused, in terms a person can read."""

    decision: str = ALLOW
    reason: str = ""
    limit_name: str = ""
    limit_value: int = 0
    used: int = 0
    estimated: int = 0
    task_id: str = ""

    @property
    def allowed(self) -> bool:
        return self.decision == ALLOW

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class TaskCloudUsage:
    """What one task has spent in the cloud. Counters only."""

    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_input_tokens: int = 0
    estimated_output_tokens: int = 0
    denials: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


class TokenGovernor:
    """
    Per-task cloud budgets, checked before the call and reconciled after.

    Deliberately not clever. It counts, compares against three configured
    limits and says yes or no; anything resembling a routing strategy belongs
    somewhere else and does not exist yet.
    """

    def __init__(self, core: MemoryCore | None = None):
        self._usage: dict[str, TaskCloudUsage] = defaultdict(TaskCloudUsage)
        self._lock = threading.Lock()
        # Tests and isolated callers remain process-local unless they opt into
        # the canonical encrypted vault. Production gateways pass memory_core.
        self._core = core
        self._load()

    def _load(self) -> None:
        if self._core is None:
            return
        stored = self._core.get_namespace("provider_usage")
        for task_id, values in (stored.get("tasks") or {}).items():
            if not isinstance(values, dict):
                continue
            fields = TaskCloudUsage.__dataclass_fields__
            self._usage[str(task_id)] = TaskCloudUsage(
                **{name: int(values.get(name, 0) or 0) for name in fields}
            )

    def set_core(self, core: MemoryCore | None) -> None:
        """Switch the durable vault when an agent receives an isolated core."""
        with self._lock:
            self._core = core
            self._usage.clear()
            self._load()

    def _persist_task(self, task_id: str) -> None:
        usage = self._usage[task_id]
        snapshot = usage.to_dict()

        def mutate(namespace):
            namespace.setdefault("tasks", {})[task_id] = snapshot
            return namespace

        if self._core is not None:
            self._core.mutate_namespace("provider_usage", mutate)

    @staticmethod
    def _entry_key(task_id: str, provider: str, account_ref: str,
                   model: str, purpose: str) -> str:
        parts = (task_id, provider, account_ref, model, purpose)
        return "|".join(str(part or "")[:120].replace("|", "_") for part in parts)

    def _persist_entry(self, task_id: str, provider: str, account_ref: str,
                       model: str, purpose: str, response: ReasoningResponse,
                       success: bool) -> None:
        key = self._entry_key(task_id, provider, account_ref, model, purpose)
        input_tokens = response.input_tokens_actual
        output_tokens = response.output_tokens_actual

        def mutate(namespace):
            entries = namespace.setdefault("entries", {})
            entry = entries.setdefault(key, {
                "task_id": task_id, "provider": provider,
                "account_ref": account_ref, "model": model,
                "purpose": purpose, "requests": 0, "successes": 0,
                "failures": 0, "input_tokens": 0, "output_tokens": 0,
                "rate_limits": 0, "quota_exhausted": 0,
                "latency_ms_total": 0,
            })
            entry["requests"] += 1
            entry["successes" if success else "failures"] += 1
            entry["input_tokens"] += int(input_tokens or response.input_tokens_estimated or 0)
            entry["output_tokens"] += int(output_tokens or response.output_tokens_estimated or 0)
            entry["latency_ms_total"] += int(response.latency_ms or 0)
            if response.error_kind == "RATE_LIMIT":
                entry["rate_limits"] += 1
            if response.error_kind == "QUOTA_EXHAUSTED":
                entry["quota_exhausted"] += 1
            return namespace

        if self._core is not None:
            self._core.mutate_namespace("provider_usage", mutate)

    # -- pre-flight --------------------------------------------------------

    def check(self, request: ReasoningRequest, is_cloud: bool = True,
              interface: str = "") -> BudgetVerdict:
        """
        Decide before anything reaches the network.

        Local requests are waved through without being counted at all: the
        budget exists to bound what leaves the machine.
        """
        task_id = request.task_id or ""

        if not is_cloud:
            return BudgetVerdict(decision=ALLOW, reason="petición local",
                                 task_id=task_id)

        estimated_input = request.estimated_input_tokens()
        # Output is genuinely unknown beforehand. A documented fraction of the
        # input is a poor estimate, so it is treated as one: it bounds runaway
        # requests without pretending to predict a specific answer.
        estimated_output = (request.max_output_chars // 4
                            if request.max_output_chars
                            else max(256, estimated_input // 4))

        with self._lock:
            usage = self._usage[task_id]
            checks = (
                ("CLOUD_MAX_REQUESTS_PER_TASK",
                 settings.cloud_max_requests_per_task,
                 usage.requests, 1),
                ("CLOUD_MAX_INPUT_TOKENS_PER_TASK",
                 settings.cloud_max_input_tokens_per_task,
                 usage.input_tokens + usage.estimated_input_tokens,
                 estimated_input),
                ("CLOUD_MAX_OUTPUT_TOKENS_PER_TASK",
                 settings.cloud_max_output_tokens_per_task,
                 usage.output_tokens + usage.estimated_output_tokens,
                 estimated_output),
            )

            for name, limit, used, increment in checks:
                # Zero means unlimited, which is how a budget is switched off
                # without deleting the configuration.
                if limit <= 0:
                    continue

                if used + increment > limit:
                    usage.denials += 1

                    verdict = BudgetVerdict(
                        decision=DENY,
                        reason=(f"la tarea alcanzaría {used + increment} y el "
                                f"límite es {limit}"),
                        limit_name=name, limit_value=limit, used=used,
                        estimated=increment, task_id=task_id,
                    )

                    emit(EventType.CLOUD_BUDGET_DENIED.value,
                         status=Status.BLOCKED.value, interface=interface,
                         task_id=task_id or None, metadata=verdict.to_dict())

                    logger.info("Cloud budget denied task=%s limit=%s",
                                task_id or "-", name)

                    return verdict

            # Reserve the estimate so two concurrent requests cannot both pass
            # a check that only one of them fits inside.
            usage.requests += 1
            usage.estimated_input_tokens += estimated_input
            usage.estimated_output_tokens += estimated_output
            self._persist_task(task_id)

        verdict = BudgetVerdict(decision=ALLOW, reason="dentro del presupuesto",
                                estimated=estimated_input, task_id=task_id)

        emit(EventType.CLOUD_BUDGET_CHECK.value, status=Status.OK.value,
             interface=interface, task_id=task_id or None,
             metadata=verdict.to_dict())

        return verdict

    # -- post-flight -------------------------------------------------------

    def record(self, request: ReasoningRequest, response: ReasoningResponse,
               is_cloud: bool = True, interface: str = "", provider: str = "",
               account_ref: str = "", model: str = "", purpose: str = "") -> None:
        """
        Replace the reservation with what actually happened.

        The estimate reserved at check time is removed and the real counts
        added, so a task that was charged 300 estimated tokens and used 180 is
        not charged 480.
        """
        if not is_cloud:
            return

        task_id = request.task_id or ""
        estimated_input = request.estimated_input_tokens()
        estimated_output = (request.max_output_chars // 4
                            if request.max_output_chars
                            else max(256, estimated_input // 4))

        actual_input = (response.input_tokens_actual
                        if response.input_tokens_actual is not None
                        else response.input_tokens_estimated)
        actual_output = (response.output_tokens_actual
                         if response.output_tokens_actual is not None
                         else estimate_tokens(response.content))

        with self._lock:
            usage = self._usage[task_id]
            usage.estimated_input_tokens = max(
                0, usage.estimated_input_tokens - estimated_input)
            usage.estimated_output_tokens = max(
                0, usage.estimated_output_tokens - estimated_output)
            usage.input_tokens += actual_input
            usage.output_tokens += actual_output
            self._persist_task(task_id)

        self._persist_entry(task_id, provider or response.provider_id,
                            account_ref or response.account_ref,
                            model or response.model_id,
                            purpose or request.purpose, response, response.ok)

        emit(EventType.USAGE_RECORDED.value, status=Status.INFO.value,
             interface=interface, task_id=task_id or None,
             metadata={"input_tokens": actual_input,
                       "output_tokens": actual_output,
                       "actual": response.input_tokens_actual is not None})

    def observe(self, request: ReasoningRequest, response: ReasoningResponse,
                provider: str = "", account_ref: str = "", model: str = "") -> None:
        """Persist a failed cloud attempt without settling the reservation."""
        if response.ok:
            return
        self._persist_entry(request.task_id or "", provider or response.provider_id,
                            account_ref or response.account_ref,
                            model or response.model_id, request.purpose,
                            response, False)

    def release(self, request: ReasoningRequest, is_cloud: bool = True) -> None:
        """
        Give back a reservation for a request that never went out.

        Without this, a provider that failed before sending anything would
        leave the task charged for tokens nobody spent.
        """
        if not is_cloud:
            return

        task_id = request.task_id or ""
        estimated_input = request.estimated_input_tokens()
        estimated_output = (request.max_output_chars // 4
                            if request.max_output_chars
                            else max(256, estimated_input // 4))

        with self._lock:
            usage = self._usage[task_id]
            usage.requests = max(0, usage.requests - 1)
            usage.estimated_input_tokens = max(
                0, usage.estimated_input_tokens - estimated_input)
            usage.estimated_output_tokens = max(
                0, usage.estimated_output_tokens - estimated_output)
            self._persist_task(task_id)

    # -- reporting ---------------------------------------------------------

    def task_usage(self, task_id: str) -> TaskCloudUsage:
        with self._lock:
            return TaskCloudUsage(**self._usage[task_id or ""].to_dict())

    def summary(self) -> dict:
        with self._lock:
            tasks = len(self._usage)
            requests = sum(item.requests for item in self._usage.values())
            denials = sum(item.denials for item in self._usage.values())
            input_tokens = sum(item.input_tokens for item in self._usage.values())
            output_tokens = sum(item.output_tokens for item in self._usage.values())

        return {
            "tasks_with_cloud_usage": tasks,
            "cloud_requests": requests,
            "cloud_denials": denials,
            "cloud_input_tokens": input_tokens,
            "cloud_output_tokens": output_tokens,
            "limits": {
                "requests_per_task": settings.cloud_max_requests_per_task,
                "input_tokens_per_task": settings.cloud_max_input_tokens_per_task,
                "output_tokens_per_task": settings.cloud_max_output_tokens_per_task,
            },
        }

    def clear(self) -> None:
        with self._lock:
            self._usage.clear()
        if self._core is not None:
            self._core.mutate_namespace("provider_usage", lambda namespace: namespace.clear() or namespace)


governor = TokenGovernor(core=memory_core)
