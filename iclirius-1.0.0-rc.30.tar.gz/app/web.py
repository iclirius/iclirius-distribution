"""Bounded, evidence-producing public web search and fetch primitives."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Protocol
from datetime import datetime, timezone
from html.parser import HTMLParser
import ipaddress
import json
import re
import socket
import time
from urllib.parse import parse_qs, unquote, urljoin, urlparse

import requests

from app.evidence import Certainty, Coverage, EvidenceRecord, SourceType
from app.version import VERSION

MAX_RESULTS = 10
MAX_REDIRECTS = 5
MAX_BYTES = 3_000_000
MAX_TEXT = 60_000
USER_AGENT = f"Iclirius/{VERSION}"
CURRENT_TERMS = ("latest", "current", "today", "recent", "right now", "version", "release", "news", "price", "última", "último", "actual", "reciente")


def requires_web_evidence(query: str) -> bool:
    """Conservative routing hint; explicit web requests always qualify."""
    value = str(query or "").lower()
    return (any(term in value for term in CURRENT_TERMS) or
            any(term in value for term in ("search the web", "search internet", "search online",
                                            "busca en internet", "busca en la web", "documentación oficial")))


@dataclass(frozen=True)
class WebSearchResult:
    title: str
    url: str
    snippet: str = ""
    rank: int = 0
    provider: str = ""
    retrieved_at: str = ""


@dataclass(frozen=True)
class WebSearchRequest:
    query: str
    max_results: int = 5
    recency: str | None = None
    domains: tuple[str, ...] = ()


@dataclass(frozen=True)
class WebFetchRequest:
    url: str


@dataclass(frozen=True)
class WebEvidence:
    result: dict
    evidence: EvidenceRecord


class SearchProvider(Protocol):
    provider_id: str
    def search(self, request: WebSearchRequest) -> list[WebSearchResult]: ...


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.title = ""
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript", "nav", "footer", "header"}:
            self._skip += 1
        if tag == "title": self._in_title = True

    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript", "nav", "footer", "header"}:
            self._skip = max(0, self._skip - 1)
        if tag == "title": self._in_title = False

    def handle_data(self, data):
        value = " ".join(data.split())
        if not value: return
        if self._in_title: self.title += (" " if self.title else "") + value
        if not self._skip: self.parts.append(value)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _public_url(url: str) -> tuple[bool, str]:
    parsed = urlparse(str(url).strip())
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return False, "BLOCKED_BY_POLICY"
    try:
        addresses = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
        for item in addresses:
            address = ipaddress.ip_address(item[4][0])
            if (address.is_private or address.is_loopback or address.is_link_local or
                    address.is_multicast or address.is_reserved or address.is_unspecified):
                return False, "BLOCKED_BY_POLICY"
    except (OSError, ValueError):
        return False, "DNS_ERROR"
    return True, ""


class WebFetchService:
    def __init__(self, *, session=None, max_bytes=MAX_BYTES, max_text=MAX_TEXT):
        self.session = session or requests.Session()
        self.max_bytes = max_bytes
        self.max_text = max_text

    def fetch(self, url: str) -> dict:
        started = time.monotonic()
        current = url
        redirects = []
        try:
            for _ in range(MAX_REDIRECTS + 1):
                allowed, reason = _public_url(current)
                if not allowed:
                    return {"requested_url": url, "final_url": current, "status_code": None,
                            "content_type": "", "title": "", "text": "", "retrieved_at": _now(),
                            "redirects": redirects, "truncated": False, "error": reason}
                response = self.session.get(current, headers={"User-Agent": USER_AGENT},
                                            timeout=(5, 10), allow_redirects=False, stream=True)
                if response.is_redirect:
                    location = response.headers.get("Location", "")
                    if not location or len(redirects) >= MAX_REDIRECTS:
                        return {"requested_url": url, "final_url": current, "status_code": response.status_code,
                                "content_type": "", "title": "", "text": "", "retrieved_at": _now(),
                                "redirects": redirects, "truncated": False, "error": "REDIRECT_LIMIT"}
                    redirects.append(current); current = urljoin(current, location); continue
                content_type = response.headers.get("Content-Type", "").split(";", 1)[0].lower()
                if response.status_code >= 400:
                    return {"requested_url": url, "final_url": current, "status_code": response.status_code,
                            "content_type": content_type, "title": "", "text": "", "retrieved_at": _now(),
                            "redirects": redirects, "truncated": False, "error": f"HTTP_{response.status_code}"}
                if content_type not in {"text/html", "text/plain", "application/json"}:
                    return {"requested_url": url, "final_url": current, "status_code": response.status_code,
                            "content_type": content_type, "title": "", "text": "", "retrieved_at": _now(),
                            "redirects": redirects, "truncated": False, "error": "UNSUPPORTED_CONTENT_TYPE"}
                chunks, total = [], 0
                for chunk in response.iter_content(65536):
                    if not chunk: continue
                    remaining = self.max_bytes - total
                    chunks.append(chunk[:remaining]); total += min(len(chunk), remaining)
                    if total >= self.max_bytes: break
                body = b"".join(chunks)
                truncated = total >= self.max_bytes
                decoded = body.decode(response.encoding or "utf-8", errors="replace")
                if content_type == "text/html":
                    parser = _TextExtractor(); parser.feed(decoded); title, text = parser.title, " ".join(parser.parts)
                else:
                    title, text = "", decoded
                    if content_type == "application/json":
                        try: text = json.dumps(response.json(), ensure_ascii=False)
                        except ValueError: pass
                return {"requested_url": url, "final_url": current, "status_code": response.status_code,
                        "content_type": content_type, "title": title[:500], "text": text[:self.max_text],
                        "retrieved_at": _now(), "redirects": redirects, "truncated": truncated or len(text) > self.max_text,
                        "error": "", "elapsed_ms": int((time.monotonic() - started) * 1000)}
            return {"requested_url": url, "final_url": current, "status_code": None, "content_type": "",
                    "title": "", "text": "", "retrieved_at": _now(), "redirects": redirects,
                    "truncated": False, "error": "REDIRECT_LIMIT"}
        except requests.Timeout:
            return {"requested_url": url, "final_url": current, "status_code": None, "content_type": "",
                    "title": "", "text": "", "retrieved_at": _now(), "redirects": redirects,
                    "truncated": False, "error": "TIMEOUT"}
        except requests.RequestException as exc:
            return {"requested_url": url, "final_url": current, "status_code": None, "content_type": "",
                    "title": "", "text": "", "retrieved_at": _now(), "redirects": redirects,
                    "truncated": False, "error": type(exc).__name__}

    def evidence(self, url: str) -> EvidenceRecord:
        result = self.fetch(url)
        ok = not result.get("error")
        return EvidenceRecord(SourceType.WEB.value, "fetch", result.get("final_url", url), result,
                              Coverage(complete=ok, errors=0 if ok else 1),
                              Certainty.VERIFIED.value if ok else Certainty.PARTIAL.value,
                              provenance={"requested_url": url}, tool_id="web.fetch",
                              duration_ms=result.get("elapsed_ms"), errors=() if ok else (result.get("error", ""),))


class WebSearchService:
    def __init__(self, *, session=None, provider: SearchProvider | None = None):
        self.session = session or requests.Session()
        self.provider = provider

    def search_request(self, request: WebSearchRequest) -> list[WebSearchResult]:
        if self.provider is not None:
            return self.provider.search(request)
        return self.search(request.query, request.max_results)

    def search(self, query: str, max_results: int = 5) -> list[WebSearchResult]:
        query = str(query or "").strip()
        if not query: return []
        limit = max(1, min(int(max_results), MAX_RESULTS))
        response = self.session.get("https://html.duckduckgo.com/html/", params={"q": query},
                                    headers={"User-Agent": USER_AGENT}, timeout=(5, 10))
        response.raise_for_status()
        parser = _TextExtractor(); parser.feed(response.text)
        links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', response.text, re.I | re.S)
        results = []
        for rank, (href, raw_title) in enumerate(links[:limit], 1):
            title = re.sub(r"<[^>]+>", "", raw_title).strip()
            target = parse_qs(urlparse(unquote(href)).query).get("uddg", [href])[0]
            if _public_url(target)[0]: results.append(WebSearchResult(title[:500], target, rank=rank, provider="duckduckgo", retrieved_at=_now()))
        return results

    def evidence(self, query: str, max_results: int = 5) -> EvidenceRecord:
        try:
            results = self.search(query, max_results)
            payload = {"query": query, "results": [asdict(item) for item in results]}
            return EvidenceRecord(SourceType.WEB.value, "search", query, payload, Coverage(complete=True),
                                  Certainty.OBSERVED.value, tool_id="web.search")
        except requests.RequestException as exc:
            return EvidenceRecord(SourceType.WEB.value, "search", query, {"query": query, "results": []},
                                  Coverage(complete=False, errors=1, reason=type(exc).__name__),
                                  Certainty.PARTIAL.value, tool_id="web.search", errors=(type(exc).__name__,))


def fetch_evidence(url: str, *, service: WebFetchService | None = None) -> WebEvidence:
    """Fetch once and attach the complete canonical provenance record."""
    service = service or WebFetchService()
    result = service.fetch(url)
    ok = not result.get("error")
    record = EvidenceRecord(
        SourceType.WEB.value, "fetch", result.get("final_url", url), result,
        Coverage(complete=ok, errors=0 if ok else 1),
        Certainty.VERIFIED.value if ok else Certainty.PARTIAL.value,
        provenance={"requested_url": url}, tool_id="web.fetch",
        duration_ms=result.get("elapsed_ms"),
        errors=() if ok else (result.get("error", ""),),
    )
    return WebEvidence(result, record)
