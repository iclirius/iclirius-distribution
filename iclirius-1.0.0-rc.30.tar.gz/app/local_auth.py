"""Machine-local authentication for an already configured Iclirius user."""

from __future__ import annotations

import base64
import getpass
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from app.touch_id import TouchIDStatus, authenticate as touch_authenticate, availability as touch_availability


def _event(event_type: str, status: str, metadata: dict | None = None) -> None:
    try:
        from app.runtime_events import emit
        emit(event_type, status=status, interface="cli", metadata=metadata or {})
    except Exception:
        pass


AUTH_SCHEMA = 1
MIN_PASSWORD_CHARS = 12
MAX_BACKOFF_SECONDS = 30


class AuthenticationError(Exception):
    pass


def auth_path() -> Path:
    return Path(os.getenv("ICLIRIUS_AUTH_PATH", "~/.iclirius/auth.json")).expanduser()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _atomic_write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}-{secrets.token_hex(4)}")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)


def _derive(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p,
                          dklen=32, maxmem=0)


def _record(user_id: str, identity: str, password: str, *, touch_available: str) -> dict:
    salt = secrets.token_bytes(16)
    # 16 MiB keeps the verifier practical on a Mac while remaining usable in
    # constrained CI/OpenSSL environments; parameters are stored with the
    # verifier so future migrations can increase them explicitly.
    n, r, p = 2**14, 8, 1
    digest = _derive(password, salt, n, r, p)
    return {
        "schema_version": AUTH_SCHEMA,
        "user_id": user_id,
        "primary_identity": identity,
        "created_at": _now(),
        "recovery": {
            "algorithm": "scrypt",
            "n": n, "r": r, "p": p,
            "salt": base64.b64encode(salt).decode("ascii"),
            "verifier": base64.b64encode(digest).decode("ascii"),
            "failed_attempts": 0,
            "next_allowed_at": 0,
        },
        "touch_id": {"available_at_enrollment": touch_available},
    }


def load() -> dict | None:
    path = auth_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or data.get("schema_version") != AUTH_SCHEMA:
        return None
    return data


def status(*, touch_probe: Callable[[], TouchIDStatus] | None = None) -> dict:
    data = load()
    touch = (touch_probe or (lambda: touch_availability()))()
    if not data:
        return {"enrolled": False, "touch_id": touch.value,
                "recovery_credential": False, "user_id": "", "primary_identity": ""}
    recovery = data.get("recovery", {})
    return {"enrolled": bool(data.get("user_id") and recovery.get("verifier")),
            "touch_id": touch.value, "recovery_credential": bool(recovery.get("verifier")),
            "user_id": str(data.get("user_id", "")),
            "primary_identity": str(data.get("primary_identity", ""))}


def enroll(user_id: str, identity: str, password: str, confirmation: str, *,
           touch_status: TouchIDStatus | None = None) -> dict:
    if not user_id or not identity:
        raise AuthenticationError("Iclirius setup must be complete before auth enrollment.")
    if len(password) < MIN_PASSWORD_CHARS:
        raise AuthenticationError(f"Recovery password must contain at least {MIN_PASSWORD_CHARS} characters.")
    if not hmac.compare_digest(password, confirmation):
        raise AuthenticationError("Recovery passwords do not match.")
    record = _record(user_id, identity, password,
                     touch_available=(touch_status or touch_availability()).value)
    _atomic_write(auth_path(), record)
    return status(touch_probe=lambda: touch_status or touch_availability())


def _verify(data: dict, password: str) -> bool:
    recovery = data.get("recovery", {})
    try:
        salt = base64.b64decode(recovery["salt"])
        expected = base64.b64decode(recovery["verifier"])
        actual = _derive(password, salt, int(recovery["n"]), int(recovery["r"]), int(recovery["p"]))
    except (KeyError, ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


def verify_recovery(password: str) -> tuple[bool, str]:
    data = load()
    if not data:
        return False, "not_configured"
    recovery = data["recovery"]
    now = time.time()
    if now < float(recovery.get("next_allowed_at", 0)):
        return False, "rate_limited"
    if _verify(data, password):
        recovery["failed_attempts"] = 0
        recovery["next_allowed_at"] = 0
        _atomic_write(auth_path(), data)
        return True, "success"
    attempts = int(recovery.get("failed_attempts", 0)) + 1
    recovery["failed_attempts"] = attempts
    recovery["next_allowed_at"] = now + min(MAX_BACKOFF_SECONDS, 2 ** min(attempts, 5))
    _atomic_write(auth_path(), data)
    return False, "invalid"


@dataclass
class AuthSession:
    user_id: str
    primary_identity: str
    method: str


def authenticate_interactive(*, prefer_touch_id: bool = True,
                             password_reader: Callable[[], str] | None = None,
                             touch_fn: Callable[[], TouchIDStatus] | None = None,
                             output: Callable[[str], None] = print) -> AuthSession | None:
    data = load()
    if not data or not data.get("user_id"):
        output("Iclirius local authentication is not enrolled. Run: iclirius auth setup")
        return None
    touch_fn = touch_fn or (lambda: touch_authenticate(compile_if_missing=True))
    if prefer_touch_id:
        _event("AUTH_TOUCH_ID_REQUESTED", "started")
        result = touch_fn()
        if result == TouchIDStatus.SUCCESS:
            _event("AUTH_SUCCESS", "ok", {"method": "touch_id"})
            return AuthSession(str(data["user_id"]), str(data.get("primary_identity", "")), "touch_id")
        if result in {TouchIDStatus.CANCELLED, TouchIDStatus.LOCKED_OUT}:
            _event("AUTH_CANCELLED", "skipped", {"reason": result.value})
            output("Touch ID did not authenticate. Use the recovery password to continue.")
        elif result not in {TouchIDStatus.UNAVAILABLE, TouchIDStatus.NOT_ENROLLED}:
            _event("AUTH_FAILED", "failed", {"method": "touch_id", "reason": result.value})
            output("Touch ID failed. Use the recovery password to continue.")
        _event("AUTH_FALLBACK_USED", "started", {"method": "recovery_password"})
    reader = password_reader or (lambda: getpass.getpass("Recovery password: "))
    for _ in range(3):
        ok, reason = verify_recovery(reader())
        if ok:
            _event("AUTH_SUCCESS", "ok", {"method": "recovery_password"})
            return AuthSession(str(data["user_id"]), str(data.get("primary_identity", "")), "recovery_password")
        if reason == "rate_limited":
            output("Too many attempts. Try again shortly.")
            return None
        output("Authentication failed.")
        _event("AUTH_FAILED", "failed", {"method": "recovery_password", "reason": reason})
    return None
