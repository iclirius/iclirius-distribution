"""Human onboarding and local-machine bootstrap for ``iclirius setup``."""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import getpass
from datetime import datetime, timezone
from pathlib import Path

from app.memory_home import MemoryHomeError, copy_legacy_tree, create, inspect, load
from app.memory_enrollment import EnrollmentError
from app.node_identity import ensure_node, local_node_path
from app.secure_storage import SecureStorageError, ensure_keychain_key
from app.user_identity import IdentityError, UserIdentity, new_identity, validate_primary_identity
from app.local_ai_setup import configure as configure_local_ai


PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = Path(os.getenv(
    "ICLIRIUS_CONFIG_PATH",
    str(PROJECT_ROOT / ".env" if (PROJECT_ROOT / ".env").exists()
        else Path.home() / ".iclirius" / "config.env"),
)).expanduser()

SETUP_STATE_PATH = Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser() / "setup-state.json"
SETUP_PHASES = ("SYSTEM_CHECK", "IDENTITY", "RECOVERY", "MEMORY_HOME", "KEYCHAIN",
                "NODE_IDENTITY", "RUNTIME", "SERVICE", "LOCAL_AI", "CAPABILITIES",
                "CLUSTER", "FINAL_VALIDATION", "COMPLETE")


def _default_home() -> Path:
    return Path.home() / "Library" / "Application Support" / "Iclirius" / "MemoryHome"


def _env_lines() -> list[str]:
    if ENV_PATH.exists():
        return ENV_PATH.read_text(encoding="utf-8").splitlines()
    template = PROJECT_ROOT / ".env.example"
    return template.read_text(encoding="utf-8").splitlines() if template.exists() else []


def _write_env(values: dict[str, str]) -> None:
    lines = _env_lines()
    seen: set[str] = set()
    output: list[str] = []
    for line in lines:
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)=", line)
        if match and match.group(1) in values:
            key = match.group(1)
            output.append(f"{key}={values[key]}")
            seen.add(key)
        else:
            output.append(line)
    if output and output[-1].strip():
        output.append("")
    for key, value in values.items():
        if key not in seen:
            output.append(f"{key}={value}")
    ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = ENV_PATH.with_name(f".{ENV_PATH.name}.tmp-{os.getpid()}")
    temp.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, ENV_PATH)


def _write_setup_state(phase: str, state: str, **details) -> None:
    """Persist non-secret onboarding progress for safe resume and diagnostics."""
    payload = {"schema_version": 2, "phase": phase, "state": state,
               "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    payload.update({key: value for key, value in details.items()
                    if not any(part in str(key).lower() for part in ("secret", "password", "token", "code"))})
    SETUP_STATE_PATH.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = SETUP_STATE_PATH.with_name(f".{SETUP_STATE_PATH.name}.tmp-{os.getpid()}")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, SETUP_STATE_PATH)


def _read_setup_state() -> dict:
    try:
        data = json.loads(SETUP_STATE_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _configure_recovery(*, identity, interactive: bool) -> dict:
    """Create the local recovery verifier without ever persisting the secret."""
    from app.local_auth import status as auth_status, enroll as enroll_auth
    current = auth_status()
    if current.get("enrolled"):
        return {"state": "CONFIGURED", "recovery_credential": True}
    if not interactive:
        return {"state": "NOT_CONFIGURED", "recovery_credential": False}
    print("\nRecovery credential")
    print("This protects local authentication and is never stored in Memory Home or logs.")
    password = getpass.getpass("Create recovery passphrase (12+ characters): ")
    confirmation = getpass.getpass("Confirm recovery passphrase: ")
    result = enroll_auth(identity.user_id, identity.primary_identity, password, confirmation)
    return {"state": "CONFIGURED", "recovery_credential": bool(result.get("enrolled"))}


def _configure_service(*, interactive: bool) -> dict:
    """Install and start the managed node service, reporting real postconditions."""
    from app import node_service
    installed = node_service.install()
    if installed.get("state") == "FAILED":
        return {"state": "BLOCKED", "error": installed.get("error", "service install failed")}
    started = node_service.start()
    if started.get("state") != "RUNNING":
        return {"state": "REPAIRABLE", "error": started.get("error", "service did not reach RUNNING"),
                "service": started}
    return {"state": "CONFIGURED", "service": started}


def _final_validation() -> dict:
    """Run read-only Doctor collection without changing setup or network trust."""
    try:
        from app.doctor import collect
        report = collect()
        setup_ready = report.get("setup", {}).get("setup_complete", False)
        service_state = report.get("managed_node_service", {}).get("state", "UNKNOWN")
        ready = bool(setup_ready and service_state == "RUNNING")
        return {"state": "CONFIGURED" if ready else "REPAIRABLE",
                "overall": report.get("overall", "unknown"),
                "setup": setup_ready, "service": service_state,
                "node_role": report.get("current_role", report.get("node_role", "INTERFACE")),
                "capabilities": report.get("capability_overall", "UNKNOWN")}
    except Exception as exc:
        return {"state": "UNKNOWN", "error": type(exc).__name__}


def _select_folder() -> Path | None:
    if platform.system() == "Darwin" and shutil.which("osascript"):
        script = 'POSIX path of (choose folder with prompt "Choose Iclirius Memory Home")'
        try:
            result = subprocess.run(["osascript", "-e", script], capture_output=True,
                                    text=True, timeout=120, check=False)
            if result.returncode == 0 and result.stdout.strip():
                return Path(result.stdout.strip()).expanduser()
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        value = input("Memory Home path: ").strip()
    except EOFError:
        return None
    return Path(value).expanduser() if value else None


def _prompt_identity() -> UserIdentity:
    while True:
        try:
            value = input("Who are you?\n> ").strip()
        except EOFError as exc:
            raise IdentityError("An identity is required.") from exc
        try:
            return new_identity(value)
        except IdentityError as exc:
            print(f"Invalid identity: {exc}")


def _legacy_sources() -> dict[str, Path]:
    from app.config import settings
    return {
        "profile": Path(settings.identity_path),
        "memory": Path(settings.memory_path),
        "core": Path(settings.memory_root),
    }


def _legacy_principal_id() -> str:
    """Read the existing encrypted principal only when it is available."""
    try:
        from app.memory_core import MemoryCore
        core = MemoryCore()
        state = core._read_state()
        value = (state.get("principal_user") or {}).get("user_id", "")
        return str(value or "")
    except Exception:
        return ""


def _migrate_legacy(home, backup_root: Path) -> dict:
    copied = 0
    backed_up = 0
    sources = _legacy_sources()
    profile = sources.get("profile", Path("/nonexistent/profile"))
    memory = sources.get("memory", Path("/nonexistent/memory"))
    core = sources.get("core", Path("/nonexistent/core"))

    def migrate(source: Path, backup: Path, destination: Path,
                *, exclude: set[str] | None = None):
        nonlocal copied, backed_up
        if not source.exists() or source.resolve() == destination.resolve():
            return
        backed_up += copy_legacy_tree(source, backup, exclude_top_level=exclude)
        copied += copy_legacy_tree(source, destination, exclude_top_level=exclude)

    # The legacy memory directory contains a nested core directory. Copy the
    # top-level stores here and migrate the canonical core separately so the
    # new home does not contain two copies of the same encrypted vault.
    migrate(profile, backup_root / "profile", home.profile_path)
    if memory.exists() and memory.resolve() != home.memory_path.resolve():
        backed_up += copy_legacy_tree(memory, backup_root / "memory",
                                       exclude_top_level={core.name})
        copied += copy_legacy_tree(memory, home.memory_path,
                                   exclude_top_level={core.name})
    migrate(core, backup_root / "core", home.core_path)
    return {"copied_files": copied, "backup_files": backed_up}


def _encrypted_state_exists() -> bool:
    for source in _legacy_sources().values():
        if source.exists() and any(item.is_file() for item in source.rglob("*")):
            return True
    return False


def _paths_overlap(first: Path, second: Path) -> bool:
    """Reject a Memory Home nested inside legacy state (or vice versa)."""
    try:
        first.resolve().relative_to(second.resolve())
        return True
    except ValueError:
        pass
    try:
        second.resolve().relative_to(first.resolve())
        return True
    except ValueError:
        return False


def status() -> dict:
    from app.config import settings
    home_info = inspect(settings.memory_home) if settings.memory_home else {
        "configured": False, "readable": False, "writable": False,
        "status": "not configured",
    }
    node = {}
    try:
        node = json.loads(local_node_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    enrollment = {"state": "not_configured"}
    if settings.memory_home:
        try:
            from app.memory_enrollment import status as enrollment_status
            enrollment = enrollment_status(settings.memory_home)
        except Exception:
            enrollment = {"state": "unavailable"}
    try:
        from app.local_auth import status as auth_status
        recovery_info = auth_status()
    except Exception:
        recovery_info = {"enrolled": False, "recovery_credential": False}
    return {
        "setup_complete": settings.setup_complete,
        "state_machine": _read_setup_state(),
        "identity": {
            "user_id": settings.user_id,
            "primary_identity": settings.principal_user_name,
            "configured": bool(settings.user_id and settings.principal_user_name),
        },
        "memory_home": home_info,
        "enrollment": enrollment,
        "keychain": {"configured": _keychain_ready()},
        "node": {"node_id": node.get("node_id") or settings.node_id,
                  "configured": bool(node.get("node_id") or settings.node_id)},
        "recovery": {"configured": bool(recovery_info.get("recovery_credential")),
                      "state": "CONFIGURED" if recovery_info.get("recovery_credential") else "NOT_CONFIGURED"},
        "config_path": str(ENV_PATH),
    }


def _keychain_ready() -> bool:
    try:
        from app.secure_storage import load_keychain_key
        return bool(load_keychain_key())
    except SecureStorageError:
        return False


def _choose_home(supplied: str | None) -> Path:
    if supplied:
        return Path(supplied).expanduser()
    print("Where should Iclirius store your Memory Home?\n")
    print("1. Default local location")
    print("2. Choose a folder")
    print("3. Use an existing Memory Home")
    choice = input("> ").strip() or "1"
    if choice == "2":
        selected = _select_folder()
        if selected:
            return selected
        print("Folder selector unavailable; using the default location.")
    if choice == "3":
        selected = _select_folder()
        if selected:
            return selected
        value = input("Existing Memory Home path: ").strip()
        if value:
            return Path(value).expanduser()
    return _default_home()


def run_setup(args: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius setup", add_help=True)
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--non-interactive", action="store_true")
    parser.add_argument("--identity", default="")
    parser.add_argument("--memory-home", default="")
    parser.add_argument("--reset-machine", action="store_true")
    parser.add_argument("--existing-memory-home", action="store_true",
                        help="Enroll this machine into an existing Memory Home")
    parser.add_argument("--repair", action="store_true",
                        help="Repair safe local setup and service state without replacing identity or data")
    parser.add_argument("--profile", default="",
                        help="node profile (interface, local-compute, code-worker, remote-worker, full-node)")
    parsed = parser.parse_args(args or [])
    if parsed.status:
        current = status()
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if current["setup_complete"] else 1
    if parsed.repair:
        current = status()
        if not current.get("setup_complete"):
            print("Setup is incomplete; run iclirius setup first.", file=sys.stderr)
            return 2
        try:
            _write_setup_state("SYSTEM_CHECK", "CONFIGURED")
            service = _configure_service(interactive=False)
            if service.get("state") == "BLOCKED":
                print(json.dumps(service, indent=2, sort_keys=True))
                return 1
            validation = _final_validation()
            _write_setup_state("FINAL_VALIDATION", validation.get("state", "UNKNOWN"),
                               overall=validation.get("overall", "unknown"))
            print("Iclirius setup repair complete.")
            print(json.dumps({"service": service, "validation": validation}, indent=2, sort_keys=True))
            return 0
        except (OSError, ValueError) as exc:
            print(f"Setup repair failed: {exc}", file=sys.stderr)
            return 1
    _write_setup_state("SYSTEM_CHECK", "CONFIGURED", installation_mode="HOMEBREW" if "/Cellar/" in str(PROJECT_ROOT) else "SOURCE_CHECKOUT")
    if parsed.reset_machine:
        if parsed.non_interactive:
            print("--reset-machine requires an explicit interactive confirmation.")
            return 2
        if input("Type RESET to clear this machine's local setup only: ").strip() != "RESET":
            print("Cancelled. Memory Home was not changed.")
            return 1
        values = {"ICLIRIUS_SETUP_COMPLETE": "false", "ICLIRIUS_USER_ID": "",
                  "PRINCIPAL_USER_NAME": "", "MEMORY_HOME": "",
                  "IDENTITY_PATH": "./data/identity", "MEMORY_PATH": "./data/memory",
                  "MEMORY_ROOT": "./data/memory/core"}
        _write_env(values)
        local_node_path().unlink(missing_ok=True)
        print("Machine setup cleared. Memory Home and user data were preserved.")
        return 0

    # A configured machine is already onboarded.  Keep setup idempotent and
    # avoid prompting for local-AI remediation on every subsequent invocation.
    # Explicit enrollment/options still take the normal path below.
    if (not parsed.non_interactive and not parsed.identity and not parsed.memory_home
            and not parsed.existing_memory_home and status()["setup_complete"]):
        current = status()
        print("Iclirius is already configured on this machine.")
        print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
        return 0

    # Local AI is optional machine onboarding. It is deliberately separate
    # from the Homebrew installer and never downloads or installs silently.
    try:
        local_ai = configure_local_ai(interactive=not parsed.non_interactive)
    except (OSError, KeyboardInterrupt, EOFError) as exc:
        print(f"Local AI setup could not be completed: {exc}", file=sys.stderr)
        return 1
    if local_ai.state == "cancelled":
        print("Setup cancelled.")
        return 1
    if local_ai.changed_model and local_ai.selected_model:
        _write_env({"DEFAULT_MODEL": local_ai.selected_model})
        print(f"Default local model set to {local_ai.selected_model} in machine configuration.")

    if (not parsed.non_interactive and not parsed.identity and not parsed.memory_home
            and not parsed.existing_memory_home and not status()["setup_complete"]):
        print("How do you want to configure Iclirius?\n\n1. Create a new identity\n2. Use an existing Memory Home")
        if input("> ").strip() == "2":
            parsed.existing_memory_home = True

    # Existing-home enrollment is deliberately explicit.  It never creates a
    # new identity and cannot silently replace a missing local Keychain key.
    if parsed.existing_memory_home:
        try:
            selected = Path(parsed.memory_home).expanduser() if parsed.memory_home else _select_folder()
            if not selected:
                print("Existing Memory Home selection cancelled.")
                return 1
            home = load(selected)
            print("Existing Iclirius Memory Home found.")
            print(f"Identity: {home.primary_identity}")
            print(f"Memory Home ID: {home.memory_home_id}")
            print("Authentication is required to enroll this Mac.")
            passphrase = getpass.getpass("Recovery passphrase: ")
            from app.existing_enrollment import enroll_machine
            info = enroll_machine(selected, passphrase)
        except (MemoryHomeError, EnrollmentError, SecureStorageError, OSError, EOFError, KeyboardInterrupt) as exc:
            print(f"Existing Memory Home enrollment failed: {exc}", file=sys.stderr)
            return 1
        print("\nExisting identity enrolled on this Mac.")
        print(f"Identity: {info['primary_identity']}")
        print(f"Node: {info['node_id']}")
        print("Memory Core: decrypted and verified")
        return 0

    if (not parsed.non_interactive and not parsed.identity
            and not parsed.memory_home):
        current = status()
        if current["setup_complete"]:
            print("Iclirius is already configured on this machine.")
            print(json.dumps(current, ensure_ascii=False, indent=2, sort_keys=True))
            return 0

    try:
        existing = status()
        legacy_id = _legacy_principal_id()
        identity_text = parsed.identity.strip()
        if not identity_text and existing["identity"]["configured"]:
            identity = UserIdentity(existing["identity"]["user_id"],
                                    validate_primary_identity(existing["identity"]["primary_identity"]))
        elif identity_text:
            identity = new_identity(identity_text)
        elif parsed.non_interactive:
            raise IdentityError("--non-interactive requires --identity.")
        else:
            identity = _prompt_identity()
        _write_setup_state("IDENTITY", "CONFIGURED", identity=identity.primary_identity)

        # Preserve the principal id already inside an encrypted legacy vault;
        # changing only the human-readable identity must not fork continuity.
        if legacy_id and not existing["identity"]["configured"]:
            identity = UserIdentity(legacy_id, identity.primary_identity, identity.display_name)

        home_path = _choose_home(parsed.memory_home) if not parsed.non_interactive else Path(parsed.memory_home).expanduser()
        if parsed.non_interactive and not parsed.memory_home:
            raise MemoryHomeError("--non-interactive requires --memory-home.")
        existing_manifest = (home_path / "manifest.json").exists()
        for legacy_source in _legacy_sources().values():
            if (not existing_manifest and legacy_source.exists()
                    and _paths_overlap(home_path, legacy_source)):
                raise MemoryHomeError(
                    "Memory Home cannot overlap the existing local Iclirius state."
                )
        if existing_manifest:
            home = load(home_path)
            if home.primary_identity.casefold() != identity.primary_identity.casefold():
                raise MemoryHomeError("Existing Memory Home belongs to another identity.")
            identity = UserIdentity(home.user_id, identity.primary_identity, identity.display_name)
        else:
            home = create(home_path, identity.user_id, identity.primary_identity)
        _write_setup_state("MEMORY_HOME", "CONFIGURED", memory_home=str(home.root))

        # Never generate a new key in front of an existing encrypted vault:
        # doing so would make that vault unreadable. A user must complete an
        # explicit key migration first. Fresh homes may bootstrap normally.
        if _encrypted_state_exists() and not _keychain_ready():
            raise SecureStorageError(
                "Encrypted existing memory was found but its Keychain material is unavailable; "
                "refusing to replace it automatically."
            )
        # This bootstrap creates local material only. It never copies a
        # Keychain value into the Memory Home.
        ensure_keychain_key()
        _write_setup_state("KEYCHAIN", "CONFIGURED", backend="macOS Keychain")
        machine_root = os.getenv("ICLIRIUS_MACHINE_STATE", "").strip()
        if machine_root:
            backup_base = Path(machine_root).expanduser()
        else:
            # Tests and relocatable installs may override ENV_PATH. Keep the
            # backup beside that machine config rather than the source tree's
            # developer home.
            backup_base = ENV_PATH.parent / ".iclirius"
        backup_root = backup_base / "backups" / f"setup-migration-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        migration = _migrate_legacy(home, backup_root)
        node = ensure_node()
        _write_setup_state("NODE_IDENTITY", "CONFIGURED", node_id=node["node_id"])
        if parsed.profile:
            from app.node_identity import set_node_role
            node = set_node_role(parsed.profile)
        _write_env({
            "ICLIRIUS_SETUP_COMPLETE": "true",
            "ICLIRIUS_USER_ID": identity.user_id,
            "PRINCIPAL_USER_NAME": identity.primary_identity,
            "MEMORY_HOME": str(home.root),
            "IDENTITY_PATH": str(home.profile_path),
            "MEMORY_PATH": str(home.memory_path),
            "MEMORY_ROOT": str(home.core_path),
            "OPENCLAW_NODE_ID": str(node["node_id"]),
        })
        _write_setup_state("RUNTIME", "CONFIGURED", version="managed")
        # LAN discovery is a machine-local convenience and defaults on for a
        # completed setup. It never changes trust or canonical Memory.
        from app.node_discovery import set_discovery_enabled
        set_discovery_enabled(True)
        recovery = _configure_recovery(identity=identity, interactive=not parsed.non_interactive)
        _write_setup_state("RECOVERY", recovery.get("state", "UNKNOWN"),
                           recovery_credential=bool(recovery.get("recovery_credential")))
        service = _configure_service(interactive=not parsed.non_interactive)
        _write_setup_state("SERVICE", service.get("state", "UNKNOWN"),
                           service_state=service.get("service", {}).get("state", service.get("error", "")))
        _write_setup_state("LOCAL_AI", "CONFIGURED" if local_ai.state in {"ready", "not_running", "not_installed"} else local_ai.state,
                           ollama=local_ai.state)
        _write_setup_state("CAPABILITIES", "CONFIGURED")
        # Cluster setup is deliberately standalone by default. Discovery never
        # becomes trust; enrollment remains an explicit operator ceremony.
        _write_setup_state("CLUSTER", "CONFIGURED", mode="STANDALONE", enrollment="CLOSED")
        validation = _final_validation()
        _write_setup_state("FINAL_VALIDATION", validation.get("state", "UNKNOWN"),
                           overall=validation.get("overall", "unknown"))
        if validation.get("state") == "CONFIGURED":
            _write_setup_state("COMPLETE", "CONFIGURED")
        else:
            _write_setup_state("FINAL_VALIDATION", "REPAIRABLE")
    except (IdentityError, MemoryHomeError, SecureStorageError, OSError) as exc:
        print(f"Setup could not be completed: {exc}", file=sys.stderr)
        return 1

    print("\nSetup complete.")
    print(f"Identity: {identity.primary_identity}")
    print(f"Memory Home: {home.root}")
    print("Local secrets: macOS Keychain")
    print(f"Node: {node['node_id']}")
    if migration["copied_files"]:
        print(f"Migrated encrypted files: {migration['copied_files']} (backup preserved)")
    print("\nCluster: standalone (no peer was trusted automatically)")
    print(f"Capabilities: {validation.get('capabilities', 'UNKNOWN')} ({validation.get('node_role', 'INTERFACE')})")
    print(f"Service: {service.get('service', {}).get('state', service.get('state', 'UNKNOWN'))}")
    print("\nRun:\n  iclirius doctor\n  iclirius node status\n  iclirius")
    return 0


def main(argv: list[str] | None = None) -> int:
    return run_setup(argv)
