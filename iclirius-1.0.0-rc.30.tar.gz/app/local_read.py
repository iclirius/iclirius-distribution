"""
Read-only local filesystem and repository inspection.

Design rule for the whole module, and the reason it exists:

    the filesystem work happens here, in Python and ripgrep;
    the model only ever sees a reduced summary.

A folder with 20,000 files is counted, classified and ranked locally, and
Ollama receives a few hundred characters of statistics. Nothing in this module
writes, moves, deletes or executes anything the user did not ask for by name,
and no function here takes a shell string.

Every path passes through app.file_catalog.validate_safe_path, which is the
single path policy in the project.
"""

from __future__ import annotations

import hashlib
import os
import subprocess
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from app.config import settings
from app.file_catalog import validate_safe_path
from app.logger import logger

# Build manifests worth surfacing when summarising a project.
BUILD_FILES = {
    "package.json", "pyproject.toml", "requirements.txt", "Pipfile", "poetry.lock",
    "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
    "pom.xml", "Cargo.toml", "go.mod", "Gemfile", "composer.json",
    "Dockerfile", "docker-compose.yml", "Makefile", "CMakeLists.txt",
}

# Directories that are noise in every summary.
SKIP_DIRS = {
    ".git", ".venv", "venv", "node_modules", "__pycache__", ".next", ".gradle",
    "build", "dist", ".idea", ".vscode", "target", ".mypy_cache", ".pytest_cache",
    "DerivedData", ".tox", "vendor",
}

TEXT_SUFFIXES = {
    ".txt", ".md", ".rst", ".log", ".csv", ".tsv", ".json", ".jsonl", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".conf", ".xml", ".html", ".htm", ".css", ".scss",
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".kt", ".kts", ".swift", ".m", ".mm",
    ".c", ".h", ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb", ".php", ".sh", ".bash",
    ".zsh", ".sql", ".gradle", ".properties", ".env.example", ".gitignore",
}

LANGUAGE_BY_SUFFIX = {
    ".py": "Python", ".js": "JavaScript", ".ts": "TypeScript", ".tsx": "TypeScript",
    ".jsx": "JavaScript", ".java": "Java", ".kt": "Kotlin", ".kts": "Kotlin",
    ".swift": "Swift", ".c": "C", ".h": "C", ".cpp": "C++", ".hpp": "C++",
    ".cs": "C#", ".go": "Go", ".rs": "Rust", ".rb": "Ruby", ".php": "PHP",
    ".sh": "Shell", ".sql": "SQL", ".m": "Objective-C",
}


class LocalReadError(RuntimeError):
    """Raised when a read operation cannot be completed."""


class LocalReadDisabled(LocalReadError):
    """Raised when local read tools are switched off."""


@dataclass
class ReadResult:
    """What every operation returns: text for the model plus metadata."""

    operation: str
    summary: str
    truncated: bool = False
    total_found: int = 0
    shown: int = 0
    details: dict = field(default_factory=dict)

    def as_model_text(self) -> str:
        text = self.summary
        limit = settings.local_read_model_chars
        return text[:limit]


def _require_enabled() -> None:
    if not settings.enable_local_read_tools:
        raise LocalReadDisabled(
            "Las herramientas de lectura local están desactivadas. "
            "Actívalas con ENABLE_LOCAL_READ_TOOLS=true en .env."
        )


def _safe_dir(path: str | Path) -> Path:
    target = validate_safe_path(path)

    if not target.exists():
        raise LocalReadError(f"No existe la ruta: {target}")

    if not target.is_dir():
        raise LocalReadError(f"No es una carpeta: {target}")

    return target


def _human_size(num_bytes: int) -> str:
    value = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{value:.1f} TB"


def _mtime(path: Path) -> str:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="minutes")
    except OSError:
        return "?"


def _walk(root: Path, max_depth: int):
    """
    Yield files under root, skipping noise directories and anything the path
    policy refuses. Depth is counted from root.
    """
    root_depth = len(root.parts)

    for current, dirs, files in os.walk(root, onerror=lambda e: None):
        current_path = Path(current)

        if len(current_path.parts) - root_depth >= max_depth:
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

        for name in files:
            candidate = current_path / name
            try:
                validate_safe_path(candidate)
            except (PermissionError, RuntimeError):
                continue
            yield candidate


# --- operations -----------------------------------------------------------


def list_directory(path: str) -> ReadResult:
    """Immediate children of a directory, directories first."""
    _require_enabled()
    target = _safe_dir(path)
    limit = settings.local_read_max_results

    entries = []
    total = 0

    try:
        for entry in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            try:
                validate_safe_path(entry)
            except (PermissionError, RuntimeError):
                continue

            total += 1

            if len(entries) < limit:
                try:
                    stat = entry.stat()
                    entries.append(
                        f"{'[dir] ' if entry.is_dir() else '      '}{entry.name}"
                        f"{'' if entry.is_dir() else f'  {_human_size(stat.st_size)}'}"
                        f"  {_mtime(entry)}"
                    )
                except OSError:
                    continue
    except PermissionError as exc:
        raise LocalReadError(f"Permiso denegado: {target}") from exc

    truncated = total > len(entries)
    header = f"Contenido de {target} ({total} elementos)"
    if truncated:
        header += f"; mostrando los primeros {len(entries)}"

    return ReadResult(
        operation="LIST_DIRECTORY",
        summary="\n".join([header, ""] + entries),
        truncated=truncated,
        total_found=total,
        shown=len(entries),
    )


def find_files(path: str, pattern: str = "*") -> ReadResult:
    """Recursive search by glob pattern, name fragment or extension."""
    _require_enabled()
    target = _safe_dir(path)
    limit = settings.local_read_max_results
    depth = settings.local_read_max_depth

    pattern = (pattern or "*").strip()
    needle = pattern.lower().lstrip("*.")

    matches: list[Path] = []
    total = 0

    for candidate in _walk(target, depth):
        name = candidate.name.lower()

        if pattern in ("*", ""):
            hit = True
        elif pattern.startswith("*."):
            hit = name.endswith(pattern[1:].lower())
        elif "*" in pattern or "?" in pattern:
            hit = candidate.match(pattern)
        else:
            hit = needle in name

        if not hit:
            continue

        total += 1
        if len(matches) < limit:
            matches.append(candidate)

    lines = []
    for match in matches:
        try:
            lines.append(f"{match.relative_to(target)}  {_human_size(match.stat().st_size)}")
        except (OSError, ValueError):
            lines.append(str(match))

    truncated = total > len(matches)
    header = f"Coincidencias de '{pattern}' en {target}: {total}"
    if truncated:
        header += f"; mostrando las primeras {len(matches)}"

    return ReadResult(
        operation="FIND_FILES",
        summary="\n".join([header, ""] + lines),
        truncated=truncated,
        total_found=total,
        shown=len(matches),
    )


def search_text(path: str, query: str) -> ReadResult:
    """
    Search text inside files.

    Uses ripgrep when available because it is dramatically faster and already
    skips binaries and ignored directories; falls back to Python otherwise.
    Either way the heavy scanning happens locally and only the reduced match
    list reaches the model.
    """
    _require_enabled()
    target = _safe_dir(path)

    query = (query or "").strip()
    if not query:
        raise LocalReadError("La búsqueda de texto necesita un término.")

    limit = settings.local_read_max_results
    matches, total, engine = _ripgrep(target, query, limit)

    if matches is None:
        matches, total = _python_grep(target, query, limit)
        engine = "python"

    truncated = total > len(matches)
    header = f"Coincidencias de '{query}' en {target}: {total} (motor: {engine})"
    if truncated:
        header += f"; mostrando las primeras {len(matches)}"

    return ReadResult(
        operation="SEARCH_TEXT",
        summary="\n".join([header, ""] + matches),
        truncated=truncated,
        total_found=total,
        shown=len(matches),
        details={"engine": engine},
    )


def _ripgrep(target: Path, query: str, limit: int):
    """Returns (lines, total, engine) or (None, 0, '') when rg is unusable."""
    command = [
        "rg", "--no-heading", "--line-number", "--with-filename",
        "--max-columns", "200", "--max-count", "5",
        "--fixed-strings", "--ignore-case",
        "--", query, str(target),
    ]

    try:
        result = subprocess.run(
            command, capture_output=True, text=True,
            timeout=settings.local_read_timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None, 0, ""

    if result.returncode not in (0, 1):
        return None, 0, ""

    raw = [line for line in result.stdout.splitlines() if line.strip()]
    lines = []

    for line in raw[:limit]:
        try:
            file_part, rest = line.split(":", 1)
            lines.append(f"{Path(file_part).relative_to(target)}:{rest.strip()[:200]}")
        except (ValueError, OSError):
            lines.append(line[:200])

    return lines, len(raw), "ripgrep"


def _python_grep(target: Path, query: str, limit: int):
    needle = query.lower()
    lines: list[str] = []
    total = 0

    for candidate in _walk(target, settings.local_read_max_depth):
        if candidate.suffix.lower() not in TEXT_SUFFIXES:
            continue

        try:
            if candidate.stat().st_size > settings.local_read_max_bytes:
                continue
            content = candidate.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        if "\x00" in content[:1024]:
            continue

        for number, line in enumerate(content.splitlines(), start=1):
            if needle in line.lower():
                total += 1
                if len(lines) < limit:
                    try:
                        rel = candidate.relative_to(target)
                    except ValueError:
                        rel = candidate
                    lines.append(f"{rel}:{number}: {line.strip()[:200]}")

    return lines, total


def read_text_file(path: str) -> ReadResult:
    """Read a permitted text file, bounded by bytes and lines."""
    _require_enabled()
    target = validate_safe_path(path)

    if not target.exists():
        raise LocalReadError(f"No existe el archivo: {target}")

    if not target.is_file():
        raise LocalReadError(f"No es un archivo: {target}")

    size = target.stat().st_size

    try:
        with target.open("rb") as handle:
            head = handle.read(settings.local_read_max_bytes)
    except OSError as exc:
        raise LocalReadError(f"No pude leer el archivo: {exc}") from exc

    if b"\x00" in head[:4096]:
        raise LocalReadError(f"El archivo parece binario: {target.name}")

    text = head.decode("utf-8", errors="replace")
    all_lines = text.splitlines()
    max_lines = settings.local_read_max_lines
    lines = all_lines[:max_lines]
    truncated = size > len(head) or len(all_lines) > max_lines

    header = f"{target} ({_human_size(size)}, {len(all_lines)} líneas leídas)"
    if truncated:
        header += f"; mostrando las primeras {len(lines)}"

    return ReadResult(
        operation="READ_TEXT_FILE",
        summary="\n".join([header, ""] + lines),
        truncated=truncated,
        total_found=len(all_lines),
        shown=len(lines),
    )


def file_stat(path: str) -> ReadResult:
    _require_enabled()
    target = validate_safe_path(path)

    if not target.exists():
        raise LocalReadError(f"No existe la ruta: {target}")

    stat = target.stat()
    kind = "carpeta" if target.is_dir() else "archivo"

    summary = "\n".join([
        f"Ruta: {target}",
        f"Tipo: {kind}",
        f"Extensión: {target.suffix or '(ninguna)'}",
        f"Tamaño: {_human_size(stat.st_size)}",
        f"Modificado: {_mtime(target)}",
    ])

    return ReadResult(operation="FILE_STAT", summary=summary, total_found=1, shown=1)


def hash_file(path: str) -> ReadResult:
    """SHA-256, streamed locally. Useful for spotting duplicates."""
    _require_enabled()
    target = validate_safe_path(path)

    if not target.is_file():
        raise LocalReadError(f"No es un archivo: {target}")

    digest = hashlib.sha256()

    try:
        with target.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError as exc:
        raise LocalReadError(f"No pude leer el archivo: {exc}") from exc

    summary = "\n".join([
        f"Archivo: {target.name}",
        f"Tamaño: {_human_size(target.stat().st_size)}",
        f"SHA-256: {digest.hexdigest()}",
    ])

    return ReadResult(
        operation="HASH_FILE",
        summary=summary,
        total_found=1,
        shown=1,
        details={"sha256": digest.hexdigest()},
    )


def directory_summary(path: str) -> ReadResult:
    """
    Statistics for a whole tree.

    This is the reduction step that makes the phase work: everything is
    counted locally and the model receives a few hundred characters.
    """
    _require_enabled()
    target = _safe_dir(path)

    files = 0
    total_bytes = 0
    by_extension: Counter[str] = Counter()
    by_language: Counter[str] = Counter()
    largest: list[tuple[int, Path]] = []
    recent: list[tuple[float, Path]] = []
    build_found: set[str] = set()
    directories = 0

    for current, dirs, names in os.walk(target, onerror=lambda e: None):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        directories += len(dirs)

        for name in names:
            candidate = Path(current) / name

            try:
                validate_safe_path(candidate)
                stat = candidate.stat()
            except (PermissionError, RuntimeError, OSError):
                continue

            files += 1
            total_bytes += stat.st_size
            suffix = candidate.suffix.lower()
            by_extension[suffix or "(sin extensión)"] += 1

            if suffix in LANGUAGE_BY_SUFFIX:
                by_language[LANGUAGE_BY_SUFFIX[suffix]] += 1

            if name in BUILD_FILES:
                build_found.add(name)

            largest.append((stat.st_size, candidate))
            recent.append((stat.st_mtime, candidate))

            if len(largest) > 2000:
                largest = sorted(largest, reverse=True)[:20]
                recent = sorted(recent, reverse=True)[:20]

    largest = sorted(largest, reverse=True)[:5]
    recent = sorted(recent, reverse=True)[:5]

    lines = [
        f"Resumen de {target}",
        f"- Archivos: {files}",
        f"- Carpetas: {directories}",
        f"- Tamaño total: {_human_size(total_bytes)}",
    ]

    if by_extension:
        top = ", ".join(f"{ext} ({count})" for ext, count in by_extension.most_common(8))
        lines.append(f"- Extensiones principales: {top}")

    if by_language:
        top = ", ".join(f"{lang} ({count})" for lang, count in by_language.most_common(5))
        lines.append(f"- Lenguajes: {top}")

    if build_found:
        lines.append(f"- Archivos de build: {', '.join(sorted(build_found))}")

    if largest:
        lines.append("- Más grandes:")
        for size, candidate in largest:
            try:
                rel = candidate.relative_to(target)
            except ValueError:
                rel = candidate
            lines.append(f"    {rel}  {_human_size(size)}")

    if recent:
        lines.append("- Modificados recientemente:")
        for mtime, candidate in recent:
            try:
                rel = candidate.relative_to(target)
            except ValueError:
                rel = candidate
            lines.append(f"    {rel}  {datetime.fromtimestamp(mtime).isoformat(timespec='minutes')}")

    return ReadResult(
        operation="DIRECTORY_SUMMARY",
        summary="\n".join(lines),
        total_found=files,
        shown=files,
        details={"files": files, "bytes": total_bytes},
    )


# --- git ------------------------------------------------------------------
#
# Read-only porcelain only. The command list is fixed in code; nothing the
# user or the model writes becomes an argument beyond the repository path.

GIT_READ_COMMANDS = {
    "GIT_STATUS": ["status", "--short", "--branch"],
    "GIT_DIFF": ["diff", "--stat"],
    "GIT_LOG": ["log", "--oneline", "-n", "20"],
}


def _repo_root(path: str) -> Path:
    target = _safe_dir(path)

    for candidate in [target, *target.parents]:
        if (candidate / ".git").exists():
            try:
                validate_safe_path(candidate)
            except (PermissionError, RuntimeError):
                break
            return candidate

    raise LocalReadError(f"No es un repositorio Git: {target}")


def _run_git(repo: Path, args: list[str]) -> str:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), *args],
            capture_output=True, text=True,
            timeout=settings.local_read_timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as exc:
        raise LocalReadError(f"No pude ejecutar git: {type(exc).__name__}") from exc

    if result.returncode != 0:
        raise LocalReadError(f"git falló: {(result.stderr or '').strip()[:200]}")

    return result.stdout


def git_read(path: str, operation: str) -> ReadResult:
    _require_enabled()

    if operation not in GIT_READ_COMMANDS:
        raise LocalReadError(f"Operación git no permitida: {operation}")

    repo = _repo_root(path)
    output = _run_git(repo, GIT_READ_COMMANDS[operation])
    lines = output.splitlines()
    limit = settings.local_read_max_results
    shown = lines[:limit]

    header = f"{operation} en {repo}"
    if len(lines) > len(shown):
        header += f" ({len(lines)} líneas; mostrando {len(shown)})"

    body = "\n".join(shown) or "(sin cambios)"

    return ReadResult(
        operation=operation,
        summary=f"{header}\n\n{body}",
        truncated=len(lines) > len(shown),
        total_found=len(lines),
        shown=len(shown),
    )


def is_git_repo(path: str) -> bool:
    try:
        _repo_root(path)
        return True
    except LocalReadError:
        return False


# --- dispatch -------------------------------------------------------------

OPERATIONS = {
    "LIST_DIRECTORY": lambda op: list_directory(op.path),
    "FIND_FILES": lambda op: find_files(op.path, op.query or "*"),
    "SEARCH_TEXT": lambda op: search_text(op.path, op.query or ""),
    "READ_TEXT_FILE": lambda op: read_text_file(op.path),
    "FILE_STAT": lambda op: file_stat(op.path),
    "HASH_FILE": lambda op: hash_file(op.path),
    "DIRECTORY_SUMMARY": lambda op: directory_summary(op.path),
    "GIT_STATUS": lambda op: git_read(op.path, "GIT_STATUS"),
    "GIT_DIFF": lambda op: git_read(op.path, "GIT_DIFF"),
    "GIT_LOG": lambda op: git_read(op.path, "GIT_LOG"),
}


def execute(operation) -> ReadResult:
    """
    Run a validated LocalOperation.

    The operation name is looked up in a fixed table; there is no path from a
    string to a shell command.
    """
    handler = OPERATIONS.get(operation.name)

    if handler is None:
        raise LocalReadError(f"Operación no soportada: {operation.name}")

    started = time.time()

    try:
        result = handler(operation)
    except (PermissionError, RuntimeError, OSError) as exc:
        logger.warning(
            "Local read failed op=%s error=%s duration_ms=%s",
            operation.name, type(exc).__name__, int((time.time() - started) * 1000),
        )
        raise

    logger.info(
        "Local read ok op=%s results=%s shown=%s truncated=%s duration_ms=%s",
        result.operation, result.total_found, result.shown, result.truncated,
        int((time.time() - started) * 1000),
    )

    return result
