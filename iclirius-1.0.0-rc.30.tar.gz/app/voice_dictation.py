"""One-shot voice input for the existing chat composer."""
from __future__ import annotations

import threading
from pathlib import Path

from app.talk.app import MicrophoneCapture, MicrophonePermissionError
from app.voice import VoiceService, voice_service


class VoiceDictationService:
    def __init__(self, *, voice: VoiceService | None = None, microphone=None):
        self.voice = voice or voice_service
        self.microphone = microphone or MicrophoneCapture()

    def transcribe_once(self, stop_event: threading.Event, *, language: str = "es",
                        on_event=None) -> str:
        path = self.microphone.capture(stop_event, on_event=on_event)
        if path is None:
            return ""
        try:
            transcript, _ = self.voice.transcribe(Path(path), on_stage=on_event,
                                                  language=language)
            return (transcript or "").strip()
        finally:
            Path(path).unlink(missing_ok=True)

