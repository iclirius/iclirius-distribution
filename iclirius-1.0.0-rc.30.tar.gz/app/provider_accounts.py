"""
Several accounts, one identity.

A Gemini account is a resource, the way a model is. Iclirius keeps the task,
the memory, the project and the continuity; an account contributes a quota and
nothing else, so swapping one for another mid-request changes which key paid
for the reasoning and nothing about what the reasoning was for.

    Gemini account A
        ↓  rate limited
    Gemini account B
        ↓  answers
    same task, same project, same identity

Selection is deterministic: sorted by priority, filtered by eligibility, first
one wins. There is no model call to decide which account to use, because that
would be paying a provider to choose which provider to pay.

The failure taxonomy is the whole point of this module. Blind failover is
worse than none: a malformed prompt retried across every account burns every
quota to produce the same error four times. So a rate limit moves on, a quota
exhaustion moves on, an auth error disables and moves on, and a bad request
stops immediately, because the next account will not like it any better.

No secret lives here. An account holds a credential *reference*, and resolving
it is app/credentials.py's job.
"""

from __future__ import annotations

import threading
import time
from dataclasses import asdict, dataclass, field

from app.logger import logger
from app.reasoning import ProviderStatus

# Failure kinds this pool routes on. They come from the provider adapters,
# which classify their own transport errors.
AUTH_ERROR = "AUTH_ERROR"
RATE_LIMIT = "RATE_LIMIT"
QUOTA_EXHAUSTED = "QUOTA_EXHAUSTED"
TIMEOUT = "TIMEOUT"
NETWORK_ERROR = "NETWORK_ERROR"
SERVER_ERROR = "SERVER_ERROR"
BAD_REQUEST = "BAD_REQUEST"
INVALID_RESPONSE = "INVALID_RESPONSE"

# What each failure means for the account, and whether to try another one.
#
#   BAD_REQUEST      the prompt was wrong, not the account. Trying a second
#                    account would burn a second quota for the same error.
#   INVALID_RESPONSE the account worked and the answer did not parse. Another
#                    account might genuinely do better, so one more try — but
#                    bounded, because a model that returns prose instead of
#                    JSON tends to keep doing it.
FAILOVER_POLICY = {
    RATE_LIMIT: True,
    QUOTA_EXHAUSTED: True,
    AUTH_ERROR: True,
    TIMEOUT: True,
    NETWORK_ERROR: True,
    SERVER_ERROR: True,
    BAD_REQUEST: False,
    INVALID_RESPONSE: True,
}


class AccountError(RuntimeError):
    """No account could serve the request."""


@dataclass
class ProviderAccount:
    """
    One account of one provider. Configuration plus live state.

    cooldown_until is runtime-only on purpose: a rate limit that lasted a
    minute should not still be remembered as a reason to skip an account after
    a restart tomorrow.
    """

    provider_id: str
    account_ref: str
    credential_ref: str = ""
    enabled: bool = True
    priority: int = 100
    model: str = ""
    status: str = ProviderStatus.AVAILABLE.value
    cooldown_until: float = 0.0
    consecutive_failures: int = 0
    last_error_kind: str = ""

    def is_cooling(self, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now

        return self.cooldown_until > now

    def eligible(self, now: float | None = None) -> bool:
        if not self.enabled:
            return False

        if self.status in (ProviderStatus.DISABLED.value,
                           ProviderStatus.EXHAUSTED.value,
                           ProviderStatus.UNAVAILABLE.value):
            return False

        return not self.is_cooling(now)

    def safe_summary(self) -> dict:
        """
        For status views and events.

        account_ref is a label the owner chose and is safe to show. The
        credential reference is not included: a Keychain service name can
        describe how someone organises their accounts.
        """
        remaining = max(0, int(self.cooldown_until - time.monotonic()))

        return {
            "provider_id": self.provider_id,
            "account_ref": self.account_ref,
            "enabled": self.enabled,
            "priority": self.priority,
            "status": self.status,
            "cooldown_seconds": remaining,
            "last_error_kind": self.last_error_kind or None,
        }

    def to_dict(self) -> dict:
        record = asdict(self)
        record.pop("credential_ref", None)

        return record


class ProviderAccountPool:
    """
    Ordered, eligible accounts for one provider family.

    Locked because two interfaces can ask at once, and a lost counter or an
    account marked exhausted by a race would be a quota decision made by
    accident.
    """

    def __init__(self, cooldown_seconds: int = 60,
                 exhaustion_cooldown_seconds: int = 900):
        self._accounts: dict[str, ProviderAccount] = {}
        self._lock = threading.Lock()
        self.cooldown_seconds = cooldown_seconds
        # An exhausted quota may reset on a window the API does not tell us
        # about, so it is parked rather than declared dead forever.
        self.exhaustion_cooldown_seconds = exhaustion_cooldown_seconds

    # -- registry ----------------------------------------------------------

    def add(self, account: ProviderAccount) -> ProviderAccount:
        with self._lock:
            self._accounts[account.account_ref] = account

        return account

    def get(self, account_ref: str) -> ProviderAccount | None:
        return self._accounts.get(account_ref)

    def list(self, provider_id: str | None = None) -> list[ProviderAccount]:
        accounts = list(self._accounts.values())

        if provider_id:
            accounts = [item for item in accounts if item.provider_id == provider_id]

        return sorted(accounts, key=lambda item: (item.priority, item.account_ref))

    def eligible(self, provider_id: str | None = None) -> list[ProviderAccount]:
        now = time.monotonic()

        with self._lock:
            self._expire_cooldowns(now)

        return [item for item in self.list(provider_id) if item.eligible(now)]

    def select(self, provider_id: str | None = None) -> ProviderAccount:
        """Highest priority eligible account. Deterministic and free."""
        candidates = self.eligible(provider_id)

        if not candidates:
            raise AccountError(
                f"No hay ninguna cuenta disponible para {provider_id or 'el proveedor'}."
            )

        return candidates[0]

    def clear(self) -> None:
        with self._lock:
            self._accounts.clear()

    # -- outcomes ----------------------------------------------------------

    def mark_success(self, account_ref: str) -> None:
        with self._lock:
            account = self._accounts.get(account_ref)

            if account is None:
                return

            account.status = ProviderStatus.AVAILABLE.value
            account.cooldown_until = 0.0
            account.consecutive_failures = 0
            account.last_error_kind = ""

    def mark_rate_limited(self, account_ref: str, seconds: int | None = None) -> None:
        """
        Park it briefly.

        Without a cooldown the same account would be tried first on the very
        next request and rate-limited again, which is how a limit becomes a
        loop.
        """
        with self._lock:
            account = self._accounts.get(account_ref)

            if account is None:
                return

            account.status = ProviderStatus.RATE_LIMITED.value
            account.cooldown_until = time.monotonic() + (
                seconds if seconds is not None else self.cooldown_seconds)
            account.consecutive_failures += 1
            account.last_error_kind = RATE_LIMIT

        logger.info("Account rate limited account_ref=%s", account_ref)

    def mark_exhausted(self, account_ref: str) -> None:
        with self._lock:
            account = self._accounts.get(account_ref)

            if account is None:
                return

            account.status = ProviderStatus.EXHAUSTED.value
            # No reset date is assumed: the API does not report one, so this is
            # a re-check interval, not a claim about when the quota returns.
            account.cooldown_until = (time.monotonic()
                                      + self.exhaustion_cooldown_seconds)
            account.consecutive_failures += 1
            account.last_error_kind = QUOTA_EXHAUSTED

        logger.info("Account quota exhausted account_ref=%s", account_ref)

    def mark_unavailable(self, account_ref: str, kind: str = AUTH_ERROR) -> None:
        """A bad key does not fix itself; the account stays out until changed."""
        with self._lock:
            account = self._accounts.get(account_ref)

            if account is None:
                return

            account.status = ProviderStatus.UNAVAILABLE.value
            account.consecutive_failures += 1
            account.last_error_kind = kind

        logger.info("Account unavailable account_ref=%s kind=%s", account_ref, kind)

    def mark_failure(self, account_ref: str, kind: str) -> bool:
        """
        Record a failure and say whether another account should be tried.

        Returns the failover decision so the caller does not re-derive the
        policy and get it subtly different.
        """
        if kind == RATE_LIMIT:
            self.mark_rate_limited(account_ref)
        elif kind == QUOTA_EXHAUSTED:
            self.mark_exhausted(account_ref)
        elif kind == AUTH_ERROR:
            self.mark_unavailable(account_ref, kind)
        else:
            with self._lock:
                account = self._accounts.get(account_ref)

                if account is not None:
                    account.consecutive_failures += 1
                    account.last_error_kind = kind

        return FAILOVER_POLICY.get(kind, False)

    def reset_status(self, account_ref: str) -> None:
        """Bring an account back deliberately. Nothing calls this on a timer."""
        with self._lock:
            account = self._accounts.get(account_ref)

            if account is not None:
                account.status = ProviderStatus.AVAILABLE.value
                account.cooldown_until = 0.0
                account.consecutive_failures = 0

    def _expire_cooldowns(self, now: float) -> None:
        """A parked account becomes eligible again once its window passes."""
        for account in self._accounts.values():
            if account.cooldown_until and account.cooldown_until <= now:
                account.cooldown_until = 0.0

                if account.status in (ProviderStatus.RATE_LIMITED.value,
                                      ProviderStatus.EXHAUSTED.value):
                    account.status = ProviderStatus.AVAILABLE.value

    def describe(self, provider_id: str | None = None) -> list[dict]:
        return [account.safe_summary() for account in self.list(provider_id)]


def parse_accounts(spec: str, provider_id: str = "gemini") -> list[ProviderAccount]:
    """
    Read the declarative account configuration.

        gemini-primary|keychain:openclaw/gemini-primary|10,
        gemini-secondary|env:GEMINI_KEY_2|20

    Pipe-separated so a Keychain reference, which already contains a colon,
    does not need escaping. Priority is optional and defaults to declaration
    order. No email is required and no secret appears.
    """
    accounts: list[ProviderAccount] = []

    for index, entry in enumerate((spec or "").split(",")):
        entry = entry.strip()

        if not entry:
            continue

        parts = [part.strip() for part in entry.split("|")]
        account_ref = parts[0]

        if not account_ref:
            continue

        credential_ref = parts[1] if len(parts) > 1 else ""

        try:
            priority = int(parts[2]) if len(parts) > 2 and parts[2] else (index + 1) * 10
        except ValueError:
            priority = (index + 1) * 10

        accounts.append(ProviderAccount(
            provider_id=provider_id,
            account_ref=account_ref,
            credential_ref=credential_ref,
            priority=priority,
        ))

    return accounts
