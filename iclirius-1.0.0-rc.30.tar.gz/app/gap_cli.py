"""CLI for the local Capability Gap Ledger."""
from __future__ import annotations

import argparse
import json

from app.capability_gap import CapabilityGapLedger
from app.config import settings
from app.version import VERSION


def _ledger():
    return CapabilityGapLedger.from_memory_home(
        getattr(settings, "memory_home", ""),
        node_id=str(getattr(settings, "node_id", "local-node")),
        user_id=getattr(settings, "user_id", None), version=VERSION,
        install_mode=getattr(settings, "install_mode", None),
        source_commit=getattr(settings, "source_commit", None),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius gaps")
    parser.add_argument("command", nargs="?", choices=("show", "verify"), default="list")
    parser.add_argument("gap_id", nargs="?")
    parser.add_argument("--open", action="store_true", dest="open_only")
    parser.add_argument("--recent", action="store_true")
    parser.add_argument("--capability")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    ledger = _ledger()
    if ledger is None:
        payload = {"status": "NOT_CONFIGURED", "message": "Memory Home is not configured."}
        print(json.dumps(payload, ensure_ascii=False) if args.json else payload["message"])
        return 0
    if args.command == "show":
        item = ledger.show(args.gap_id or "")
        if not item:
            print(json.dumps({"status": "NOT_FOUND"}) if args.json else "Gap no encontrado.")
            return 1
        print(json.dumps(item.to_dict(), ensure_ascii=False, indent=2) if args.json else
              f"{item.gap_id} {item.status} {item.category} ({item.occurrences})\n{item.representative_summary}")
        return 0
    if args.command == "verify":
        # Verification requires a structured regression fixture and is never
        # delegated to the model.  Until one is registered, fail closed.
        payload = {"gap_id": args.gap_id or "", "status": "NOT_VERIFIABLE",
                   "reason": "no deterministic regression fixture registered"}
        print(json.dumps(payload, ensure_ascii=False) if args.json else
              "NOT_VERIFIABLE: no deterministic regression fixture registered.")
        return 2
    items = ledger.aggregates(status="OPEN" if args.open_only else None, capability=args.capability)
    payload = {"open": sum(item.status == "OPEN" for item in items),
               "total": len(items), "gaps": [item.to_dict() for item in items]}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"Capability gaps — OPEN: {payload['open']} TOTAL: {payload['total']}")
        for item in items[:20]:
            print(f"{item.gap_id} [{item.status}] {item.category} x{item.occurrences}: {item.representative_summary}")
    return 0
