"""Read-only installation and runtime diagnostics for Iclirius."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _filesystem_diagnostics() -> dict:
    """Check configured metadata roots without traversing or reading files."""
    try:
        from app.config import settings
        configured = list(settings.file_manager_allowed_roots)
    except Exception:
        configured = []
    roots = []
    for raw in configured:
        path = Path(raw).expanduser()
        try:
            from app.file_roots import detect_provider
            provider = detect_provider(path)
            roots.append({"path": str(path.resolve(strict=False)), "display_name": path.name,
                          "provider": provider.value, "cloud_backed": provider.value != "LOCAL",
                          "configured": True,
                          "exists": path.exists(), "directory": path.is_dir(),
                          "readable": os.access(path, os.R_OK)})
        except OSError as exc:
            roots.append({"path": str(path), "configured": True, "exists": False,
                          "directory": False, "readable": False, "error": type(exc).__name__})
    memory_path = getattr(settings, "memory_home", "") if "settings" in locals() else ""
    return {"configured": bool(configured), "roots": roots,
            "memory_home": {"configured": bool(memory_path),
                            "accessible": bool(memory_path and os.access(Path(memory_path).expanduser(), os.R_OK))},
            "capabilities": {
                "inventory": {"status": "AVAILABLE"},
                "classification": {"status": "AVAILABLE"},
                "project_detection": {"status": "AVAILABLE"},
                "git_read": {"status": "AVAILABLE" if shutil.which("git") else "UNAVAILABLE"},
                "metadata_search": {"status": "AVAILABLE"},
                "content_extraction_text": {"status": "AVAILABLE"},
                "content_extraction_json_xml_csv": {"status": "AVAILABLE"},
                "content_extraction_pdf_text": {"status": "AVAILABLE" if _module_available("pypdf") else "UNAVAILABLE"},
                "content_extraction_docx": {"status": "AVAILABLE"},
                "ocr": {"status": "DEFERRED"},
                "semantic_index": {"status": "DEFERRED"},
                "content_analysis": {"status": "DEFERRED"},
                "persistent_index": {"status": "DEFERRED"},
                "safe_actions": {"status": "AVAILABLE"},
                "action_engine": {"status": "AVAILABLE"},
                "candidate_set": {"status": "AVAILABLE"},
                "dry_run": {"status": "AVAILABLE"},
                "confirmation": {"status": "AVAILABLE"},
                "trash": {"status": "AVAILABLE" if platform.system() == "Darwin" else "UNAVAILABLE"},
                "move": {"status": "AVAILABLE"},
                "rename": {"status": "AVAILABLE"},
                "verification": {"status": "AVAILABLE"},
                "receipts": {"status": "AVAILABLE"},
                "identity_gate": {"status": "AVAILABLE"},
                "permanent_delete": {"status": "INTENTIONALLY_UNSUPPORTED"},
            },
            "scan_performed": False}


def _attachment_diagnostics() -> dict:
    """Inspect the bounded staging policy without reading attachment content."""
    try:
        from app.config import settings
        root = Path(settings.state_path).expanduser() / "attachments"
        max_bytes = int(getattr(settings, "attachment_max_bytes", 10 * 1024 * 1024))
        ttl = int(getattr(settings, "attachment_ttl_seconds", 3600))
        return {"status": "AVAILABLE", "staging_root": str(root), "exists": root.exists(),
                "readable": os.access(root, os.R_OK) if root.exists() else None,
                "writable": os.access(root, os.W_OK) if root.exists() else None,
                "max_bytes": max_bytes, "ttl_seconds": ttl, "policy": "LOCAL_ONLY",
                "file3_integration": "AVAILABLE", "cleanup": "CONTROLLED_ROOT_ONLY",
                "supported_types": "FILE-3", "scan_performed": False}
    except Exception as exc:
        return {"status": "UNAVAILABLE", "reason": type(exc).__name__}


def _module_available(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


def _command(name: str) -> str | None:
    return shutil.which(name)


def _run(argv: list[str], timeout: float = 8) -> tuple[bool, str]:
    try:
        result = subprocess.run(argv, capture_output=True, text=True,
                                timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return False, ""
    return result.returncode == 0, (result.stdout or result.stderr or "").strip()


def _configured_models() -> tuple[list[str], list[str]]:
    try:
        from app.config import settings
        required = [settings.default_model, settings.fast_model, settings.heavy_model]
        optional = [settings.embed_model]
    except Exception:
        required, optional = [], []
    return (list(dict.fromkeys(name for name in required if name)),
            list(dict.fromkeys(name for name in optional if name)))


def _installed_models(ollama: str | None) -> list[str]:
    if not ollama:
        return []
    ok, output = _run([ollama, "list"])
    if not ok:
        return []
    models = []
    for line in output.splitlines()[1:]:
        fields = line.split()
        if fields:
            models.append(fields[0])
    return models


def _ollama_service() -> tuple[bool, str]:
    try:
        with urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as response:
            return response.status == 200, "running"
    except (OSError, URLError, ValueError):
        return False, "not running"


def collect() -> dict:
    """Return safe, machine-readable diagnostics without secrets or mutation."""
    python_ok = sys.version_info >= (3, 10)
    git = _command("git")
    brew = _command("brew")
    ollama = _command("ollama")
    ffmpeg = _command("ffmpeg")
    ollama_running, ollama_state = _ollama_service() if ollama else (False, "not installed")
    configured_required, configured_optional = _configured_models()
    configured = configured_required + configured_optional
    installed = _installed_models(ollama) if ollama_running else []
    model_state = {name: (name in installed) for name in configured}

    try:
        import faster_whisper  # noqa: F401
        stt_installed = True
    except Exception:
        stt_installed = False

    try:
        from app.config import settings
        memory_enabled = settings.enable_memory_core
        local_read = settings.enable_local_read_tools
        execute = settings.execute_enabled
        telegram_enabled = settings.enable_telegram
        telegram_configured = bool(settings.telegram_bot_token and settings.allowed_user_ids)
        identity = settings.principal_user_name or "not configured"
        telegram_settings = settings
    except Exception:
        memory_enabled = local_read = execute = telegram_enabled = False
        telegram_configured = False
        identity = "not configured"
        telegram_settings = None

    keychain_ok = False
    keychain_observation = "missing"
    security = _command("security")
    if security:
        keychain_ok, keychain_output = _run([security, "find-generic-password", "-a", "iclirius",
                               "-s", "iclirius_memory_key", "-w"])
        if not keychain_ok:
            detail = keychain_output.lower()
            if "not valid" in detail or "not permitted" in detail or "permission" in detail:
                keychain_observation = "unknown"

    venv = Path(sys.prefix) != Path(sys.base_prefix)
    package_ok = (PROJECT_ROOT / "app" / "cli.py").exists()
    git_repo = (PROJECT_ROOT / ".git").exists()
    try:
        from app.setup import status as setup_status
        setup = setup_status()
    except Exception:
        setup = {
            "setup_complete": False,
            "identity": {"configured": False},
            "memory_home": {"configured": False, "status": "unavailable"},
            "keychain": {"configured": False},
            "node": {"configured": False},
        }
    try:
        from app.local_auth import status as auth_status
        authentication = auth_status()
    except Exception:
        authentication = {"enrolled": False, "touch_id": "unavailable",
                          "recovery_credential": False, "user_id": "",
                          "primary_identity": ""}
    required_models_ok = bool(configured_required) and bool(model_state.get(configured_required[0], False))
    blockers = {
        "platform": platform.system() == "Darwin",
        "python": python_ok,
        "venv": venv,
        # A packaged installation is valid without a .git directory. Git is
        # reported separately for project tooling.
        "package": package_ok,
        "git": bool(git),
        "ollama": bool(ollama and ollama_running),
        "models": required_models_ok,
        "setup": bool(setup.get("setup_complete")),
    }
    overall = "ready" if all(blockers.values()) else "blocked"
    from app.capability_audit import collect as collect_capabilities
    try:
        from app.config import settings
        capability_setup = dict(setup)
        capability_setup["keychain"] = dict(setup.get("keychain", {}))
        capability_setup["keychain"]["observation"] = keychain_observation if security else "unknown"
        capability = collect_capabilities(
            ollama={"installed": bool(ollama), "running": ollama_running,
                    "state": ollama_state,
                    "models": {"default": settings.default_model,
                                "fast": settings.fast_model,
                                "heavy": settings.heavy_model,
                                "embed": settings.embed_model,
                                "installed": installed}},
            setup=capability_setup, authentication=authentication)
    except Exception:
        capability = {"schema_version": 2, "capabilities": [],
                      "network": {}, "tailscale": {}, "remote_access": {}, "voice": {}}
    try:
        from app.node_identity import node_role
        effective_role = node_role()
    except Exception:
        effective_role = "INTERFACE"
    if str(effective_role).upper() in {"INTERFACE", "CODE_WORKER", "REMOTE_WORKER"}:
        for item in capability.get("capabilities", []):
            if item.get("id") in {"ai.ollama", "ai.default_model"}:
                item["required"] = False
    required_capabilities = [item for item in capability.get("capabilities", []) if item.get("required")]
    capability_blocked = [item["id"] for item in required_capabilities
                          if item.get("status") in {"BLOCKED", "MISSING", "UNAVAILABLE", "POLICY_BLOCKED"}]
    limitations = [item["id"] for item in capability.get("capabilities", [])
                   if item.get("status") == "DEGRADED"]
    untested = [item["id"] for item in capability.get("capabilities", [])
                if item.get("status") == "UNTESTED"]
    optional = [item["id"] for item in capability.get("capabilities", [])
                if item.get("status") == "OPTIONAL"]
    capability["blockers"] = capability_blocked
    capability["limitations"] = limitations
    capability["untested"] = untested
    capability["optional"] = optional
    from app.node_capability_profile import build_node_capability_profile
    role_profile = build_node_capability_profile({"setup": setup, "authentication": authentication,
        "capability_audit": capability, "node_role": effective_role,
        "ollama": {"running": ollama_running}, "models": {"installed": installed}})
    from app.installation_state import assess as assess_installation
    installation = assess_installation({"capability_profile": role_profile,
                                        "node_role": effective_role})
    from app.provenance import collect as collect_provenance, running_node
    provenance = collect_provenance()
    try:
        from app.node_service import status as managed_service_status
        managed_service = managed_service_status()
    except Exception:
        managed_service = {"state": "UNKNOWN"}
    try:
        from app.cluster_security import doctor_status as cluster_doctor_status
        cluster = cluster_doctor_status()
    except Exception as exc:
        cluster = {"identity": {"status": "UNAVAILABLE", "reason": type(exc).__name__},
                   "discovery": {"enabled": False, "backend": "BONJOUR", "listener_ready": False},
                   "enrollment": {"state": "UNAVAILABLE"}}
    try:
        from app.secure_channel import status as secure_channel_status
        secure_channel = secure_channel_status()
    except Exception as exc:
        secure_channel = {"identity_binding": {"status": "UNAVAILABLE", "reason": type(exc).__name__},
                          "tls": "TLS1.3", "protocol_version": 1, "port": 18890,
                          "trusted_peers": 0, "revoked_peers": 0}
    # The configured role is the authoritative readiness boundary. Raw probe
    # observations remain available in capability_audit, while the Doctor
    # summary mirrors NodeCapabilityProfile exactly.
    capability["overall"] = role_profile.get("overall_readiness", "BLOCKED")
    try:
        from app.tool_adapter import INTEGRATION_MODE, default_registry
        tool_adapter = {
            "status": "AVAILABLE",
            "integration_mode": INTEGRATION_MODE,
            "native_openclaw_detected": any((Path.home() / ".openclaw" / "tools").glob("node-*/lib/node_modules/openclaw")) or any(
                path.is_dir() for path in (Path("/opt/homebrew/lib/node_modules/openclaw"),
                                           Path("/usr/local/lib/node_modules/openclaw"))),
            "registered_read_tools": [item.tool_id for item in default_registry.descriptors() if item.mode == "READ"],
            "protected_write_tools": [item.tool_id for item in default_registry.descriptors() if item.mode == "WRITE"],
        }
    except Exception:
        tool_adapter = {"status": "UNAVAILABLE", "integration_mode": "CONTRACT_ONLY_FOR_NOW",
                        "native_openclaw_detected": False, "registered_read_tools": [],
                        "protected_write_tools": []}
    try:
        from app.telegram_lease import diagnostics as telegram_lease_diagnostics
        telegram_lease_path = (getattr(telegram_settings, "telegram_lease_path", "") or
                               str(Path.home() / ".iclirius" / "telegram-lease.json"))
        telegram_state = telegram_lease_diagnostics(
            mode=getattr(telegram_settings, "telegram_mode", "SINGLE"),
            backend=getattr(telegram_settings, "telegram_lease_backend", "FILE"),
            token=getattr(telegram_settings, "telegram_bot_token", ""),
            node_id=getattr(telegram_settings, "node_id", ""),
            user_id=getattr(telegram_settings, "user_id", ""), path=telegram_lease_path)
    except Exception:
        telegram_state = {"mode": "UNKNOWN", "state": "UNKNOWN", "failover_ready": False}
    return {
        "overall": capability["overall"].lower(),
        "platform": {"system": platform.system(), "release": platform.mac_ver()[0] or platform.release(),
                      "architecture": platform.machine(), "supported": blockers["platform"]},
        "python": {"version": platform.python_version(), "supported": python_ok, "venv": venv},
        "package": {"runtime": "OpenClaw embedded", "present": package_ok, "repository": git_repo},
        "git": {"installed": bool(git), "branch": _git_branch(git), "dirty": _git_dirty(git)},
        "homebrew": {"installed": bool(brew), "path": brew or ""},
        "ollama": {"installed": bool(ollama), "running": ollama_running, "state": ollama_state},
        "models": {"configured": configured, "required": configured_required,
                    "optional": configured_optional, "installed": installed,
                    "available": model_state},
        "memory": {"enabled": memory_enabled,
                    "status": "ready" if memory_enabled and keychain_ok else ("not configured" if memory_enabled else "disabled")},
        "identity": {"display_name": identity, "configured": identity != "not configured"},
        "setup": setup,
        "authentication": authentication,
        "tools": {"filesystem": local_read, "shell": execute, "git": bool(git), "python": python_ok,
                   "tool_adapter": tool_adapter,
                   "filesystem_metadata": _filesystem_diagnostics(),
                   "attachments": _attachment_diagnostics()},
        "voice": {"tts": bool(shutil.which("say")), "stt": stt_installed, "ffmpeg": bool(ffmpeg)},
        "interfaces": {"cli": package_ok, "telegram": telegram_enabled and telegram_configured},
        "providers": {"local": "ollama" if ollama else "not installed", "gemini": "disabled by default"},
        "blockers": blockers,
        "capability_audit": capability,
        "capability_overall": capability["overall"],
        "node_role": effective_role,
        "current_role": role_profile.get("current_role", effective_role),
        "role_health": role_profile.get("health", {}),
        "installation": installation.to_dict(),
        "provenance": provenance,
        "node_runtime": running_node(),
        "managed_node_service": managed_service,
        "cluster": cluster,
        "secure_channel": secure_channel,
        "telegram": telegram_state,
        "eligible_roles": role_profile.get("eligible_roles", []),
        "required_capabilities": required_capabilities,
        "optional_capabilities": [item for item in capability.get("capabilities", []) if item.get("status") == "OPTIONAL"],
        "untested_capabilities": untested,
        "limitations": limitations,
        "optional": optional,
        "repair_required": bool(capability_blocked),
        "optional_enhancements_available": bool(optional),
    }


def _git_branch(git: str | None) -> str:
    if not git:
        return ""
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "branch", "--show-current"])
    return value if ok else ""


def _git_dirty(git: str | None) -> bool:
    if not git:
        return False
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "status", "--porcelain"])
    return bool(value) if ok else False


def _mark(ok: bool, text: str, optional: bool = False) -> str:
    return f"{'✓' if ok else ('○' if optional else '✗')} {text}"


def _cap_mark(item: dict, role: str = "") -> str:
    status = str(item.get("status", "UNTESTED"))
    if item.get("id") in {"ai.ollama", "ai.default_model"} and str(role).upper() not in {"LOCAL_COMPUTE", "FULL_NODE"}:
        status = "OPTIONAL"
    glyph = {"READY": "✓", "AVAILABLE": "✓", "DEGRADED": "!",
             "OPTIONAL": "○", "MISSING": "✗", "UNAVAILABLE": "✗", "BLOCKED": "⛔",
             "POLICY_BLOCKED": "⛔", "UNTESTED": "?"}.get(status, "?")
    return f"{glyph} {item.get('summary', item.get('id', 'unknown'))} [{status}]"


def render(report: dict) -> str:
    lines = ["Iclirius Doctor", ""]
    installation = report.get("installation")
    if installation:
        lines += ["INSTALLATION", f"Profile: {installation['profile']}",
                  f"Status: {installation['state']}", ""]
    lines += ["CORE"]
    lines += [_mark(report["platform"]["supported"], "macOS"),
              _mark(report["python"]["supported"], f"Python {report['python']['version']}"),
              _mark(report["python"]["venv"], "virtualenv", optional=True),
              _mark(report["package"]["present"], "Iclirius runtime"),
              _mark(report["git"]["installed"], "Git")]
    lines.append(_mark(report["memory"]["status"] == "ready", "Memory Core", optional=True))
    setup = report.get("setup", {})
    identity = setup.get("identity", {})
    home = setup.get("memory_home", {})
    lines += ["", "SETUP",
              _mark(bool(setup.get("setup_complete")), "Setup complete"),
              _mark(bool(identity.get("configured")), "Identity", optional=True),
              _mark(home.get("status") == "ready", "Memory Home", optional=True),
              _mark(bool(setup.get("keychain", {}).get("configured")), "Keychain", optional=True),
              _mark(bool(setup.get("node", {}).get("configured")), "Node", optional=True)]
    enrollment = setup.get("enrollment", {})
    lines.append(_mark(enrollment.get("state") in {"prepared", "not_prepared"},
                       f"Cross-device enrollment ({enrollment.get('state', 'unknown')})", optional=True))
    auth = report.get("authentication", {})
    lines += ["", "LOCAL AUTHENTICATION",
              _mark(bool(auth.get("enrolled")), "Recovery credential", optional=True),
              _mark(auth.get("touch_id") == "available", f"Touch ID ({auth.get('touch_id', 'unavailable')})", optional=True)]
    cluster = report.get("cluster", {})
    cluster_identity = cluster.get("identity", {})
    cluster_discovery = cluster.get("discovery", {})
    cluster_enrollment = cluster.get("enrollment", {})
    lines += ["", "CLUSTER IDENTITY",
              _mark(cluster_identity.get("status") == "READY", "Node key", optional=True),
              f"  Fingerprint  {cluster_identity.get('fingerprint') or 'unavailable'}",
              _mark(bool(cluster.get("trust_registry")), "Trust registry", optional=True),
              "", "DISCOVERY",
              _mark(bool(cluster_discovery.get("enabled")), "Discovery enabled", optional=True),
              f"  Backend      {cluster_discovery.get('backend', 'unknown')}",
              _mark(bool(cluster_discovery.get("listener_ready")), "Listener readiness", optional=True),
              "", "ENROLLMENT",
              f"  Availability {cluster_enrollment.get('state', 'UNKNOWN')}",
              f"  Pending      {cluster_enrollment.get('remaining_seconds', 0)} seconds"]
    secure = report.get("secure_channel", {})
    secure_identity = secure.get("identity_binding", {})
    lines += ["", "SECURE CHANNEL",
              _mark(secure_identity.get("status") == "READY", "Identity binding", optional=True),
              f"  TLS          {secure.get('tls', 'unknown')}",
              f"  Protocol     v{secure.get('protocol_version', 'unknown')}",
              f"  Port         {secure.get('port', 'unknown')}",
              _mark(bool(secure.get("trusted_peers", 0) >= 0), "Trust registry", optional=True),
              "  Arbitrary execution disabled"]
    lines += ["", "ROLE",
              f"  {report.get('current_role', report.get('node_role', 'INTERFACE'))} [{report.get('role_health', {}).get('health', 'UNKNOWN')}]",
              "", "REQUIRED CAPABILITIES"]
    lines.extend(_cap_mark(item, report.get("current_role", "")) for item in report.get("required_capabilities", []))
    lines += ["", "OPTIONAL CAPABILITIES"]
    lines.extend(_cap_mark(item, report.get("current_role", "")) for item in report.get("optional_capabilities", []))
    lines += ["", "TOOLS",
              _mark(report["tools"]["filesystem"], "Filesystem", optional=True),
              _mark(report["tools"]["shell"], "Shell", optional=True),
              _mark(report["tools"]["git"], "Git"),
              _mark(report["tools"]["python"], "Python"),
              _mark(report["tools"].get("tool_adapter", {}).get("status") == "AVAILABLE", "Iclirius Tool Adapter"),
              _mark(report["tools"].get("attachments", {}).get("status") == "AVAILABLE", "Attachment Gateway"),
              "", "VOICE",
              _mark(report["voice"]["tts"], "TTS", optional=True),
              _mark(report["voice"]["stt"], "STT", optional=True),
              _mark(report["voice"]["ffmpeg"], "ffmpeg", optional=True),
              "", "INTERFACES",
              _mark(report["interfaces"]["cli"], "CLI"),
              _mark(report["interfaces"]["telegram"], "Telegram", optional=True),
              ""]
    audited = report.get("capability_audit", {}).get("capabilities", [])
    for category, title in (("system", "SYSTEM"), ("core", "ICLIRIUS CORE"),
                            ("authentication", "AUTHENTICATION"),
                            ("local_ai", "LOCAL AI"), ("tools", "TOOLS"),
                            ("memory", "MEMORY"), ("network", "NETWORK"),
                            ("voice", "VOICE")):
        items = [item for item in audited if item.get("category") == category]
        if items:
            lines.append(title)
            lines.extend(_cap_mark(item, report.get("current_role", report.get("node_role", ""))) for item in items)
    lines.append(f"Overall: {report.get('capability_overall', report['overall']).upper()}")
    blockers = report.get("capability_audit", {}).get("blockers", [])
    limitations = report.get("limitations", [])
    optional_items = report.get("optional", [])
    if blockers:
        lines.extend(["", "BLOCKERS", *[f"- {value}" for value in blockers]])
    if limitations:
        lines.extend(["", "LIMITATIONS", *[f"- {value}" for value in limitations]])
    if report.get("untested_capabilities"):
        lines.extend(["", "UNTESTED", *[f"- {value}" for value in report["untested_capabilities"]]])
    if optional_items:
        lines.extend(["", "OPTIONAL", *[f"- {value}" for value in optional_items]])
    deep = report.get("deep_diagnostics")
    if deep:
        lines.extend(["", "DEEP DIAGNOSTICS"])
        for probe in deep.get("probes", []):
            status = probe.get("status", "UNTESTED")
            duration = f" {probe['duration_ms']} ms" if probe.get("duration_ms") else ""
            glyph = {"READY": "✓", "AVAILABLE": "✓", "DEGRADED": "!",
                     "OPTIONAL": "○", "MISSING": "✗", "UNAVAILABLE": "✗", "BLOCKED": "⛔",
                     "POLICY_BLOCKED": "⛔", "UNTESTED": "?"}.get(status, "?")
            lines.append(f"{glyph} {probe.get('summary', probe.get('id', 'probe'))} [{status}]{duration}")
    if report["git"]["dirty"]:
        lines.append("Note: repository has uncommitted changes.")
    try:
        from app.repair import RepairPlanner
        plan = RepairPlanner().build(report, report.get("node_role"))
        if plan.actions:
            lines.extend(["", "REPAIR AVAILABLE", "Run: iclirius repair --plan",
                          "Apply interactively: iclirius repair"])
    except Exception:
        pass
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = list(argv or [])
    report = collect()
    if "--deep" in args:
        from app.deep_diagnostics import run as run_deep
        deep = run_deep(report)
        report["deep_diagnostics"] = {key: value for key, value in deep.items()
                                      if key != "capability_audit"}
        report["capability_audit"] = deep["capability_audit"]
        report["capability_overall"] = deep["capability_audit"]["overall"]
        report["limitations"] = deep["capability_audit"]["limitations"]
        report["optional"] = deep["capability_audit"]["optional"]
        report["untested_capabilities"] = deep["capability_audit"].get("untested", [])
        report["optional_capabilities"] = [item for item in deep["capability_audit"].get("capabilities", [])
                                            if item.get("status") == "OPTIONAL"]
    if "--repair" in args or "--fix" in args:
        # Planning is read-only; execution is a separate, explicit confirmation
        # gate. JSON mode never enters this branch.
        from app.repair import RepairPlanner, RepairExecutor, RepairProgressReporter, render as render_plan
        role = report.get("node_role") or report.get("role") or "interface"
        optional_mode = "--optional" in args
        plan = RepairPlanner().build(report, role, include_optional=optional_mode)
        print(render(report))
        print("\nREPAIR AVAILABLE\n" + render_plan(plan))
        if optional_mode:
            print("\nOptional enhancements are plan-only; no actions were executed.")
            return 0
        if not plan.actions:
            return 0 if report.get("capability_overall", "BLOCKED").upper() != "BLOCKED" else 1
        if not sys.stdin.isatty():
            print("Confirmation required; no actions executed in non-interactive mode.")
            return 2
        answer = input("\nApply recommended repairs? [y/N] ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Repair declined; no changes made.")
            return 0
        before_installation = report.get("installation", {})
        result = RepairExecutor(progress=RepairProgressReporter()).execute(plan, approved=True)
        # Re-assess once after a repair batch.  A bounded single re-check
        # prevents a broken prerequisite from producing an infinite loop.
        refreshed = collect()
        before_key = (before_installation.get("state"), tuple(before_installation.get("missing_required", [])))
        after_installation = refreshed.get("installation", {})
        after_key = (after_installation.get("state"), tuple(after_installation.get("missing_required", [])))
        if result.get("status") == "COMPLETE" and before_key == after_key and plan.actions:
            result["status"] = "NO_PROGRESS"
        print(json.dumps({"repair": result, "installation": after_installation,
                          "overall": refreshed.get("overall")},
                         ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if (result.get("status") not in {"FAILED", "NO_PROGRESS"}
                     and all(item.get("result") not in {"FAILED"} for item in result.get("actions", []))
                     and refreshed.get("installation", {}).get("state") != "BLOCKED") else 1
    if "--json" in args:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(render(report))
    overall = report.get("capability_overall") or report.get("overall", "blocked")
    return 0 if overall.upper() != "BLOCKED" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
