"""Explicit offline migration. Never invoked at import or normal startup.

Call migrate_legacy with explicit paths, after stopping legacy writers. Backups
are encrypted, sources are retained, conflicts abort before the atomic commit.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path

from app.memory_core import MemoryCore, _write_lock, SCHEMA_VERSION


class MigrationError(RuntimeError):
    pass


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _json(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False).encode()


def _merge(target, incoming):
    for key, value in incoming.items():
        if key not in target:
            target[key] = value
        elif isinstance(target[key], dict) and isinstance(value, dict):
            _merge(target[key], value)
        elif target[key] != value:
            raise MigrationError("Conflicting legacy and canonical values; no commit")


def migrate_legacy(core: MemoryCore, *, identity_path: Path, memory_path: Path,
                   backup_root: Path, task_path: Path | None = None,
                   project_status_path: Path | None = None, checkpoint=None):
    """Merge a verified source snapshot in one commit, retaining all legacy data.

    checkpoint is a fault-injection hook for isolated tests. Unknown identity is
    preserved as unknown, never assigned to the current principal. Existing IDs
    and timestamps remain untouched. Changed source prefixes are conflicts.
    """
    sources = []
    for root, name, namespace, kind in [
        (identity_path, "profile.json", "profile", "json"),
        (memory_path, "projects.json", "projects", "json"),
        (memory_path, "preferences.json", "preferences", "json"),
        (memory_path, "conversations.jsonl", "conversations", "rows"),
        (memory_path, "notes.jsonl", "notes", "rows"),
        (memory_path, "learned.jsonl", "learnings", "rows"),
        (memory_path, "summary.md", "summary", "text"),
        (memory_path, "digest_log.jsonl", "digest_log", "text"),
        (identity_path, "personality.md", "personality", "text"),
    ]:
        for suffix in ("", ".enc"):
            path = Path(root) / (name + suffix)
            if path.exists():
                sources.append((path, namespace, kind))
    if task_path is not None and Path(task_path).exists():
        sources.append((Path(task_path), "queue_tasks", "rows"))
    if project_status_path is not None and Path(project_status_path).exists():
        sources.append((Path(project_status_path), "project_status", "text"))
    backup_root = Path(backup_root)
    backup_root.mkdir(parents=True, exist_ok=True, mode=0o700)
    backup = Path(tempfile.mkdtemp(prefix="canonical-v2-", dir=backup_root))
    try:
        with _write_lock(core.lock_file, 10):
            before = core.state_file.read_bytes() if core.state_file.exists() else None
            if before is not None:
                (backup / "canonical-before.enc").write_bytes(before)
                os.chmod(backup / "canonical-before.enc", 0o600)
            state = core._read_state()
            ledger = state.setdefault("migrations", {})
            fingerprints = {}
            source_manifest = []
            for index, (path, namespace, kind) in enumerate(sources):
                if path.is_symlink() or not path.is_file():
                    raise MigrationError("Unsafe legacy source")
                raw = path.read_bytes()
                fingerprints[path] = _hash(raw)
                text = core.secure.read_text(path) if path.suffix == ".enc" else raw.decode("utf-8")
                # Even plaintext legacy gets an encrypted backup, never a new
                # plaintext copy. Backup is complete before any state commit.
                core.secure.write_text(backup / f"source-{index}.enc", text)
                os.chmod(backup / f"source-{index}.enc", 0o600)
                source_manifest.append({"original": str(path.resolve()), "backup": f"source-{index}.enc",
                                        "ciphertext_hash": _hash(raw), "namespace": namespace})
                source_id = _hash(str(path.resolve()).encode())
                previous = ledger.get(source_id, {})
                if kind == "rows":
                    rows = [json.loads(line) for line in text.splitlines() if line.strip()]
                    if not all(isinstance(row, dict) for row in rows):
                        raise MigrationError("Invalid legacy row")
                    hashes = [_hash(_json(row)) for row in rows]
                    old_hashes = previous.get("rows", [])
                    if hashes[:len(old_hashes)] != old_hashes:
                        raise MigrationError("Legacy source changed; no commit")
                    for offset, row in enumerate(rows[len(old_hashes):], len(old_hashes)):
                        if namespace == "queue_tasks":
                            if not row.get("id"):
                                raise MigrationError("Legacy task has no ID")
                            _merge(state.setdefault(namespace, {}), {row["id"]: row})
                        else:
                            record = dict(row)
                            # Occurrence position preserves identical but distinct
                            # historic turns. Content IDs dedupe plaintext/enc twins.
                            if namespace == "conversations":
                                record.setdefault("event_id", "legacy_" + _hash(_json([namespace, offset, row])))
                            marker = _hash(_json([namespace, offset, row]))
                            imported = state.setdefault("migration_events", {})
                            if marker not in imported:
                                existing = next((item for item in state[namespace]
                                                 if record.get("event_id") and item.get("event_id") == record["event_id"]), None)
                                if existing is not None and existing != record:
                                    raise MigrationError("Legacy event ID conflict")
                                if existing is None:
                                    state[namespace].append(record)
                                if namespace == "conversations" and record.get("session_id"):
                                    session = state["sessions"].setdefault(record["session_id"], {})
                                    for key in ("principal_id", "user_id", "interface", "project_id"):
                                        if key in record:
                                            _merge(session, {key: record[key]})
                                    if record.get("timestamp"):
                                        session.setdefault("created_at", record["timestamp"])
                                        session.setdefault("updated_at", record["timestamp"])
                                imported[marker] = True
                    ledger[source_id] = {"schema_version": SCHEMA_VERSION, "rows": hashes}
                elif kind == "json":
                    value = json.loads(text)
                    if not isinstance(value, dict):
                        raise MigrationError("Invalid legacy object")
                    digest = _hash(_json(value))
                    if previous.get("digest") == digest:
                        continue
                    if namespace == "preferences":
                        target = state["profile"].setdefault("preferences", {})
                        _merge(target, value.get("preferences", value))
                    elif namespace == "projects":
                        _merge(state["projects"], value.get("projects", value))
                    else:
                        _merge(state[namespace], value)
                    ledger[source_id] = {"schema_version": SCHEMA_VERSION, "digest": _hash(_json(value))}
                else:
                    if previous.get("digest") == _hash(raw):
                        continue
                    _merge(state["legacy_documents"], {namespace: text})
                    ledger[source_id] = {"schema_version": SCHEMA_VERSION, "digest": _hash(raw)}
            manifest = {"schema_version": SCHEMA_VERSION, "before_exists": before is not None,
                        "before_hash": _hash(before) if before is not None else "",
                        "source_count": len(sources), "sources": source_manifest, "state": "prepared"}
            core.secure.write_json(backup / "manifest.enc", manifest)
            if checkpoint:
                checkpoint("backed_up")
            for path, digest in fingerprints.items():
                if _hash(path.read_bytes()) != digest:
                    raise MigrationError("Legacy source changed during migration")
            if state == core._read_state():
                return {"state": "unchanged", "backup": str(backup), "sources": len(sources)}
            # Prepare separately so failures before replace leave the original
            # untouched. Store the expected commit hash for conditional rollback.
            candidate = backup / "canonical-after.enc"
            staging = MemoryCore(candidate)
            staging._secure = core.secure
            staging._write_state(state)
            committed = candidate.read_bytes()
            manifest.update(state="prepared", after_hash=_hash(committed))
            core.secure.write_json(backup / "manifest.enc", manifest)
            if checkpoint:
                checkpoint("before_commit")
            fd, name = tempfile.mkstemp(dir=core.state_file.parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(committed)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(name, core.state_file)
            finally:
                Path(name).unlink(missing_ok=True)
            if checkpoint:
                checkpoint("after_commit")
            if core._read_state() != staging._read_state():
                raise MigrationError("Canonical verification failed")
            manifest["state"] = "verified"
            core.secure.write_json(backup / "manifest.enc", manifest)
            return {"state": "verified", "backup": str(backup), "sources": len(sources)}
    except Exception as exc:
        reason = str(exc) if isinstance(exc, MigrationError) else "Migration incomplete"
        raise MigrationError(reason + "; encrypted backup retained at " + str(backup)) from None


def rollback(core: MemoryCore, backup: Path):
    """Restore only the exact migrated revision; never overwrite newer writes."""
    backup = Path(backup)
    with _write_lock(core.lock_file, 10):
        manifest = core.secure.read_json(backup / "manifest.enc", {})
        current = core.state_file.read_bytes() if core.state_file.exists() else b""
        if _hash(current) != manifest.get("after_hash"):
            raise MigrationError("Rollback refused: canonical state has changed")
        if manifest.get("before_exists"):
            before = (backup / "canonical-before.enc").read_bytes()
            if _hash(before) != manifest.get("before_hash"):
                raise MigrationError("Backup verification failed")
            fd, name = tempfile.mkstemp(dir=core.state_file.parent)
            try:
                with os.fdopen(fd, "wb") as stream:
                    stream.write(before)
                os.replace(name, core.state_file)
            finally:
                Path(name).unlink(missing_ok=True)
        else:
            core.state_file.unlink()
    return True
