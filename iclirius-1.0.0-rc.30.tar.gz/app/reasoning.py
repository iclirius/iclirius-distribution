"""
The contract between Iclirius and whatever does the reasoning.

Iclirius owns identity, memory, tasks, context, permissions, execution and
continuity. A provider owns none of that. It receives an already-reduced
ContextPackage and returns text, and everything that happens to that text
afterwards — parsing, grounding, validating, asking permission, executing — is
decided here, not there.

    Iclirius
        ↓  ReasoningRequest (ContextPackage, purpose, limits)
    Gateway → Router → Provider adapter → engine
        ↓  ReasoningResponse (text, usage, latency, status)
    Iclirius decides what it means

Three things a provider deliberately cannot do:

  - Reach state. It gets a ContextPackage, never the Memory Core, the Task
    Engine or the filesystem. What it cannot see, it cannot leak.
  - Run tools. There is no shell, no read, no write, no fetch. A provider
    proposes; the agent disposes.
  - Own a task. Provider ids, account references and model names are
    auxiliary metadata. A task belongs to Iclirius, and swapping engines
    changes nothing about it.

Nothing in this module talks to a network, and no provider-specific object is
allowed to escape past ReasoningResponse.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum


class ProviderError(RuntimeError):
    """A provider could not answer."""


class ProviderUnavailable(ProviderError):
    """The engine itself is unreachable. Another model will not help."""


class Purpose(str, Enum):
    """
    Why reasoning is being asked for.

    A closed set rather than a free string, because routing will later depend
    on it: a summary can go to a cheap engine, a patch cannot.
    """

    GENERAL_REASONING = "GENERAL_REASONING"
    ANALYZE_EVIDENCE = "ANALYZE_EVIDENCE"
    PATCH_GENERATION = "PATCH_GENERATION"
    SUMMARIZATION = "SUMMARIZATION"
    PLANNING = "PLANNING"
    NARRATION = "NARRATION"


class ProviderType(str, Enum):
    """
    Kinds of provider the architecture allows for.

    Only OLLAMA has an adapter. The others exist so the contract does not need
    redesigning later; declaring a type is not implementing one, and nothing
    in this codebase can route to them.
    """

    OLLAMA = "OLLAMA"
    GEMINI = "GEMINI"
    OPENAI = "OPENAI"
    ANTHROPIC = "ANTHROPIC"
    KIMI = "KIMI"


class ResponseMode(str, Enum):
    TEXT = "TEXT"
    STRUCTURED_JSON = "STRUCTURED_JSON"


class ResponseStatus(str, Enum):
    OK = "OK"
    FAILED = "FAILED"
    UNAVAILABLE = "UNAVAILABLE"
    RATE_LIMITED = "RATE_LIMITED"
    EXHAUSTED = "EXHAUSTED"


class ProviderStatus(str, Enum):
    """Aligned with the RuntimeStatus vocabulary the UI already draws."""

    AVAILABLE = "AVAILABLE"
    ACTIVE = "ACTIVE"
    IDLE = "IDLE"
    UNAVAILABLE = "UNAVAILABLE"
    RATE_LIMITED = "RATE_LIMITED"
    EXHAUSTED = "EXHAUSTED"
    DISABLED = "DISABLED"


# Same documented approximation the Context Engine uses. Reported, never used
# to decide truncation.
CHARS_PER_TOKEN = 4


def estimate_tokens(text: str) -> int:
    return max(0, round(len(text or "") / CHARS_PER_TOKEN))


@dataclass(frozen=True)
class ProviderCapabilities:
    """
    What a provider can actually do.

    Only things that can be determined. There is no "quality" field, because
    nothing here could fill it honestly.
    """

    max_context_chars: int
    structured_output: bool = False
    supports_system_prompt: bool = True
    supports_streaming: bool = False
    local: bool = True
    network_required: bool = False
    cost_class: str = "free"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ReasoningRequest:
    """
    One ask. Carries context that has already been reduced.

    The prompt comes from a ContextPackage the Context Engine assembled and
    budgeted. A provider never assembles its own context, so it can never
    widen what it sees.
    """

    purpose: str = Purpose.GENERAL_REASONING.value
    prompt: str = ""
    request_id: str = field(default_factory=lambda: f"req_{uuid.uuid4().hex[:12]}")
    task_id: str | None = None
    project_id: str | None = None
    model_preference: str | None = None
    # An explicit ask for one provider. Absent by default, which is what keeps
    # LOCAL the normal path; present only when someone deliberately chose.
    provider_preference: str | None = None
    tier: str = "default"
    response_mode: str = ResponseMode.TEXT.value
    max_output_chars: int = 0
    created_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    metadata: dict = field(default_factory=dict)

    @classmethod
    def from_package(cls, package, **kwargs) -> "ReasoningRequest":
        """Build from an assembled ContextPackage rather than a raw string."""
        return cls(prompt=package.prompt, **kwargs)

    @property
    def input_chars(self) -> int:
        return len(self.prompt or "")

    def estimated_input_tokens(self) -> int:
        return estimate_tokens(self.prompt)

    def safe_metadata(self) -> dict:
        """
        For events: identifiers and sizes, never the prompt.

        A request carries the whole assembled context, so this is the only
        thing about it that may be logged.
        """
        return {
            "request_id": self.request_id,
            "purpose": self.purpose,
            "tier": self.tier,
            "provider_preference": self.provider_preference,
            "input_chars": self.input_chars,
            "estimated_input_tokens": self.estimated_input_tokens(),
        }


@dataclass
class ReasoningResponse:
    """
    One answer, in terms the agent understands.

    Provider-specific objects stop here. Whatever an engine's client library
    returns is translated into this and discarded, so the agent never grows a
    dependency on one engine's response shape.
    """

    request_id: str
    provider_id: str = ""
    account_ref: str = ""
    model_id: str = ""
    status: str = ResponseStatus.OK.value
    content: str = ""
    structured_result: dict | None = None
    latency_ms: int = 0
    finish_reason: str = "stop"
    status_code: int | None = None
    error: str = ""
    input_tokens_estimated: int = 0
    output_tokens_estimated: int = 0
    input_tokens_actual: int | None = None
    output_tokens_actual: int | None = None
    # Typed failure, so a router can tell "this key is wrong" from "this
    # prompt was wrong" instead of treating every failure alike.
    error_kind: str = ""
    cost_estimated: float = 0.0
    # Whether that number means anything. Local reasoning genuinely costs
    # nothing; a metered provider without configured pricing costs an amount
    # we do not know, and reporting that as 0.0 would be a false claim.
    cost_known: bool = True

    @property
    def ok(self) -> bool:
        return self.status == ResponseStatus.OK.value

    def safe_metadata(self) -> dict:
        """Sizes, ids and timings. Never the content."""
        return {
            "request_id": self.request_id,
            "provider_id": self.provider_id,
            "account_ref": self.account_ref,
            "model_id": self.model_id,
            "status": self.status,
            "finish_reason": self.finish_reason,
            "status_code": self.status_code,
            "latency_ms": self.latency_ms,
            "output_chars": len(self.content or ""),
            "input_tokens": self.input_tokens_actual or self.input_tokens_estimated,
            "output_tokens": self.output_tokens_actual or self.output_tokens_estimated,
            "cost": self.cost_estimated if self.cost_known else "unknown",
            "error_kind": self.error_kind or None,
        }


class ReasoningProvider:
    """
    What every adapter implements.

    A plain base class rather than a Protocol so a half-finished adapter fails
    loudly at registration instead of at the first request.
    """

    provider_id: str = ""
    provider_type: str = ProviderType.OLLAMA.value
    account_ref: str = "local"

    def models(self) -> list[str]:
        raise NotImplementedError

    def health(self) -> str:
        """One of ProviderStatus."""
        raise NotImplementedError

    def capabilities(self) -> ProviderCapabilities:
        raise NotImplementedError

    def generate(self, request: ReasoningRequest, model: str) -> ReasoningResponse:
        raise NotImplementedError

    def describe(self) -> dict:
        """Safe metadata for a registry listing or a UI."""
        return {
            "provider_id": self.provider_id,
            "provider_type": self.provider_type,
            "account_ref": self.account_ref,
            "capabilities": self.capabilities().to_dict(),
        }
