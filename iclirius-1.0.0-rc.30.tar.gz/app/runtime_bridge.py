"""
A local, read-only window into the running agent.

A future TUI runs as a separate process and needs to know what Iclirius is
doing. It should not scrape logs, and it must not reach into the Memory Core.
This bridge is the seam between the two.

Deliberate constraints:

  - Unix domain socket, never TCP. There is no port, so there is nothing to
    expose to the network by accident, and filesystem permissions do the
    access control: the socket is created 0600, owner only.

  - Read only. Four commands, a closed set: status, events, nodes, models.
    No command executes a tool, changes a model, mutates a task, reads a file
    or dumps memory. Control surfaces belong to authorised interfaces, not to
    an observability channel.

  - Bounded everywhere. Request size, response size, connection timeout and
    backlog are all capped, and the server runs on a daemon thread so it can
    never keep the process alive or block a reply to the user.

If the bridge fails to start or dies, the agent does not care. Observability
is never allowed to take down the thing being observed.
"""

from __future__ import annotations

import json
import os
import socket
import threading
from pathlib import Path

from app.config import settings
from app.logger import logger

MAX_REQUEST_BYTES = 4096
MAX_RESPONSE_BYTES = 256 * 1024
SOCKET_TIMEOUT = 5.0
BACKLOG = 4

COMMANDS = ("status", "events", "nodes", "models", "ping")

# sockaddr_un caps the path. macOS allows about 104 bytes, and bind() fails
# with a bare "invalid argument" past it, which is easy to misread as a
# permissions problem.
MAX_SOCKET_PATH = 100


def socket_path() -> Path:
    return Path(settings.runtime_socket_path).expanduser()


class RuntimeBridge:
    """Serves snapshots over a local socket. Never mutates anything."""

    def __init__(self, agent=None, path: Path | None = None):
        self.agent = agent
        self.path = Path(path) if path else socket_path()
        self._server: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    # -- lifecycle ---------------------------------------------------------

    def start(self) -> bool:
        """Begin serving. Returns False on any problem; never raises."""
        if not settings.enable_runtime_bridge:
            return False

        if len(str(self.path)) > MAX_SOCKET_PATH:
            logger.warning(
                "Runtime bridge path is too long for a unix socket chars=%s max=%s",
                len(str(self.path)), MAX_SOCKET_PATH,
            )
            return False

        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)

            # A socket left behind by a crashed process would block bind.
            if self.path.exists():
                self.path.unlink()

            server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            server.bind(str(self.path))
            os.chmod(self.path, 0o600)
            server.listen(BACKLOG)
            server.settimeout(1.0)

            self._server = server
            self._stop.clear()
            self._thread = threading.Thread(target=self._serve, daemon=True,
                                            name="runtime-bridge")
            self._thread.start()

            logger.info("Runtime bridge listening path=%s", self.path)
            return True
        except Exception:
            logger.warning("Runtime bridge could not start", exc_info=False)
            self.stop()
            return False

    def stop(self) -> None:
        self._stop.set()

        if self._server is not None:
            try:
                self._server.close()
            except OSError:
                pass
            self._server = None

        try:
            if self.path.exists():
                self.path.unlink()
        except OSError:
            pass

    # -- serving -----------------------------------------------------------

    def _serve(self) -> None:
        while not self._stop.is_set() and self._server is not None:
            try:
                connection, _ = self._server.accept()
            except socket.timeout:
                continue
            except OSError:
                break

            try:
                self._handle(connection)
            except Exception:
                logger.warning("Runtime bridge request failed", exc_info=False)
            finally:
                try:
                    connection.close()
                except OSError:
                    pass

    def _handle(self, connection: socket.socket) -> None:
        connection.settimeout(SOCKET_TIMEOUT)

        raw = connection.recv(MAX_REQUEST_BYTES)

        if len(raw) >= MAX_REQUEST_BYTES:
            self._send(connection, {"error": "request too large"})
            return

        response = self.handle_request(raw.decode("utf-8", errors="replace"))
        self._send(connection, response)

    @staticmethod
    def _send(connection: socket.socket, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False)[:MAX_RESPONSE_BYTES]
        connection.sendall(body.encode("utf-8"))

    # -- protocol ----------------------------------------------------------

    def handle_request(self, raw: str) -> dict:
        """
        Parse and dispatch. Anything unexpected is refused, not guessed.

        Separated from the socket so the protocol is testable without any I/O.
        """
        text = (raw or "").strip()

        if not text:
            return {"error": "empty request"}

        command = text
        payload: dict = {}

        if text.startswith("{"):
            try:
                parsed = json.loads(text)
            except json.JSONDecodeError:
                return {"error": "malformed request"}

            if not isinstance(parsed, dict):
                return {"error": "malformed request"}

            command = str(parsed.get("command", "")).strip()
            payload = parsed

        command = command.lower()

        if command not in COMMANDS:
            return {"error": f"unknown command: {command[:40]}"}

        try:
            return self._dispatch(command, payload)
        except Exception:
            logger.warning("Runtime bridge command failed command=%s", command, exc_info=False)
            return {"error": "internal error"}

    def _dispatch(self, command: str, payload: dict) -> dict:
        if command == "ping":
            return {"ok": True}

        snapshot = self._snapshot()

        if command == "status":
            return snapshot

        if command == "nodes":
            return {"nodes": snapshot.get("nodes", [])}

        if command == "models":
            return {"runtimes": snapshot.get("runtimes", [])}

        if command == "events":
            limit = payload.get("limit", 20)
            limit = min(int(limit) if str(limit).isdigit() else 20, 100)
            return {"events": snapshot.get("recent_activity", [])[-limit:]}

        return {"error": "unsupported"}

    def _snapshot(self) -> dict:
        from app.runtime_state import build_snapshot

        healthy = None
        models: list[str] = []

        if self.agent is not None:
            try:
                healthy = self.agent.ollama.health()
                models = self.agent.ollama.installed_models() if healthy else []
            except Exception:
                healthy = None

        return build_snapshot(self.agent, ollama_healthy=healthy,
                              installed_models=models).to_dict()


# --- client ---------------------------------------------------------------


def query(command: str = "status", path: Path | None = None,
          timeout: float = SOCKET_TIMEOUT) -> dict:
    """Ask a running Iclirius for its state. Used by tests and a future TUI."""
    target = Path(path) if path else socket_path()

    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(timeout)
            client.connect(str(target))
            client.sendall(command.encode("utf-8"))

            chunks = []
            while True:
                chunk = client.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
                if sum(len(c) for c in chunks) >= MAX_RESPONSE_BYTES:
                    break

        return json.loads(b"".join(chunks).decode("utf-8"))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        return {"error": f"{type(exc).__name__}"}
