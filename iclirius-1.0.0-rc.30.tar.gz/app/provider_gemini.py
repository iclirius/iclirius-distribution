"""
Gemini as a reasoning resource. It owns nothing.

This is the first real cloud integration, so the boundaries matter more here
than anywhere else. Gemini receives an already-reduced ContextPackage and
returns text. It has no filesystem, no shell, no permission layer, no Memory
Core, no Task Engine and no Telegram, and none of that is a matter of
discipline: this module imports none of them, and a test reads its imports to
prove it.

On the API. This talks to the official generateContent REST endpoint over
HTTPS with `requests`, which the project already depends on, rather than
adding the Google SDK. The reason is not weight but control: the endpoint is a
constant in this file, the timeout is explicit, redirects are refused, the
response body is capped, and the API key travels in a header instead of a
query string so it cannot end up in a URL echoed back inside an error. A
vendored SDK would decide all five of those for us, and they are exactly the
decisions this phase is about. The model name is configuration, never a
hardcoded contract.

The key is resolved per request and dropped. Nothing here stores it on the
instance, and every error string is scrubbed before it leaves the module,
because a cloud error that quotes the request is the realistic way an API key
reaches a log.
"""

from __future__ import annotations

import json
import time

import requests

from app.config import settings
from app.credentials import (
    CredentialError,
    CredentialRef,
    CredentialStore,
    credential_store,
    redact,
)
from app.logger import logger
from app.reasoning import (
    ProviderCapabilities,
    ProviderStatus,
    ProviderType,
    ReasoningProvider,
    ReasoningRequest,
    ReasoningResponse,
    ResponseMode,
    ResponseStatus,
    estimate_tokens,
)

# Trusted and constant. There is no user-controlled or model-controlled base
# URL: a provider that could be pointed at an arbitrary endpoint would be a
# way to exfiltrate the context package.
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# A model answering with a gigabyte would be a denial of service against the
# agent, so the body is read incrementally and abandoned past this size.
MAX_RESPONSE_BYTES = 2_000_000


# Typed failures. Phase 4.2 routes on these; here they make the difference
# between "this key is wrong" and "this prompt was wrong" explicit rather than
# leaving every failure looking alike.
AUTH_ERROR = "AUTH_ERROR"
RATE_LIMIT = "RATE_LIMIT"
QUOTA_EXHAUSTED = "QUOTA_EXHAUSTED"
TIMEOUT = "TIMEOUT"
NETWORK_ERROR = "NETWORK_ERROR"
SERVER_ERROR = "SERVER_ERROR"
BAD_REQUEST = "BAD_REQUEST"
INVALID_RESPONSE = "INVALID_RESPONSE"

_STATUS_FOR_KIND = {
    RATE_LIMIT: ResponseStatus.RATE_LIMITED.value,
    QUOTA_EXHAUSTED: ResponseStatus.EXHAUSTED.value,
    AUTH_ERROR: ResponseStatus.UNAVAILABLE.value,
    NETWORK_ERROR: ResponseStatus.UNAVAILABLE.value,
}


def classify_http(status_code: int, body: str) -> str:
    """
    Turn an HTTP status into something a failover policy can act on.

    429 is deliberately split: a rate limit recovers on its own, an exhausted
    quota does not, and treating them alike would either hammer a limit or
    give up on one.
    """
    lowered = (body or "").lower()

    if status_code in (401, 403):
        return AUTH_ERROR

    if status_code == 429:
        if "quota" in lowered and "rate" not in lowered:
            return QUOTA_EXHAUSTED

        return RATE_LIMIT

    if status_code == 400:
        # A blown context window is the request's fault, not the account's.
        return BAD_REQUEST

    if status_code >= 500:
        return SERVER_ERROR

    return BAD_REQUEST


class GeminiReasoningProvider(ReasoningProvider):
    """One Gemini account, behind the Phase 4.0 contract."""

    provider_type = ProviderType.GEMINI.value

    def __init__(self, account_ref: str = "gemini-primary",
                 credential_ref: str = "",
                 model: str = "",
                 provider_id: str = "",
                 store: CredentialStore | None = None,
                 session: object | None = None):
        self.account_ref = account_ref
        self.provider_id = provider_id or account_ref
        self.model = model or settings.gemini_model
        self.credential = CredentialRef(
            provider_id="gemini",
            account_ref=account_ref,
            credential_ref=credential_ref or settings.gemini_credential_ref,
        )
        self.store = store or credential_store
        # Injectable so tests exercise auth failures, rate limits, timeouts and
        # malformed bodies without touching the network.
        self.session = session or requests
        self._active = False
        self._last_status = ProviderStatus.AVAILABLE.value

    # -- contract ----------------------------------------------------------

    def models(self) -> list[str]:
        return [self.model] if self.model else []

    def health(self) -> str:
        """
        Configuration health, not a live probe.

        Asking Gemini whether it is up costs a request against a metered
        account, so this reports whether it *could* be called: enabled, with a
        model and a resolvable credential. What the last real request observed
        is tracked separately.
        """
        if not settings.gemini_enabled:
            return ProviderStatus.DISABLED.value

        if not self.model:
            return ProviderStatus.DISABLED.value

        if not self.store.exists(self.credential):
            return ProviderStatus.UNAVAILABLE.value

        if self._active:
            return ProviderStatus.ACTIVE.value

        return self._last_status

    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            max_context_chars=settings.gemini_max_context_chars,
            structured_output=True,
            supports_system_prompt=True,
            supports_streaming=False,
            local=False,
            network_required=True,
            # Pricing is not configured, and inventing a number that ages badly
            # inside core logic is worse than admitting it is unknown.
            cost_class="unknown",
        )

    def describe(self) -> dict:
        described = super().describe()
        described["credential"] = self.store.metadata(self.credential)
        described["model"] = self.model

        return described

    # -- the request -------------------------------------------------------

    def generate(self, request: ReasoningRequest, model: str) -> ReasoningResponse:
        response = ReasoningResponse(
            request_id=request.request_id,
            provider_id=self.provider_id,
            account_ref=self.account_ref,
            model_id=model or self.model,
            input_tokens_estimated=request.estimated_input_tokens(),
            # Unknown, not zero. Zero would be a claim about price, and no
            # pricing is configured.
            cost_estimated=0.0,
            cost_known=False,
        )

        if not settings.gemini_enabled:
            response.status = ResponseStatus.UNAVAILABLE.value
            response.error = "Gemini está desactivado (GEMINI_ENABLED=false)."
            return response

        started = time.monotonic()
        self._active = True
        api_key = ""

        try:
            # Resolved here, used once, and never stored on the instance.
            api_key = self.store.resolve(self.credential)
            payload = self._build_payload(request)
            body, status_code = self._post(payload, api_key, response.model_id)
            response.status_code = status_code

            if status_code != 200:
                kind = classify_http(status_code, body)
                self._fail(response, kind, body, api_key, status_code)
            else:
                self._parse(response, body, api_key, request)
        except CredentialError as exc:
            self._fail(response, AUTH_ERROR, str(exc), api_key)
        except requests.Timeout:
            self._fail(response, TIMEOUT, "La petición superó el tiempo límite.",
                       api_key)
        except requests.RequestException as exc:
            self._fail(response, NETWORK_ERROR, f"{type(exc).__name__}: {exc}",
                       api_key)
        except Exception as exc:
            self._fail(response, INVALID_RESPONSE, f"{type(exc).__name__}: {exc}",
                       api_key)
        finally:
            # Drop the local reference. Python cannot guarantee the value is
            # gone from memory, but nothing here keeps holding it.
            api_key = ""
            self._active = False
            response.latency_ms = int((time.monotonic() - started) * 1000)

        return response

    def _build_payload(self, request: ReasoningRequest) -> dict:
        """
        The whole request body.

        Exactly one part: the assembled ContextPackage prompt. No conversation
        history, no tool declarations, no session id — a Gemini thread is not
        a task, and continuity lives in Iclirius.
        """
        config: dict = {}

        if request.max_output_chars:
            config["maxOutputTokens"] = max(
                1, request.max_output_chars // 4)

        if request.response_mode == ResponseMode.STRUCTURED_JSON.value:
            config["responseMimeType"] = "application/json"

        payload = {
            "contents": [{"role": "user", "parts": [{"text": request.prompt}]}],
        }

        if config:
            payload["generationConfig"] = config

        return payload

    def _post(self, payload: dict, api_key: str, model: str) -> tuple[str, int]:
        """
        One HTTPS call, with every limit set explicitly.

        The key goes in a header rather than the query string precisely so it
        cannot appear in a URL that an error message quotes back.
        """
        url = f"{GEMINI_BASE_URL}/models/{model}:generateContent"

        result = self.session.post(
            url,
            headers={
                "x-goog-api-key": api_key,
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=settings.gemini_timeout_seconds,
            # A redirect from this endpoint would mean sending the key and the
            # context somewhere the code did not choose.
            allow_redirects=False,
            stream=True,
        )

        chunks: list[bytes] = []
        total = 0

        for chunk in result.iter_content(chunk_size=65536):
            if not chunk:
                continue

            total += len(chunk)

            if total > MAX_RESPONSE_BYTES:
                logger.warning("Gemini response exceeded the size cap; discarding")
                return "", 400

            chunks.append(chunk)

        return b"".join(chunks).decode("utf-8", errors="replace"), result.status_code

    def discover_models(self) -> list[dict]:
        """List models available to this credential without changing routing."""
        api_key = ""
        try:
            api_key = self.store.resolve(self.credential)
            result = self.session.get(
                f"{GEMINI_BASE_URL}/models",
                headers={"x-goog-api-key": api_key},
                timeout=settings.gemini_timeout_seconds,
                allow_redirects=False,
            )
            if result.status_code != 200:
                return []
            payload = result.json()
            models = payload.get("models") if isinstance(payload, dict) else []
            return [
                {"name": item.get("name", ""),
                 "base_model_id": item.get("baseModelId", ""),
                 "supported_generation": "generateContent" in (item.get("supportedGenerationMethods") or [])}
                for item in models if isinstance(item, dict)
            ]
        except Exception:
            return []
        finally:
            api_key = ""

    def _parse(self, response: ReasoningResponse, body: str, api_key: str,
               request: ReasoningRequest) -> None:
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self._fail(response, INVALID_RESPONSE, "La respuesta no era JSON.",
                       api_key)
            return

        candidates = payload.get("candidates") or []

        if not candidates:
            reason = ((payload.get("promptFeedback") or {}).get("blockReason")
                      or "sin candidatos")
            self._fail(response, INVALID_RESPONSE, f"Sin respuesta: {reason}",
                       api_key)
            return

        candidate = candidates[0]
        parts = ((candidate.get("content") or {}).get("parts") or [])
        text = "".join(str(part.get("text", "")) for part in parts)

        if not text.strip():
            self._fail(response, INVALID_RESPONSE, "La respuesta venía vacía.",
                       api_key)
            return

        response.content = text
        response.finish_reason = str(candidate.get("finishReason", "stop")).lower()

        if request.response_mode == ResponseMode.STRUCTURED_JSON.value:
            # Parsed for convenience only. Structured output from a provider
            # is not a trusted patch: the local validations remain the
            # authority over anything that reaches a file.
            response.structured_result = _maybe_json(text)

        # Real counts when the API reports them, estimates otherwise. The two
        # are kept apart rather than blended, so nobody mistakes one for the
        # other later.
        usage = payload.get("usageMetadata") or {}

        if "promptTokenCount" in usage:
            response.input_tokens_actual = _safe_count(usage["promptTokenCount"])

        if "candidatesTokenCount" in usage:
            response.output_tokens_actual = _safe_count(usage["candidatesTokenCount"])

        response.output_tokens_estimated = estimate_tokens(text)
        self._last_status = ProviderStatus.AVAILABLE.value

    def _fail(self, response: ReasoningResponse, kind: str, detail: str,
              api_key: str, status_code: int = 0) -> None:
        """
        Record a typed failure, scrubbed.

        The key is passed in so it can be removed by exact value: a short or
        oddly shaped one would slip past the generic patterns, and this is the
        only place that knows what it actually was.
        """
        response.status = _STATUS_FOR_KIND.get(kind, ResponseStatus.FAILED.value)
        response.error_kind = kind
        response.error = redact(f"{kind}: {detail}"[:400], api_key)

        if kind in (RATE_LIMIT, QUOTA_EXHAUSTED, AUTH_ERROR):
            self._last_status = {
                RATE_LIMIT: ProviderStatus.RATE_LIMITED.value,
                QUOTA_EXHAUSTED: ProviderStatus.EXHAUSTED.value,
                AUTH_ERROR: ProviderStatus.UNAVAILABLE.value,
            }[kind]

        logger.warning("Gemini request failed account=%s kind=%s http=%s",
                       self.account_ref, kind, status_code or "-")


def _maybe_json(text: str) -> dict | None:
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return None

    return parsed if isinstance(parsed, dict) else None


def _safe_count(value) -> int | None:
    try:
        count = int(value)
    except (TypeError, ValueError):
        return None
    return count if count >= 0 else None
