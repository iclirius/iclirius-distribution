"""Bounded, local-only attachment staging and FILE-3 handoff."""
from __future__ import annotations

import hashlib
import mimetypes
import os
import secrets
import shutil
import stat
import time
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from app.config import settings
from app.evidence import EvidenceRecord
from app.file_evidence import content_evidence, extract_file
from app.filesystem_evidence import FileRecord, FileRoot, FileScanSpec, scan


RECEIVED = "RECEIVED"
STAGED = "STAGED"
AUTHORIZED = "AUTHORIZED"
REJECTED = "REJECTED"
EXPIRED = "EXPIRED"
CONSUMED = "CONSUMED"
FAILED = "FAILED"

REASON_CODES = {
    "IDENTITY_REQUIRED", "OWNER_MISMATCH", "NODE_MISMATCH", "FILE_TOO_LARGE",
    "UNSUPPORTED_TYPE", "MIME_MISMATCH", "EMPTY_FILE", "STAGING_FAILED",
    "FILE_NOT_FOUND", "EXPIRED_ATTACHMENT", "CONTENT_EXTRACTION_FAILED",
    "AMBIGUOUS_ATTACHMENT", "ATTACHMENT_NOT_FOUND", "PATH_TRAVERSAL",
}

TEXT_EXTENSIONS = {".txt", ".md", ".rst", ".log", ".py", ".js", ".jsx", ".ts", ".tsx",
                   ".java", ".kt", ".swift", ".c", ".h", ".cpp", ".cc", ".cxx", ".hpp",
                   ".go", ".rs", ".sh", ".bash", ".zsh", ".yaml", ".yml", ".toml", ".ini",
                   ".cfg", ".conf", ".html", ".css", ".sql", ".jsonl", ".json", ".xml", ".csv"}
SUPPORTED_EXTENSIONS = TEXT_EXTENSIONS | {".pdf", ".docx"}
UNSUPPORTED_EXTENSIONS = {".zip", ".tar", ".gz", ".7z", ".rar", ".dmg", ".pkg", ".exe", ".bin", ".xlsm", ".docm"}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _stamp(value: datetime | None = None) -> str:
    return (value or _now()).isoformat(timespec="seconds")


def _safe_suffix(filename: str) -> str:
    name = Path(str(filename or "attachment")).name
    suffix = Path(name).suffix.casefold()
    return suffix if suffix and len(suffix) <= 16 and suffix.replace(".", "").isalnum() else ""


def _detected_type(path: Path, reported_mime: str | None) -> tuple[str | None, str | None]:
    suffix = path.suffix.casefold()
    mime, _ = mimetypes.guess_type(path.name)
    try:
        header = path.read_bytes()[:4096]
    except OSError:
        return None, None
    if header.startswith(b"%PDF-"):
        return "application/pdf", "pdf"
    if header.startswith(b"PK\x03\x04") and suffix == ".docx":
        return "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx"
    if suffix in TEXT_EXTENSIONS:
        try:
            header.decode("utf-8")
        except UnicodeDecodeError:
            return None, None
        return mime or "text/plain", "text"
    return mime, None


@dataclass(frozen=True)
class AttachmentRecord:
    attachment_id: str
    source: str
    source_message_id: str | None
    source_session_id: str | None
    authenticated_user_id: str | None
    node_id: str
    original_filename: str
    safe_filename: str
    reported_mime: str | None
    detected_mime: str | None
    size_bytes: int
    content_hash: str | None
    staged_path: str
    created_at: str
    expires_at: str
    status: str
    reason_code: str | None = None
    detected_type: str | None = None
    warnings: tuple[str, ...] = ()

    def to_dict(self, *, include_path: bool = False) -> dict:
        value = asdict(self)
        value["warnings"] = list(self.warnings)
        if not include_path:
            value.pop("staged_path", None)
        return value


class AttachmentGateway:
    """Owns only controlled temporary attachment files."""

    def __init__(self, *, staging_root: str | Path | None = None, node_id: str | None = None,
                 max_bytes: int | None = None, ttl_seconds: int | None = None):
        configured = staging_root or Path(getattr(settings, "state_path", "~/.iclirius/state")) / "attachments"
        self.staging_root = Path(configured).expanduser().resolve(strict=False)
        self.node_id = node_id or str(getattr(settings, "node_id", "unknown-node"))
        self.max_bytes = int(max_bytes if max_bytes is not None else getattr(settings, "attachment_max_bytes", 10 * 1024 * 1024))
        self.ttl_seconds = int(ttl_seconds if ttl_seconds is not None else getattr(settings, "attachment_ttl_seconds", 3600))
        self._records: dict[str, AttachmentRecord] = {}

    def _ensure_staging_root(self) -> None:
        self.staging_root.mkdir(parents=True, exist_ok=True)
        os.chmod(self.staging_root, stat.S_IRWXU)

    def allocate_path(self, original_filename: str) -> tuple[str, Path]:
        self._ensure_staging_root()
        attachment_id = "att_" + secrets.token_hex(12)
        safe = attachment_id + _safe_suffix(original_filename)
        return attachment_id, self.staging_root / safe

    def stage_file(self, source_path: str | Path, *, original_filename: str = "attachment",
                   reported_mime: str | None = None, authenticated_user_id: str | None = None,
                   source: str = "telegram", source_message_id: str | None = None,
                   source_session_id: str | None = None, attachment_id: str | None = None) -> AttachmentRecord:
        now = _now()
        self._ensure_staging_root()
        attachment_id = attachment_id or "att_" + secrets.token_hex(12)
        safe = attachment_id + _safe_suffix(original_filename)
        target = self.staging_root / safe
        if not authenticated_user_id:
            return self._record(attachment_id, source, source_message_id, source_session_id, None,
                                original_filename, safe, reported_mime, None, 0, None, target, now, REJECTED, "IDENTITY_REQUIRED")
        try:
            raw_source = Path(source_path).expanduser()
            if raw_source.is_symlink():
                raise PermissionError("symlink source")
            source_file = raw_source.resolve(strict=True)
            if not source_file.is_file():
                raise FileNotFoundError("source is not a regular file")
            size = source_file.stat().st_size
            if size == 0:
                return self._record(attachment_id, source="telegram", source_message_id=source_message_id,
                                    source_session_id=source_session_id, authenticated_user_id=authenticated_user_id,
                                    original_filename=original_filename, safe_filename=safe, reported_mime=reported_mime,
                                    detected_mime=None, size_bytes=0, content_hash=None, staged_path=target,
                                    created=now, status=REJECTED, reason_code="EMPTY_FILE")
            if size > self.max_bytes:
                return self._record(attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                                    original_filename, safe, reported_mime, None, size, None, target, now, REJECTED, "FILE_TOO_LARGE")
            shutil.copyfile(source_file, target)
        except (OSError, ValueError):
            return self._record(attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                                original_filename, safe, reported_mime, None, 0, None, target, now, FAILED, "STAGING_FAILED")
        return self._finalize(attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                              original_filename, safe, reported_mime, target, now)

    def finalize_staged(self, staged_path: str | Path, *, attachment_id: str, original_filename: str,
                        reported_mime: str | None, authenticated_user_id: str | None,
                        source: str = "telegram", source_message_id: str | None = None,
                        source_session_id: str | None = None) -> AttachmentRecord:
        """Finalize a file downloaded by an existing interface downloader."""
        self._ensure_staging_root()
        path = Path(staged_path).expanduser().resolve(strict=False)
        if path.parent != self.staging_root or not authenticated_user_id:
            return self._record(attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                                original_filename, path.name, reported_mime, None, 0, None, path, _now(), REJECTED,
                                "IDENTITY_REQUIRED" if not authenticated_user_id else "STAGING_FAILED")
        return self._finalize(attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                              original_filename, path.name, reported_mime, path, _now())

    def _finalize(self, attachment_id, source, source_message_id, source_session_id, user_id,
                  original_filename, safe, reported_mime, target, now):
        try:
            size = target.stat().st_size
            if size == 0:
                return self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                    original_filename, safe, reported_mime, None, 0, None, target, now, REJECTED, "EMPTY_FILE")
            if size > self.max_bytes:
                return self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                    original_filename, safe, reported_mime, None, size, None, target, now, REJECTED, "FILE_TOO_LARGE")
            detected_mime, detected_type = _detected_type(target, reported_mime)
            if Path(original_filename).suffix.casefold() in UNSUPPORTED_EXTENSIONS or not detected_type:
                return self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                    original_filename, safe, reported_mime, detected_mime, size, None, target, now, REJECTED, "UNSUPPORTED_TYPE", detected_type)
            if reported_mime and detected_mime and reported_mime != detected_mime:
                compatible = reported_mime == "text/plain" and detected_type == "text"
                if not compatible:
                    return self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                        original_filename, safe, reported_mime, detected_mime, size, None, target, now, REJECTED, "MIME_MISMATCH", detected_type)
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            record = self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                  original_filename, safe, reported_mime, detected_mime, size, digest, target, now, AUTHORIZED, None, detected_type)
            self._records[attachment_id] = record
            return record
        except OSError:
            return self._record(attachment_id, source, source_message_id, source_session_id, user_id,
                                original_filename, safe, reported_mime, None, 0, None, target, now, FAILED, "STAGING_FAILED")

    def _record(self, attachment_id, source, source_message_id, source_session_id, authenticated_user_id,
                original_filename, safe_filename, reported_mime, detected_mime, size_bytes, content_hash,
                staged_path, created, status, reason_code=None, detected_type=None):
        record = AttachmentRecord(attachment_id, source, str(source_message_id) if source_message_id is not None else None,
                                  str(source_session_id) if source_session_id is not None else None,
                                  str(authenticated_user_id) if authenticated_user_id is not None else None,
                                  self.node_id, str(original_filename or "attachment"), safe_filename,
                                  reported_mime, detected_mime, int(size_bytes or 0), content_hash, str(staged_path),
                                  _stamp(created), _stamp(created + timedelta(seconds=self.ttl_seconds)), status, reason_code,
                                  detected_type, ())
        self._records[attachment_id] = record
        return record

    def get(self, attachment_id: str, *, user_id: str | None = None, node_id: str | None = None) -> AttachmentRecord | None:
        record = self._records.get(attachment_id)
        if not record:
            return None
        if datetime.fromisoformat(record.expires_at) <= _now():
            self._records[attachment_id] = replace(record, status=EXPIRED, reason_code="EXPIRED_ATTACHMENT")
            return self._records[attachment_id]
        if user_id is not None and str(user_id) != record.authenticated_user_id:
            return replace(record, status=REJECTED, reason_code="OWNER_MISMATCH")
        if node_id is not None and str(node_id) != record.node_id:
            return replace(record, status=REJECTED, reason_code="NODE_MISMATCH")
        return record

    def latest(self, *, user_id: str, session_id: str | None = None) -> AttachmentRecord | None:
        rows = [item for item in self._records.values() if item.authenticated_user_id == str(user_id)
                and item.status == AUTHORIZED and (session_id is None or item.source_session_id == str(session_id))]
        rows.sort(key=lambda item: item.created_at)
        return rows[-1] if rows else None

    def to_file_record(self, attachment_id: str, *, user_id: str, node_id: str) -> FileRecord:
        record = self.get(attachment_id, user_id=user_id, node_id=node_id)
        if not record or record.status != AUTHORIZED:
            raise PermissionError(record.reason_code if record else "ATTACHMENT_NOT_FOUND")
        path = Path(record.staged_path).resolve(strict=True)
        if path.parent != self.staging_root or not path.is_file() or path.is_symlink():
            raise PermissionError("STAGING_FAILED")
        root = FileRoot.from_path(self.staging_root, root_id="attachment_root_" + attachment_id,
                                  node_id=node_id, user_id=user_id, require_allowed=False,
                                  display_name="Attachment")
        result = scan(FileScanSpec(root, recursive=False, include_hidden=True, max_entries=4))
        rows = [row for row in result.records if row.is_file and row.name == path.name]
        if len(rows) != 1:
            raise FileNotFoundError("FILE_NOT_FOUND")
        return replace(rows[0], metadata_state={**rows[0].metadata_state, "attachment_id": attachment_id,
                                                "source": record.source, "source_message_id": record.source_message_id,
                                                "source_session_id": record.source_session_id,
                                                "authenticated_user_id": record.authenticated_user_id,
                                                "content_hash": record.content_hash})

    def extract(self, attachment_id: str, *, user_id: str, node_id: str, query: str = "") -> tuple[FileRecord, object, EvidenceRecord]:
        file_record = self.to_file_record(attachment_id, user_id=user_id, node_id=node_id)
        content = extract_file(file_record)
        evidence = content_evidence(content)
        provenance = {**evidence.provenance, "attachment_id": attachment_id, "source": "telegram",
                      "authenticated_user_id": user_id, "node_id": node_id, "content_hash": file_record.metadata_state.get("content_hash")}
        evidence = replace(evidence, provenance=provenance)
        return file_record, content, evidence

    def cleanup(self, *, now: datetime | None = None) -> int:
        now = now or _now()
        removed = 0
        for attachment_id, record in list(self._records.items()):
            if datetime.fromisoformat(record.expires_at) > now:
                continue
            path = Path(record.staged_path)
            if path.parent == self.staging_root and path.exists():
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    continue
            self._records[attachment_id] = replace(record, status=EXPIRED, reason_code="EXPIRED_ATTACHMENT")
        return removed
