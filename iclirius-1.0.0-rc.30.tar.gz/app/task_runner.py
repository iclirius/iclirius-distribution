from app.task_queue import get_task, set_task_result
from app.worker_client import ask_worker
from app.logger import logger


def run_task_on_worker(task_id: str) -> str:
    task = get_task(task_id)

    if not task:
        return f"No encontré la tarea con ID: {task_id}"

    status = task.get("status")

    if status not in {"pending", "failed"}:
        return f"La tarea {task_id} no está pendiente. Estado actual: {status}"

    text = task.get("text", "").strip()

    if not text:
        return f"La tarea {task_id} no tiene texto."

    set_task_result(task_id, "running", "Enviada a worker.")

    try:
        logger.info("Running task on worker task_id=%s", task_id)
        result = ask_worker(text)

        if not result:
            result = "Worker no devolvió resultado."

        set_task_result(task_id, "done", result)

        return (
            f"Tarea ejecutada en worker: {task_id}\n"
            f"Estado: done\n\n"
            f"Resultado:\n{result[:3200]}"
        )

    except Exception as exc:
        logger.exception("Task worker execution failed task_id=%s", task_id)
        set_task_result(task_id, "failed", str(exc))

        return (
            f"Tarea falló en worker: {task_id}\n"
            f"Estado: failed\n"
            f"Error: {exc}"
        )
