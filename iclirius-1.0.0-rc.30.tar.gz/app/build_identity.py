"""Deterministic release/build identity exposed by CLI and service diagnostics."""
from __future__ import annotations

import subprocess
from pathlib import Path

from app.version import VERSION


def _revision() -> str:
    root = Path(__file__).resolve().parents[1]
    marker = root / "app" / "build_revision.txt"
    if marker.is_file():
        value = marker.read_text(encoding="utf-8").strip()
        if value:
            return value
    if (root / ".git").exists():
        try:
            result = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                                    capture_output=True, text=True, timeout=2, check=False)
            value = result.stdout.strip()
            if result.returncode == 0 and value:
                return value
        except (OSError, subprocess.SubprocessError):
            pass
    return "unknown"


def collect() -> dict:
    from app.provenance import collect as provenance
    data = provenance()
    revision = _revision()
    data.update({"build_revision": revision,
                 "build_identity": f"{VERSION}+{revision[:12]}",
                 "service_build_identity": f"{VERSION}+{revision[:12]}"})
    return data
