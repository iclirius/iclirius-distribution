"""Small, dependency-free presentation layer for the interactive CLI."""

from __future__ import annotations

import os
import re
import shutil
import sys
from contextlib import contextmanager


_ANSI_SEQUENCE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")


def _clean_input(raw: str) -> str:
    """Remove terminal control sequences without altering ordinary text."""
    text = _ANSI_SEQUENCE.sub("", raw or "")
    return "".join(char for char in text if char in "\t\n\r" or ord(char) >= 32).strip()


class CLIUI:
    """Render chat affordances without coupling them to the agent."""

    def __init__(self, output=None):
        self.output = output or sys.stdout
        try:
            self.is_tty = bool(self.output.isatty())
        except Exception:
            self.is_tty = False
        self.color = self.is_tty and not bool(os.environ.get("NO_COLOR"))
        self.width = shutil.get_terminal_size((80, 24)).columns

    def _color(self, text: str, code: str) -> str:
        return f"\033[{code}m{text}\033[0m" if self.color else text

    def identity(self, text: str) -> str:
        return self._color(text, "36")

    def user(self, text: str) -> str:
        return self._color(text, "33")

    def warning(self, text: str) -> str:
        return self._color(text, "33")

    def error(self, text: str) -> str:
        return self._color(text, "31")

    def prompt(self) -> str:
        return self.user("You > ")

    def header(self, agent, version: str) -> str:
        from app.config import settings

        mode = getattr(agent, "mode", "LOCAL")
        model = getattr(settings, "default_model", "") or "configured-local-model"
        provider = "Ollama" if mode == "LOCAL" else mode.title()
        node = getattr(settings, "node_id", "unknown-node") or "unknown-node"
        user = "not configured"
        try:
            principal = agent.core.principal_user() or {}
            user = principal.get("display_name") or user
        except Exception:
            pass
        line = "─" * max(20, min(60, self.width))
        return "\n".join((
            f"Iclirius v{version}",
            f"{mode} · {provider} · {model}",
            f"node  · {node}",
            f"user  · {user}",
            line,
            "Escribe /help para comandos.",
        ))

    @contextmanager
    def working(self):
        """A single reversible indicator; disabled for pipes and tests."""
        if not self.is_tty:
            yield
            return
        marker = self.identity("Iclirius · working…")
        print(marker, end="", file=self.output, flush=True)
        try:
            yield
        finally:
            print("\r\033[2K", end="", file=self.output, flush=True)

    def event(self, event) -> None:
        """Render only user-relevant operational milestones."""
        event_type = getattr(event, "event_type", "")
        metadata = getattr(event, "metadata", {}) or {}
        if event_type == "TOOL_STARTED":
            operation = str(getattr(event, "operation", "") or metadata.get("operation", ""))
            labels = {
                "LIST_DIRECTORY": "reading files",
                "FIND_FILES": "searching files",
                "SEARCH_TEXT": "searching text",
                "READ_TEXT_FILE": "reading file",
                "FILE_STAT": "checking file metadata",
                "DIRECTORY_SUMMARY": "reading files",
                "GIT_STATUS": "checking git status",
                "GIT_DIFF": "checking git diff",
                "GIT_LOG": "checking git history",
            }
            label = labels.get(operation)
            if label:
                print(self._color(f"→ {label}", "36"), file=self.output, flush=True)
        elif event_type == "PROVIDER_FALLBACK":
            from_model = metadata.get("from_model", "current model")
            to_model = metadata.get("to_model", "next model")
            print(self.warning(f"⚠ {from_model} unavailable"), file=self.output)
            print(f"→ switching to {to_model}", file=self.output, flush=True)
