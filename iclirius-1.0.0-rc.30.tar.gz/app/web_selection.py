"""Deterministic, explainable selection of web evidence for a question.

Selection quality describes usefulness as a candidate for this request. It is
not a truth or trust score. Page text is never consulted for authority claims.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from app.config import settings
from app.web_grounding import GroundedEvidence

_WORD = re.compile(r"[\w]{2,}", re.UNICODE)
_STOP = set("a an and are as at be by can do for from how in into is it of on or the this to was what when where which who why with about according latest current recent newest busca encuentra información información sobre cuál que como del los las una uno para por según es son fue include reports experiencing developers users community experience forum official documentation docs".split())
_INTENT_TERMS = {
    "DOCUMENTATION": {"documentation", "documentacion", "docs", "official", "oficial", "api", "reference", "manual", "documented"},
    "CURRENT_EVENT": {"latest", "current", "today", "recent", "news", "release", "última", "actual", "reciente", "hoy", "noticias", "actualidad"},
    "COMMUNITY_EXPERIENCE": {"community", "developers", "users", "experience", "problems", "issues", "opinions", "experiencia", "desarrolladores", "usuarios", "comunidad", "problemas", "opiniones", "forum", "reddit"},
    "COMPARISON": {"compare", "comparison", "versus", "difference", "differences", "vs", "compara", "comparar", "diferencia", "diferencias"},
    "NAVIGATION": {"website", "homepage", "site", "url", "página", "pagina", "sitio", "encuentra", "find"},
    "OPINION": {"opinion", "recommend", "better", "best", "should", "pros", "cons", "opinión", "recomienda", "mejor"},
}
_COMMUNITY_HOST_HINTS = ("community", "forum", "forums", "discuss", "reddit", "stackoverflow", "stackexchange")
_TRACKING = {"gclid", "fbclid", "mc_cid", "mc_eid"}


@dataclass(frozen=True)
class EvidenceQuality:
    evidence_id: str
    source_domain: str
    relevance: str
    source_relationship: str
    freshness: str
    completeness: str
    selection: str
    reason: str
    duplicate_of: str = ""
    warnings: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        value = asdict(self)
        value["warnings"] = list(self.warnings)
        return value


@dataclass(frozen=True)
class EvidenceSelection:
    intent: str
    candidates: tuple[GroundedEvidence, ...]
    selected: tuple[GroundedEvidence, ...]
    qualities: tuple[EvidenceQuality, ...]
    context_budget_chars: int
    used_budget_chars: int

    @property
    def duplicates(self) -> int:
        return sum(bool(item.duplicate_of) for item in self.qualities)

    @property
    def rejected(self) -> int:
        return sum(item.selection == "REJECTED" for item in self.qualities)

    def to_dict(self) -> dict:
        return {"intent": self.intent, "candidate_count": len(self.candidates),
                "selected_count": len(self.selected), "duplicate_count": self.duplicates,
                "rejected_count": self.rejected, "context_budget_chars": self.context_budget_chars,
                "used_budget_chars": self.used_budget_chars,
                "selected_ids": [item.evidence_id for item in self.selected],
                "qualities": [item.to_dict() for item in self.qualities]}


def classify_query_intent(query: str) -> str:
    words = {word.lower() for word in _WORD.findall(query or "")}
    for intent in ("COMPARISON", "COMMUNITY_EXPERIENCE", "CURRENT_EVENT", "NAVIGATION", "DOCUMENTATION", "OPINION"):
        if words & _INTENT_TERMS[intent]:
            return intent
    return "FACTUAL" if words else "UNKNOWN"


def _tokens(value: str) -> set[str]:
    return {word.lower() for word in _WORD.findall(value or "") if word.lower() not in _STOP}


def _token_sequence(value: str) -> list[str]:
    return [word.lower() for word in _WORD.findall(value or "") if word.lower() not in _STOP]


def _canonical_url(url: str) -> str:
    parsed = urlsplit((url or "").strip())
    query = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True)
             if not key.lower().startswith("utm_") and key.lower() not in _TRACKING]
    return urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), parsed.path.rstrip("/") or "/",
                       urlencode(sorted(query)), ""))


def _result(item: GroundedEvidence) -> dict:
    return item.record.result if isinstance(item.record.result, dict) else {}


def _host(item: GroundedEvidence) -> str:
    return (urlsplit(item.record.target).hostname or "").lower().removeprefix("www.")


def _relationship(item: GroundedEvidence, query_tokens: set[str]) -> str:
    host = _host(item)
    host_parts = set(_tokens(host.replace(".", " ").replace("-", " ")))
    if any(hint in host for hint in _COMMUNITY_HOST_HINTS):
        return "COMMUNITY"
    if host_parts & query_tokens:
        return "PRIMARY"
    # A documentation-looking path or a page's self-description is not enough
    # to call its publisher official. Without a topic/domain relationship this
    # remains a secondary/unknown source.
    return "SECONDARY" if host else "UNKNOWN"


def _freshness(item: GroundedEvidence) -> str:
    stamp = _result(item).get("retrieved_at") or item.record.provenance.get("retrieved_at") or item.record.observed_at
    try:
        parsed = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()
        return "RECENT" if -300 <= age <= 30 * 86400 else "STALE"
    except (TypeError, ValueError):
        return "UNKNOWN"


def _quality(item: GroundedEvidence, query_tokens: set[str], query_phrase: str,
             intent: str) -> tuple[str, str, str, tuple[str, ...], int]:
    result = _result(item)
    title = str(result.get("title", ""))
    snippet = str(result.get("snippet", ""))
    content = str(result.get("content", ""))
    title_tokens, snippet_tokens, body_tokens = _tokens(title), _tokens(snippet), _tokens(content)
    denominator = max(1, len(query_tokens))
    coverage = (3 * len(query_tokens & title_tokens) + 2 * len(query_tokens & snippet_tokens)
                + len(query_tokens & body_tokens)) / (6 * denominator)
    haystack = " ".join(_WORD.findall((title + " " + snippet + " " + content).lower()))
    phrase_match = len(query_tokens) > 1 and bool(query_phrase) and query_phrase in haystack
    relevance = "HIGH" if phrase_match or coverage >= 0.55 else "MEDIUM" if coverage >= 0.22 else "LOW"
    relationship = _relationship(item, query_tokens)
    freshness = _freshness(item)
    warnings = []
    truncated = bool(result.get("truncated"))
    fetched = bool(result.get("retrieval") == "fetched" or content)
    completeness = "TRUNCATED" if truncated else "COMPLETE" if fetched else "SNIPPET_ONLY"
    if truncated:
        warnings.append("fetch_truncated")
    if not fetched:
        warnings.append("fetch_incomplete")
    if str(result.get("content_type", "")).lower() not in {"text/html", "text/plain", "application/json", "search_snippet"}:
        warnings.append("unknown_content_type")
    redirect_chain = result.get("redirect_chain") or item.record.provenance.get("redirect_chain") or ()
    if redirect_chain:
        warnings.append("redirected")
    scheme = urlsplit(item.record.target).scheme.lower()
    if scheme == "http":
        warnings.append("unencrypted_http")
    rank = result.get("rank", 99)
    try:
        rank_signal = max(0, 10 - int(rank))
    except (TypeError, ValueError):
        rank_signal = 0
    score = {"HIGH": 30, "MEDIUM": 15, "LOW": 0}[relevance] + min(10, rank_signal)
    if intent == "DOCUMENTATION":
        score += {"PRIMARY": 14, "SECONDARY": 0, "COMMUNITY": -4, "UNKNOWN": 0}[relationship]
    elif intent == "COMMUNITY_EXPERIENCE":
        score += {"COMMUNITY": 18, "PRIMARY": 2, "SECONDARY": 4, "UNKNOWN": 0}[relationship]
    elif intent == "CURRENT_EVENT":
        score += 8 if freshness == "RECENT" else -4 if freshness == "STALE" else 0
    elif intent in {"COMPARISON", "OPINION"}:
        score += 2 if relationship in {"COMMUNITY", "SECONDARY"} else 0
    score += 4 if fetched else -5
    score -= 5 if truncated else 0
    score += 1 if scheme == "https" else -1 if scheme == "http" else 0
    status_code = result.get("status_code")
    if status_code is not None:
        try:
            if not 200 <= int(status_code) < 300:
                warnings.append("non_success_http_status")
                score -= 8
        except (TypeError, ValueError):
            warnings.append("unknown_http_status")
    return relevance, relationship, freshness, tuple(warnings), score


def _cost(item: GroundedEvidence, budget: int) -> int:
    result = _result(item)
    text = str(result.get("content", ""))
    # Approximate the existing bounded context format and its even per-source
    # allocation; this is a budget estimate, not a token/truth score.
    content_budget = max(240, budget // 2 - 240)
    return 240 + min(len(text), content_budget)


def select_evidence(query: str, candidates: list[GroundedEvidence], *,
                    context_budget_chars: int | None = None) -> EvidenceSelection:
    """Rank and bound candidate evidence without changing canonical evidence IDs."""
    candidates = list(candidates)
    budget = max(0, min(32_000, context_budget_chars if context_budget_chars is not None
                         else settings.context_evidence_max_chars))
    intent = classify_query_intent(query)
    query_tokens = _tokens(query)
    query_phrase = " ".join(_token_sequence(query)[:32])
    scored = []
    for position, item in enumerate(candidates):
        relevance, relationship, freshness, warnings, score = _quality(item, query_tokens, query_phrase, intent)
        scored.append((item, position, relevance, relationship, freshness, warnings, score))

    # Group URL/final-URL and exact normalized-text duplicates. Keep the
    # best representative by quality/completeness, not input order.
    parents = {row[0].evidence_id: row[0].evidence_id for row in scored}

    def find(identifier: str) -> str:
        while parents[identifier] != identifier:
            parents[identifier] = parents[parents[identifier]]
            identifier = parents[identifier]
        return identifier

    def union(left: str, right: str) -> None:
        first, second = find(left), find(right)
        if first != second:
            parents[second] = first

    seen_keys: dict[str, str] = {}
    for item, *_ in scored:
        result = _result(item)
        urls = [_canonical_url(value) for value in
                (item.record.target, str(result.get("requested_url", "")),
                 str(result.get("final_url", ""))) if value]
        text = re.sub(r"\s+", " ", str(result.get("content", ""))).strip().casefold()
        digest = hashlib.sha256(text.encode()).hexdigest() if text else ""
        keys = [*(f"url:{url}" for url in urls), *([f"text:{digest}"] if digest else [])]
        for key in keys:
            if key in seen_keys:
                union(item.evidence_id, seen_keys[key])
            else:
                seen_keys[key] = item.evidence_id

    groups: dict[str, list[tuple]] = {}
    for row in scored:
        groups.setdefault(find(row[0].evidence_id), []).append(row)
    duplicate_of: dict[str, str] = {}
    for rows in groups.values():
        representative = max(rows, key=lambda row: (bool(_result(row[0]).get("content")),
                                                      not bool(_result(row[0]).get("truncated")),
                                                      row[6], -row[1]))
        for row in rows:
            if row[0].evidence_id != representative[0].evidence_id:
                duplicate_of[row[0].evidence_id] = representative[0].evidence_id

    # When multiple results cover the question, weak matches do not displace
    # relevant evidence. If all are weak, preserve the best candidate so the
    # grounding layer can explicitly report limits rather than fabricate.
    eligible = [row for row in scored if row[2] != "LOW" and row[0].evidence_id not in duplicate_of]
    if not eligible:
        eligible = [row for row in scored if row[0].evidence_id not in duplicate_of]
    eligible.sort(key=lambda row: (-row[6], row[1]))

    selected: list[GroundedEvidence] = []
    selected_domains: set[str] = set()
    reasons: dict[str, tuple[str, str]] = {}
    used = 0
    for row in eligible:
        item, _position, relevance, relationship, freshness, _warnings, _score = row
        cost = _cost(item, budget)
        if used + cost > budget:
            reasons[item.evidence_id] = ("REJECTED", "context budget")
            continue
        domain = _host(item)
        # For multi-perspective questions, choose a new domain before a second
        # candidate from a domain already represented, while retaining all
        # independent candidates if space remains.
        diversify = intent in {"COMMUNITY_EXPERIENCE", "COMPARISON", "OPINION"}
        if diversify and domain in selected_domains and any(_host(other[0]) not in selected_domains for other in eligible
                                                              if other[0].evidence_id not in duplicate_of):
            reasons[item.evidence_id] = ("REJECTED", "lower-ranked same source; source diversity")
            continue
        selected.append(item)
        selected_domains.add(domain)
        used += cost
        if relevance == "LOW": reason = "best available candidate; weak query match"
        elif relationship == "PRIMARY" and intent == "DOCUMENTATION": reason = "direct query match; documentation intent favors topic-related primary-source signal"
        elif relationship == "COMMUNITY" and intent == "COMMUNITY_EXPERIENCE": reason = "direct query match; community intent"
        elif relevance == "HIGH": reason = "direct query match; independent source"
        else: reason = "partial query match; ranked candidate"
        if freshness == "STALE" and intent == "CURRENT_EVENT": reason += "; retrieval is stale"
        reasons[item.evidence_id] = ("SELECTED", reason)

    qualities = []
    for item, _position, relevance, relationship, freshness, warnings, _score in scored:
        if item.evidence_id in duplicate_of:
            selection, reason = "REJECTED", f"duplicate of {duplicate_of[item.evidence_id]}"
        else:
            selection, reason = reasons.get(item.evidence_id, ("REJECTED", "lower-ranked candidate"))
        qualities.append(EvidenceQuality(item.evidence_id, _host(item), relevance, relationship, freshness,
                                         "TRUNCATED" if "fetch_truncated" in warnings else
                                         "SNIPPET_ONLY" if "fetch_incomplete" in warnings else "COMPLETE",
                                         selection, reason, duplicate_of.get(item.evidence_id, ""), warnings))
    return EvidenceSelection(intent, tuple(candidates), tuple(selected), tuple(qualities), budget, used)
