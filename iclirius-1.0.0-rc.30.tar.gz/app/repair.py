"""Explicit, role-aware repair planning and execution.

Repair is deliberately separate from Doctor: planning observes, execution
mutates only approved, typed actions.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from app.doctor import collect as collect_doctor
from app.node_capability_profile import build_node_capability_profile
from app.node_health import normalize_role

SCHEMA_VERSION = 1
RISK = {"SAFE", "CONFIRM", "MANUAL", "POLICY_BLOCKED"}
PHASES = {"STARTING", "RUNNING", "DOWNLOADING", "INSTALLING", "VERIFYING", "COMPLETED", "FAILED", "CANCELLED"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class RepairProgressEvent:
    action_id: str
    action_index: int
    action_total: int
    phase: str
    message: str
    elapsed_ms: int = 0
    percent: float | None = None
    current_bytes: int | None = None
    total_bytes: int | None = None
    rate_bytes_per_second: float | None = None
    eta_seconds: int | None = None

    def __post_init__(self):
        if self.phase not in PHASES:
            raise ValueError("invalid repair progress phase")

    def to_dict(self) -> dict:
        return asdict(self)


def parse_ollama_progress(line: str) -> dict:
    """Extract only explicit Ollama progress values; unknown output is safe."""
    import re
    result: dict = {}
    match = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
    if match:
        result["percent"] = float(match.group(1))
    sizes = re.findall(r"(\d+(?:\.\d+)?)\s*(KB|MB|GB|B)\b", line, re.I)
    if len(sizes) >= 2:
        units = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3}
        result["current_bytes"] = int(float(sizes[0][0]) * units[sizes[0][1].upper()])
        result["total_bytes"] = int(float(sizes[1][0]) * units[sizes[1][1].upper()])
    return result


class RepairProgressReporter:
    def __init__(self, output=None, is_tty: bool | None = None):
        self.output = output or sys.stdout
        self.is_tty = self.output.isatty() if is_tty is None else is_tty
        self.events: list[RepairProgressEvent] = []

    def __call__(self, event: RepairProgressEvent) -> None:
        self.events.append(event)
        elapsed = f"Elapsed {event.elapsed_ms / 1000:.0f}s"
        if event.percent is not None:
            progress = f" {event.percent:.0f}%"
        else:
            progress = ""
        if self.is_tty:
            marker = "✓" if event.phase == "COMPLETED" else ("✗" if event.phase == "FAILED" else "→")
            print(f"\r{marker} [{event.action_index}/{event.action_total}] {event.message}{progress}  {elapsed}", end="", file=self.output, flush=True)
            if event.phase in {"COMPLETED", "FAILED", "CANCELLED"}:
                print(file=self.output)
        else:
            print(f"[repair] [{event.action_index}/{event.action_total}] {event.phase.lower()} {event.message}{progress} ({elapsed})", file=self.output, flush=True)


@dataclass(frozen=True)
class RepairAction:
    id: str
    capability: str
    title: str
    description: str
    risk_class: str
    required: bool = False
    target_role: str = ""
    estimated_download: str = ""
    requires_network: bool = False
    requires_admin: bool = False
    executable: str = ""
    verification: str = ""
    status: str = "PROPOSED"

    def __post_init__(self):
        if self.risk_class not in RISK:
            raise ValueError("invalid repair risk class")

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class RepairPlan:
    actions: tuple[RepairAction, ...] = field(default_factory=tuple)
    schema_version: int = SCHEMA_VERSION
    generated_at: str = field(default_factory=_now)
    overall: str = ""
    eligible_roles: tuple[str, ...] = field(default_factory=tuple)
    communication_ready: bool = False

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "generated_at": self.generated_at,
                "overall": self.overall, "eligible_roles": list(self.eligible_roles),
                "communication_ready": self.communication_ready,
                "actions": [a.to_dict() for a in self.actions]}


class RepairPlanner:
    def build(self, report: dict, role: str | None = None, *, include_optional: bool = False) -> RepairPlan:
        effective_role = normalize_role(role or report.get("node_role") or report.get("role") or "interface")
        profile = build_node_capability_profile({**report, "node_role": effective_role})
        actions: list[RepairAction] = []
        setup = report.get("setup", {})
        node_ready = bool(setup.get("node", {}).get("node_id"))
        if not node_ready:
            actions.append(RepairAction("node.identity", "NODE_COMMUNICATION_READY",
                "Initialize node identity", "Create the missing machine-local Ed25519 identity in Keychain.",
                "SAFE", target_role="INTERFACE", executable="security", verification="node identity"))

        ollama = report.get("ollama", {})
        brew = bool(report.get("homebrew", {}).get("installed"))
        if not ollama.get("installed") and effective_role in {"LOCAL_COMPUTE", "FULL_NODE"}:
            actions.append(RepairAction("ollama.install", "LOCAL_REASONING", "Install Ollama",
                "Install the official Ollama Homebrew package after confirmation.",
                "CONFIRM" if brew else "MANUAL", required=effective_role in {"LOCAL_COMPUTE", "FULL_NODE"},
                target_role="LOCAL_COMPUTE", requires_network=True, requires_admin=False,
                executable="brew", verification="Ollama API"))
        elif not ollama.get("running") and effective_role in {"LOCAL_COMPUTE", "FULL_NODE"}:
            actions.append(RepairAction("ollama.start", "LOCAL_REASONING", "Start Ollama",
                "Start the existing Ollama runtime after confirmation; no installation is performed.",
                "CONFIRM" if brew else "MANUAL", target_role="LOCAL_COMPUTE", executable="brew" if brew else "ollama", verification="Ollama API"))

        models = report.get("models", {})
        required = models.get("required", [])
        installed = set(models.get("installed", []))
        default = required[0] if required else ""
        if default and default not in installed and ollama.get("running") and effective_role in {"LOCAL_COMPUTE", "FULL_NODE"}:
            actions.append(RepairAction("model.default", "LOCAL_REASONING", f"Download {default}",
                f"Download the configured default model with Ollama after confirmation.", "CONFIRM",
                required=effective_role in {"LOCAL_COMPUTE", "FULL_NODE"}, target_role="LOCAL_COMPUTE",
                estimated_download="size reported by Ollama when available", requires_network=True,
                executable="ollama", verification="model listing"))

        if not report.get("voice", {}).get("ffmpeg") and effective_role in {"FULL_NODE", "CODE_WORKER"}:
            actions.append(RepairAction("voice.ffmpeg", "VOICE", "Install ffmpeg",
                "Install ffmpeg through Homebrew for optional media features.",
                "CONFIRM" if brew else "MANUAL", target_role="FULL_NODE", requires_network=True,
                executable="brew", verification="ffmpeg --version"))
        if not report.get("git", {}).get("installed") and effective_role in {"CODE_WORKER", "FULL_NODE"} and brew:
            actions.append(RepairAction("git.install", "VERSION_CONTROL", "Install Git",
                "Install Git through the official Homebrew formula for this role.", "CONFIRM",
                required=True, target_role=effective_role, requires_network=True,
                executable="brew", verification="git --version"))

        service = report.get("managed_node_service", {})
        if service.get("state") == "SERVICE_RUNTIME_STALE":
            actions.append(RepairAction(
                "node.service.reinstall", "NODE_SERVICE", "Regenerate packaged node service",
                "Rewrite the managed LaunchAgent with the currently installed runtime; the operation preserves user state.",
                "CONFIRM", target_role=effective_role, executable="iclirius node install",
                verification="LaunchAgent runtime matches installed package"))

        if include_optional:
            # Optional enhancements are shown explicitly and are never applied
            # by Doctor's planning mode. They require a separate user decision.
            for tier, label in (("fast", "Fast model"), ("heavy", "Heavy model"), ("embed", "Embeddings")):
                model = str(models.get(tier, ""))
                if model and model not in installed:
                    actions.append(RepairAction(f"model.{tier}", "OPTIONAL_LOCAL_AI", f"Download {model}",
                        f"Install the optional {label.lower()} with Ollama after confirmation.", "CONFIRM",
                        target_role=effective_role, requires_network=True, executable="ollama", verification="model listing"))
            if not report.get("voice", {}).get("ffmpeg"):
                actions.append(RepairAction("voice.ffmpeg.optional", "OPTIONAL_VOICE", "Install ffmpeg",
                    "Install optional audio tooling through Homebrew after confirmation.",
                    "CONFIRM" if brew else "MANUAL", target_role=effective_role, requires_network=True,
                    executable="brew", verification="ffmpeg --version"))
            if not report.get("voice", {}).get("stt"):
                actions.append(RepairAction("voice.stt", "OPTIONAL_VOICE", "Install faster-whisper",
                    "Install and configure optional local speech-to-text dependencies manually.",
                    "MANUAL", target_role=effective_role, requires_network=True,
                    executable="pip", verification="faster-whisper import"))
            if not report.get("tools", {}).get("filesystem"):
                actions.append(RepairAction("tools.filesystem", "OPTIONAL_TOOLS", "Configure filesystem roots",
                    "Choose allowed filesystem roots interactively; no paths are invented automatically.",
                    "CONFIRM", target_role=effective_role, verification="configured roots"))
            if not report.get("tools", {}).get("shell"):
                actions.append(RepairAction("tools.shell", "OPTIONAL_TOOLS", "Enable shell policy",
                    "Shell execution remains disabled until an explicit execution policy is configured.",
                    "POLICY_BLOCKED", target_role=effective_role, verification="execution policy"))
            if not shutil.which("tailscale"):
                actions.append(RepairAction("network.tailscale", "OPTIONAL_NETWORK", "Configure Tailscale",
                    "Tailscale setup is manual and is never performed automatically.", "MANUAL",
                    target_role=effective_role, verification="tailscale status"))

        return RepairPlan(tuple(actions), overall=profile.get("overall_readiness", ""),
                          eligible_roles=tuple(profile.get("eligible_roles", [])),
                          communication_ready=node_ready)


class RepairExecutor:
    def __init__(self, runner=None, progress=None):
        self.runner = runner or subprocess.run
        self.progress = progress or (lambda event: None)
        self._child = None

    def _emit(self, action, index, total, phase, message, started, **kwargs):
        self.progress(RepairProgressEvent(action.id, index, total, phase, message,
                                          int((time.monotonic() - started) * 1000), **kwargs))

    def execute(self, plan: RepairPlan, approved: bool = False) -> dict:
        if not approved:
            return {"schema_version": SCHEMA_VERSION, "status": "DECLINED", "actions": []}
        results = []
        total = len(plan.actions)
        for index, action in enumerate(plan.actions, 1):
            if action.risk_class in {"MANUAL", "POLICY_BLOCKED"}:
                results.append({"id": action.id, "result": "MANUAL" if action.risk_class == "MANUAL" else "POLICY_BLOCKED"})
                continue
            started = time.monotonic()
            self._emit(action, index, total, "STARTING", action.title, started)
            try:
                result = self._run_action(action, index, total, started)
                verified = self._verify_action(action)
                if not verified:
                    raise RuntimeError("repair verification failed")
                results.append({"id": action.id, "result": result, "verified": True})
                self._emit(action, index, total, "COMPLETED", action.title, started)
            except KeyboardInterrupt:
                self._terminate_child()
                self._emit(action, index, total, "CANCELLED", action.title, started)
                results.append({"id": action.id, "result": "CANCELLED"})
                break
            except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                self._emit(action, index, total, "FAILED", action.title, started)
                results.append({"id": action.id, "result": "FAILED", "error_category": type(exc).__name__})
        report = collect_doctor()
        try:
            from app.deep_diagnostics import run as run_deep
            deep = run_deep(report)
            if isinstance(deep, dict):
                report = dict(report)
                report["capability_audit"] = deep.get("capability_audit", report.get("capability_audit", {}))
                report["deep_diagnostics"] = deep
        except Exception:
            # Verification remains useful even when an optional deep probe is
            # unavailable in a restricted environment.
            pass
        profile = build_node_capability_profile(report)
        failed = any(item.get("result") == "FAILED" for item in results)
        manual = any(item.get("result") in {"MANUAL", "POLICY_BLOCKED"} for item in results)
        outcome = "FAILED" if failed else ("PARTIAL" if manual else "COMPLETE")
        return {"schema_version": SCHEMA_VERSION, "status": outcome, "actions": results,
                "verification": {"overall": profile.get("overall_readiness"),
                                 "eligible_roles": profile.get("eligible_roles", [])}}

    def _stream_command(self, argv, action, index, total, started, timeout):
        popen = getattr(subprocess, "Popen")
        process = popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        text=True, bufsize=1, shell=False)
        self._child = process
        stop = threading.Event()
        def heartbeat():
            while not stop.wait(3):
                self._emit(action, index, total, "RUNNING", f"{action.title} — still running", started)
        thread = threading.Thread(target=heartbeat, daemon=True); thread.start()
        try:
            deadline = time.monotonic() + timeout
            for line in process.stdout or ():
                details = parse_ollama_progress(line) if action.id == "model.default" else {}
                self._emit(action, index, total, "DOWNLOADING" if action.id == "model.default" else "INSTALLING",
                           line.strip() or action.title, started, **details)
                if time.monotonic() > deadline:
                    raise subprocess.TimeoutExpired(argv, timeout)
            returncode = process.wait(timeout=max(0, deadline - time.monotonic()))
            if returncode:
                raise subprocess.CalledProcessError(returncode, argv)
            return "SUCCESS"
        finally:
            stop.set(); thread.join(timeout=1); self._child = None

    def _terminate_child(self):
        child = self._child
        if child is None:
            return
        try:
            child.terminate(); child.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            try: child.kill()
            except OSError: pass
            try: child.wait(timeout=2)
            except subprocess.TimeoutExpired: pass

    def _run_action(self, action: RepairAction, index=1, total=1, started=None) -> str:
        started = started or time.monotonic()
        if action.id == "node.identity":
            from app.node_pairing import identity
            identity(); return "SUCCESS"
        if action.id == "ollama.install":
            return self._stream_command(["brew", "install", "ollama"], action, index, total, started, 300)
        if action.id == "ollama.start":
            return self._stream_command(["brew", "services", "start", "ollama"], action, index, total, started, 60)
        if action.id == "model.default":
            return self._stream_command(["ollama", "pull", action.title.removeprefix("Download ")], action, index, total, started, 1800)
        if action.id == "voice.ffmpeg":
            return self._stream_command(["brew", "install", "ffmpeg"], action, index, total, started, 300)
        if action.id == "git.install":
            return self._stream_command(["brew", "install", "git"], action, index, total, started, 300)
        if action.id == "node.service.reinstall":
            from app.node_service import reinstall
            result = reinstall()
            if result.get("state") == "SERVICE_RUNTIME_STALE":
                raise RuntimeError("node service runtime remains stale")
            return "SUCCESS"
        raise RuntimeError("unsupported repair action")

    def _verify_action(self, action: RepairAction) -> bool:
        """Verify the authoritative result of an action, never its exit code alone."""
        import shutil
        if action.id == "node.identity":
            from app.node_pairing import identity
            return bool(identity().node_id)
        if action.id == "git.install":
            return shutil.which("git") is not None
        if action.id == "voice.ffmpeg":
            return shutil.which("ffmpeg") is not None
        if action.id in {"ollama.install", "ollama.start", "model.default"}:
            from app.doctor import _ollama_service, _installed_models
            ollama = shutil.which("ollama")
            running, _ = _ollama_service()
            if action.id == "model.default":
                model = action.title.removeprefix("Download ")
                return running and model in _installed_models(ollama)
            return bool(ollama and running)
        if action.id == "node.service.reinstall":
            from app.node_service import status
            return status().get("state") != "SERVICE_RUNTIME_STALE"
        return False


def render(plan: RepairPlan) -> str:
    lines = ["ICLIRIUS REPAIR", "", "Current role eligibility"]
    lines.extend(f"  {role:20} READY" for role in plan.eligible_roles)
    lines += ["", "Proposed actions"]
    if not plan.actions:
        lines.append("  No repair required.")
    for index, action in enumerate(plan.actions, 1):
        lines.append(f"  {index}. {action.title} [{action.risk_class}]")
        lines.append(f"     {action.description}")
    lines += ["", f"Node communication runtime: {'READY' if plan.communication_ready else 'NOT READY'}"]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(prog="iclirius repair")
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--role", choices=("interface", "local-compute", "code-worker", "full-node"))
    args = parser.parse_args(argv or [])
    plan = RepairPlanner().build(collect_doctor(), args.role)
    if args.json or args.plan:
        print(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) if args.json else render(plan))
        return 0
    print(render(plan))
    if not plan.actions:
        return 0
    if not sys.stdin.isatty():
        print("Confirmation required; no actions executed in non-interactive mode.")
        return 2
    answer = input("\nApply repair plan? [y/N] ").strip().lower()
    if answer not in {"y", "yes"}:
        print("Repair declined; no changes made."); return 0
    print(f"\nApplying {len(plan.actions)} approved actions", flush=True)
    reporter = RepairProgressReporter()
    result = RepairExecutor(progress=reporter).execute(plan, approved=True)
    print("\nRepair actions completed. Verifying node...", flush=True)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if all(item.get("result") not in {"FAILED"} for item in result["actions"]) else 1
