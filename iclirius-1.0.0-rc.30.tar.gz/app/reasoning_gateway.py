"""
The single door between Iclirius and any reasoning engine.

Everything that needs a model goes through here: general chat, evidence
analysis, patch generation, the optional summary line. The agent no longer
knows that Ollama speaks HTTP, which is the point — when a second provider
arrives it plugs in behind this door rather than into nine call sites.

    ReasoningRequest
        ↓  router picks provider + model order (deterministic, free)
    provider.generate(request, model)
        ↓  failure → next model in the order
    ReasoningResponse  +  usage recorded  +  events emitted

The gateway keeps the local fallback semantics unchanged: an unreachable
engine stops the attempt immediately, because trying another model against a
server that is down cannot help, while a model that merely refused the work is
followed by the next one in the chain.

Usage accounting is a ledger, not a policy. It can answer how much was spent
per task, per provider and per account, which is what a budget will later need
— but there is no budget yet, nothing is throttled, and for a local engine the
cost is zero by construction.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field

from app.logger import logger
from app.provider_registry import (
    Mode,
    ProviderRegistry,
    ProviderRouter,
    RoutingError,
    registry as default_registry,
    router as default_router,
)
from app.config import settings
from app.config import settings as settings_module
from app.reasoning import (
    Purpose,
    ReasoningRequest,
    ReasoningResponse,
    ResponseStatus,
)
from app.runtime_events import EventType, Status, emit


def _family(decision) -> str:
    """
    The provider family for an event.

    RuntimeEvent.provider has meant "ollama", not "ollama-local", since the
    event contract was written. The instance id travels in metadata so both
    are available without redefining a field a UI already reads.
    """
    return (decision.provider_type or "").lower() or decision.provider_id


class GatewayError(RuntimeError):
    """No provider could answer, and there is nothing left to try."""


@dataclass
class UsageRecord:
    """Counters for one dimension. No prompt, no answer, ever."""

    requests: int = 0
    errors: int = 0
    rate_limits: int = 0
    input_tokens_estimated: int = 0
    output_tokens_estimated: int = 0
    input_tokens_actual: int = 0
    output_tokens_actual: int = 0
    cost_estimated: float = 0.0
    latency_ms_total: int = 0

    def add(self, response: ReasoningResponse) -> None:
        self.requests += 1
        self.input_tokens_estimated += response.input_tokens_estimated
        self.output_tokens_estimated += response.output_tokens_estimated
        self.input_tokens_actual += response.input_tokens_actual or 0
        self.output_tokens_actual += response.output_tokens_actual or 0
        self.cost_estimated += response.cost_estimated
        self.latency_ms_total += response.latency_ms

        if response.status == ResponseStatus.RATE_LIMITED.value:
            self.rate_limits += 1
        elif not response.ok:
            self.errors += 1

    def to_dict(self) -> dict:
        return asdict(self)


class UsageLedger:
    """
    What has been spent, sliced the three ways a budget will need.

    Deliberately a skeleton: it records and answers, and decides nothing. A
    governor that enforced limits would belong on top of this, not inside it.
    """

    def __init__(self):
        self._by_provider: dict[str, UsageRecord] = defaultdict(UsageRecord)
        self._by_account: dict[str, UsageRecord] = defaultdict(UsageRecord)
        self._by_task: dict[str, UsageRecord] = defaultdict(UsageRecord)
        self._total = UsageRecord()
        self._lock = threading.Lock()

    def record(self, response: ReasoningResponse, task_id: str | None = None) -> None:
        with self._lock:
            self._total.add(response)
            self._by_provider[response.provider_id or "?"].add(response)
            self._by_account[response.account_ref or "?"].add(response)

            if task_id:
                self._by_task[task_id].add(response)

    def total(self) -> UsageRecord:
        with self._lock:
            return UsageRecord(**self._total.to_dict())

    def by_provider(self, provider_id: str) -> UsageRecord:
        with self._lock:
            return UsageRecord(**self._by_provider[provider_id].to_dict())

    def by_account(self, account_ref: str) -> UsageRecord:
        with self._lock:
            return UsageRecord(**self._by_account[account_ref].to_dict())

    def by_task(self, task_id: str) -> UsageRecord:
        with self._lock:
            return UsageRecord(**self._by_task[task_id].to_dict())

    def summary(self) -> dict:
        """Compact totals for the runtime snapshot."""
        with self._lock:
            total = self._total

            return {
                "requests": total.requests,
                "errors": total.errors,
                "estimated_input_tokens": total.input_tokens_estimated,
                "estimated_output_tokens": total.output_tokens_estimated,
                "cost_estimated": round(total.cost_estimated, 6),
                "providers": {
                    name: record.requests
                    for name, record in self._by_provider.items()
                },
            }

    def clear(self) -> None:
        with self._lock:
            self._by_provider.clear()
            self._by_account.clear()
            self._by_task.clear()
            self._total = UsageRecord()


@dataclass
class GatewayResult:
    """What the agent gets back: an answer plus how it was reached."""

    response: ReasoningResponse
    decision: object = None
    budget: object = None
    attempts: int = 1
    routing_ms: int = 0
    gateway_ms: int = 0
    fallbacks_used: int = 0

    @property
    def ok(self) -> bool:
        return self.response.ok

    @property
    def content(self) -> str:
        return self.response.content


class ReasoningGateway:
    """Routes, calls, records and reports. It does not interpret answers."""

    def __init__(self, registry: ProviderRegistry | None = None,
                 router: ProviderRouter | None = None,
                 ledger: UsageLedger | None = None,
                 accounts=None, governor=None):
        from app.provider_accounts import ProviderAccountPool
        from app.token_governor import TokenGovernor

        self.registry = registry or default_registry
        self.router = router or default_router
        self.ledger = ledger or UsageLedger()
        self.accounts = accounts if accounts is not None else ProviderAccountPool()
        self.governor = governor if governor is not None else TokenGovernor()

    def submit(self, request: ReasoningRequest, mode: str = Mode.LOCAL.value,
               model_chain: list[str] | None = None,
               interface: str = "") -> GatewayResult:
        """
        Answer one request, trying the routed models in order.

        Raises GatewayError only when routing itself is impossible. A provider
        that answered with a failure comes back as a failed response, so the
        caller can decide whether that is fatal for what it was doing.
        """
        started = time.monotonic()
        route_started = time.monotonic()

        try:
            decision = self.router.route(request, mode=mode, model_chain=model_chain)
        except RoutingError as exc:
            emit(EventType.PROVIDER_REQUEST_FAILED.value, status=Status.FAILED.value,
                 interface=interface, task_id=request.task_id,
                 metadata={**request.safe_metadata(), "error": "routing"})
            raise GatewayError(str(exc)) from exc

        routing_ms = int((time.monotonic() - route_started) * 1000)

        emit(EventType.ROUTING_DECISION.value, status=Status.INFO.value,
             interface=interface, task_id=request.task_id,
             provider=_family(decision), model=decision.model_id,
             account_ref=decision.account_ref,
             metadata=decision.safe_metadata())

        provider = self.registry.get(decision.provider_id)

        if provider is None:
            raise GatewayError(f"El proveedor {decision.provider_id} desapareció.")

        if not provider.capabilities().local:
            return self._submit_cloud(request, decision, interface, started,
                                      routing_ms)

        chain = [decision.model_id, *decision.fallback_order]
        response: ReasoningResponse | None = None
        attempts = 0

        for index, model in enumerate(chain):
            attempts += 1

            emit(EventType.PROVIDER_REQUEST_STARTED.value,
                 status=Status.STARTED.value, interface=interface,
                 task_id=request.task_id, provider=_family(decision),
                 model=model, account_ref=decision.account_ref,
                 metadata={**request.safe_metadata(),
                           "provider_id": decision.provider_id})

            try:
                response = provider.generate(request, model)
            except Exception as exc:
                logger.warning("Provider raised id=%s model=%s error=%s",
                               decision.provider_id, model, type(exc).__name__)
                response = ReasoningResponse(
                    request_id=request.request_id,
                    provider_id=decision.provider_id,
                    account_ref=decision.account_ref,
                    model_id=model,
                    status=ResponseStatus.FAILED.value,
                    error=f"{type(exc).__name__}: {exc}",
                )

            self.ledger.record(response, task_id=request.task_id)

            # What the engine actually said, for the next routing decision.
            self.registry.record_status(decision.provider_id, response.status
                                        if not response.ok else "AVAILABLE")

            if response.ok:
                emit(EventType.PROVIDER_REQUEST_COMPLETED.value, status=Status.OK.value,
                     interface=interface, task_id=request.task_id,
                     provider=_family(decision), model=model,
                     account_ref=decision.account_ref,
                     duration_ms=response.latency_ms,
                     metadata=response.safe_metadata())
                break

            self._emit_failure(response, decision, interface, request)

            # An unreachable engine will not become reachable for the next
            # model in the list. This mirrors the behaviour the agent had
            # before the gateway existed.
            if response.status == ResponseStatus.UNAVAILABLE.value:
                break

            if index < len(chain) - 1:
                emit(EventType.PROVIDER_FALLBACK.value, status=Status.INFO.value,
                     interface=interface, task_id=request.task_id,
                     provider=_family(decision),
                     metadata={"from_model": model, "to_model": chain[index + 1]})

        return GatewayResult(
            response=response,
            decision=decision,
            attempts=attempts,
            routing_ms=routing_ms,
            gateway_ms=int((time.monotonic() - started) * 1000),
            fallbacks_used=max(0, attempts - 1),
        )

    def _submit_cloud(self, request, decision, interface, started,
                      routing_ms) -> GatewayResult:
        """
        A metered request: budget first, then accounts in order.

        The budget is checked before anything reaches the network, because a
        limit enforced afterwards is not a limit. Then the pool is walked —
        rate-limited accounts step aside, an exhausted one is parked, a bad
        request stops immediately — and if every account is spent the caller
        is told that plainly rather than being handed a local answer dressed
        up as a cloud one.
        """
        verdict = self.governor.check(request, is_cloud=True, interface=interface)

        if not verdict.allowed:
            return GatewayResult(
                response=ReasoningResponse(
                    request_id=request.request_id,
                    provider_id=decision.provider_id,
                    account_ref=decision.account_ref,
                    status=ResponseStatus.FAILED.value,
                    error_kind="BUDGET_DENIED",
                    error=f"Presupuesto de nube agotado: {verdict.reason}",
                    cost_known=False,
                ),
                decision=decision, attempts=0, routing_ms=routing_ms,
                gateway_ms=int((time.monotonic() - started) * 1000),
                budget=verdict,
            )

        accounts = [decision.account_ref, *decision.account_order]
        accounts = accounts[:max(1, settings.cloud_max_account_attempts)]
        response = None
        attempts = 0

        for index, account_ref in enumerate(accounts):
            provider = self.registry.get(account_ref)

            if provider is None:
                continue

            attempts += 1

            emit(EventType.ACCOUNT_SELECTED.value, status=Status.INFO.value,
                 interface=interface, task_id=request.task_id,
                 provider=_family(decision), account_ref=account_ref,
                 metadata={"attempt": attempts, "priority_position": index})

            emit(EventType.PROVIDER_REQUEST_STARTED.value,
                 status=Status.STARTED.value, interface=interface,
                 task_id=request.task_id, provider=_family(decision),
                 model=decision.model_id, account_ref=account_ref,
                 metadata={**request.safe_metadata(),
                           "provider_id": provider.provider_id})

            try:
                response = provider.generate(request, decision.model_id)
            except Exception as exc:
                logger.warning("Cloud provider raised account=%s error=%s",
                               account_ref, type(exc).__name__)
                response = ReasoningResponse(
                    request_id=request.request_id,
                    provider_id=provider.provider_id, account_ref=account_ref,
                    model_id=decision.model_id,
                    status=ResponseStatus.FAILED.value,
                    error_kind="INVALID_RESPONSE",
                    error=f"{type(exc).__name__}", cost_known=False,
                )

            self.ledger.record(response, task_id=request.task_id)

            if not response.ok:
                self.governor.observe(request, response,
                                       provider=_family(decision),
                                       account_ref=account_ref,
                                       model=decision.model_id)

            if response.ok:
                self.accounts.mark_success(account_ref)
                self.governor.record(request, response, is_cloud=True,
                                     interface=interface,
                                     provider=_family(decision),
                                     account_ref=account_ref,
                                     model=decision.model_id,
                                     purpose=request.purpose)

                emit(EventType.PROVIDER_REQUEST_COMPLETED.value,
                     status=Status.OK.value, interface=interface,
                     task_id=request.task_id, provider=_family(decision),
                     model=decision.model_id, account_ref=account_ref,
                     duration_ms=response.latency_ms,
                     metadata=response.safe_metadata())

                return GatewayResult(
                    response=response, decision=decision, attempts=attempts,
                    routing_ms=routing_ms,
                    gateway_ms=int((time.monotonic() - started) * 1000),
                    fallbacks_used=max(0, attempts - 1), budget=verdict,
                )

            self._emit_failure(response, decision, interface, request)

            should_failover = self.accounts.mark_failure(
                account_ref, response.error_kind or "SERVER_ERROR")

            self._emit_account_failure(response, account_ref, decision, interface)

            if not should_failover:
                # A malformed prompt will not become well-formed on another
                # account; retrying would burn a second quota for the same
                # error.
                break

            if index < len(accounts) - 1:
                emit(EventType.ACCOUNT_FALLBACK.value, status=Status.INFO.value,
                     interface=interface, task_id=request.task_id,
                     provider=_family(decision),
                     metadata={"from_account": account_ref,
                               "to_account": accounts[index + 1],
                               "reason": response.error_kind})

        # Nothing sent, so the reservation goes back.
        self.governor.release(request, is_cloud=True)

        return GatewayResult(
            response=response or ReasoningResponse(
                request_id=request.request_id, provider_id=decision.provider_id,
                status=ResponseStatus.UNAVAILABLE.value,
                error="Ninguna cuenta pudo responder.", cost_known=False),
            decision=decision, attempts=attempts, routing_ms=routing_ms,
            gateway_ms=int((time.monotonic() - started) * 1000),
            fallbacks_used=max(0, attempts - 1), budget=verdict,
        )

    @staticmethod
    def _emit_account_failure(response, account_ref, decision, interface) -> None:
        kind = response.error_kind or ""

        event = {
            "RATE_LIMIT": EventType.ACCOUNT_RATE_LIMITED,
            "QUOTA_EXHAUSTED": EventType.ACCOUNT_EXHAUSTED,
        }.get(kind)

        if event is None:
            return

        emit(event.value, status=Status.BLOCKED.value, interface=interface,
             provider=_family(decision), account_ref=account_ref,
             metadata={"kind": kind})

    @staticmethod
    def _emit_failure(response, decision, interface, request) -> None:
        """
        Report what actually happened.

        A rate-limit event is only emitted when a provider reported one. A
        local engine does not produce them, and inventing one would make the
        status view describe a problem that does not exist.
        """
        event = {
            ResponseStatus.RATE_LIMITED.value: EventType.PROVIDER_RATE_LIMITED,
            ResponseStatus.EXHAUSTED.value: EventType.PROVIDER_EXHAUSTED,
        }.get(response.status, EventType.PROVIDER_REQUEST_FAILED)

        emit(event.value, status=Status.FAILED.value, interface=interface,
             task_id=request.task_id, provider=_family(decision),
             model=response.model_id, account_ref=decision.account_ref,
             duration_ms=response.latency_ms,
             metadata={"status": response.status,
                       "error": (response.error or "")[:120]})


def build_gateway_for(client_factory, core=None) -> ReasoningGateway:
    """
    A gateway bound to one owner's Ollama client.

    Each agent gets its own registry so the provider resolves that agent's
    client on every call. Sharing one global provider would mean an agent
    reconfiguring its engine had no effect on the requests it makes.
    """
    from app.provider_ollama import OllamaProvider

    from app.provider_accounts import ProviderAccountPool
    from app.token_governor import TokenGovernor
    from app.memory_core import memory_core

    own_registry = ProviderRegistry()
    own_registry.register(OllamaProvider(client_factory=client_factory))

    pool = ProviderAccountPool(
        cooldown_seconds=settings_module.gemini_rate_limit_cooldown_seconds,
        exhaustion_cooldown_seconds=(
            settings_module.gemini_exhaustion_cooldown_seconds),
    )
    register_cloud_providers(own_registry, pool=pool)

    return ReasoningGateway(
        registry=own_registry,
        router=ProviderRouter(own_registry, accounts=pool),
        accounts=pool,
        governor=TokenGovernor(core=core or memory_core),
    )


def register_cloud_providers(target: ProviderRegistry, pool=None) -> list[str]:
    """
    Register configured cloud providers, if any are switched on.

    Nothing is registered unless it is explicitly enabled, so a default
    install has exactly one provider and no route to the network. Registering
    a provider does not make it the default either — reaching it still
    requires asking for it by name.
    """
    from app.config import settings

    registered: list[str] = []

    if not settings.gemini_enabled:
        return registered

    from app.provider_gemini import GeminiReasoningProvider

    for account in gemini_accounts():
        if target.get(account["account_ref"]) is not None:
            continue

        target.register(GeminiReasoningProvider(
            account_ref=account["account_ref"],
            credential_ref=account["credential_ref"],
            model=account.get("model") or "",
        ))
        registered.append(account["account_ref"])

        if pool is not None:
            from app.provider_accounts import ProviderAccount

            pool.add(ProviderAccount(
                provider_id="gemini",
                account_ref=account["account_ref"],
                credential_ref=account["credential_ref"],
                priority=account.get("priority", 100),
                model=account.get("model") or "",
            ))

    return registered


def gemini_accounts() -> list[dict]:
    """
    The configured Gemini accounts, from either form of configuration.

    GEMINI_ACCOUNTS declares several. The single-account settings from Phase
    4.1 still work and are treated as the first account, so an existing setup
    keeps working without being rewritten.
    """
    from app.config import settings
    from app.provider_accounts import parse_accounts

    declared = parse_accounts(settings.gemini_accounts_raw)

    if declared:
        return [{
            "account_ref": account.account_ref,
            "credential_ref": account.credential_ref,
            "model": settings.gemini_model,
            "priority": account.priority,
        } for account in declared]

    if not settings.gemini_account_ref:
        return []

    return [{
        "account_ref": settings.gemini_account_ref,
        "credential_ref": settings.gemini_credential_ref,
        "model": settings.gemini_model,
        "priority": 10,
    }]


def build_default_gateway() -> ReasoningGateway:
    """
    The gateway Iclirius uses: one local provider, registered explicitly.

    Registration is idempotent so importing this twice does not raise; the
    registry itself still refuses genuine duplicates.
    """
    from app.provider_ollama import OllamaProvider

    if default_registry.get("ollama-local") is None:
        default_registry.register(OllamaProvider())

    return ReasoningGateway(registry=default_registry, router=default_router)


# Agents build their own gateway so the registry is bound to that agent's
# Ollama client and Memory Core. Do not instantiate one at import time: it
# registers a second unused local provider for every CLI/Telegram process.
