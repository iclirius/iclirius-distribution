import subprocess

from app.config import settings


def worker_target() -> str:
    if not settings.worker_ssh_host or not settings.worker_ssh_user:
        raise RuntimeError("WORKER_SSH_HOST o WORKER_SSH_USER no está configurado en .env")

    return f"{settings.worker_ssh_user}@{settings.worker_ssh_host}"


def ssh_base_command() -> list[str]:
    command = [
        "ssh",
        "-o", "IdentitiesOnly=yes",
        "-o", "PreferredAuthentications=publickey,password",
        "-o", "ConnectTimeout=20",
    ]

    if getattr(settings, "worker_ssh_key", ""):
        command.extend(["-i", settings.worker_ssh_key])

    command.append(worker_target())
    return command


def run_worker_ssh(command: str, timeout: int = 180) -> tuple[bool, str]:
    ssh_command = ssh_base_command() + [command]

    try:
        result = subprocess.run(
            ssh_command,
            text=True,
            capture_output=True,
            timeout=timeout,
        )

        output = (result.stdout or "") + (result.stderr or "")
        return result.returncode == 0, output.strip()

    except subprocess.TimeoutExpired as exc:
        output = ""
        if exc.stdout:
            output += exc.stdout
        if exc.stderr:
            output += exc.stderr
        return False, f"SSH command timed out.\n{output}".strip()

    except Exception as exc:
        return False, f"SSH command failed: {exc}"


def worker_update_text() -> str:
    project_dir = settings.worker_project_dir

    command = f'''
cd "{project_dir}" || exit 1
git pull
source .venv/bin/activate
pip install -r requirements.txt
python -m py_compile app/config.py app/worker_client.py app/worker_control.py interfaces/cli.py interfaces/telegram_bot.py
echo "Worker update completed."
'''.strip()

    ok, output = run_worker_ssh(command, timeout=300)

    if ok:
        return "Worker update OK:\n" + output[-3500:]

    return "Worker update FAILED:\n" + output[-3500:]


def worker_logs_text(lines: int = 80) -> str:
    project_dir = settings.worker_project_dir
    lines = max(20, min(int(lines), 200))

    command = f'''
cd "{project_dir}" || exit 1
if [ -f logs/worker_server.log ]; then
  tail -n {lines} logs/worker_server.log
elif [ -f logs/openclaw.log ]; then
  tail -n {lines} logs/openclaw.log
else
  echo "No worker log found."
fi
'''.strip()

    ok, output = run_worker_ssh(command, timeout=60)

    if ok:
        return "Worker logs:\n" + output[-3500:]

    return "Worker logs FAILED:\n" + output[-3500:]


def worker_restart_text() -> str:
    project_dir = settings.worker_project_dir

    command = f'''
cd "{project_dir}" || exit 1
pkill -f "workers.worker_server" 2>/dev/null || true
pkill -f "worker_server.py" 2>/dev/null || true
sleep 2
source .venv/bin/activate
mkdir -p logs
nohup python -m workers.worker_server >> logs/worker_server.log 2>&1 &
echo "Worker server restarted."
sleep 2
lsof -i :18889 || true
'''.strip()

    ok, output = run_worker_ssh(command, timeout=120)

    if ok:
        return "Worker restart OK:\n" + output[-3500:]

    return "Worker restart FAILED:\n" + output[-3500:]


def worker_awake_text() -> str:
    command = r'''
mkdir -p ~/.iclirius
PID_FILE="$HOME/.iclirius/worker_awake.pid"
LOG_FILE="$HOME/.iclirius/worker_awake.log"

if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE")"

  if ps -p "$PID" >/dev/null 2>&1; then
    echo "Worker awake mode already active."
    echo "PID: $PID"
    exit 0
  fi
fi

nohup caffeinate -dimsu > "$LOG_FILE" 2>&1 &
PID="$!"
echo "$PID" > "$PID_FILE"

echo "Worker awake mode enabled."
echo "PID: $PID"
echo "Log: $LOG_FILE"
'''.strip()

    ok, output = run_worker_ssh(command, timeout=60)

    if ok:
        return "Worker awake OK:\n" + output[-3500:]

    return "Worker awake FAILED:\n" + output[-3500:]


def worker_sleep_text() -> str:
    command = r'''
PID_FILE="$HOME/.iclirius/worker_awake.pid"

if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE")"

  if ps -p "$PID" >/dev/null 2>&1; then
    kill "$PID" 2>/dev/null || true
    sleep 1
    kill -9 "$PID" 2>/dev/null || true
    echo "Stopped worker awake PID $PID"
  else
    echo "Worker awake PID was not running."
  fi

  rm -f "$PID_FILE"
else
  echo "No worker awake PID file found."
fi

pkill -f "caffeinate -dimsu" 2>/dev/null || true

echo "Worker awake mode disabled."
'''.strip()

    ok, output = run_worker_ssh(command, timeout=60)

    if ok:
        return "Worker sleep OK:\n" + output[-3500:]

    return "Worker sleep FAILED:\n" + output[-3500:]
