def is_status_or_books_progress_question(text: str) -> bool:
    t = (text or "").lower()

    triggers = [
        "cómo va",
        "como va",
        "cuántos libros van",
        "cuantos libros van",
        "libros van",
        "sigue procesando",
        "continua procesando",
        "continúa procesando",
        "estado de libros",
        "estado de librería",
        "estado de biblioteca",
        "procesamiento de libros",
        "cuántos ha procesado",
        "cuantos ha procesado",
        "cuántos lleva",
        "cuantos lleva",
    ]

    return any(x in t for x in triggers)


def answer_status_or_books_progress(text: str):
    if not is_status_or_books_progress_question(text):
        return None

    try:
        from app.library_status import library_status
        return library_status()
    except Exception as exc:
        return f"No pude leer el estado real de librería: {exc}"
