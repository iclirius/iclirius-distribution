"""Guided, explicit onboarding for the optional local Ollama runtime."""

from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass, field
from subprocess import Popen
from typing import Callable

from app.config import settings
from models.ollama_client import OllamaClient


@dataclass
class LocalAIResult:
    state: str
    ollama_installed: bool
    running: bool
    models: list[str] = field(default_factory=list)
    selected_model: str = ""
    changed_model: bool = False


def _yes(prompt: str, input_fn=input) -> bool:
    return input_fn(prompt).strip().lower() in {"y", "yes", "s", "si"}


def _probe(executable: str | None, client_factory: Callable[[], OllamaClient]) -> LocalAIResult:
    installed = bool(executable)
    if not installed:
        return LocalAIResult("not_installed", False, False)
    client = client_factory()
    running = bool(client.health())
    models = client.installed_models() if running else []
    return LocalAIResult("ready" if running else "not_running", True, running, models)


def _start_ollama(input_fn=input, runner=subprocess.run) -> bool:
    if shutil.which("open"):
        # `open -a Ollama` asks macOS to launch the installed app and does not
        # create a second HTTP server when one is already running.
        runner(["open", "-a", "Ollama"], capture_output=True, text=True, check=False)
        return True
    return False


def _install_ollama(input_fn=input, runner=subprocess.run) -> bool:
    brew = shutil.which("brew")
    if not brew:
        print("Install Ollama from https://ollama.com/download/mac, then rerun iclirius setup.")
        return False
    print("The following will be installed: Ollama (Homebrew cask).")
    if not _yes("Install Ollama with Homebrew now? [y/N] ", input_fn):
        return False
    result = runner([brew, "install", "--cask", "ollama"], check=False)
    return getattr(result, "returncode", 1) == 0


def _pull(executable: str, model: str, runner=Popen) -> bool:
    print(f"Downloading local model {model} with Ollama...")
    process = runner([executable, "pull", model], stdout=None, stderr=None, text=True)
    return process.wait() == 0


def configure(*, interactive: bool = True, input_fn=input,
              executable_finder: Callable[[str], str | None] = shutil.which,
              client_factory: Callable[[], OllamaClient] | None = None,
              runner=subprocess.run, popen=Popen,
              retries: int = 3) -> LocalAIResult:
    """Detect/configure local AI without changing setup or downloading silently."""
    client_factory = client_factory or (lambda: OllamaClient())
    executable = executable_finder("ollama")
    result = _probe(executable, client_factory)
    if result.state == "not_installed":
        print("Iclirius uses Ollama for local AI.")
        if not interactive:
            return result
        print("1. Install Ollama\n2. Continue without local AI\n3. Exit setup")
        choice = input_fn("> ").strip()
        if choice == "1" and _install_ollama(input_fn, runner):
            executable = executable_finder("ollama")
            result = _probe(executable, client_factory)
        elif choice == "3":
            return LocalAIResult("cancelled", False, False)
        else:
            return result
    if result.state == "not_running":
        print("Ollama is installed but is not currently running.")
        if not interactive:
            return result
        print("1. Start Ollama\n2. Retry\n3. Continue without local AI\n4. Exit setup")
        choice = input_fn("> ").strip()
        if choice == "1":
            _start_ollama(input_fn, runner)
        elif choice == "4":
            return LocalAIResult("cancelled", True, False)
        elif choice == "3":
            return result
        for _ in range(max(1, retries)):
            time.sleep(0.25)
            result = _probe(executable, client_factory)
            if result.running:
                break
        if not result.running:
            return result

    configured = [settings.default_model, settings.fast_model, settings.heavy_model]
    configured = list(dict.fromkeys(name for name in configured if name))
    print("LOCAL MODELS")
    for name in configured:
        print(("✓ " if name in result.models else "✗ ") + name)
    for name in result.models:
        if name not in configured:
            print("✓ " + name)
    default = settings.default_model
    if default in result.models:
        print(f"✓ {default} already installed")
        result.selected_model = default
        return result
    if not interactive:
        return result
    print(f"Default local model {default} is not installed.")
    print("1. Download the default model\n2. Choose another installed model\n3. Continue without local AI\n4. Exit setup")
    choice = input_fn("> ").strip()
    if choice == "1":
        if not _yes(f"Download {default} now? [y/N] ", input_fn):
            return result
        if not _pull(executable, default, popen):
            print("Ollama model download failed.")
            return result
        result = _probe(executable, client_factory)
        if default not in result.models:
            return result
        result.selected_model = default
        return result
    if choice == "2":
        alternatives = [name for name in result.models if name]
        if not alternatives:
            print("No installed model is available to select.")
            return result
        for index, name in enumerate(alternatives, 1):
            print(f"{index}. {name}")
        try:
            selected = alternatives[int(input_fn("> ").strip()) - 1]
        except (ValueError, IndexError):
            return result
        result.selected_model, result.changed_model = selected, selected != default
        return result
    if choice == "4":
        return LocalAIResult("cancelled", True, True, result.models)
    return result
