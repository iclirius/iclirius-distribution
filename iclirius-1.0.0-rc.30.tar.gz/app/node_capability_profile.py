"""Interpret Doctor evidence into operational node eligibility."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from dataclasses import asdict, dataclass
from app.node_health import ROLE_REQUIREMENTS, evaluate_health, normalize_role


SCHEMA_VERSION = 1


@dataclass(frozen=True)
class OperationalCapability:
    status: str
    evidence_level: str
    available: bool | None
    reasons: tuple[str, ...] = ()
    limitations: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return asdict(self) | {"reasons": list(self.reasons),
                               "limitations": list(self.limitations),
                               "dependencies": list(self.dependencies)}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _index(report: dict) -> dict[str, dict]:
    audit = report.get("capability_audit", {})
    return {item.get("id", ""): item for item in audit.get("capabilities", [])}


def _probe_index(report: dict) -> dict[str, dict]:
    return {item.get("id", ""): item for item in report.get("deep_diagnostics", {}).get("probes", [])}


def _cap(report: dict, name: str, dependencies: tuple[str, ...], probes: tuple[str, ...] = ()) -> OperationalCapability:
    items = _index(report)
    item = items.get(name, {})
    status = str(item.get("status", "UNTESTED"))
    available = item.get("available")
    reasons = [str(item.get("summary", name))]
    limitations = [str(item["limitation"])] if item.get("limitation") else []
    evidence = "OBSERVED"
    probe_map = _probe_index(report)
    relevant = [probe_map[p] for p in probes if p in probe_map]
    if relevant and all(p.get("success") is True and p.get("status") in {"READY", "AVAILABLE"} for p in relevant):
        evidence = "VERIFIED"
        status = "READY" if status not in {"BLOCKED", "MISSING", "UNAVAILABLE"} else status
        available = True
        reasons.extend(str(p.get("summary", p["id"])) for p in relevant)
    elif relevant and any(p.get("success") is True for p in relevant):
        evidence = "PARTIAL"
    elif report.get("deep_diagnostics"):
        evidence = "PARTIAL"
    return OperationalCapability(status, evidence, available, tuple(reasons), tuple(limitations), dependencies)


def _role(eligible: bool, evidence: str, limitation: str = "") -> dict:
    return {"eligible": eligible, "evidence_level": evidence,
            "limitation": limitation}


def build_node_capability_profile(report: dict) -> dict:
    """Build a safe profile from normal Doctor evidence and optional deep probes."""
    setup = report.get("setup", {})
    auth = report.get("authentication", {})
    core_ready = bool(setup.get("setup_complete"))
    identity_ready = bool(setup.get("identity", {}).get("configured"))
    node_id = str(setup.get("node", {}).get("node_id") or report.get("node_id") or "unknown-node")
    caps = {
        "interface": _cap(report, "iclirius.setup", ("setup", "identity", "auth"), ("process.python",)),
        "local_reasoning": _cap(report, "ai.default_model", ("ai.ollama", "ai.default_model"), ("ollama.api_model", "ollama.inference")),
        "file_access": _cap(report, "tools.filesystem", ("tools.filesystem",), ("filesystem.temp_rw",)),
        "code_execution": _cap(report, "tools.python", ("tools.python", "tools.filesystem"), ("process.python", "filesystem.temp_rw")),
        "memory_access": _cap(report, "memory.encryption", ("memory.home", "memory.encryption"), ("memory.decrypt", "memory.lock")),
        "network_outbound": _cap(report, "network.outbound", ("network.dns", "network.https"), ("network.dns", "network.https")),
        "remote_connectivity": _cap(report, "network.tailscale", ("network.tailscale",), ("network.tailscale",)),
        "voice": _cap(report, "voice.ffmpeg", ("voice.ffmpeg",), ("voice.ffmpeg",)),
        "version_control": _cap(report, "tools.git", ("tools.git",), ("tool.git",)),
    }
    # Local Tailscale status and ffmpeg do not prove Iclirius peer transport or
    # end-to-end voice inference. Keep both capabilities explicitly partial.
    remote_cap = caps["remote_connectivity"]
    if remote_cap.available is True:
        caps["remote_connectivity"] = OperationalCapability(
            "AVAILABLE", "PARTIAL", True, remote_cap.reasons,
            ("Iclirius node-to-node transport has not been validated",),
            remote_cap.dependencies)
    voice_cap = caps["voice"]
    if voice_cap.available is True:
        caps["voice"] = OperationalCapability(
            "AVAILABLE", "PARTIAL", True, voice_cap.reasons,
            ("active TTS/STT inference remains untested",), voice_cap.dependencies)
    # Interface needs setup, identity and local authentication, but never
    # Telegram, voice, Git, Ollama or a source checkout.
    interface_ok = core_ready and identity_ready and bool(auth.get("enrolled"))
    if interface_ok and caps["interface"].evidence_level == "OBSERVED":
        caps["interface"] = OperationalCapability("READY", "OBSERVED", True,
                                                   ("setup, identity and local authentication configured",), (), caps["interface"].dependencies)
    elif not interface_ok:
        caps["interface"] = OperationalCapability("BLOCKED", "OBSERVED", False,
                                                   ("setup, identity or local authentication incomplete",), (), caps["interface"].dependencies)
    deep = bool(report.get("deep_diagnostics"))
    if interface_ok and deep and caps["interface"].evidence_level != "VERIFIED":
        caps["interface"] = OperationalCapability("READY", "PARTIAL", True,
                                                   caps["interface"].reasons, ("interactive session not exercised by Doctor",), caps["interface"].dependencies)
    limitations: list[dict] = []
    blockers: list[dict] = []
    for name, cap in caps.items():
        if cap.limitations:
            limitations.append({"code": f"{name}.limited", "severity": "info",
                                "capability": name, "summary": cap.limitations[0]})
        if cap.status in {"BLOCKED", "MISSING", "UNAVAILABLE", "POLICY_BLOCKED"}:
            blockers.append({"code": f"{name}.blocked", "capability": name,
                             "summary": cap.reasons[0] if cap.reasons else "required evidence unavailable"})
    local = caps["local_reasoning"].available is True and caps["local_reasoning"].status == "READY"
    files = caps["file_access"].available is True and caps["file_access"].status in {"READY", "AVAILABLE"}
    code = caps["code_execution"].available is True and caps["code_execution"].status in {"READY", "AVAILABLE"}
    memory = caps["memory_access"].available is True and caps["memory_access"].status == "READY"
    network = caps["network_outbound"].available is True and caps["network_outbound"].status == "READY"
    interface = interface_ok
    remote = caps["remote_connectivity"].available is True
    roles = {
        "INTERFACE": _role(interface, "VERIFIED" if deep and interface else "OBSERVED"),
        "LOCAL_COMPUTE": _role(local, caps["local_reasoning"].evidence_level,
                                "Ollama/default model/inference evidence is incomplete" if not local else ""),
        "CODE_WORKER": _role(files and code, "VERIFIED" if files and code and deep else "PARTIAL",
                              "filesystem and Python execution are both required" if not files or not code else ""),
        "REMOTE_WORKER": _role(files and code and remote, "PARTIAL" if files and code and remote else "OBSERVED",
                                "Iclirius node-to-node transport has not been validated" if files and code and remote else "worker and remote-connectivity evidence required"),
        "FULL_NODE": _role(interface and local and files and code and memory and network,
                            "VERIFIED" if interface and local and files and code and memory and network and deep else "PARTIAL",
                            "one or more core operational capabilities is unavailable" if not (interface and local and files and code and memory and network) else ""),
    }
    eligible = [name for name, value in roles.items() if value["eligible"]]
    configured_role = normalize_role(report.get("node_role") or report.get("role") or "interface")
    current_eligible = roles[configured_role]["eligible"]
    overall = "READY" if current_eligible else ("DEGRADED" if eligible else "BLOCKED")
    evidence_levels = [cap.evidence_level for cap in caps.values()]
    evidence = "VERIFIED" if evidence_levels and all(v == "VERIFIED" for v in evidence_levels) else ("PARTIAL" if "VERIFIED" in evidence_levels else "OBSERVED")
    health = evaluate_health({"capabilities": {name: value.to_dict() for name, value in caps.items()}}, configured_role)
    required_capabilities = [name for name, cap in caps.items()
                             if name in ROLE_REQUIREMENTS[configured_role]["required"]]
    optional_capabilities = [name for name, cap in caps.items()
                             if cap.status == "OPTIONAL" or name not in ROLE_REQUIREMENTS[configured_role]["required"]]
    untested_capabilities = [name for name, cap in caps.items() if cap.status == "UNTESTED"]
    return {"schema_version": SCHEMA_VERSION, "node_id": node_id, "generated_at": _now(),
            "evidence_level": evidence, "overall_readiness": overall,
            "current_role": normalize_role(configured_role), "health": health,
            "capabilities": {name: cap.to_dict() for name, cap in caps.items()},
            "required_capabilities": required_capabilities,
            "optional_capabilities": optional_capabilities,
            "untested_capabilities": untested_capabilities,
            "eligible_roles": eligible, "roles": roles, "limitations": limitations,
            "blockers": blockers}


def from_snapshot(snapshot: dict) -> dict:
    """Provide an observed profile for callers that only have NodeSnapshot data."""
    caps = snapshot.get("capabilities", {})
    audit = {"node_role": snapshot.get("node", {}).get("role", "interface"),
             "capability_audit": {"capabilities": []}, "setup": {"setup_complete": True,
              "identity": {"configured": True}, "node": {"node_id": snapshot.get("node", {}).get("node_id")}},
             "authentication": {"enrolled": True}}
    mapping = {"filesystem_read": "tools.filesystem", "python": "tools.python",
               "git": "tools.git", "reasoning_local": "ai.default_model"}
    for source, target in mapping.items():
        audit["capability_audit"]["capabilities"].append({"id": target, "status": "AVAILABLE" if caps.get(source) else "OPTIONAL",
                                                            "available": bool(caps.get(source)), "summary": source})
    audit["capability_audit"]["capabilities"].extend([
        {"id": "memory.encryption", "status": "READY" if snapshot.get("memory", {}).get("encryption_ready") else "BLOCKED",
         "available": bool(snapshot.get("memory", {}).get("encryption_ready")), "summary": "memory"},
        {"id": "network.outbound", "status": "READY", "available": True, "summary": "network"},
    ])
    return build_node_capability_profile(audit)


def render(profile: dict) -> str:
    lines = ["ICLIRIUS NODE CAPABILITIES", "", f"Node  {profile.get('node_id', 'unknown-node')}", "",
             "OPERATIONAL CAPABILITIES"]
    for name, value in profile.get("capabilities", {}).items():
        lines.append(f"  {name.replace('_', ' ').title():22} {value['status']:12} {value['evidence_level']}")
    lines += ["", "ELIGIBLE ROLES"]
    for role in ("INTERFACE", "LOCAL_COMPUTE", "CODE_WORKER", "REMOTE_WORKER", "FULL_NODE"):
        item = profile.get("roles", {}).get(role, {})
        marker = "✓" if item.get("eligible") else "○"
        suffix = f" ({item.get('evidence_level', 'OBSERVED').lower()})" if item.get("eligible") else ""
        lines.append(f"  {marker} {role}{suffix}")
    if profile.get("limitations"):
        lines += ["", "LIMITATIONS"]
        lines.extend(f"  - {item['summary']}" for item in profile["limitations"])
    if profile.get("blockers"):
        lines += ["", "BLOCKERS"]
        lines.extend(f"  - {item['capability']}: {item['summary']}" for item in profile["blockers"])
    return "\n".join(lines)
