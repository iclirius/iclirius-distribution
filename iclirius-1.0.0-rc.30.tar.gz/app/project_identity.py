"""
Project identity from local signals.

A project is identified in this order:

  1. the git repository root, fingerprinted by its remote URL when there is
     one, otherwise by the resolved root path;
  2. an explicit project id supplied by the caller;
  3. the current working directory, when it looks like a project;
  4. nothing.

The folder name alone is never the identity: two checkouts of different
repositories can both be called "app". The name is kept only as a display
label, while the stable id comes from a hash of the remote or the resolved
path, so the same repository resolves to the same project from the CLI, from
Telegram and after a rename.
"""

from __future__ import annotations

import hashlib
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ProjectSignal:
    project_id: str
    display_name: str
    root: str
    source: str
    git_remote_fingerprint: str | None = None


def _fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def find_git_root(start: str | Path) -> Path | None:
    """Nearest ancestor containing .git, without invoking git."""
    try:
        current = Path(start).expanduser().resolve()
    except (OSError, RuntimeError):
        return None

    if current.is_file():
        current = current.parent

    for candidate in [current, *current.parents]:
        if (candidate / ".git").exists():
            return candidate

    return None


def git_remote_url(repo_root: Path, timeout: int = 5) -> str | None:
    """origin URL, or None. Read-only plumbing."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo_root), "config", "--get", "remote.origin.url"],
            capture_output=True, text=True, timeout=timeout,
        )
    except (OSError, subprocess.SubprocessError):
        return None

    url = (result.stdout or "").strip()
    return url or None


def normalise_remote(url: str) -> str:
    """
    Reduce a remote URL to a stable form.

    git@github.com:me/repo.git and https://github.com/me/repo both become
    github.com/me/repo, so the same project is recognised regardless of how it
    was cloned.
    """
    value = url.strip().removesuffix(".git")

    for prefix in ("https://", "http://", "ssh://", "git://"):
        value = value.removeprefix(prefix)

    if value.startswith("git@"):
        value = value[4:]

    value = value.replace(":", "/", 1) if "@" not in value else value
    value = value.split("@")[-1]

    return value.strip("/").lower()


def detect(start: str | Path | None = None, explicit_id: str | None = None) -> ProjectSignal | None:
    """
    Resolve the project for a location.

    Returns None when there is no signal strong enough, which is the correct
    answer for a chat that has nothing to do with a project.
    """
    if explicit_id:
        return ProjectSignal(
            project_id=explicit_id,
            display_name=explicit_id,
            root="",
            source="explicit",
        )

    if start is None:
        return None

    try:
        location = Path(start).expanduser().resolve()
    except (OSError, RuntimeError):
        return None

    if not location.exists():
        return None

    repo_root = find_git_root(location)

    if repo_root is not None:
        remote = git_remote_url(repo_root)

        if remote:
            normalised = normalise_remote(remote)
            return ProjectSignal(
                project_id=f"proj_{_fingerprint(normalised)}",
                display_name=repo_root.name,
                root=str(repo_root),
                source="git_remote",
                git_remote_fingerprint=_fingerprint(normalised),
            )

        return ProjectSignal(
            project_id=f"proj_{_fingerprint(str(repo_root))}",
            display_name=repo_root.name,
            root=str(repo_root),
            source="git_root",
        )

    # No repository: only treat a directory as a project when it carries a
    # recognisable marker, so an arbitrary cwd does not become one.
    markers = (
        "package.json", "pyproject.toml", "requirements.txt", "build.gradle",
        "build.gradle.kts", "pom.xml", "Cargo.toml", "go.mod",
    )

    directory = location if location.is_dir() else location.parent

    if any((directory / marker).exists() for marker in markers):
        return ProjectSignal(
            project_id=f"proj_{_fingerprint(str(directory))}",
            display_name=directory.name,
            root=str(directory),
            source="cwd_marker",
        )

    return None


def resolve_by_name(name: str, known: dict) -> str | None:
    """
    Find a known project id by display name, case-insensitively.

    Used when the user says "how is STM-COVE going" from Telegram, where there
    is no working directory to infer anything from.
    """
    if not name:
        return None

    wanted = name.strip().lower()

    for project_id, record in known.items():
        display = str(record.get("display_name", "")).lower()
        if display and (display == wanted or wanted in display or display in wanted):
            return project_id

    return None
