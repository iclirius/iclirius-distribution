"""Portable, password-wrapped enrollment for an existing Memory Home.

The envelope contains no plaintext memory key.  It is an authenticated AES-GCM
record whose wrapping key is derived from the owner's recovery passphrase.  The
passphrase verifier in ``auth.json`` remains machine-local and is never used as
the memory key.
"""

from __future__ import annotations

import base64
import binascii
import json
import os
import secrets
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
from cryptography.fernet import Fernet, InvalidToken

from app.memory_home import MemoryHome, MemoryHomeError, load
from app.secure_storage import SecureStorageError, load_keychain_key, store_keychain_key


ENVELOPE_VERSION = 1
ENVELOPE_NAME = "enrollment.json"
KDF_NAME = "scrypt"
KDF_N, KDF_R, KDF_P = 2**14, 8, 1


class EnrollmentError(ValueError):
    """A safe, user-facing enrollment failure."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def envelope_path(home: MemoryHome) -> Path:
    return home.metadata_path / ENVELOPE_NAME


def _b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii")


def _unb64(value: object, label: str) -> bytes:
    if not isinstance(value, str) or not value:
        raise EnrollmentError(f"Enrollment {label} is invalid.")
    try:
        return base64.urlsafe_b64decode(value.encode("ascii"))
    except (ValueError, TypeError, binascii.Error) as exc:
        raise EnrollmentError(f"Enrollment {label} is invalid.") from exc


def _derive(passphrase: str, salt: bytes, *, n: int = KDF_N,
            r: int = KDF_R, p: int = KDF_P) -> bytes:
    import hashlib
    if not isinstance(passphrase, str) or not passphrase:
        raise EnrollmentError("A recovery passphrase is required.")
    if n < 2**14 or n > 2**20 or r < 1 or r > 32 or p < 1 or p > 8:
        raise EnrollmentError("Enrollment KDF parameters are unsupported.")
    return hashlib.scrypt(passphrase.encode("utf-8"), salt=salt, n=n, r=r,
                          p=p, dklen=32, maxmem=0)


def _aad(home: MemoryHome, created_at: str, kdf: dict) -> bytes:
    data = {"version": ENVELOPE_VERSION, "memory_home_id": home.memory_home_id,
            "user_id": home.user_id, "created_at": created_at, "kdf": kdf,
            "cipher": "aes-256-gcm"}
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _atomic_write(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    handle, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    temp = Path(name)
    try:
        os.fchmod(handle, 0o600)
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _validate_key(raw: str | bytes) -> bytes:
    key = raw.encode("ascii") if isinstance(raw, str) else bytes(raw)
    try:
        Fernet(key)
    except (ValueError, TypeError) as exc:
        raise EnrollmentError("Memory encryption material is invalid.") from exc
    return key


def verify_memory_key(home: MemoryHome, key: bytes) -> bool:
    """Verify the key against the encrypted core without changing it."""
    key = _validate_key(key)
    state = home.core_path / "state.json.enc"
    if not state.exists():
        return True
    try:
        Fernet(key).decrypt(state.read_bytes())
        return True
    except (OSError, InvalidToken, ValueError):
        return False


def prepare(home: MemoryHome, passphrase: str, *, key: str | bytes | None = None) -> dict:
    """Create/replace the enrollment envelope using the existing Fernet key."""
    if not home.root.exists() or not home.metadata_path.is_dir():
        raise EnrollmentError("Memory Home is not ready for enrollment.")
    existing = envelope_path(home)
    if existing.exists():
        # Idempotent reruns verify the existing record and never rotate it
        # implicitly. A corrupt record must be repaired explicitly later.
        recover(home, passphrase)
        return {"prepared": True, "version": ENVELOPE_VERSION,
                "memory_home_id": home.memory_home_id, "user_id": home.user_id,
                "path": str(existing), "reused": True}
    try:
        raw_key = key if key is not None else load_keychain_key()
    except SecureStorageError as exc:
        raise EnrollmentError("Memory encryption material is unavailable on this Mac.") from exc
    memory_key = _validate_key(raw_key)
    if not verify_memory_key(home, memory_key):
        raise EnrollmentError("Existing Memory Core could not be decrypted.")
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    kdf = {"name": KDF_NAME, "n": KDF_N, "r": KDF_R, "p": KDF_P,
           "salt": _b64(salt)}
    created_at = _now()
    wrapping_key = _derive(passphrase, salt)
    ciphertext = AESGCM(wrapping_key).encrypt(nonce, memory_key,
                                               _aad(home, created_at, kdf))
    envelope = {
        "format": "iclirius-memory-enrollment",
        "version": ENVELOPE_VERSION,
        "memory_home_id": home.memory_home_id,
        "user_id": home.user_id,
        "created_at": created_at,
        "kdf": kdf,
        "cipher": "aes-256-gcm",
        "nonce": _b64(nonce),
        "ciphertext": _b64(ciphertext),
    }
    _atomic_write(envelope_path(home), envelope)
    recovered = recover(home, passphrase)
    if recovered != memory_key:
        raise EnrollmentError("Enrollment verification failed.")
    return {"prepared": True, "version": ENVELOPE_VERSION,
            "memory_home_id": home.memory_home_id, "user_id": home.user_id,
            "path": str(envelope_path(home))}


def recover(home: MemoryHome, passphrase: str) -> bytes:
    """Recover the memory key and prove it decrypts the existing core."""
    path = envelope_path(home)
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise EnrollmentError("This Memory Home has no valid enrollment envelope.") from exc
    if not isinstance(envelope, dict) or envelope.get("format") != "iclirius-memory-enrollment":
        raise EnrollmentError("This Memory Home has no valid enrollment envelope.")
    if envelope.get("version") != ENVELOPE_VERSION or envelope.get("cipher") != "aes-256-gcm":
        raise EnrollmentError("This enrollment envelope version is unsupported.")
    if envelope.get("memory_home_id") != home.memory_home_id or envelope.get("user_id") != home.user_id:
        raise EnrollmentError("Enrollment identity does not match this Memory Home.")
    kdf = envelope.get("kdf")
    if not isinstance(kdf, dict) or kdf.get("name") != KDF_NAME:
        raise EnrollmentError("Enrollment KDF is unsupported.")
    salt = _unb64(kdf.get("salt"), "salt")
    nonce = _unb64(envelope.get("nonce"), "nonce")
    ciphertext = _unb64(envelope.get("ciphertext"), "ciphertext")
    if len(salt) != 16 or len(nonce) != 12 or len(ciphertext) < 16:
        raise EnrollmentError("Enrollment envelope is corrupt.")
    try:
        wrapping_key = _derive(passphrase, salt, n=int(kdf["n"]),
                               r=int(kdf["r"]), p=int(kdf["p"]))
        key = AESGCM(wrapping_key).decrypt(nonce, ciphertext,
                                           _aad(home, str(envelope["created_at"]), kdf))
        key = _validate_key(key)
    except (KeyError, TypeError, ValueError, InvalidToken, InvalidTag) as exc:
        raise EnrollmentError("Unable to unlock this Memory Home.") from exc
    if not verify_memory_key(home, key):
        raise EnrollmentError("Unable to decrypt this Memory Home.")
    return key


def status(home_path: str | Path) -> dict:
    try:
        home = load(home_path)
    except Exception as exc:
        return {"state": "unavailable", "error": str(exc)}
    path = envelope_path(home)
    if not path.is_file():
        return {"state": "not_prepared", "memory_home_id": home.memory_home_id,
                "user_id": home.user_id}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        valid = (isinstance(data, dict) and data.get("version") == ENVELOPE_VERSION
                 and data.get("memory_home_id") == home.memory_home_id
                 and data.get("user_id") == home.user_id)
    except (OSError, ValueError):
        valid = False
    return {"state": "prepared" if valid else "corrupt",
            "memory_home_id": home.memory_home_id, "user_id": home.user_id}


def provision_keychain(key: bytes) -> bool:
    _validate_key(key)
    return store_keychain_key(key)
