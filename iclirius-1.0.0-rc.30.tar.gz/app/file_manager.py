from __future__ import annotations

import json
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from app.config import settings

from app.config import settings
from app.file_catalog import validate_safe_path as _validate_safe_path


REPORT_DIR = Path(settings.state_path) / "file_manager" / "reports"
QUARANTINE_DIR = Path(settings.state_path) / "file_manager" / "quarantine"


# Path validation lives in app.file_catalog so there is exactly one policy.
# This module used to carry a near-identical copy that drifted.
def validate_safe_path(path: str | Path) -> Path:
    return _validate_safe_path(path)


def _new_scan_id() -> str:
    return "scan_" + datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]


def _report_path(scan_id: str) -> Path:
    return REPORT_DIR / f"{scan_id}.json"


def _write_report(report: dict) -> None:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    _report_path(report["scan_id"]).write_text(json.dumps(report, ensure_ascii=False, indent=2))


def _read_report(scan_id: str) -> dict:
    path = _report_path(scan_id)

    if not path.exists():
        raise FileNotFoundError(f"No encontré reporte: {scan_id}")

    return json.loads(path.read_text())


def scan_empty_files(root_path: str, max_files: int = 5000) -> dict:
    root = validate_safe_path(root_path)

    if not root.exists():
        raise FileNotFoundError(f"No existe la ruta: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"No es carpeta: {root}")

    scan_id = _new_scan_id()
    empty_files = []
    empty_dirs = []
    scanned_files = 0
    skipped = []

    for item in root.rglob("*"):
        try:
            validate_safe_path(item)
        except Exception as exc:
            skipped.append({"path": str(item), "reason": str(exc)})
            continue

        try:
            if item.is_file():
                scanned_files += 1

                if scanned_files > max_files:
                    skipped.append({"path": str(item), "reason": "max_files limit reached"})
                    break

                if item.stat().st_size == 0:
                    empty_files.append({
                        "path": str(item),
                        "size": 0,
                        "modified_at": datetime.fromtimestamp(item.stat().st_mtime).isoformat(timespec="seconds"),
                    })

            elif item.is_dir():
                try:
                    if not any(item.iterdir()):
                        empty_dirs.append({
                            "path": str(item),
                            "modified_at": datetime.fromtimestamp(item.stat().st_mtime).isoformat(timespec="seconds"),
                        })
                except Exception as exc:
                    skipped.append({"path": str(item), "reason": str(exc)})

        except Exception as exc:
            skipped.append({"path": str(item), "reason": str(exc)})

    report = {
        "scan_id": scan_id,
        "type": "empty_files",
        "root": str(root),
        "created_at": _now(),
        "scanned_files": scanned_files,
        "empty_files": empty_files,
        "empty_dirs": empty_dirs,
        "skipped": skipped[:200],
        "status": "scanned",
    }

    _write_report(report)
    return report


def format_empty_report(report: dict) -> str:
    lines = [
        f"Reporte: {report['scan_id']}",
        f"Ruta: {report['root']}",
        f"Archivos revisados: {report.get('scanned_files', 0)}",
        f"Archivos vacíos: {len(report.get('empty_files', []))}",
        f"Carpetas vacías: {len(report.get('empty_dirs', []))}",
        "",
    ]

    empty_files = report.get("empty_files", [])
    empty_dirs = report.get("empty_dirs", [])

    if empty_files:
        lines.append("Archivos vacíos:")
        for item in empty_files[:20]:
            lines.append(f"- {item['path']}")

        if len(empty_files) > 20:
            lines.append(f"... y {len(empty_files) - 20} más")

    if empty_dirs:
        lines.append("")
        lines.append("Carpetas vacías:")
        for item in empty_dirs[:20]:
            lines.append(f"- {item['path']}")

        if len(empty_dirs) > 20:
            lines.append(f"... y {len(empty_dirs) - 20} más")

    lines.append("")
    lines.append(f"No borré nada. Para mover archivos vacíos a cuarentena usa: /file_quarantine {report['scan_id']}")

    return "\\n".join(lines)[:3900]


def list_reports(limit: int = 20) -> str:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    reports = sorted(REPORT_DIR.glob("scan_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    if not reports:
        return "No hay reportes."

    lines = ["Reportes recientes:"]

    for path in reports[:limit]:
        try:
            report = json.loads(path.read_text())
            lines.append(
                f"- {report.get('scan_id')} | {report.get('type')} | "
                f"empty_files={len(report.get('empty_files', []))} | root={report.get('root')}"
            )
        except Exception:
            lines.append(f"- {path.name}")

    return "\\n".join(lines)[:3900]


def quarantine_empty_files(scan_id: str) -> str:
    report = _read_report(scan_id)

    if report.get("status") == "quarantined":
        return f"El reporte {scan_id} ya fue movido a cuarentena."

    items = report.get("empty_files", [])

    if not items:
        return f"El reporte {scan_id} no tiene archivos vacíos para cuarentena."

    quarantine_root = QUARANTINE_DIR / scan_id
    quarantine_root.mkdir(parents=True, exist_ok=True)

    moved = []
    failed = []

    for item in items:
        src = Path(item["path"])

        try:
            src = validate_safe_path(src)

            if not src.exists():
                failed.append({"path": str(src), "reason": "already missing"})
                continue

            if not src.is_file():
                failed.append({"path": str(src), "reason": "not a file"})
                continue

            safe_name = str(src).replace("/", "__").replace(" ", "_")
            dst = quarantine_root / safe_name

            shutil.move(str(src), str(dst))

            moved.append({
                "from": str(src),
                "to": str(dst),
            })

        except Exception as exc:
            failed.append({"path": item.get("path"), "reason": str(exc)})

    report["status"] = "quarantined"
    report["quarantined_at"] = _now()
    report["moved"] = moved
    report["failed_quarantine"] = failed

    _write_report(report)

    return (
        f"Cuarentena completada para {scan_id}\\n"
        f"Movidos: {len(moved)}\\n"
        f"Fallidos: {len(failed)}\\n"
        f"Ruta cuarentena: {quarantine_root}\\n\\n"
        f"No borré nada permanentemente."
    )[:3900]


def file_empty_text(root_path: str) -> str:
    report = scan_empty_files(root_path)
    return format_empty_report(report)


def file_quarantine_text(scan_id: str) -> str:
    return quarantine_empty_files(scan_id)


def file_reports_text() -> str:
    return list_reports()
