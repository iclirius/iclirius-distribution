from __future__ import annotations
import argparse
import json
from app.installation_knowledge import current_guide, render


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius installation")
    parser.add_argument("command", nargs="?", choices=("guide",), default="guide")
    parser.add_argument("--profile", default="INTERFACE")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv or [])
    print(json.dumps(current_guide().to_dict(), ensure_ascii=False, indent=2, sort_keys=True)
          if args.json else render(args.profile))
    return 0
