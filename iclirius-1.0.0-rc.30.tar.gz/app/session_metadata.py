"""Stable metadata shared by interfaces without making them memory owners."""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass

from app.config import settings


@dataclass(frozen=True)
class SessionMetadata:
    user_id: str
    node_id: str
    interface: str
    session_id: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def new_session(interface: str, session_id: str = "") -> SessionMetadata:
    try:
        from app.node_identity import read_node
        node_id = str((read_node() or {}).get("node_id") or settings.node_id or "unknown-node")
    except Exception:
        node_id = str(settings.node_id or "unknown-node")
    return SessionMetadata(
        user_id=str(settings.user_id or ""),
        node_id=node_id,
        interface=str(interface or "unknown"),
        session_id=session_id or f"session_{uuid.uuid4().hex}",
    )
