"""Bounded, reversible probes used by ``iclirius doctor --deep``."""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path

from app.capability_audit import CapabilityStatus


@dataclass(frozen=True)
class DiagnosticProbeResult:
    id: str
    capability_id: str
    status: str
    success: bool | None
    tested: bool
    duration_ms: int
    summary: str
    evidence: str = ""
    error_category: str = ""
    limitation: str = ""
    cleanup_status: str = "not_applicable"

    def to_dict(self) -> dict:
        return asdict(self)


def _probe(probe_id: str, capability_id: str, fn, *, timeout: float = 5.0) -> DiagnosticProbeResult:
    started = time.monotonic()
    error_category = ""
    try:
        status, success, summary, evidence, limitation, cleanup = fn(timeout)
    except TimeoutError:
        error_category = "timeout"
        status, success, summary, evidence, limitation, cleanup = (
            CapabilityStatus.UNTESTED.value, None, "Probe timed out", "", "timeout", "unknown")
    except PermissionError:
        error_category = "permission"
        status, success, summary, evidence, limitation, cleanup = (
            CapabilityStatus.UNTESTED.value, None, "Probe permission unavailable", "", "permission", "unknown")
    except Exception as exc:
        error_category = type(exc).__name__
        status, success, summary, evidence, limitation, cleanup = (
            CapabilityStatus.BLOCKED.value, False, "Probe failed", "", type(exc).__name__, "unknown")
    return DiagnosticProbeResult(
        probe_id, capability_id, status, success, success is not None,
        int((time.monotonic() - started) * 1000), summary, evidence,
        error_category, limitation, cleanup,
    )


def _filesystem(timeout: float):
    del timeout
    with tempfile.TemporaryDirectory(prefix="iclirius-doctor-") as directory:
        root = Path(directory)
        source, replacement = root / "probe.txt", root / "replacement.txt"
        content = "iclirius-doctor-probe"
        source.write_text(content, encoding="utf-8")
        with source.open("r+", encoding="utf-8") as handle:
            handle.flush()
            os.fsync(handle.fileno())
        if source.read_text(encoding="utf-8") != content:
            return CapabilityStatus.BLOCKED.value, False, "Filesystem read/write mismatch", "", "content mismatch", "verified"
        source.replace(replacement)
        replacement.unlink()
        cleaned = not any(root.iterdir())
    return (CapabilityStatus.READY.value if cleaned else CapabilityStatus.DEGRADED.value,
            cleaned, "Temporary read/write/cleanup succeeded", "tempfile", "" if cleaned else "residue", "verified")


def _python(timeout: float):
    executable = os.sys.executable
    result = subprocess.run([executable, "-c", "print('iclirius-doctor-ok')"],
                            capture_output=True, text=True, timeout=timeout, check=False)
    ok = result.returncode == 0 and result.stdout.strip() == "iclirius-doctor-ok"
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.BLOCKED.value,
            ok, "Python subprocess probe", executable, "unexpected output" if not ok else "", "not_applicable")


def _git(timeout: float):
    binary = shutil.which("git")
    if not binary:
        return CapabilityStatus.OPTIONAL.value, None, "Git executable unavailable", "", "optional", "not_applicable"
    result = subprocess.run([binary, "--version"], capture_output=True, text=True,
                            timeout=timeout, check=False)
    ok = result.returncode == 0
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.BLOCKED.value,
            ok, "Git read-only probe", (result.stdout or "").strip(), "", "not_applicable")


def _memory_health(timeout: float):
    del timeout
    from app.memory_core import MemoryCore
    ok = MemoryCore().health()
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.BLOCKED.value,
            ok, "Memory Core decrypt/integrity check", "canonical API", "", "not_applicable")


def _memory_lock(timeout: float):
    from app.memory_core import _write_lock
    with tempfile.TemporaryDirectory(prefix="iclirius-doctor-lock-") as directory:
        lock = Path(directory) / "probe.lock"
        with _write_lock(lock, min(timeout, 2.0)):
            pass
        lock.unlink(missing_ok=True)
        cleaned = not lock.exists()
    return (CapabilityStatus.READY.value if cleaned else CapabilityStatus.DEGRADED.value,
            cleaned, "Temporary lock acquire/release succeeded", "dedicated lock", "", "verified")


def _ollama(timeout: float, model: str, base_url: str):
    request = urllib.request.Request(f"{base_url.rstrip('/')}/api/tags", method="GET")
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read(512 * 1024).decode("utf-8"))
    names = {item.get("name") for item in payload.get("models", []) if isinstance(item, dict)}
    if model not in names:
        return CapabilityStatus.BLOCKED.value, False, "Ollama API reachable; default model missing", "model missing", "pull deferred", "not_applicable"
    return CapabilityStatus.READY.value, True, "Ollama API and model listing succeeded", model, "", "not_applicable"


def _inference(timeout: float, model: str, base_url: str):
    from models.ollama_client import OllamaClient
    client = OllamaClient(base_url=base_url, timeout=max(1, int(timeout)), max_attempts=1)
    answer = client.generate("Reply with exactly: OK", model=model)
    ok = answer.strip() == "OK"
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.DEGRADED.value,
            ok, "Minimal Ollama inference smoke", "exact OK" if ok else "response received", "unexpected response" if not ok else "", "not_applicable")


def _dns(timeout: float):
    old = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)
    try:
        socket.getaddrinfo("api.github.com", 443, type=socket.SOCK_STREAM)
    finally:
        socket.setdefaulttimeout(old)
    return CapabilityStatus.READY.value, True, "DNS resolution succeeded", "api.github.com", "", "not_applicable"


def _https(timeout: float):
    request = urllib.request.Request("https://api.github.com/", method="GET",
                                     headers={"User-Agent": "iclirius-doctor"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response.read(1024)
            code = response.status
    except urllib.error.HTTPError as exc:
        code = exc.code
    ok = 200 <= code < 500
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.BLOCKED.value,
            ok, "HTTPS transport responded", f"HTTP {code}", "", "not_applicable")


def _tailscale(timeout: float):
    binary = shutil.which("tailscale")
    if not binary:
        return CapabilityStatus.OPTIONAL.value, None, "Tailscale not installed", "", "optional", "not_applicable"
    result = subprocess.run([binary, "status", "--json"], capture_output=True, text=True,
                            timeout=timeout, check=False)
    if result.returncode != 0:
        return CapabilityStatus.UNTESTED.value, None, "Tailscale status unavailable", "", "read-only status failed", "not_applicable"
    data = json.loads(result.stdout or "{}")
    running = str(data.get("BackendState", "")).lower() == "running"
    return (CapabilityStatus.READY.value if running else CapabilityStatus.DEGRADED.value,
            running, "Tailscale backend status", str(data.get("BackendState", "unknown")), "", "not_applicable")


def _localhost_port(port: int, name: str, timeout: float):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        result = sock.connect_ex(("127.0.0.1", port))
    if result == 0:
        return CapabilityStatus.AVAILABLE.value, True, f"{name} localhost listener detected", f"127.0.0.1:{port}", "", "not_applicable"
    return CapabilityStatus.AVAILABLE.value, False, f"{name} localhost listener not detected", f"127.0.0.1:{port}", "service may be disabled", "not_applicable"


def _ffmpeg(timeout: float):
    binary = shutil.which("ffmpeg")
    if not binary:
        return CapabilityStatus.OPTIONAL.value, None, "ffmpeg unavailable", "", "optional", "not_applicable"
    result = subprocess.run([binary, "-version"], capture_output=True, text=True,
                            timeout=timeout, check=False)
    ok = result.returncode == 0
    return (CapabilityStatus.READY.value if ok else CapabilityStatus.BLOCKED.value,
            ok, "ffmpeg version probe", binary, "", "not_applicable")


def run(report: dict) -> dict:
    """Run bounded probes and return diagnostics plus merged capability state."""
    from app.config import settings
    probes = []
    probes.append(_probe("filesystem.temp_rw", "tools.filesystem", _filesystem, timeout=3))
    probes.append(_probe("process.python", "tools.python", _python, timeout=5))
    probes.append(_probe("tool.git", "tools.git", _git, timeout=5))
    probes.append(_probe("memory.decrypt", "memory.encryption", _memory_health, timeout=5))
    probes.append(_probe("memory.lock", "memory.locking", _memory_lock, timeout=3))
    model = settings.default_model
    base = settings.ollama_base_url
    probes.append(_probe("ollama.api_model", "ai.default_model",
                         lambda timeout: _ollama(timeout, model, base), timeout=5))
    if report.get("ollama", {}).get("running") and model in report.get("models", {}).get("installed", []):
        probes.append(_probe("ollama.inference", "ai.inference",
                             lambda timeout: _inference(timeout, model, base), timeout=30))
    else:
        probes.append(DiagnosticProbeResult("ollama.inference", "ai.inference",
                                            CapabilityStatus.UNTESTED.value, None, False, 0,
                                            "Inference not run because Ollama/model unavailable",
                                            limitation="requires reachable default model"))
    probes.append(_probe("network.dns", "network.dns", _dns, timeout=5))
    probes.append(_probe("network.https", "network.https", _https, timeout=8))
    probes.append(_probe("network.github_api", "network.github_api", _https, timeout=8))
    probes.append(_probe("network.tailscale", "network.tailscale", _tailscale, timeout=5))
    probes.append(_probe("remote.ssh", "remote.ssh", lambda timeout: _localhost_port(22, "SSH", timeout), timeout=2))
    probes.append(_probe("remote.screen_sharing", "remote.screen_sharing", lambda timeout: _localhost_port(5900, "Screen Sharing", timeout), timeout=2))
    probes.append(_probe("voice.ffmpeg", "voice.ffmpeg", _ffmpeg, timeout=5))
    started = time.monotonic()
    merged = json.loads(json.dumps(report.get("capability_audit", {})))
    by_cap = {item.capability_id: item for item in probes if item.success is not None}
    for item in merged.get("capabilities", []):
        probe = by_cap.get(item.get("id"))
        if not probe:
            continue
        item["status"] = probe.status
        item["available"] = probe.success
        item["tested"] = probe.tested
        item["evidence"] = probe.evidence or item.get("evidence", "")
        item["limitation"] = probe.limitation or item.get("limitation", "")
    # A successful DNS and HTTPS probe upgrades the aggregate outbound
    # observation while keeping the individual probe records authoritative.
    dns_ok = next((p.success for p in probes if p.id == "network.dns"), None)
    https_ok = next((p.success for p in probes if p.id == "network.https"), None)
    if dns_ok is True and https_ok is True:
        outbound = next((item for item in merged.get("capabilities", [])
                         if item.get("id") == "network.outbound"), None)
        if outbound:
            outbound.update({"status": CapabilityStatus.READY.value,
                             "available": True, "tested": True,
                             "evidence": "DNS and HTTPS probes succeeded",
                             "limitation": ""})
    blockers = [item["id"] for item in merged.get("capabilities", [])
                if item.get("required") and item.get("status") in {"BLOCKED", "MISSING", "POLICY_BLOCKED"}]
    limitations = [item["id"] for item in merged.get("capabilities", [])
                   if item.get("status") in {"DEGRADED", "UNTESTED"}]
    optional = [item["id"] for item in merged.get("capabilities", []) if item.get("status") == "OPTIONAL"]
    merged.update({"blockers": blockers, "limitations": limitations, "optional": optional,
                   "overall": "BLOCKED" if blockers else ("DEGRADED" if limitations else "READY")})
    return {"schema_version": 1, "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "duration_ms": int((time.monotonic() - started) * 1000),
            "probes": [probe.to_dict() for probe in probes], "capability_audit": merged}
