import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional
from app.config import settings


STATE_DIR = Path(settings.state_path)

MANIFEST_JSONL = STATE_DIR / "file_manifest.jsonl"
MANIFEST_INDEX = STATE_DIR / "file_manifest_index.json"
ERRORS_JSONL = STATE_DIR / "file_errors.jsonl"


SUPPORTED_EXTENSIONS = {
    ".epub", ".pdf", ".txt", ".md", ".docx", ".rtf",
    ".csv", ".xlsx", ".xls", ".json", ".jsonl",
    ".mobi", ".azw3"
}


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def file_fingerprint(path: str) -> Optional[Dict]:
    p = Path(path)

    if not p.exists() or not p.is_file():
        return None

    stat = p.stat()

    return {
        "path": str(p),
        "name": p.name,
        "extension": p.suffix.lower(),
        "size": stat.st_size,
        "mtime": stat.st_mtime,
        "mtime_iso": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
    }


def quick_hash(path: str, max_bytes: int = 1024 * 1024) -> Optional[str]:
    p = Path(path)
    if not p.exists() or not p.is_file():
        return None

    h = hashlib.sha256()
    size = p.stat().st_size

    with p.open("rb") as f:
        h.update(f.read(max_bytes))
        if size > max_bytes:
            f.seek(max(0, size - max_bytes))
            h.update(f.read(max_bytes))

    h.update(str(size).encode())
    return h.hexdigest()


def load_manifest_index() -> Dict[str, Dict]:
    if MANIFEST_INDEX.exists():
        try:
            return json.loads(MANIFEST_INDEX.read_text(encoding="utf-8"))
        except Exception:
            return {}

    index = {}

    if MANIFEST_JSONL.exists():
        with MANIFEST_JSONL.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                path = row.get("path")
                if path:
                    index[path] = row

    save_manifest_index(index)
    return index


def save_manifest_index(index: Dict[str, Dict]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MANIFEST_INDEX.write_text(
        json.dumps(index, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def append_jsonl(path: Path, row: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def mark_file(
    path: str,
    status: str,
    job_id: str = "",
    error: str = "",
    extra: Optional[Dict] = None,
) -> Dict:
    fp = file_fingerprint(path) or {
        "path": path,
        "name": Path(path).name,
        "extension": Path(path).suffix.lower(),
        "size": None,
        "mtime": None,
        "mtime_iso": None,
    }

    row = {
        **fp,
        "status": status,
        "job_id": job_id,
        "error": error,
        "updated_at": now(),
        **(extra or {}),
    }

    index = load_manifest_index()
    index[path] = row
    save_manifest_index(index)
    append_jsonl(MANIFEST_JSONL, row)

    if status == "failed":
        append_jsonl(ERRORS_JSONL, row)

    return row


def should_skip_file(path: str) -> bool:
    fp = file_fingerprint(path)
    if not fp:
        return True

    if fp["extension"] not in SUPPORTED_EXTENSIONS:
        return True

    index = load_manifest_index()
    old = index.get(path)

    if not old:
        return False

    if old.get("status") != "processed":
        return False

    same_size = old.get("size") == fp.get("size")
    same_mtime = old.get("mtime") == fp.get("mtime")

    return bool(same_size and same_mtime)


def manifest_summary() -> str:
    index = load_manifest_index()
    total = len(index)

    counts = {}
    by_ext = {}

    for row in index.values():
        status = row.get("status", "unknown")
        ext = row.get("extension") or "sin_ext"
        counts[status] = counts.get(status, 0) + 1
        by_ext[ext] = by_ext.get(ext, 0) + 1

    lines = []
    lines.append(f"Archivos en manifest: {total}")
    lines.append("")
    lines.append("Por estado:")
    for k, v in sorted(counts.items(), key=lambda x: x[0]):
        lines.append(f"- {k}: {v}")

    lines.append("")
    lines.append("Extensiones principales:")
    for k, v in sorted(by_ext.items(), key=lambda x: x[1], reverse=True)[:15]:
        lines.append(f"- {k}: {v}")

    if ERRORS_JSONL.exists():
        errors = sum(1 for _ in ERRORS_JSONL.open("r", encoding="utf-8"))
        lines.append("")
        lines.append(f"Errores registrados: {errors}")

    return "\n".join(lines)
