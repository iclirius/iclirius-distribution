from pathlib import Path
from typing import Dict

from app.file_state import SUPPORTED_EXTENSIONS, should_skip_file


def scan_pending(root_path: str) -> Dict:
    root = Path(root_path).expanduser()

    result = {
        "root_path": str(root),
        "total_supported": 0,
        "pending": [],
        "skipped": [],
        "missing_root": not root.exists(),
    }

    if not root.exists():
        return result

    for p in root.rglob("*"):
        if not p.is_file():
            continue

        if p.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue

        result["total_supported"] += 1

        if should_skip_file(str(p)):
            result["skipped"].append(str(p))
        else:
            result["pending"].append(str(p))

    return result


def format_pending_scan(root_path: str, limit: int = 20) -> str:
    result = scan_pending(root_path)

    if result["missing_root"]:
        return f"No existe la ruta: {root_path}"

    lines = []
    lines.append(f"Ruta: {result['root_path']}")
    lines.append(f"Archivos soportados: {result['total_supported']}")
    lines.append(f"Pendientes: {len(result['pending'])}")
    lines.append(f"Saltados por estar igual: {len(result['skipped'])}")

    if result["pending"]:
        lines.append("")
        lines.append("Primeros pendientes:")
        for p in result["pending"][:limit]:
            lines.append(f"- {p}")

    return "\n".join(lines)
