"""Administrative local-authentication commands (never unlock protected data)."""

from __future__ import annotations

import argparse
import getpass

from app.config import settings
from app.local_auth import AuthenticationError, enroll, status
from app.touch_id import availability, authenticate, TouchIDStatus


def _render(info: dict) -> str:
    identity = info.get("primary_identity") or "not configured"
    return "\n".join([
        "Iclirius Authentication",
        "",
        f"Identity: {identity}",
        f"Authentication: {'enabled' if info.get('enrolled') else 'not enrolled'}",
        f"Touch ID: {info.get('touch_id', 'unavailable')}",
        f"Recovery credential: {'configured' if info.get('recovery_credential') else 'not configured'}",
    ])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius auth")
    parser.add_argument("command", nargs="?", choices=("setup", "status"), default="status")
    args = parser.parse_args(argv or [])
    if args.command == "status":
        info = status()
        if not info.get("primary_identity"):
            info["primary_identity"] = settings.principal_user_name
        print(_render(info))
        return 0
    if not settings.setup_complete or not settings.user_id or not settings.principal_user_name:
        print("Iclirius setup must be complete before local authentication enrollment.")
        return 2
    print("Iclirius Authentication Setup\n")
    print(f"Identity: {settings.principal_user_name}")
    touch = availability(compile_if_missing=True)
    print(f"Touch ID: {touch.value}")
    try:
        password = getpass.getpass("Create recovery password: ")
        confirmation = getpass.getpass("Confirm recovery password: ")
        if touch not in {TouchIDStatus.UNAVAILABLE, TouchIDStatus.NOT_ENROLLED}:
            print("Authenticate with Touch ID to finish enrollment.")
            touch_result = authenticate()
            if touch_result != TouchIDStatus.SUCCESS:
                print("Touch ID was not completed; recovery-password authentication remains available.")
        info = enroll(settings.user_id, settings.principal_user_name, password, confirmation,
                      touch_status=touch)
    except (EOFError, KeyboardInterrupt):
        print("\nAuthentication enrollment cancelled.")
        return 1
    except AuthenticationError as exc:
        print(f"Authentication enrollment failed: {exc}")
        return 2
    print("\nLocal authentication enabled.")
    print(_render(info))
    return 0
