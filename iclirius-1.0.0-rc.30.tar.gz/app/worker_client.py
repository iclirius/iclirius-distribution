import requests

from app.config import settings


def ask_worker(prompt: str) -> str:
    worker_url = getattr(settings, "worker_url", "") or ""

    if not worker_url:
        raise RuntimeError("WORKER_URL is not configured")

    response = requests.post(
        worker_url,
        json={"prompt": prompt},
        timeout=180,
    )

    response.raise_for_status()
    data = response.json()

    if not data.get("ok"):
        raise RuntimeError(data.get("error", "Worker returned an error"))

    return data.get("response", "").strip()



def worker_status_text() -> str:
    worker_url = getattr(settings, "worker_url", "") or ""
    enabled = getattr(settings, "enable_worker_delegation", False)

    lines = [
        "Worker status:",
        f"- Delegation enabled: {enabled}",
        f"- Worker URL: {worker_url or 'not configured'}",
    ]

    if not worker_url:
        lines.append("- Result: NOT CONFIGURED")
        return "\n".join(lines)

    try:
        response = requests.post(
            worker_url,
            json={"prompt": "Responde solo: worker OK"},
            timeout=30,
        )

        response.raise_for_status()
        data = response.json()

        lines.append(f"- HTTP: {response.status_code}")
        lines.append(f"- Node ID: {data.get('node_id', 'unknown')}")
        lines.append(f"- Result: {'OK' if data.get('ok') else 'ERROR'}")

        worker_response = str(data.get("response", "")).strip()
        if worker_response:
            lines.append(f"- Response: {worker_response[:500]}")

    except Exception as exc:
        lines.append("- Result: ERROR")
        lines.append(f"- Error: {exc}")

    return "\n".join(lines)
