"""Bounded, query-time file content extraction and search."""
from __future__ import annotations

import csv
import io
import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from app.evidence import Coverage, EvidenceRecord, SourceType

MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_CHARS = 20000
MAX_PDF_PAGES = 10
MAX_LINES = 5000
MAX_FILES = 200
MAX_MATCHES = 50
IGNORED_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", "dist", "build", "coverage", ".pytest_cache"}
TEXT_EXTENSIONS = {".txt", ".md", ".py", ".js", ".jsx", ".ts", ".tsx", ".rs", ".go", ".java", ".swift", ".sh", ".bash", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".xml", ".html", ".css", ".sql"}
SECRET_NAMES = {".env", ".env.local", ".env.production", "credentials", "id_rsa", "id_ed25519", "authorized_keys"}
SECRET_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".enc"}


class ContentState:
    READABLE = "READABLE"; EMPTY = "EMPTY"; UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT"; PERMISSION_DENIED = "PERMISSION_DENIED"; NOT_FOUND = "NOT_FOUND"; TOO_LARGE = "TOO_LARGE"; BINARY = "BINARY"; DECODE_ERROR = "DECODE_ERROR"; PARSE_ERROR = "PARSE_ERROR"; PARTIAL = "PARTIAL"; PROTECTED = "PROTECTED"; NO_EXTRACTABLE_TEXT = "NO_EXTRACTABLE_TEXT"; ENCRYPTED = "ENCRYPTED"


@dataclass(frozen=True)
class FileContentRequest:
    path: str
    query: str = ""
    operation: str = "extract"
    max_chars: int = MAX_CHARS
    recursive: bool = True
    max_pages: int = MAX_PDF_PAGES
    allow_large_pdf: bool = False

    def to_dict(self): return asdict(self)


@dataclass(frozen=True)
class ContentEvidence:
    source: str
    relative_path: str
    format: str
    state: str
    content: str = ""
    locations: tuple[dict, ...] = ()
    encoding: str = "utf-8"
    truncated: bool = False
    observed_at: str = ""
    evidence: EvidenceRecord | None = field(default=None, repr=False)
    diagnostics: dict = field(default_factory=dict)

    def to_dict(self):
        return {"source": self.source, "relative_path": self.relative_path, "format": self.format, "state": self.state, "content": self.content, "locations": list(self.locations), "encoding": self.encoding, "truncated": self.truncated, "observed_at": self.observed_at, "diagnostics": dict(self.diagnostics), "evidence": self.evidence.to_dict() if self.evidence else None}


def _protected(path: Path) -> bool:
    return path.name.lower() in SECRET_NAMES or path.suffix.lower() in SECRET_SUFFIXES or any(p.lower() in {".ssh", "keychains", "credentials", "secrets"} for p in path.parts)


def _format(path: Path) -> str:
    ext = path.suffix.lower()
    return {".json": "json", ".csv": "csv", ".pdf": "pdf", ".docx": "docx", ".xlsx": "xlsx"}.get(ext, "text" if ext in TEXT_EXTENSIONS else "unsupported")


class FileContentService:
    def __init__(self, root: str | Path, *, max_file_bytes: int = MAX_FILE_BYTES, max_chars: int = MAX_CHARS):
        self.root = Path(root).expanduser().resolve()
        self.max_file_bytes = max_file_bytes
        self.max_chars = max_chars

    def _resolve(self, value: str) -> Path:
        candidate = Path(value).expanduser()
        if not candidate.is_absolute(): candidate = self.root / candidate
        target = candidate.resolve()
        if target != self.root and self.root not in target.parents: raise PermissionError("path escapes requested root")
        if _protected(target): raise PermissionError("content protected by policy")
        return target

    def extract(self, request: FileContentRequest) -> ContentEvidence:
        try:
            path = self._resolve(request.path)
        except PermissionError as exc:
            candidate = Path(request.path).expanduser()
            if not candidate.is_absolute():
                candidate = self.root / candidate
            target = candidate.resolve()
            if self.root in target.parents or target == self.root:
                rel = str(target.relative_to(self.root))
                if "protected" in str(exc):
                    return self._result(target, rel, ContentState.PROTECTED)
            raise
        rel = str(path.relative_to(self.root))
        if not path.exists(): return self._result(path, rel, ContentState.NOT_FOUND)
        if not path.is_file(): return self._result(path, rel, ContentState.UNSUPPORTED_FORMAT)
        try: size = path.stat().st_size
        except OSError: return self._result(path, rel, ContentState.PERMISSION_DENIED)
        fmt = _format(path)
        # PDFs are parsed directly from their authorized path with a bounded
        # page/character budget.  Other formats retain the conservative byte
        # limit; attachments do not opt into large-document parsing.
        if size > self.max_file_bytes and not (fmt == "pdf" and request.allow_large_pdf):
            return self._result(path, rel, ContentState.TOO_LARGE,
                                diagnostics={"size_bytes": size, "max_file_bytes": self.max_file_bytes})
        if fmt == "unsupported": return self._result(path, rel, ContentState.UNSUPPORTED_FORMAT)
        if fmt == "docx" or fmt == "xlsx": return self._result(path, rel, ContentState.UNSUPPORTED_FORMAT, format_name=fmt)
        if fmt == "pdf":
            evidence = self._pdf(path, rel, request=request)
            # Preserve the conservative contract for an oversized file that
            # is not parseable as a PDF at all.  A valid large PDF reaches the
            # bounded reader above; malformed bytes remain a size/format
            # refusal rather than pretending extraction failed after reading
            # an unbounded payload.
            if (size > self.max_file_bytes and request.allow_large_pdf
                    and evidence.state == ContentState.PARSE_ERROR):
                diagnostics = dict(evidence.diagnostics)
                diagnostics["size_bytes"] = size
                diagnostics["max_file_bytes"] = self.max_file_bytes
                return self._result(path, rel, ContentState.TOO_LARGE, format_name="pdf",
                                    diagnostics=diagnostics)
            return evidence
        try: raw = path.read_bytes()
        except OSError: return self._result(path, rel, ContentState.PERMISSION_DENIED, format_name=fmt)
        if b"\x00" in raw[:4096]: return self._result(path, rel, ContentState.BINARY, format_name=fmt)
        try: text = raw.decode("utf-8")
        except UnicodeDecodeError: return self._result(path, rel, ContentState.DECODE_ERROR, format_name=fmt)
        original_text = text
        truncated = len(text) > min(request.max_chars, self.max_chars) or len(text.splitlines()) > MAX_LINES
        if fmt == "json":
            try: text = json.dumps(json.loads(original_text), ensure_ascii=False, indent=2)
            except json.JSONDecodeError: return self._result(path, rel, ContentState.PARSE_ERROR, format_name=fmt)
        elif fmt == "csv":
            try:
                rows = list(csv.reader(io.StringIO(original_text)))[:200]
                text = "\n".join(",".join(row[:50]) for row in rows)[:self.max_chars]
            except csv.Error: return self._result(path, rel, ContentState.PARSE_ERROR, format_name=fmt)
        text = "\n".join(text.splitlines()[:MAX_LINES])[:min(request.max_chars, self.max_chars)]
        return self._result(path, rel, ContentState.EMPTY if not text else (ContentState.PARTIAL if truncated else ContentState.READABLE), content=text, format_name=fmt, truncated=truncated)

    def search(self, request: FileContentRequest) -> list[ContentEvidence]:
        if not request.query: raise ValueError("query is required")
        root = self._resolve(request.path)
        paths = [root] if root.is_file() else self._walk(root, request.recursive)
        results = []
        for path in paths[:MAX_FILES]:
            evidence = self.extract(FileContentRequest(str(path), max_chars=self.max_chars,
                                                       max_pages=request.max_pages,
                                                       allow_large_pdf=request.allow_large_pdf))
            if evidence.state not in {ContentState.READABLE, ContentState.PARTIAL}: continue
            locations = []
            for number, line in enumerate(evidence.content.splitlines(), 1):
                if request.query in line:
                    locations.append({"line": number, "snippet": line[:500]})
                    if len(locations) >= MAX_MATCHES: break
            if locations: results.append(ContentEvidence(evidence.source, evidence.relative_path, evidence.format, evidence.state, evidence.content, tuple(locations), evidence.encoding, evidence.truncated, evidence.observed_at, evidence.evidence))
        return results

    def _walk(self, root: Path, recursive: bool):
        if not recursive: return [p for p in root.iterdir() if p.is_file()]
        found = []
        for current, dirs, names in os.walk(root):
            dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS)
            for name in sorted(names):
                path = Path(current) / name
                if not _protected(path): found.append(path)
                if len(found) >= MAX_FILES: return found
        return found

    def _pdf(self, path: Path, rel: str, *, request: FileContentRequest):
        diagnostics = {"pages_total": None, "pages_read": 0, "characters_extracted": 0,
                       "text_layer": None, "encrypted": False, "parser": "pypdf",
                       "page_budget": max(1, min(int(request.max_pages or MAX_PDF_PAGES), MAX_PDF_PAGES)),
                       "character_budget": max(1, min(int(request.max_chars or self.max_chars), self.max_chars)),
                       "size_bytes": path.stat().st_size if path.exists() else None}
        try:
            from pypdf import PdfReader
            # Passing the path lets pypdf seek through the cross-reference
            # table instead of materialising a potentially very large PDF.
            reader = PdfReader(str(path), strict=False)
            diagnostics["encrypted"] = bool(reader.is_encrypted)
            if reader.is_encrypted:
                try:
                    decrypted = reader.decrypt("")
                except Exception:
                    decrypted = 0
                if not decrypted:
                    return self._result(path, rel, ContentState.ENCRYPTED, format_name="pdf",
                                        diagnostics=diagnostics)
            diagnostics["pages_total"] = len(reader.pages)
            pages = []
            max_pages = max(1, min(int(request.max_pages or MAX_PDF_PAGES), MAX_PDF_PAGES))
            char_budget = max(1, min(int(request.max_chars or self.max_chars), self.max_chars))
            for index, page in enumerate(reader.pages[:max_pages], 1):
                value = page.extract_text() or ""
                pages.append((index, value))
                if sum(len(item) for _, item in pages) >= char_budget:
                    break
            diagnostics["pages_read"] = len(pages)
            raw_text = "\n".join(value for _, value in pages)
            diagnostics["characters_extracted"] = len(raw_text)
            diagnostics["text_layer"] = bool(raw_text.strip())
            text = "\n".join(f"[page {i}]\n{value}" for i, value in pages if value.strip())
            truncated = len(text) > char_budget or len(pages) < len(reader.pages)
            text = text[:char_budget]
            if not text.strip():
                state = ContentState.NO_EXTRACTABLE_TEXT
            else:
                state = ContentState.PARTIAL if truncated else ContentState.READABLE
            return self._result(path, rel, state, content=text, format_name="pdf",
                                locations=tuple({"page": i} for i, value in pages if value.strip()),
                                truncated=truncated, diagnostics=diagnostics)
        except Exception as exc:
            diagnostics["error_type"] = type(exc).__name__
            return self._result(path, rel, ContentState.PARSE_ERROR, format_name="pdf",
                                diagnostics=diagnostics)

    def _result(self, path, rel, state, *, content="", format_name=None, locations=(), truncated=False, diagnostics=None):
        fmt = format_name or _format(path)
        diagnostics = dict(diagnostics or {})
        record = EvidenceRecord(SourceType.FILESYSTEM.value, "file_content", str(path), {"relative_path": rel, "format": fmt, "state": state, "content": content[:self.max_chars], "locations": list(locations), "truncated": truncated, "diagnostics": diagnostics}, Coverage(complete=state in {ContentState.READABLE, ContentState.EMPTY}), provenance={"extraction": "query-time", "format": fmt})
        return ContentEvidence(str(path), rel, fmt, state, content[:self.max_chars], tuple(locations), "utf-8", truncated, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), record, diagnostics)
