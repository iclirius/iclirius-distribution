"""Safe, non-secret revision metadata for the encrypted Memory Core state."""

from __future__ import annotations

import json
import os
import platform
import uuid
from datetime import datetime, timezone
from pathlib import Path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def metadata_path(state_file: Path) -> Path:
    return Path(f"{state_file}.meta.json")


def read(state_file: Path) -> dict:
    path = metadata_path(state_file)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def bump(state_file: Path, *, node_id: str = "") -> dict:
    previous = read(state_file)
    try:
        revision = int(previous.get("revision", 0)) + 1
    except (TypeError, ValueError):
        revision = 1
    value = {
        "schema_version": 1,
        "revision": revision,
        "journal_head": f"j_{uuid.uuid4().hex}",
        "writer_node_id": node_id or platform.node() or "local-node",
        "last_write_at": _now(),
    }
    path = metadata_path(state_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, path)
    return value
