"""
What a child process is allowed to inherit.

Two levels, because two situations need different things.

`minimal_environment` is an allowlist: nothing survives unless it is named.
That is right for the safe-execute profiles, where the child is a test runner
or a build and we know exactly what it needs.

`redacted_environment` keeps everything except variables whose name says they
hold a credential. That is right for the long-standing background jobs, which
are OpenClaw modules launched with `python -m` and need the working
environment they have always had. Stripping their credentials is safe because
app/config.py calls load_dotenv() on import, so a child re-reads .env for
itself rather than depending on what the parent handed down.

Neither function is a substitute for the other. An allowlist applied to the
jobs would be a rewrite of code that works; a redaction applied to safe
execute would be weaker than what that path already guarantees.
"""

from __future__ import annotations

import os
import re

# Names that hold a credential, whatever the project calls them.
SECRET_NAME = re.compile(
    r"TOKEN|SECRET|PASSWORD|PASSWD|API[_-]?KEY|_KEY$|^KEY_|CREDENTIAL|"
    r"PRIVATE|AUTH|SESSION|COOKIE|SIGNATURE|SALT",
    re.IGNORECASE,
)


def looks_like_secret(name: str) -> bool:
    return bool(SECRET_NAME.search(name or ""))


def minimal_environment(allow: set[str], extra: dict | None = None) -> dict:
    """
    Build an environment from an allowlist.

    A variable nobody thought about is excluded by default rather than
    inherited, which is the only ordering that stays correct as the process
    environment grows.
    """
    env = {}

    for name in allow:
        value = os.environ.get(name)

        if value is None or looks_like_secret(name):
            continue

        env[name] = value

    env.update(extra or {})

    return env


def redacted_environment(base: dict | None = None) -> dict:
    """
    The current environment minus anything that names a credential.

    For children that need the working environment but have no business
    holding the bot token or the worker secret.
    """
    source = base if base is not None else os.environ

    return {name: value for name, value in source.items()
            if not looks_like_secret(name)}
