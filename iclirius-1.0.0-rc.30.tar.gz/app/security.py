from app.config import settings


def is_allowed_user(user_id: int) -> bool:
    if not settings.allowed_user_ids:
        return False

    return user_id in settings.allowed_user_ids


def is_owner_user(user_id: int) -> bool:
    if not settings.owner_user_ids:
        return False

    return user_id in settings.owner_user_ids


def is_leader() -> bool:
    return settings.role.lower() == "leader"
