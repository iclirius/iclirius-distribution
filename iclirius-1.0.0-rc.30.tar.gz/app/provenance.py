"""Safe runtime provenance; never includes tokens or environment dumps."""
from __future__ import annotations

import os
import subprocess
import re
import sys
from pathlib import Path
from app.version import VERSION


def collect() -> dict:
    root = Path(__file__).resolve().parents[1]
    source = (root / ".git").exists()
    result = {"version": VERSION, "python": sys.version.split()[0],
              "runtime_path": str(Path(sys.executable).resolve()),
              "installation_mode": "SOURCE_CHECKOUT" if source else "HOMEBREW",
              "repository": str(root) if source else ""}
    if source:
        try:
            result["branch"] = subprocess.run(["git", "-C", str(root), "branch", "--show-current"],
                                               capture_output=True, text=True, timeout=2,
                                               check=False).stdout.strip()
            result["commit"] = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                                               capture_output=True, text=True, timeout=2,
                                               check=False).stdout.strip()
        except (OSError, subprocess.SubprocessError):
            result.update({"branch": "", "commit": ""})
    return result


def running_node() -> dict:
    """Best-effort metadata for the user LaunchAgent; never reads secrets."""
    result = {"state": "UNKNOWN", "pid": None, "runtime_path": "",
              "installation_mode": "UNKNOWN", "source": "launchctl"}
    launchctl = "/bin/launchctl"
    try:
        proc = subprocess.run([launchctl, "print", f"gui/{os.getuid()}/com.iclirius.openclaw.node"],
                              capture_output=True, text=True, timeout=2, check=False)
    except (OSError, subprocess.SubprocessError):
        return result
    if proc.returncode != 0:
        result["state"] = "STOPPED"
        return result
    text = proc.stdout or ""
    match = re.search(r"\bpid = (\d+)", text)
    result["state"] = "RUNNING"
    result["pid"] = int(match.group(1)) if match else None
    work = re.search(r"working directory = (.+)", text)
    result["runtime_path"] = work.group(1).strip() if work else ""
    result["installation_mode"] = ("SOURCE_CHECKOUT" if "/.git" in result["runtime_path"] or
                                    "/OpenClaw/" in result["runtime_path"] else "UNKNOWN")
    return result
