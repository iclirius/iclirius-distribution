"""Conservative, local evidence assessment; source statements are not truth.

Only selected passages are assessed. Lexical coverage and bounded assertion
patterns can establish an extractive answer, not general semantic entailment.
Unknown conflicts, publisher independence and publication age stay unknown.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from urllib.parse import urlsplit

from app.web_selection import _tokens
from app.web_independence import cluster_evidence

_INTENT = set("documentation docs official documented reference latest current today recent news community experience opinion experiences opinión experiencia según documentación what did do does changed changes change cuál qué cómo cuándo cuánto cuántos and y de la el".split())
_ASSERTION = re.compile(
    r"^(.{2,160}?)\s+(is|are|was|es|son|supports?|soporta|requires?|requiere|uses?|usa|"
    r"adds?|added|includes?|incluye|reports?|reportan|costs?|cuesta|has|tiene|accepts?|"
    r"increased?|aumentó|aumenta|"
    r"does not support|doesn't support|no soporta)\s+(.{1,300})$", re.I)
_NEGATIVE = re.compile(r"^(?:not|no)\s+", re.I)
_RELATION_GROUPS = (
    {"before", "after"}, {"minimum", "least", "at", "most", "maximum"},
    {"percent", "percentage"}, {"required", "optional", "not"},
    {"support", "supports", "supported"}, {"release", "released", "launch", "launched"},
    {"listen", "listens", "listener", "accept", "accepts", "connection", "connections"},
    {"increase", "increased", "increases", "increasing"},
)


def normalize(text: str) -> str:
    # Preserve numbers, negation, units and operators. Token-only comparison
    # would incorrectly equate -1 with 1 or a > b with a < b.
    return re.sub(r"\s+", " ", text.casefold()).strip().rstrip(".!?")


def terms(text: str) -> set[str]:
    return (_tokens(text) - _INTENT - {"changed", "changes"}) | set(re.findall(r"\b\d+(?:\.\d+)+\b", text))


@dataclass(frozen=True)
class AssessedStatement:
    evidence_id: str
    passage_id: str
    text: str
    facet: int
    direct: bool
    slot: str = ""
    value: str = ""
    relation_match: bool = True


@dataclass(frozen=True)
class EvidenceAssessment:
    status: str
    relevance: dict
    source_quality: dict
    source_diversity: dict
    source_independence: dict
    corroboration: dict
    contradiction: dict
    coverage: dict
    freshness: dict
    sufficiency: dict
    evidence_ids: tuple[str, ...]
    statements: tuple[AssessedStatement, ...]

    def to_dict(self) -> dict:
        return asdict(self)

    def supports_statement(self, row: AssessedStatement) -> bool:
        """A covered facet cannot lend another source its quality or freshness.

        Apply the existing sufficiency criteria to the individual assertion at
        the output boundary as well as when deciding facet coverage.
        """
        quality = self.source_quality.get(row.evidence_id, {})
        corroborated = any(row.slot == match['slot'] and row.value == match['value']
                           and row.evidence_id in match['evidence_ids']
                           for match in self.corroboration['matches'])
        membership = self.source_independence.get('membership', {}).get(row.evidence_id, {})
        cluster_id = membership.get('cluster_id')
        cluster_members = [eid for eid, info in self.source_independence.get('membership', {}).items()
                           if info.get('cluster_id') == cluster_id]
        representative = min(cluster_members) if cluster_members else row.evidence_id
        return bool(row.direct and row.facet in self.coverage['covered']
                    and row.relation_match
                    and row.evidence_id == representative
                    and quality.get('complete_fetch')
                    and (quality.get('intent_suitable') or corroborated)
                    and self.freshness['sources'].get(row.evidence_id) in {'NOT_REQUIRED', 'RECENT'})

    def instruction(self) -> str:
        return (f"EvidenceAssessment={self.status}. Covered facets={self.coverage['covered']}; "
                f"unverified facets={self.coverage['missing']}. "
                f"Relevant sources={self.relevance['with_relevant_statements']}; "
                f"quality=intent-aware heuristic; domain groups={self.source_diversity['count']}; "
                f"independent clusters={self.source_independence['independent_cluster_count']}; "
                f"corroborations={len(self.corroboration['matches'])}; contradiction={self.contradiction['status']}; "
                f"freshness required={self.freshness['required']}. "
                "Only repeat source statements; never fill gaps or resolve conflicts. Application policy, not model confidence.")


def _publisher(url: str) -> str:
    # Conservative suffix grouping. This intentionally undercounts publishers
    # on multi-label public suffixes; distinct groups still do not prove independence.
    host = (urlsplit(url).hostname or "").lower()
    return ".".join(host.split(".")[-2:])


def _freshness(result: dict, applicable: bool, now: datetime) -> str:
    if not applicable:
        return "NOT_REQUIRED"
    # A recent fetch does not make the page's assertions current.
    stamp = result.get("published_at") or result.get("updated_at")
    if not stamp:
        return "UNKNOWN_PUBLICATION_DATE"
    try:
        date = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        age = (now - date).total_seconds()
        return "RECENT" if -300 <= age <= 30 * 86400 else "STALE"
    except (TypeError, ValueError):
        return "UNKNOWN_PUBLICATION_DATE"


def _assertion(text: str) -> tuple[str, str]:
    match = _ASSERTION.fullmatch(text.strip().rstrip(".!"))
    if not match:
        return "", ""
    subject, predicate, value = match.groups()
    predicate = predicate.lower()
    negative = predicate in {"does not support", "doesn't support", "no soporta"}
    if negative or predicate in {"support", "supports", "soporta"}:
        negative = negative or bool(_NEGATIVE.match(value))
        return normalize(subject) + " :: supports " + normalize(_NEGATIVE.sub("", value)), "no" if negative else "yes"
    return normalize(subject) + " :: " + predicate, normalize(value)


def _relation_match(question: str, sentence: str, slot: str) -> bool:
    """Require explicit query relation/value terms in the source assertion."""
    if not slot:
        return False
    if " :: " in slot:
        subject, predicate = slot.split(" :: ", 1)
    else:
        subject, predicate = (slot.rsplit(" supports ", 1) if " supports " in slot else (slot, ""))
    relation_terms = terms(question) - set(subject.split())
    if not relation_terms:
        return True
    sentence_terms = terms(sentence)
    numeric = {token for token in relation_terms if re.search(r"\d", token)}
    if numeric and not numeric <= sentence_terms:
        return False
    non_numeric = relation_terms - numeric
    if not non_numeric:
        return True
    # Property questions often use a domain verb ("listen") while the source
    # expresses the value with a copula ("is 8080").  Accept that form only
    # when the subject and explicit value already align; unrelated predicates
    # such as "documented" still fail below.
    if predicate in {"is", "are", "was", "es", "son"} and non_numeric:
        subject_tail = subject.split()[-1] if subject.split() else ""
        if subject_tail in terms(question) and not (
                ("percent" in relation_terms or "percentage" in relation_terms)
                and not ({"percent", "percentage"} & sentence_terms)
                or (non_numeric & {"listen", "listens", "accept", "accepts"}
                    and not any(re.search(r"\d", token) for token in sentence_terms))):
            return True
    if non_numeric & terms(predicate):
        return True
    if non_numeric & sentence_terms:
        return True
    for group in _RELATION_GROUPS:
        if (non_numeric & group) and (sentence_terms & group):
            return True
    return False


def _overlap(required: set[str], sentence: set[str]) -> set[str]:
    hits = required & sentence
    for group in _RELATION_GROUPS:
        if required & group and sentence & group:
            hits.add(next(iter(required & group)))
    return hits


def assess_evidence(question, selection, passages, *, now=None) -> EvidenceAssessment:
    now = now or datetime.now(timezone.utc)
    facets = [part.strip(" ?.;") for part in re.split(r"\s+(?:and|y)\s+|[?;]+", question, flags=re.I)
              if terms(part)] or [question.strip()]
    if len(facets) > 8:
        facets = facets[:7] + ["; ".join(facets[7:])]
    facet_terms = [terms(part) for part in facets]
    qualities = {q.evidence_id: q for q in selection.qualities}
    records = {e.evidence_id: e for e in passages.evidence}
    clusters, membership = cluster_evidence(list(records.values()))
    fresh_required = selection.intent == "CURRENT_EVENT" or bool(re.search(
        r"\b(latest|current|today|recent|actual|hoy|última|actualidad)\b", question, re.I))
    freshness = {eid: _freshness(e.record.result, fresh_required, now) for eid, e in records.items()}
    quality = {}
    for eid, evidence in records.items():
        result = evidence.record.result
        q = qualities.get(eid)
        relationship = q.source_relationship if q else "UNKNOWN"
        complete = result.get("retrieval") == "fetched" and not result.get("truncated")
        status = result.get("status_code")
        complete = complete and (status is None or isinstance(status, int) and 200 <= status < 300)
        suitable = relationship == "PRIMARY" or (
            selection.intent in {"COMMUNITY_EXPERIENCE", "OPINION"} and relationship == "COMMUNITY")
        quality[eid] = {"relationship": relationship, "complete_fetch": bool(complete),
                        "intent_suitable": suitable, "authority": "HEURISTIC_NOT_VERIFIED"}

    statements = []
    for passage in passages.selected:
        if passage.role != "DIRECT":
            continue
        for sentence in re.split(r"(?<=[.!?])\s+|\n+", passage.text):
            sentence = sentence.strip()
            if not sentence or len(sentence) > 500 or sentence.endswith("?"):
                continue
            slot, value = _assertion(sentence)
            for index, required in enumerate(facet_terms):
                hits = _overlap(required, terms(sentence))
                if not required or not hits or len(hits) / len(required) < 0.5:
                    continue
                relation_match = _relation_match(facets[index], sentence, slot)
                direct = bool(slot) and len(hits) / len(required) >= 0.5 and relation_match
                statements.append(AssessedStatement(passage.evidence_id, passage.passage_id,
                    sentence, index, direct, slot, value, relation_match))
    statements = tuple(statements)
    groups: dict[str, list[AssessedStatement]] = {}
    for statement in statements:
        if statement.slot:
            groups.setdefault(statement.slot, []).append(statement)
    conflicts, corroborated = [], []
    for slot, rows in groups.items():
        values = {row.value for row in rows}
        # Same-subject explicit value disagreement is a potential conflict,
        # including disagreements within one source; never pick a winner.
        if len(values) > 1:
            conflicts.append({"slot": slot, "values": sorted(values),
                              "evidence_ids": sorted({row.evidence_id for row in rows})})
        else:
            cluster_ids = {membership[row.evidence_id]["cluster_id"] for row in rows}
            if len(cluster_ids) > 1:
                corroborated.append({"slot": slot, "value": rows[0].value,
                                     "evidence_ids": sorted({row.evidence_id for row in rows}),
                                     "cluster_ids": sorted(cluster_ids)})
    corroborated_assertions = {(eid, row["slot"], row["value"])
                              for row in corroborated for eid in row["evidence_ids"]}
    covered = sorted({row.facet for row in statements if row.direct and row.relation_match and
                      quality[row.evidence_id]["complete_fetch"] and
                      (quality[row.evidence_id]["intent_suitable"] or
                       (row.evidence_id, row.slot, row.value) in corroborated_assertions) and
                      freshness[row.evidence_id] in {"NOT_REQUIRED", "RECENT"}})
    missing = [i for i in range(len(facets)) if i not in covered]
    if not selection.candidates:
        status = "NO_EVIDENCE"
    elif conflicts:
        status = "CONFLICTING"
    elif covered and not missing:
        status = "SUPPORTED"
    elif covered:
        status = "PARTIALLY_SUPPORTED"
    else:
        status = "INSUFFICIENT"
    domains = sorted({_publisher(e.record.target) for e in records.values()} - {""})
    independent_clusters = sorted(clusters)
    return EvidenceAssessment(status,
        {"found": len(selection.candidates), "selected": len(selection.selected),
         "with_relevant_statements": len({row.evidence_id for row in statements}), "method": "lexical_facets"},
        quality, {"publisher_groups": domains, "count": len(domains), "independence": "UNVERIFIED"},
        {"clusters": {key: value.to_dict() for key, value in clusters.items()},
         "membership": membership, "independent_cluster_count": len(independent_clusters),
         "method": "canonical_url_content_title_attribution_similarity"},
        {"matches": corroborated, "method": "equal_explicit_assertions_across_source_clusters"},
        {"status": "DETECTED" if conflicts else "NOT_DETECTED", "conflicts": conflicts,
         "semantic_conflicts": "NOT_EXHAUSTIVELY_CHECKED"},
        {"facets": facets, "covered": covered, "missing": missing, "method": "lexical_and_explicit_assertion"},
        {"required": fresh_required, "sources": freshness, "max_age_days": 30},
        {"status": status, "policy": "complete direct assertion from intent-suitable source or corroboration; all facets; freshness when required"},
        tuple(records), statements)


def assessed_response(assessment: EvidenceAssessment) -> str:
    """Deterministic attributed fallback, without allowing LLM gap filling."""
    if assessment.status in {"NO_EVIDENCE", "INSUFFICIENT"}:
        return "No hay evidencia suficiente para afirmar una respuesta a esta pregunta."
    if assessment.status == "CONFLICTING":
        slots = {row["slot"] for row in assessment.contradiction["conflicts"]}
        rows = [row for row in assessment.statements if row.slot in slots]
        prefix = "Las fuentes presentan versiones contradictorias; no puedo resolver la discrepancia."
    else:
        rows = [row for row in assessment.statements if assessment.supports_statement(row)]
        prefix = "Las fuentes consultadas indican:"
    lines, seen = [prefix], set()
    for row in rows:
        key = (row.evidence_id, row.text)
        if key not in seen:
            # Source-supplied citation tokens cannot become application citations.
            quote = re.sub(r"\[\s*E[^\]]*\]", "", row.text, flags=re.I)
            quote = re.sub(r"https?://\S+", "(URL en el texto fuente)", quote)
            lines.append(f"- «{quote}» [{row.evidence_id}]")
            seen.add(key)
    if assessment.status == "PARTIALLY_SUPPORTED":
        missing = [assessment.coverage["facets"][i] for i in assessment.coverage["missing"]]
        lines.append("No pude verificar: " + "; ".join(missing) + ".")
    return "\n".join(lines)
