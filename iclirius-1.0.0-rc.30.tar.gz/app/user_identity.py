"""Canonical human identity used by setup and future interface bindings."""

from __future__ import annotations

import re
import uuid
from dataclasses import asdict, dataclass


IDENTITY_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


class IdentityError(ValueError):
    """The setup identity is missing or malformed."""


@dataclass(frozen=True)
class UserIdentity:
    user_id: str
    primary_identity: str
    display_name: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def validate_primary_identity(value: str) -> str:
    normalized = " ".join(str(value or "").strip().split())
    if not normalized or len(normalized) > 320 or not IDENTITY_RE.fullmatch(normalized):
        raise IdentityError("Primary identity must be a valid email-like identifier.")
    return normalized.casefold()


def new_identity(primary_identity: str, display_name: str = "") -> UserIdentity:
    return UserIdentity(
        user_id=str(uuid.uuid4()),
        primary_identity=validate_primary_identity(primary_identity),
        display_name=" ".join(str(display_name or "").strip().split())[:120],
    )


def identity_from_dict(data: dict) -> UserIdentity:
    if not isinstance(data, dict):
        raise IdentityError("Identity data must be an object.")
    user_id = str(data.get("user_id") or "").strip()
    try:
        uuid.UUID(user_id)
    except (ValueError, AttributeError):
        raise IdentityError("Identity user_id is not a valid UUID.") from None
    return UserIdentity(
        user_id=user_id,
        primary_identity=validate_primary_identity(data.get("primary_identity", "")),
        display_name=" ".join(str(data.get("display_name") or "").strip().split())[:120],
    )
