"""Deterministic source-origin clustering for web evidence."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from urllib.parse import urlsplit

from app.web_selection import _canonical_url, _result, _tokens

_URL = re.compile(r"https?://[^\s)\]>]+", re.I)
_COPY_HINT = re.compile(r"\b(?:copied|mirror|mirrored|reproduced|转载|via|source|fuente|original)\b", re.I)


def _text(item) -> str:
    return re.sub(r"\s+", " ", str(_result(item).get("content", ""))).strip().casefold()


def _title(item) -> str:
    return re.sub(r"\s+", " ", str(_result(item).get("title", ""))).strip().casefold()


def _jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 0.0


def _origin_urls(item) -> set[str]:
    metadata = _result(item).get("metadata") or {}
    values = [str(_result(item).get(key, "")) for key in
              ("requested_url", "final_url", "source_url", "origin_url", "canonical_url")]
    values.extend(str(metadata.get(key, "")) for key in ("source_url", "origin_url", "canonical_url"))
    body = _text(item)
    values.extend(_URL.findall(body) if _COPY_HINT.search(body) else ())
    return {_canonical_url(value) for value in values if value}


def _publisher(item) -> str:
    target = str(_result(item).get("final_url") or item.record.target)
    host = (urlsplit(target).hostname or "").lower()
    return ".".join(host.split(".")[-2:])


@dataclass(frozen=True)
class SourceCluster:
    cluster_id: str
    evidence_ids: tuple[str, ...]
    reason: str
    signals: tuple[str, ...]

    def to_dict(self) -> dict:
        return asdict(self)


def _near_mirror(left, right) -> tuple[bool, tuple[str, ...]]:
    left_text, right_text = _text(left), _text(right)
    if not left_text or not right_text:
        return False, ()
    signals = []
    left_first = re.split(r"(?<=[.!?])\s+", left_text, maxsplit=1)[0]
    right_first = re.split(r"(?<=[.!?])\s+", right_text, maxsplit=1)[0]
    if _origin_urls(left) & _origin_urls(right):
        signals.append("shared_origin_or_canonical_url")
    if _publisher(left) and _publisher(left) == _publisher(right):
        signals.append("shared_publisher_group")
    if left_text == right_text:
        signals.append("normalized_content_hash")
    similarity = _jaccard(_tokens(left_text), _tokens(right_text))
    if similarity >= 0.75 and max(len(left_text), len(right_text)) >= 80:
        signals.append("content_similarity")
    if _jaccard(_tokens(_title(left)), _tokens(_title(right))) >= 0.80:
        signals.append("title_similarity")
    if _COPY_HINT.search(left_text) or _COPY_HINT.search(right_text):
        signals.append("copy_or_attribution_hint")
    same = "shared_origin_or_canonical_url" in signals
    same = same or "shared_publisher_group" in signals
    same = same or ("copy_or_attribution_hint" in signals and
                    ("normalized_content_hash" in signals or "content_similarity" in signals
                     or "title_similarity" in signals or _jaccard(_tokens(left_text), _tokens(right_text)) >= 0.60))
    same = same or ("content_similarity" in signals and (
        "title_similarity" in signals or similarity >= 0.88 or
        (left_first and left_first == right_first)))
    return same, tuple(signals)


def cluster_evidence(evidence) -> tuple[dict[str, SourceCluster], dict[str, dict]]:
    rows = list(evidence)
    parent = {item.evidence_id: item.evidence_id for item in rows}
    signals: dict[str, set[str]] = {item.evidence_id: set() for item in rows}

    def find(key):
        while parent[key] != key:
            parent[key] = parent[parent[key]]
            key = parent[key]
        return key

    def union(left, right):
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    for index, left in enumerate(rows):
        for right in rows[index + 1:]:
            same, clues = _near_mirror(left, right)
            if same:
                union(left.evidence_id, right.evidence_id)
                signals[left.evidence_id].update(clues)
                signals[right.evidence_id].update(clues)
    groups: dict[str, list] = {}
    for item in rows:
        groups.setdefault(find(item.evidence_id), []).append(item)
    clusters, membership = {}, {}
    for index, members in enumerate(groups.values(), start=1):
        cluster_id = f"SC{index}"
        ids = tuple(item.evidence_id for item in members)
        clues = tuple(sorted(set().union(*(signals[item.evidence_id] for item in members))))
        cluster = SourceCluster(cluster_id, ids, "deterministic origin similarity", clues)
        clusters[cluster_id] = cluster
        for item in members:
            membership[item.evidence_id] = {"cluster_id": cluster_id,
                                             "signals": list(clues),
                                             "independent_origin": len(ids) == 1}
    return clusters, membership
