"""Canonical provenance and certainty model for authoritative observations."""
from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum


class Certainty(str, Enum):
    VERIFIED = "VERIFIED"
    OBSERVED = "OBSERVED"
    PARTIAL = "PARTIAL"
    INFERRED = "INFERRED"
    UNVERIFIED = "UNVERIFIED"
    CONFLICTED = "CONFLICTED"


class SourceType(str, Enum):
    FILESYSTEM = "filesystem"
    GIT = "git"
    PROCESS = "process"
    RUNTIME = "runtime"
    MEMORY_CORE = "memory_core"
    NODE_RUNTIME = "node_runtime"
    NETWORK = "network"
    OLLAMA = "ollama"
    DETERMINISTIC = "deterministic_calculation"
    USER = "user_statement"
    WEB = "web"


@dataclass(frozen=True)
class Coverage:
    complete: bool | None = None
    scanned_items: int = 0
    inaccessible_items: int = 0
    permission_denied: int = 0
    errors: int = 0
    skipped_items: int = 0
    reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class EvidenceRecord:
    source_type: str
    operation: str
    target: str
    result: dict
    coverage: Coverage | dict = field(default_factory=Coverage)
    certainty: str = Certainty.OBSERVED.value
    evidence_id: str = field(default_factory=lambda: f"ev_{uuid.uuid4().hex}")
    schema_version: int = 1
    observed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds"))
    provenance: dict = field(default_factory=dict)
    node_id: str = ""
    tool_id: str = ""
    duration_ms: int | None = None
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def __post_init__(self):
        if self.certainty not in {item.value for item in Certainty}:
            raise ValueError("invalid evidence certainty")
        if isinstance(self.coverage, dict):
            object.__setattr__(self, "coverage", Coverage(**self.coverage))

    def to_dict(self) -> dict:
        data = asdict(self)
        data["coverage"] = self.coverage.to_dict()
        data["errors"] = list(self.errors)
        data["warnings"] = list(self.warnings)
        return data

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True, default=str).encode()).hexdigest()[:16]


SOURCE_AUTHORITY = {
    "FILESYSTEM_FACT": {SourceType.FILESYSTEM.value},
    "GIT_FACT": {SourceType.GIT.value},
    "NODE_FACT": {SourceType.NODE_RUNTIME.value},
    "MEMORY_FACT": {SourceType.MEMORY_CORE.value},
    "PROCESS_FACT": {SourceType.PROCESS.value, SourceType.RUNTIME.value},
    "NETWORK_FACT": {SourceType.NETWORK.value},
    "PACKAGE_FACT": {SourceType.RUNTIME.value, SourceType.OLLAMA.value},
}


def source_can_prove(claim_type: str, source_type: str) -> bool:
    return source_type in SOURCE_AUTHORITY.get(claim_type, set())


def certainty_for_coverage(coverage: Coverage, observed: bool = True) -> str:
    if not observed:
        return Certainty.UNVERIFIED.value
    if coverage.complete is True and coverage.errors == 0 and coverage.permission_denied == 0:
        return Certainty.VERIFIED.value
    if coverage.complete is False or coverage.errors or coverage.permission_denied or coverage.inaccessible_items:
        return Certainty.PARTIAL.value
    return Certainty.OBSERVED.value
