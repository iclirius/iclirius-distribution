"""
Who is allowed to do what.

Read has been implicitly permitted since Phase 3; write is the first
capability that needs a decision from the user. This module holds that
decision and nothing else.

Two rules shape it:

  - An approval names one patch. "sí" resolves the pending proposal it was a
    reply to, identified by patch_id. There is no reusable yes: approving a
    change to TokenStore.kt does not authorise the next change to anything.

  - Approvals expire. A proposal reviewed twenty minutes ago described a file
    as it was then, so a stale approval is refused and the work has to be
    proposed again against the current file.

The default is confirm-required. A fresh install can read, has the write
capability present, and will not write without being asked.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from app.config import settings
from app.logger import logger


class Capability(str, Enum):
    READ = "READ"
    WRITE = "WRITE"
    EXECUTE = "EXECUTE"
    # Declared so the vocabulary does not need redesigning later. Nothing in
    # the codebase grants these, and no executor exists for them.
    NETWORK = "NETWORK"
    DELETE = "DELETE"
    SUDO = "SUDO"


class Decision(str, Enum):
    ALLOWED = "ALLOWED"
    CONFIRM_REQUIRED = "CONFIRM_REQUIRED"
    DENIED = "DENIED"


# Capabilities that exist in the enum but are never granted. EXECUTE left this
# set in Phase 3.6 because a real executor now exists for it, bounded to fixed
# argv from a local table. NETWORK stays denied even though execution happens:
# a build runs offline, and nothing in OpenClaw grants a subprocess the right
# to reach the internet on the model's behalf.
NEVER_GRANTED = {Capability.NETWORK, Capability.DELETE, Capability.SUDO}


@dataclass
class PendingApproval:
    patch_id: str
    summary: dict
    preview: str
    requested_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    interface: str = ""
    expires_at: float = 0.0

    def is_expired(self, now: float) -> bool:
        return self.expires_at > 0 and now >= self.expires_at


@dataclass
class PendingExecutionApproval:
    """
    An execution awaiting a yes.

    Bound to one execution_id for the same reason a write approval is bound to
    one patch_id: approving a test run is not approving the next one.
    """

    execution_id: str
    operation: str
    profile: str
    command: str
    cwd: str
    requested_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    interface: str = ""
    expires_at: float = 0.0

    def is_expired(self, now: float) -> bool:
        return self.expires_at > 0 and now >= self.expires_at


class PermissionLayer:
    """
    Decides capabilities and holds pending write approvals.

    In-process and per-node, like the rest of the runtime. Approvals are held
    in memory on purpose: a pending write should not survive a restart, since
    the file may have changed while the process was down.
    """

    def __init__(self):
        self._pending: dict[str, PendingApproval] = {}
        self._pending_executions: dict[str, PendingExecutionApproval] = {}
        self._lock = threading.Lock()

    # -- capability decisions ---------------------------------------------

    def check(self, capability: Capability | str) -> Decision:
        capability = Capability(capability) if not isinstance(capability, Capability) \
            else capability

        if capability in NEVER_GRANTED:
            return Decision.DENIED

        if capability is Capability.READ:
            return (Decision.ALLOWED if settings.enable_local_read_tools
                    else Decision.DENIED)

        if capability is Capability.WRITE:
            if not settings.write_enabled:
                return Decision.DENIED
            return (Decision.CONFIRM_REQUIRED if settings.write_confirm_required
                    else Decision.ALLOWED)

        if capability is Capability.EXECUTE:
            if not settings.execute_enabled:
                return Decision.DENIED
            return (Decision.CONFIRM_REQUIRED if settings.execute_confirm_required
                    else Decision.ALLOWED)

        return Decision.DENIED

    def can(self, capability: Capability | str) -> bool:
        """True only when no confirmation is needed."""
        return self.check(capability) is Decision.ALLOWED

    # -- pending write approvals ------------------------------------------

    def request_approval(self, proposal, interface: str = "") -> PendingApproval:
        """Register a proposal as awaiting a decision from the user."""
        import time

        pending = PendingApproval(
            patch_id=proposal.patch_id,
            summary=proposal.summary(),
            preview=proposal.preview(),
            interface=interface,
            expires_at=time.monotonic() + settings.write_approval_ttl_seconds,
        )

        with self._lock:
            self._prune_locked()
            self._pending[proposal.patch_id] = pending

        return pending

    def pending(self, interface: str | None = None) -> list[PendingApproval]:
        import time

        now = time.monotonic()

        with self._lock:
            self._prune_locked()
            items = [
                item for item in self._pending.values()
                if not item.is_expired(now)
                and (interface is None or item.interface == interface)
            ]

        return sorted(items, key=lambda item: item.requested_at, reverse=True)

    def resolve_target(self, patch_id: str | None = None,
                       interface: str | None = None) -> PendingApproval | None:
        """
        Find which patch an answer refers to.

        With an explicit patch_id, that one. Without, the single pending
        proposal, if there is exactly one. Several pending proposals are
        ambiguous and this returns None rather than guessing: applying the
        wrong change to someone's source is not a recoverable mistake.
        """
        if patch_id:
            with self._lock:
                self._prune_locked()
                return self._pending.get(patch_id)

        candidates = self.pending(interface=interface)

        if len(candidates) == 1:
            return candidates[0]

        return None

    def approve(self, patch_id: str) -> PendingApproval | None:
        """
        Consume an approval.

        Removed on use, so the same yes can never authorise a second write.
        """
        import time

        with self._lock:
            pending = self._pending.pop(patch_id, None)

        if pending is None:
            return None

        if pending.is_expired(time.monotonic()):
            logger.info("Write approval expired patch_id=%s", patch_id)
            return None

        return pending

    def deny(self, patch_id: str) -> PendingApproval | None:
        with self._lock:
            return self._pending.pop(patch_id, None)

    # -- pending execution approvals --------------------------------------

    def request_execution(self, execution_id: str, operation: str, profile: str,
                          command: str, cwd: str,
                          interface: str = "") -> PendingExecutionApproval:
        import time

        pending = PendingExecutionApproval(
            execution_id=execution_id,
            operation=operation,
            profile=profile,
            command=command,
            cwd=cwd,
            interface=interface,
            expires_at=time.monotonic() + settings.execute_approval_ttl_seconds,
        )

        with self._lock:
            self._prune_executions_locked()
            self._pending_executions[execution_id] = pending

        return pending

    def pending_executions(self, interface: str | None = None
                           ) -> list[PendingExecutionApproval]:
        import time

        now = time.monotonic()

        with self._lock:
            self._prune_executions_locked()
            items = [
                item for item in self._pending_executions.values()
                if not item.is_expired(now)
                and (interface is None or item.interface == interface)
            ]

        return sorted(items, key=lambda item: item.requested_at, reverse=True)

    def resolve_execution_target(self, execution_id: str | None = None,
                                 interface: str | None = None
                                 ) -> PendingExecutionApproval | None:
        """Same rule as writes: never guess between two pending executions."""
        if execution_id:
            with self._lock:
                self._prune_executions_locked()
                return self._pending_executions.get(execution_id)

        candidates = self.pending_executions(interface=interface)

        if len(candidates) == 1:
            return candidates[0]

        return None

    def approve_execution(self, execution_id: str) -> PendingExecutionApproval | None:
        import time

        with self._lock:
            pending = self._pending_executions.pop(execution_id, None)

        if pending is None:
            return None

        if pending.is_expired(time.monotonic()):
            logger.info("Execution approval expired execution_id=%s", execution_id)
            return None

        return pending

    def deny_execution(self, execution_id: str) -> PendingExecutionApproval | None:
        with self._lock:
            return self._pending_executions.pop(execution_id, None)

    def _prune_executions_locked(self) -> None:
        import time

        now = time.monotonic()
        expired = [key for key, item in self._pending_executions.items()
                   if item.is_expired(now)]

        for key in expired:
            self._pending_executions.pop(key, None)

        if expired:
            logger.info("Pruned expired execution approvals count=%s", len(expired))

    def clear(self) -> None:
        with self._lock:
            self._pending.clear()
            self._pending_executions.clear()

    def _prune_locked(self) -> None:
        import time

        now = time.monotonic()
        expired = [key for key, item in self._pending.items() if item.is_expired(now)]

        for key in expired:
            self._pending.pop(key, None)

        if expired:
            logger.info("Pruned expired write approvals count=%s", len(expired))


permission_layer = PermissionLayer()
