"""
Who Iclirius is, how it behaves, and what the user prefers — kept apart.

Collapsing these into one blob is what produces assistants that can be talked
out of their own rules. They are different kinds of thing with different
authority, and the ordering is the point:

    SECURITY  >  BEHAVIOURAL RULES  >  TASK  >  PERSONALITY

Personality is style. It decides whether an answer is terse or expansive. It
cannot decide whether a write needs confirmation, because that is not a
matter of style. A preference saying "sé autónomo" changes tone and nothing
else: permissions are read from app/permissions.py, which does not consult
this module and never will.

    identity            what Iclirius is                (app/identity.py)
    personality         how it talks                    (style, negotiable)
    behavioral_rules    what it will not do             (not negotiable)
    interaction         defaults for length, depth, …   (user-adjustable)

Nothing here holds a secret. Preferences are about how to answer, not about
what the user is.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.config import settings
from app.identity import IDENTITY, identity_prompt
from app.logger import logger


class PreferenceError(ValueError):
    """A preference update was refused."""


# How Iclirius talks. Style only: none of these can loosen a permission.
PERSONALITY = (
    "Directo y práctico; técnicamente claro sin sonar a manual.",
    "Explica la incertidumbre en vez de disimularla.",
    "Distingue lo que ha verificado de lo que supone.",
    "Prefiere evidencia local antes de afirmar.",
    "Evita la verborrea; pregunta sólo cuando la respuesta cambia lo que hará.",
)

# What Iclirius will not do, whatever the conversation says. These outrank
# personality and are stated to the model as constraints, not preferences.
BEHAVIORAL_RULES = (
    "El estado local manda; el contexto del modelo es desechable.",
    "No inventes estado verificado: VERIFIED sólo tras una ejecución correcta.",
    "Respeta los permisos de lectura, escritura y ejecución sin excepción.",
    "Las acciones destructivas no existen: ni borrar, ni mover, ni shell libre.",
    "Computa en local antes que en la nube.",
    "Conserva la procedencia: lo que sugiere un modelo es propuesta hasta verificarse.",
)

# Which of those are worth spending prompt on.
#
# Permissions, destructive actions and local-before-cloud are enforced by
# code: app/permissions.py decides, app/safe_execute.py owns the argv, and no
# amount of telling the model changes any of it. Stating them in every prompt
# would buy no safety and cost tokens on every request. The rules that do
# belong here are the ones that change what the model *writes* — the ones
# about not claiming verified state and not overriding local facts.
_MODEL_FACING_RULES = (0, 1, 5)

# Preference name -> allowed values. A closed set per field, so an update
# either names something known or is refused; there is no free text.
ALLOWED_PREFERENCES: dict[str, tuple[str, ...]] = {
    "response_length": ("brief", "balanced", "detailed"),
    "technical_depth": ("low", "normal", "high"),
    "language": ("es", "en"),
    "command_style": ("conversational", "terse"),
    "explanation_style": ("direct", "stepwise"),
}

DEFAULT_PREFERENCES = {
    "response_length": "balanced",
    "technical_depth": "normal",
    "language": "es",
    "command_style": "conversational",
    "explanation_style": "direct",
}

# Names a preference update may never touch, whatever it is called. Personality
# is not a channel for changing security posture.
PROTECTED_FIELDS = frozenset({
    "write_enabled", "write_confirm_required", "execute_enabled",
    "execute_confirm_required", "permission_mode", "allowed_roots",
    "file_manager_allowed_roots", "allowed_user_ids", "owner_user_ids",
    "capabilities", "security", "permissions", "budgets", "timeouts",
    "write_approval_ttl_seconds", "execute_approval_ttl_seconds",
    "context_total_max_chars", "autonomous", "auto_approve", "confirm",
})

# Rendered style hints. Short strings, because they ship on every request.
_LENGTH_HINT = {
    "brief": "Responde en pocas frases.",
    "balanced": "",
    "detailed": "Puedes extenderte cuando el detalle aporte.",
}

_DEPTH_HINT = {
    "low": "Evita jerga; explica los términos técnicos.",
    "normal": "",
    "high": "Asume nivel técnico alto; ve al grano técnico.",
}


@dataclass
class AssistantProfile:
    """The whole profile, assembled from its four separate parts."""

    personality: tuple[str, ...] = PERSONALITY
    behavioral_rules: tuple[str, ...] = BEHAVIORAL_RULES
    preferences: dict = field(default_factory=lambda: dict(DEFAULT_PREFERENCES))

    @property
    def identity_name(self) -> str:
        return IDENTITY.name

    def identity_block(self, runtime: str = "", model: str = "") -> str:
        return identity_prompt(runtime=runtime, model=model)

    def rules_block(self) -> str:
        """
        The constraints worth telling the model about.

        The full contract is behavioral_rules; this renders the subset that
        the model can actually violate. The rest are structural and are
        enforced whether or not the model has been told.
        """
        rules = [self.behavioral_rules[index] for index in _MODEL_FACING_RULES
                 if index < len(self.behavioral_rules)]

        return "Reglas:\n" + "\n".join(f"- {rule}" for rule in rules)

    def personality_block(self) -> str:
        """
        Style, stated as style.

        Kept to a handful of lines because it is paid for on every request and
        a long personality prompt crowds out the evidence that actually
        answers the question.
        """
        # Two traits, not five: style hints have sharply diminishing returns
        # in a prompt, and the rest of the personality is expressed by how the
        # rest of the system behaves rather than by describing it.
        lines = [f"- {trait}" for trait in self.personality[:2]]

        for hint in (_LENGTH_HINT.get(self.preferences.get("response_length", "")),
                     _DEPTH_HINT.get(self.preferences.get("technical_depth", ""))):
            if hint:
                lines.append(f"- {hint}")

        if self.preferences.get("language") == "en":
            lines.append("- Responde en inglés.")

        return "Estilo:\n" + "\n".join(lines)

    def prompt_block(self, runtime: str = "", model: str = "") -> str:
        """Identity, rules and style, in precedence order."""
        return "\n\n".join([
            self.identity_block(runtime=runtime, model=model),
            self.rules_block(),
            self.personality_block(),
        ])

    def sizes(self) -> dict:
        """What each part costs. Reported, not guessed."""
        identity = len(self.identity_block(runtime="Ollama",
                                           model=settings.default_model))
        rules = len(self.rules_block())
        personality = len(self.personality_block())

        return {
            "identity_chars": identity,
            "behavioral_rules_chars": rules,
            "personality_chars": personality,
            "total_chars": identity + rules + personality + 2,
            "estimated_tokens": round((identity + rules + personality) / 4),
        }


def validate_preference(name: str, value) -> tuple[str, str]:
    """
    Check one preference, or refuse it.

    Refusing loudly matters here: a silently dropped preference looks like the
    assistant ignoring the user, and a silently accepted unknown field is how
    a security setting ends up living in a personality store.
    """
    key = str(name or "").strip().lower()

    if not key:
        raise PreferenceError("La preferencia no tiene nombre.")

    if key in PROTECTED_FIELDS:
        raise PreferenceError(
            f"'{key}' es un ajuste de seguridad, no una preferencia de estilo. "
            f"Se cambia en .env, no hablando conmigo."
        )

    if key not in ALLOWED_PREFERENCES:
        raise PreferenceError(
            f"No conozco la preferencia '{key}'. "
            f"Existen: {', '.join(sorted(ALLOWED_PREFERENCES))}."
        )

    candidate = str(value or "").strip().lower()
    allowed = ALLOWED_PREFERENCES[key]

    if candidate not in allowed:
        raise PreferenceError(
            f"'{candidate}' no vale para {key}. Opciones: {', '.join(allowed)}."
        )

    return key, candidate


class ProfileStore:
    """
    Loads and saves the profile through the Memory Core.

    Best effort on read: an unavailable core yields the defaults rather than
    an error, because failing to load a style preference must never stop
    Iclirius from answering.
    """

    SECTION = "interaction"

    def __init__(self, core):
        self.core = core

    def load(self) -> AssistantProfile:
        preferences = dict(DEFAULT_PREFERENCES)

        try:
            stored = (self.core.get_profile() or {}).get(self.SECTION) or {}
        except Exception:
            logger.warning("Could not read the assistant profile", exc_info=False)
            stored = {}

        for name, value in stored.items():
            try:
                key, checked = validate_preference(name, value)
                preferences[key] = checked
            except PreferenceError:
                # Stored value no longer valid: fall back rather than refuse.
                continue

        return AssistantProfile(preferences=preferences)

    def set_preferences(self, updates: dict) -> dict:
        """
        Apply validated preferences and persist them.

        All-or-nothing: a batch with one bad field changes nothing, so a typo
        cannot half-apply.
        """
        if not updates:
            raise PreferenceError("No indicaste ninguna preferencia.")

        checked = {}

        for name, value in updates.items():
            key, candidate = validate_preference(name, value)
            checked[key] = candidate

        self.core.update_profile(self.SECTION, checked)

        return checked
