"""Authorized, deterministic file-content extraction and evidence.

The public extraction entry point accepts a FileRecord, never an arbitrary path.
File contents are untrusted data and are never executed or interpreted as policy.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import mimetypes
import re
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree

from app.evidence import Certainty, Coverage, EvidenceRecord, SourceType, certainty_for_coverage
from app.file_analysis import classification_for
from app.filesystem_evidence import FileRecord

EXTRACTED = "EXTRACTED"
PARTIALLY_EXTRACTED = "PARTIALLY_EXTRACTED"
UNSUPPORTED = "UNSUPPORTED"
FAILED = "FAILED"
EMPTY = "EMPTY"
TEXT_EXTENSIONS = {".txt", ".md", ".rst", ".log", ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".kt", ".kts", ".swift", ".c", ".h", ".cpp", ".cc", ".cxx", ".hpp", ".go", ".rs", ".sh", ".bash", ".zsh", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".html", ".css", ".sql", ".jsonl", ".json", ".xml", ".csv"}
MAX_DEFAULT_BYTES = 10 * 1024 * 1024
MAX_DEFAULT_CHARS = 200_000
MAX_DEFAULT_SEGMENTS = 10_000


@dataclass(frozen=True)
class ContentSegment:
    segment_id: str
    file_id: str
    location: dict
    text: str
    char_start: int
    char_end: int
    extractor: str
    coverage: str = "COMPLETE"

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True)
class FileContentRecord:
    content_id: str
    file_id: str
    node_id: str
    root_id: str
    relative_path: str
    content_type: str
    extractor: str
    extractor_version: str
    observed_at: str
    size_bytes: int | None
    modified_at: str | None
    characters_extracted: int
    truncated: bool
    state: str
    coverage: Coverage
    certainty: str
    warnings: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    segments: tuple[ContentSegment, ...] = ()
    structured: dict = field(default_factory=dict)
    stale: bool = False

    def to_dict(self):
        value = asdict(self)
        value["warnings"], value["errors"] = list(self.warnings), list(self.errors)
        value["segments"] = [segment.to_dict() for segment in self.segments]
        value["coverage"] = self.coverage.to_dict()
        return value


@dataclass(frozen=True)
class ContentSearchMatch:
    file_id: str
    relative_path: str
    segment_id: str
    location: dict
    matched_text: str
    observed_at: str
    extractor: str

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True)
class ContentSearchResult:
    query: str
    mode: str
    files_searched: int
    files_matched: int
    segments_matched: int
    coverage: Coverage
    matches: tuple[ContentSearchMatch, ...]
    extraction_ids: tuple[str, ...]
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def to_dict(self):
        value = asdict(self)
        value["coverage"] = self.coverage.to_dict()
        value["matches"] = [match.to_dict() for match in self.matches]
        value["extraction_ids"] = list(self.extraction_ids)
        return value


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _id(prefix: str, value: str) -> str:
    return prefix + hashlib.sha256(value.encode()).hexdigest()[:24]


def _safe_record_path(record: FileRecord) -> Path:
    """Revalidate the FileRecord scope before opening anything."""
    if not record.accessible or not record.is_file or record.is_symlink:
        raise PermissionError("file record is not an accessible regular file")
    path = Path(record.absolute_path).expanduser()
    root_parts = Path(record.absolute_path).parts[: -len(Path(record.relative_path).parts)] if record.relative_path != "." else Path(record.absolute_path).parts
    # FileRecord's absolute path was produced by FILE-1; reject traversal and
    # verify the relative identity without trusting caller-provided path text.
    if ".." in Path(record.relative_path).parts:
        raise PermissionError("relative path traversal")
    try:
        path = path.resolve(strict=True)
    except OSError as exc:
        raise FileNotFoundError(str(exc)) from exc
    if not path.is_file() or path.is_symlink():
        raise PermissionError("record no longer points to a regular file")
    return path


def _stale(record: FileRecord, path: Path) -> bool:
    try:
        stat = path.stat()
    except OSError:
        return True
    current_mtime = datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(timespec="seconds")
    return (record.size_bytes is not None and stat.st_size != record.size_bytes) or (record.modified_at and current_mtime != record.modified_at)


def _segments(record: FileRecord, text: str, extractor: str, *, max_segments: int) -> tuple[ContentSegment, ...]:
    result = []
    offset = 0
    for line_number, line in enumerate(text.splitlines(keepends=True), 1):
        value = line.rstrip("\r\n")
        end = offset + len(value)
        result.append(ContentSegment(_id("seg_", f"{record.file_id}:{line_number}:{offset}"), record.file_id,
                                     {"line": line_number}, value, offset, end, extractor))
        offset += len(line)
        if len(result) >= max_segments:
            break
    if not result and text:
        result.append(ContentSegment(_id("seg_", record.file_id), record.file_id, {}, text, 0, len(text), extractor))
    return tuple(result)


def _structured_segments(record: FileRecord, values: list[tuple[dict, str]], extractor: str, max_segments: int):
    segments = []
    for index, (location, value) in enumerate(values[:max_segments]):
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True)
        segments.append(ContentSegment(_id("seg_", f"{record.file_id}:{location}:{index}"), record.file_id, location, text, 0, len(text), extractor))
    return tuple(segments)


def _json_values(value, path="$", output=None):
    output = output or []
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{path}.{key}"
            output.append(({"json_path": child_path}, child if isinstance(child, str) else json.dumps(child, ensure_ascii=False, sort_keys=True)))
            _json_values(child, child_path, output)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            child_path = f"{path}[{index}]"
            output.append(({"json_path": child_path}, child if isinstance(child, str) else json.dumps(child, ensure_ascii=False, sort_keys=True)))
            _json_values(child, child_path, output)
    return output


def _xml_values(element, path="", output=None):
    output = output or []
    tag = element.tag.rsplit("}", 1)[-1]
    current = f"{path}/{tag}"
    if element.attrib:
        for key, value in element.attrib.items():
            output.append(({"xml_path": current, "attribute": key}, value))
    if (element.text or "").strip():
        output.append(({"xml_path": current}, element.text.strip()))
    for child in list(element):
        _xml_values(child, current, output)
    return output


def _result(record, *, content_type, extractor, observed_at, state, text="", structured=None,
            warnings=(), errors=(), segments=(), truncated=False, stale=False, scanned_items=1):
    coverage = Coverage(complete=state in {EXTRACTED, EMPTY}, scanned_items=scanned_items,
                        errors=len(errors), reason=state)
    certainty = certainty_for_coverage(coverage, observed=state not in {FAILED, UNSUPPORTED})
    return FileContentRecord(_id("content_", record.file_id + observed_at + extractor), record.file_id,
                             record.node_id, record.root_id, record.relative_path, content_type,
                             extractor, "1", observed_at, record.size_bytes, record.modified_at,
                             len(text), truncated, state, coverage, certainty, tuple(warnings), tuple(errors),
                             tuple(segments), structured or {}, stale)


def extract_file(record: FileRecord, *, observed_at: str | None = None, max_bytes: int = MAX_DEFAULT_BYTES,
                 max_chars: int = MAX_DEFAULT_CHARS, max_segments: int = MAX_DEFAULT_SEGMENTS) -> FileContentRecord:
    observed_at = observed_at or _now()
    try:
        path = _safe_record_path(record)
    except FileNotFoundError as exc:
        return _result(record, content_type="unknown", extractor="authorized-reader", observed_at=observed_at, state=FAILED, errors=(type(exc).__name__,))
    except PermissionError as exc:
        return _result(record, content_type="unknown", extractor="authorized-reader", observed_at=observed_at, state=FAILED, errors=(str(exc),))
    stale = _stale(record, path)
    try:
        size = path.stat().st_size
        if size > max_bytes:
            return _result(record, content_type="unknown", extractor="authorized-reader", observed_at=observed_at, state=PARTIALLY_EXTRACTED, warnings=("max_bytes_reached",), truncated=True, stale=stale)
        raw = path.read_bytes()
    except OSError as exc:
        return _result(record, content_type="unknown", extractor="authorized-reader", observed_at=observed_at, state=FAILED, errors=(type(exc).__name__,), stale=stale)
    ext = Path(record.name).suffix.casefold()
    extractor = f"file-{ext.lstrip('.') or 'binary'}"
    if ext in {".zip", ".tar", ".gz", ".7z", ".rar", ".exe", ".bin"}:
        return _result(record, content_type="binary", extractor=extractor, observed_at=observed_at, state=UNSUPPORTED, stale=stale)
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(raw))
            segments, pages, failed = [], 0, 0
            for page_number, page in enumerate(reader.pages, 1):
                try:
                    value = page.extract_text() or ""
                    if value.strip():
                        segments.append(ContentSegment(_id("seg_", f"{record.file_id}:page:{page_number}"), record.file_id, {"page": page_number}, value, 0, len(value), "pypdf"))
                    pages += 1
                except Exception:
                    failed += 1
            text = "\n".join(segment.text for segment in segments)[:max_chars]
            state = EXTRACTED if pages and not failed and text.strip() else PARTIALLY_EXTRACTED if failed else UNSUPPORTED
            warnings = ("image_only_or_no_extractable_text",) if not text.strip() else ()
            return _result(record, content_type="pdf", extractor="pypdf", observed_at=observed_at, state=state,
                           text=text, segments=tuple(segments[:max_segments]), warnings=warnings, stale=stale, truncated=len(text) >= max_chars)
        except Exception as exc:
            return _result(record, content_type="pdf", extractor="pypdf", observed_at=observed_at, state=FAILED, errors=(type(exc).__name__,), stale=stale)
    if ext == ".docx":
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                xml = archive.read("word/document.xml")
            root = ElementTree.fromstring(xml)
            paragraphs = []
            for index, paragraph in enumerate(root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p")):
                text = "".join(node.text or "" for node in paragraph.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"))
                if text: paragraphs.append(ContentSegment(_id("seg_", f"{record.file_id}:paragraph:{index}"), record.file_id, {"paragraph": index}, text, 0, len(text), "docx-xml"))
            text = "\n".join(segment.text for segment in paragraphs)[:max_chars]
            return _result(record, content_type="docx", extractor="docx-xml", observed_at=observed_at, state=EXTRACTED if text else EMPTY, text=text, segments=tuple(paragraphs[:max_segments]), stale=stale, truncated=len(text) >= max_chars)
        except Exception as exc:
            return _result(record, content_type="docx", extractor="docx-xml", observed_at=observed_at, state=FAILED, errors=(type(exc).__name__,), stale=stale)
    if ext in TEXT_EXTENSIONS or record.mime_type and record.mime_type.startswith("text/"):
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text = raw.decode("utf-8", errors="replace")
            except Exception as exc:
                return _result(record, content_type="text", extractor="text-utf8", observed_at=observed_at, state=FAILED, errors=(type(exc).__name__,), stale=stale)
        truncated = len(text) > max_chars
        text = text[:max_chars]
        if ext == ".json":
            try:
                value = json.loads(text)
                return _result(record, content_type="json", extractor="json-stdlib", observed_at=observed_at, state=EMPTY if not text else (PARTIALLY_EXTRACTED if truncated else EXTRACTED), text=text, structured={"root_type": type(value).__name__}, segments=_structured_segments(record, _json_values(value), "json-stdlib", max_segments), truncated=truncated, stale=stale)
            except json.JSONDecodeError as exc:
                return _result(record, content_type="json", extractor="json-stdlib", observed_at=observed_at, state=FAILED, errors=(f"JSONDecodeError:{exc.lineno}",), stale=stale)
        if ext == ".xml":
            try:
                root = ElementTree.fromstring(text)
                values = _xml_values(root)
                return _result(record, content_type="xml", extractor="xml-stdlib", observed_at=observed_at, state=PARTIALLY_EXTRACTED if truncated else EXTRACTED, text=text, structured={"root_element": root.tag, "namespaces": sorted({node.tag.split("}", 1)[0][1:] for node in root.iter() if "}" in node.tag})}, segments=_structured_segments(record, values, "xml-stdlib", max_segments), truncated=truncated, stale=stale)
            except ElementTree.ParseError as exc:
                return _result(record, content_type="xml", extractor="xml-stdlib", observed_at=observed_at, state=FAILED, errors=(f"XMLParseError:{exc.position[0]}",), stale=stale)
        if ext == ".csv":
            try:
                rows = list(csv.reader(io.StringIO(text), strict=True))
                headers = rows[0] if rows else []
                segments = tuple(ContentSegment(_id("seg_", f"{record.file_id}:row:{i}"), record.file_id, {"row": i, "columns": len(row)}, ",".join(row), 0, len(",".join(row)), "csv-stdlib") for i, row in enumerate(rows[:max_segments], 1))
                return _result(record, content_type="csv", extractor="csv-stdlib", observed_at=observed_at, state=EMPTY if not rows else (PARTIALLY_EXTRACTED if truncated else EXTRACTED), text=text[:max_chars], structured={"headers": headers, "row_count": max(0, len(rows) - 1), "column_count": max((len(row) for row in rows), default=0)}, segments=segments, truncated=truncated, stale=stale)
            except csv.Error as exc:
                return _result(record, content_type="csv", extractor="csv-stdlib", observed_at=observed_at, state=FAILED, errors=(str(exc),), stale=stale)
        return _result(record, content_type="source_code" if classification_for(record)["family"] not in {"unknown", "directory"} else "text", extractor="text-utf8", observed_at=observed_at, state=EMPTY if not text else (PARTIALLY_EXTRACTED if truncated else EXTRACTED), text=text, segments=_segments(record, text, "text-utf8", max_segments=max_segments), truncated=truncated, stale=stale)
    return _result(record, content_type="binary", extractor=extractor, observed_at=observed_at, state=UNSUPPORTED, stale=stale)


def content_evidence(content: FileContentRecord) -> EvidenceRecord:
    return EvidenceRecord(SourceType.FILESYSTEM.value, "file_content", content.relative_path, content.to_dict(), content.coverage,
                           content.certainty, evidence_id=content.content_id, observed_at=content.observed_at,
                           provenance={"file_id": content.file_id, "root_id": content.root_id, "node_id": content.node_id,
                                       "relative_path": content.relative_path, "state": content.state, "extractor": content.extractor,
                                       "stale": content.stale}, node_id=content.node_id, tool_id="file_evidence",
                           errors=content.errors, warnings=content.warnings)


def search_content(records: list[FileContentRecord] | tuple[FileContentRecord, ...], query: str, *, mode="exact", max_matches=1000) -> ContentSearchResult:
    if not query:
        raise ValueError("query is required")
    terms = [query] if mode in {"exact", "case_insensitive"} else query.split()
    terms = [term for term in terms if term]
    matches = []
    for record in records:
        for segment in record.segments:
            haystack = segment.text if mode == "exact" else segment.text.casefold()
            needles = terms if mode == "exact" else [term.casefold() for term in terms]
            if mode in {"exact", "case_insensitive"}:
                hit = needles[0] in haystack
            elif mode == "and":
                hit = all(term in haystack.casefold() for term in needles)
            elif mode == "or":
                hit = any(term in haystack.casefold() for term in needles)
            elif mode == "token":
                hit = all(re.search(r"\b" + re.escape(term) + r"\b", haystack, re.IGNORECASE) for term in terms)
            else:
                raise ValueError(f"unknown search mode: {mode}")
            if hit:
                matches.append(ContentSearchMatch(record.file_id, record.relative_path, segment.segment_id, segment.location, segment.text, record.observed_at, record.extractor))
                if len(matches) >= max_matches:
                    break
    coverage = Coverage(complete=all(record.state in {EXTRACTED, EMPTY} and not record.stale for record in records), scanned_items=len(records), errors=sum(len(record.errors) for record in records), reason="content_search")
    return ContentSearchResult(query, mode, len(records), len({match.file_id for match in matches}), len(matches), coverage, tuple(matches), tuple(record.content_id for record in records), tuple(error for record in records for error in record.errors))


def json_path_values(content: FileContentRecord, path: str):
    return [segment.text for segment in content.segments if segment.location.get("json_path") == path]


def xml_path_values(content: FileContentRecord, path: str):
    return [segment.text for segment in content.segments if segment.location.get("xml_path") == path]


def csv_column_total(content: FileContentRecord, column: str | int) -> float:
    rows = [segment.text.split(",") for segment in content.segments]
    if not rows:
        return 0.0
    index = rows[0].index(str(column)) if isinstance(column, str) and str(column) in rows[0] else int(column)
    return sum(float(row[index]) for row in rows[1:] if len(row) > index and row[index].strip())
