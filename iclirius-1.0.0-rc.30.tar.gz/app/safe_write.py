"""
The first capability that can change a file.

    MODEL PROPOSES CHANGE.
    ICLIRIUS VALIDATES CHANGE.
    LOCAL EXECUTOR APPLIES CHANGE.

A model produces a PatchProposal: structured data describing exact text to
replace. It cannot open a file, call write_text, spawn a process or run a
shell; the executor here is the only thing that touches the filesystem, and it
only ever acts on a proposal that survived every check below.

Changes are anchored replacements rather than a unified diff. A diff applies by
line position and drifts silently when the file moved on; an anchored change
carries the exact original text and how many times it must occur, so a stale or
ambiguous edit fails loudly instead of corrupting the file.

Three properties matter most:

  - Write is strictly narrower than read. Everything readable is not writable:
    secrets, the encrypted vault, git internals and non-text files are refused
    even when the same path would be readable.

  - Stale writes are impossible. The file is fingerprinted when the proposal is
    made and again immediately before applying. Any change in between aborts,
    so a human edit is never silently overwritten.

  - Nothing is half-applied. Every file is validated before the first byte is
    written, and a failure mid-way rolls the earlier files back from content
    held in memory.
"""

from __future__ import annotations

import hashlib
import os
import tempfile
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path

from app.config import settings
from app.file_catalog import validate_safe_path
from app.logger import logger

# Text formats a code assistant has business editing. Everything else,
# including images, archives, databases and anything encrypted, is refused.
WRITABLE_SUFFIXES = {
    ".py", ".kt", ".kts", ".java", ".swift", ".m", ".mm",
    ".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs",
    ".c", ".h", ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb", ".php",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".properties",
    ".md", ".rst", ".txt", ".xml", ".html", ".css", ".scss",
    ".gradle", ".sql", ".sh", ".bash", ".zsh", ".gitignore",
}

# Path components that are never writable, whatever the read policy allows.
WRITE_BLOCKED_PARTS = {
    ".git", ".ssh", ".gnupg", ".config", ".venv", "venv", "node_modules",
    "__pycache__", "Keychains", "data", "logs", "site-packages",
}

# Filenames that are never writable even inside an otherwise editable tree.
WRITE_BLOCKED_NAMES = {
    ".env", ".env.local", ".env.production", ".env.example",
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "authorized_keys",
    "known_hosts", "credentials", ".netrc", ".pgpass", ".htpasswd",
}


class PatchStatus(str, Enum):
    PROPOSED = "PROPOSED"
    VALIDATED = "VALIDATED"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    APPROVED = "APPROVED"
    DENIED = "DENIED"
    APPLIED = "APPLIED"
    VERIFIED_DIFF = "VERIFIED_DIFF"
    REJECTED = "REJECTED"
    STALE = "STALE"
    FAILED = "FAILED"
    EXPIRED = "EXPIRED"


class Risk(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class WriteError(RuntimeError):
    """Raised when a patch cannot be accepted or applied."""


class PatchValidationError(WriteError):
    """Raised when a proposal fails validation."""


class StalePatchError(WriteError):
    """Raised when the file changed after the proposal was made."""


class WriteDisabledError(WriteError):
    """Raised when write capability is switched off."""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def fingerprint(text: str) -> str:
    """Content hash. Comparing these is how a stale write is caught."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def fingerprint_file(path: Path) -> str:
    try:
        return fingerprint(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError):
        return ""


# --- model ----------------------------------------------------------------


@dataclass
class Change:
    """One anchored replacement inside one file."""

    original: str
    replacement: str
    expected_occurrences: int = 1
    context_before: str = ""
    context_after: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def added_chars(self) -> int:
        return max(0, len(self.replacement) - len(self.original))

    @property
    def removed_chars(self) -> int:
        return max(0, len(self.original) - len(self.replacement))

    @property
    def changed_lines(self) -> int:
        return max(self.original.count("\n"), self.replacement.count("\n")) + 1


@dataclass
class FileChange:
    target_path: str
    changes: list[Change] = field(default_factory=list)
    base_fingerprint: str = ""
    operation: str = "APPLY_PATCH"
    new_content: str = ""

    def to_dict(self) -> dict:
        return {
            "target_path": self.target_path,
            "changes": [change.to_dict() for change in self.changes],
            "base_fingerprint": self.base_fingerprint,
            "operation": self.operation,
        }

    @property
    def added_lines(self) -> int:
        return sum(change.replacement.count("\n") + 1 for change in self.changes)

    @property
    def removed_lines(self) -> int:
        return sum(change.original.count("\n") + 1 for change in self.changes)


@dataclass
class PatchProposal:
    patch_id: str
    task_id: str | None = None
    project_id: str | None = None
    files: list[FileChange] = field(default_factory=list)
    reason: str = ""
    risk: str = Risk.MEDIUM.value
    status: str = PatchStatus.PROPOSED.value
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "patch_id": self.patch_id,
            "task_id": self.task_id,
            "project_id": self.project_id,
            "files": [f.to_dict() for f in self.files],
            "reason": self.reason,
            "risk": self.risk,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "error": self.error,
        }

    def mark(self, status: str, error: str = "") -> "PatchProposal":
        self.status = status
        self.error = error[:300]
        self.updated_at = _now()
        return self

    @property
    def added_lines(self) -> int:
        return sum(f.added_lines for f in self.files)

    @property
    def removed_lines(self) -> int:
        return sum(f.removed_lines for f in self.files)

    def summary(self) -> dict:
        """Metadata only. Never the diff body."""
        return {
            "patch_id": self.patch_id,
            "status": self.status,
            "risk": self.risk,
            "files": [Path(f.target_path).name for f in self.files],
            "file_count": len(self.files),
            "added_lines": self.added_lines,
            "removed_lines": self.removed_lines,
            "reason": self.reason[:160],
            "created_at": self.created_at,
        }

    def preview(self, max_chars: int | None = None) -> str:
        """A bounded, human-readable preview. Not the whole file."""
        limit = max_chars or settings.write_preview_chars
        lines = [
            f"Cambio propuesto ({self.risk}): {self.reason[:160]}",
            f"Archivos: {len(self.files)} | +{self.added_lines} / -{self.removed_lines} líneas",
            "",
        ]

        for file_change in self.files:
            name = Path(file_change.target_path).name
            lines.append(f"--- {name} ({file_change.operation})")

            for change in file_change.changes[:3]:
                for row in change.original.splitlines()[:4]:
                    lines.append(f"  - {row[:100]}")
                for row in change.replacement.splitlines()[:4]:
                    lines.append(f"  + {row[:100]}")
                lines.append("")

        return "\n".join(lines)[:limit]


# --- path policy ----------------------------------------------------------


def validate_write_path(path: str | Path) -> Path:
    """
    Write policy: everything read requires, plus more.

    The read validator already enforces the allowed roots, resolves symlinks
    and blocks secrets. This adds the rules that only matter when writing.
    """
    target = validate_safe_path(path)

    lowered_parts = {part.lower() for part in target.parts}

    for blocked in WRITE_BLOCKED_PARTS:
        if blocked.lower() in lowered_parts:
            raise PatchValidationError(
                f"No se puede escribir dentro de {blocked}: {target.name}"
            )

    if target.name.lower() in {name.lower() for name in WRITE_BLOCKED_NAMES}:
        raise PatchValidationError(f"Archivo no editable: {target.name}")

    if target.suffix.lower() not in WRITABLE_SUFFIXES:
        raise PatchValidationError(
            f"Extensión no editable: {target.suffix or '(sin extensión)'}"
        )

    return target


# --- validation -----------------------------------------------------------


def _read_text(target: Path) -> str:
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise PatchValidationError(f"No pude leer {target.name}: {exc}") from exc

    if len(raw) > settings.write_max_file_bytes:
        raise PatchValidationError(
            f"{target.name} supera el tamaño máximo editable "
            f"({len(raw)} > {settings.write_max_file_bytes} bytes)."
        )

    if b"\x00" in raw[:4096]:
        raise PatchValidationError(f"{target.name} parece binario.")

    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PatchValidationError(f"{target.name} no es UTF-8 válido.") from exc


def _apply_change(text: str, change: Change, index: int, name: str) -> str:
    """
    Replace exactly the occurrence the change means.

    A repeated anchor is the dangerous case: picking the first match would
    quietly edit the wrong line. When context_before or context_after is
    given, the anchor plus its surroundings must be unique; without them a
    repeated anchor is refused outright. There is no first-match-wins.
    """
    found = text.count(change.original)

    if found == 0:
        raise PatchValidationError(
            f"El texto original del cambio {index} no aparece en {name}."
        )

    if change.context_before or change.context_after:
        anchored = f"{change.context_before}{change.original}{change.context_after}"
        anchored_found = text.count(anchored)

        if anchored_found == 1:
            replacement = (
                f"{change.context_before}{change.replacement}{change.context_after}"
            )
            return text.replace(anchored, replacement, 1)

        if anchored_found == 0:
            raise PatchValidationError(
                f"El contexto del cambio {index} no coincide en {name}."
            )

        raise PatchValidationError(
            f"El cambio {index} sigue siendo ambiguo en {name}: "
            f"{anchored_found} coincidencias incluso con contexto."
        )

    if found == 1 and change.expected_occurrences == 1:
        return text.replace(change.original, change.replacement, 1)

    if found != change.expected_occurrences:
        raise PatchValidationError(
            f"El cambio {index} de {name} esperaba "
            f"{change.expected_occurrences} coincidencia(s) y hay {found}. "
            f"Usa context_before/context_after para desambiguar."
        )

    return text.replace(change.original, change.replacement)


def validate_file_change(file_change: FileChange) -> tuple[Path, str, str]:
    """
    Check one file and compute its result without writing anything.

    Returns (path, original_text, new_text). Raises on any problem, so a
    caller can validate every file before the first byte is written.
    """
    target = validate_write_path(file_change.target_path)

    if file_change.operation == "CREATE_TEXT_FILE":
        if target.exists():
            raise PatchValidationError(
                f"{target.name} ya existe. Crear no puede sobrescribir."
            )

        if not target.parent.is_dir():
            raise PatchValidationError(f"La carpeta destino no existe: {target.parent}")

        content = file_change.new_content

        if len(content.encode("utf-8")) > settings.write_max_file_bytes:
            raise PatchValidationError("El contenido nuevo supera el tamaño máximo.")

        return target, "", content

    if not target.is_file():
        raise PatchValidationError(f"No existe el archivo: {target}")

    original = _read_text(target)

    # Stale check: the file must be exactly what the proposal was built from.
    if file_change.base_fingerprint:
        current = fingerprint(original)
        if current != file_change.base_fingerprint:
            raise StalePatchError(
                f"{target.name} cambió desde que se propuso el patch. No lo sobrescribo."
            )

    if not file_change.changes:
        raise PatchValidationError(f"El patch para {target.name} no tiene cambios.")

    if len(file_change.changes) > settings.write_max_patches_per_file:
        raise PatchValidationError(
            f"Demasiados cambios en {target.name}: {len(file_change.changes)} > "
            f"{settings.write_max_patches_per_file}."
        )

    updated = original

    for index, change in enumerate(file_change.changes, start=1):
        if not change.original:
            raise PatchValidationError(
                f"El cambio {index} de {target.name} no indica el texto original."
            )

        updated = _apply_change(updated, change, index, target.name)

    if updated == original:
        raise PatchValidationError(f"El patch no cambia nada en {target.name}.")

    if len(updated.encode("utf-8")) > settings.write_max_file_bytes:
        raise PatchValidationError(f"{target.name} quedaría por encima del tamaño máximo.")

    return target, original, updated


def validate_proposal(proposal: PatchProposal) -> list[tuple[Path, str, str]]:
    """
    Validate every file before any write.

    This is what makes multi-file safe: if one file is stale or blocked, the
    whole proposal is refused and nothing has been touched.
    """
    if not settings.write_enabled:
        raise WriteDisabledError(
            "La escritura está desactivada. Actívala con WRITE_ENABLED=true en .env."
        )

    if not proposal.files:
        raise PatchValidationError("El patch no incluye archivos.")

    if len(proposal.files) > settings.write_max_files_per_interaction:
        raise PatchValidationError(
            f"Demasiados archivos: {len(proposal.files)} > "
            f"{settings.write_max_files_per_interaction}."
        )

    if proposal.added_lines + proposal.removed_lines > settings.write_max_changed_lines:
        raise PatchValidationError(
            f"El patch cambia demasiadas líneas "
            f"({proposal.added_lines + proposal.removed_lines} > "
            f"{settings.write_max_changed_lines})."
        )

    added = sum(c.added_chars for f in proposal.files for c in f.changes)
    removed = sum(c.removed_chars for f in proposal.files for c in f.changes)

    if added > settings.write_max_added_chars:
        raise PatchValidationError(f"El patch añade demasiado texto ({added} chars).")

    if removed > settings.write_max_removed_chars:
        raise PatchValidationError(f"El patch elimina demasiado texto ({removed} chars).")

    seen: set[str] = set()
    resolved = []

    for file_change in proposal.files:
        target, original, updated = validate_file_change(file_change)

        if str(target) in seen:
            raise PatchValidationError(f"El mismo archivo aparece dos veces: {target.name}")

        seen.add(str(target))
        resolved.append((target, original, updated))

    return resolved


# --- atomic write ---------------------------------------------------------


def write_atomically(target: Path, content: str) -> None:
    """
    Replace a file without ever leaving it half-written.

    The temporary file lives in the same directory so os.replace is a rename
    within one filesystem, which is atomic. The original mode is preserved,
    and a failure anywhere leaves the original untouched.
    """
    directory = target.parent
    mode = None

    if target.exists():
        try:
            mode = target.stat().st_mode & 0o777
        except OSError:
            mode = None

    handle, temp_name = tempfile.mkstemp(dir=str(directory), prefix=".openclaw-", suffix=".tmp")
    temp_path = Path(temp_name)

    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())

        if mode is not None:
            os.chmod(temp_path, mode)

        os.replace(temp_path, target)
    except Exception:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass
        raise


def apply_proposal(proposal: PatchProposal) -> dict:
    """
    Apply a validated proposal, revalidating first.

    Revalidation is not paranoia: time passes between proposing, previewing
    and approving, and the file may have moved on. On a mid-way failure the
    already-written files are restored from the originals held in memory.
    """
    resolved = validate_proposal(proposal)

    written: list[tuple[Path, str]] = []

    try:
        for target, original, updated in resolved:
            write_atomically(target, updated)
            written.append((target, original))
    except Exception as exc:
        for target, original in reversed(written):
            try:
                if original:
                    write_atomically(target, original)
                elif target.exists():
                    # A file we had just created: removing it restores the
                    # tree to the state before the proposal.
                    target.unlink()
            except Exception:
                logger.exception("Rollback failed for %s", target.name)

        proposal.mark(PatchStatus.FAILED.value, str(exc))
        raise WriteError(f"No pude aplicar el patch: {exc}") from exc

    results = []

    for (target, original, updated), file_change in zip(resolved, proposal.files):
        results.append({
            "target": str(target),
            "name": target.name,
            "base_fingerprint": file_change.base_fingerprint,
            "new_fingerprint": fingerprint(updated),
            "verified": target.read_text(encoding="utf-8") == updated,
        })

    proposal.mark(PatchStatus.APPLIED.value)

    return {"files": results, "applied": len(results)}


def build_proposal(files: list[FileChange], reason: str = "",
                   task_id: str | None = None, project_id: str | None = None,
                   risk: str = Risk.MEDIUM.value) -> PatchProposal:
    """Create a proposal, fingerprinting each existing target as it stands now."""
    for file_change in files:
        if file_change.operation != "CREATE_TEXT_FILE" and not file_change.base_fingerprint:
            try:
                target = validate_write_path(file_change.target_path)
                if target.is_file():
                    file_change.base_fingerprint = fingerprint_file(target)
            except (PatchValidationError, PermissionError, RuntimeError):
                # Left empty on purpose: validation will refuse it properly
                # and with a better message than we could give here.
                pass

    return PatchProposal(
        patch_id=f"patch_{uuid.uuid4().hex[:10]}",
        task_id=task_id,
        project_id=project_id,
        files=files,
        reason=reason[: settings.memory_fact_chars],
        risk=risk,
    )
