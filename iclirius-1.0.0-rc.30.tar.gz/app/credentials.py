"""
References to secrets, never secrets.

The rule this module exists to enforce: nothing durable in OpenClaw holds an
API key. Memory, tasks, runtime snapshots, events, logs and usage records hold
a *reference* — a string that says where a secret lives — and the value itself
is fetched at the moment of a request and dropped again.

    credential_ref = "keychain:openclaw/gemini-primary"
    credential_ref = "env:GEMINI_API_KEY"

A reference is safe to write down, safe to show in a status view and safe to
put in an event. The value is none of those things.

Two backends. The Keychain is the recommended one on macOS and reuses the same
`security` command the memory encryption key already uses, so there is one way
secrets are stored rather than two. The environment backend exists for
development and tests; it is documented as such and still only stores the
reference in runtime state.

Python cannot promise a secret is scrubbed from memory — strings are immutable
and the interpreter may have copied one anywhere — so this module does not
pretend to. What it does promise is narrower and actually achievable: the
value is never returned into anything that persists, and every error message
that could carry it is scrubbed before it leaves.
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import asdict, dataclass
from enum import Enum

from app.logger import logger

KEYCHAIN_TIMEOUT = 10


class CredentialError(RuntimeError):
    """A credential could not be resolved."""


class CredentialNotConfigured(CredentialError):
    """No reference was configured at all."""


class AuthType(str, Enum):
    API_KEY = "API_KEY"
    # Declared for later. No adapter uses one and nothing here implements a
    # token exchange.
    OAUTH = "OAUTH"
    NONE = "NONE"


class CredentialStatus(str, Enum):
    CONFIGURED = "CONFIGURED"
    MISSING = "MISSING"
    UNREADABLE = "UNREADABLE"
    NOT_REQUIRED = "NOT_REQUIRED"


@dataclass(frozen=True)
class CredentialRef:
    """
    Where a secret lives, and who it belongs to. Never what it is.

    This is the object that travels: into provider configuration, into account
    records, into anything a UI might render. It is safe precisely because
    resolving it is a separate, deliberate step.
    """

    provider_id: str
    account_ref: str
    credential_ref: str = ""
    auth_type: str = AuthType.API_KEY.value

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def backend(self) -> str:
        """`keychain`, `env`, or empty when nothing is configured."""
        if not self.credential_ref or ":" not in self.credential_ref:
            return ""

        return self.credential_ref.split(":", 1)[0].strip().lower()

    @property
    def locator(self) -> str:
        if ":" not in self.credential_ref:
            return ""

        return self.credential_ref.split(":", 1)[1].strip()

    def safe_summary(self) -> dict:
        """
        For status views and events.

        The backend and the account label are useful and harmless; the locator
        is not included because a Keychain service name can describe an
        account structure the owner may not want on a screen.
        """
        return {
            "provider_id": self.provider_id,
            "account_ref": self.account_ref,
            "auth_type": self.auth_type,
            "credential_backend": self.backend or "none",
            "configured": bool(self.credential_ref),
        }


# --- redaction ------------------------------------------------------------
#
# Cloud errors are the realistic leak. A provider can echo the request URL,
# and an API key is often a query parameter; a stack trace then carries it
# into a log, an event and a bug report.

_KEY_SHAPES = [
    re.compile(r"\bAIza[0-9A-Za-z_\-]{20,}"),                 # google api key
    re.compile(r"\bsk-[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\b(?:key|api[_-]?key|token|secret|password)=[^\s&\"']{6,}",
               re.IGNORECASE),
    re.compile(r"\bBearer\s+[A-Za-z0-9._\-]{12,}", re.IGNORECASE),
]

_REDACTED = "[redacted]"


def redact(text: str, *extra_secrets: str) -> str:
    """
    Remove anything key-shaped, plus specific values the caller knows about.

    The extra arguments matter: a short or unusually formatted key would slip
    past the patterns, and the one place that knows the exact value is the
    code that just used it.
    """
    cleaned = str(text or "")

    for secret in extra_secrets:
        if secret and len(secret) >= 8:
            cleaned = cleaned.replace(secret, _REDACTED)

    for pattern in _KEY_SHAPES:
        cleaned = pattern.sub(_REDACTED, cleaned)

    return cleaned


class CredentialStore:
    """
    Resolves references. Cannot enumerate secrets.

    There is deliberately no `list_all` and no `get_by_index`: the store
    answers a question about one named reference and nothing more, so a bug
    elsewhere cannot walk it.
    """

    def exists(self, ref: CredentialRef) -> bool:
        return self.status(ref) is CredentialStatus.CONFIGURED

    def status(self, ref: CredentialRef) -> CredentialStatus:
        """Whether it can be resolved, without returning the value."""
        if ref.auth_type == AuthType.NONE.value:
            return CredentialStatus.NOT_REQUIRED

        if not ref.credential_ref:
            return CredentialStatus.MISSING

        try:
            value = self._resolve_raw(ref)
        except CredentialError:
            return CredentialStatus.UNREADABLE

        return CredentialStatus.CONFIGURED if value else CredentialStatus.MISSING

    def metadata(self, ref: CredentialRef) -> dict:
        """Safe description. Never the value, never the locator."""
        return {**ref.safe_summary(), "status": self.status(ref).value}

    def resolve(self, ref: CredentialRef) -> str:
        """
        Fetch the value for immediate use.

        Callers must use it for one request and let it go: not stored on an
        object that outlives the call, not put in a dataclass, not logged.
        """
        if ref.auth_type == AuthType.NONE.value:
            return ""

        if not ref.credential_ref:
            raise CredentialNotConfigured(
                f"No hay credencial configurada para {ref.account_ref}."
            )

        value = self._resolve_raw(ref)

        if not value:
            raise CredentialNotConfigured(
                f"La credencial de {ref.account_ref} está vacía o no existe."
            )

        return value

    def store(self, ref: CredentialRef, value: str) -> None:
        """Store one secret in its named backend; never writes a token file."""
        if ref.auth_type == AuthType.NONE.value or not ref.credential_ref:
            raise CredentialNotConfigured("No hay referencia de credencial configurada.")
        if ref.backend != "keychain":
            raise CredentialError("Solo se permite almacenar credenciales en Keychain.")
        locator = ref.locator
        service, account = (locator.split("/", 1) if "/" in locator else (locator, ref.account_ref))
        if not service or not account:
            raise CredentialError("La referencia de Keychain no es válida.")
        try:
            result = subprocess.run(
                ["security", "add-generic-password", "-U", "-s", service,
                 "-a", account, "-w", value],
                capture_output=True, text=True, timeout=KEYCHAIN_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError):
            raise CredentialError("No pude guardar la credencial en Keychain.") from None
        if result.returncode != 0:
            raise CredentialError("No pude guardar la credencial en Keychain.")

    def delete(self, ref: CredentialRef) -> None:
        """Delete only the named credential; absence is idempotent."""
        if not ref.credential_ref or ref.backend != "keychain":
            return
        locator = ref.locator
        service, account = (locator.split("/", 1) if "/" in locator else (locator, ref.account_ref))
        try:
            subprocess.run(
                ["security", "delete-generic-password", "-s", service, "-a", account],
                capture_output=True, text=True, timeout=KEYCHAIN_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError):
            raise CredentialError("No pude eliminar la credencial de Keychain.") from None

    def _resolve_raw(self, ref: CredentialRef) -> str:
        backend = ref.backend

        if backend == "keychain":
            return self._from_keychain(ref)

        if backend == "env":
            return os.environ.get(ref.locator, "").strip()

        raise CredentialError(
            f"Backend de credenciales desconocido: '{backend or ref.credential_ref}'. "
            f"Usa keychain:servicio/cuenta o env:VARIABLE."
        )

    @staticmethod
    def _from_keychain(ref: CredentialRef) -> str:
        """
        Read from the macOS Keychain, the same way the memory key is read.

        The locator is `service/account`; without a slash the account defaults
        to the account_ref, which is the common case.
        """
        locator = ref.locator

        if "/" in locator:
            service, account = locator.split("/", 1)
        else:
            service, account = locator, ref.account_ref

        if not service:
            raise CredentialError("La referencia de Keychain no indica servicio.")

        try:
            result = subprocess.run(
                ["security", "find-generic-password",
                 "-s", service, "-a", account, "-w"],
                capture_output=True, text=True, timeout=KEYCHAIN_TIMEOUT,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            # The exception text could echo the command; scrub before it moves.
            raise CredentialError(
                redact(f"No pude leer el Keychain: {type(exc).__name__}")) from None

        if result.returncode != 0:
            # stderr from `security` names the item, not the secret, but it is
            # scrubbed anyway rather than trusted.
            logger.info("Keychain lookup failed for account_ref=%s", ref.account_ref)
            return ""

        return result.stdout.strip()


credential_store = CredentialStore()
