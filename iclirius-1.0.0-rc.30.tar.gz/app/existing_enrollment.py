"""Transactional second-machine enrollment orchestration."""

from __future__ import annotations

import os
from pathlib import Path

from app import local_auth
from app.config import settings
from app.memory_enrollment import EnrollmentError, prepare, provision_keychain, recover, verify_memory_key
from app.memory_home import load
from app.node_identity import ensure_node
from app.secure_storage import SecureStorageError
from app.touch_id import availability


def enroll_machine(home_path: str | Path, recovery_passphrase: str, *,
                   local_passphrase: str | None = None) -> dict:
    """Enroll this machine after cryptographically validating an existing home.

    All validation precedes machine-state writes.  The shared Memory Home is
    never changed by this operation.
    """
    home = load(home_path)
    key = recover(home, recovery_passphrase)
    if not verify_memory_key(home, key):
        raise EnrollmentError("Unable to decrypt this Memory Home.")
    # The local credential defaults to the already validated recovery phrase;
    # it is hashed into a new machine-local verifier and is never persisted.
    credential = local_passphrase or recovery_passphrase
    if len(credential) < local_auth.MIN_PASSWORD_CHARS:
        raise EnrollmentError("Recovery passphrase is too short for local authentication.")
    node_path = Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser() / "node.json"
    had_node = node_path.exists()
    existing_node = None
    if had_node:
        from app.node_identity import read_node
        existing_node = read_node()
    auth_path = local_auth.auth_path()
    old_auth = auth_path.read_bytes() if auth_path.exists() else None
    from app.setup import ENV_PATH
    old_env = ENV_PATH.read_bytes() if ENV_PATH.exists() else None
    try:
        provision_keychain(key)
        touch = availability(compile_if_missing=True)
        local_auth.enroll(home.user_id, home.primary_identity, credential, credential,
                          touch_status=touch)
        node = ensure_node()
        from app.setup import _write_env
        _write_env({
            "ICLIRIUS_SETUP_COMPLETE": "true",
            "ICLIRIUS_USER_ID": home.user_id,
            "PRINCIPAL_USER_NAME": home.primary_identity,
            "MEMORY_HOME": str(home.root),
            "IDENTITY_PATH": str(home.profile_path),
            "MEMORY_PATH": str(home.memory_path),
            "MEMORY_ROOT": str(home.core_path),
            "OPENCLAW_NODE_ID": str(node["node_id"]),
        })
    except Exception as exc:
        # The setup-complete marker is written last.  Existing local state is
        # left intact rather than risking deletion of a user's credentials.
        if old_auth is None:
            auth_path.unlink(missing_ok=True)
        else:
            auth_path.write_bytes(old_auth)
        if not had_node:
            node_path.unlink(missing_ok=True)
        if old_env is None:
            ENV_PATH.unlink(missing_ok=True)
        else:
            ENV_PATH.write_bytes(old_env)
        if isinstance(exc, (EnrollmentError, SecureStorageError)):
            raise
        raise EnrollmentError("Local enrollment could not be completed safely.") from exc
    return {"user_id": home.user_id, "primary_identity": home.primary_identity,
            "memory_home_id": home.memory_home_id, "node_id": node["node_id"],
            "touch_id": touch.value, "previous_node": existing_node}
