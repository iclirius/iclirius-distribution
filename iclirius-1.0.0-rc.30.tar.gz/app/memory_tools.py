from pathlib import Path

from app.config import settings
from app.memory_core import MemoryCore

SUMMARY_PATH = Path(settings.memory_path) / "summary.md"
LEARNED_PATH = Path(settings.memory_path) / "learned.jsonl"
DIGEST_LOG_PATH = Path(settings.memory_path) / "digest_log.jsonl"
PERSONALITY_PATH = Path(settings.identity_path) / "personality.md"
PROJECT_STATUS_PATH = Path(settings.state_path) / "project_status.md"


def _legacy_text(key, lines=80, empty="Sin datos."):
    text = MemoryCore().get_namespace("legacy_documents").get(key, "")
    return "\n".join(str(text).splitlines()[-lines:]) or empty


def memory_summary_text(lines: int = 80) -> str:
    return "Resumen vivo:\n" + _legacy_text("summary", lines)


def learned_text(lines: int = 30) -> str:
    """
    What Iclirius has picked up, from the canonical encrypted state.

    Historical plaintext files require explicit migration before display.
    """
    entries = []

    try:
        from app.memory_core import MemoryCore

        entries = MemoryCore().learnings(limit=lines)
    except Exception:
        entries = []

    parts = ["Aprendizajes automáticos:"]

    if entries:
        parts.extend(f"- {item.get('text', '')}" for item in entries)
    else:
        parts.append("Sin aprendizajes nuevos todavía.")

    return "\n".join(parts)


def digest_log_text(lines: int = 40) -> str:
    return "Digest log:\n" + _legacy_text("digest_log", lines, "Sin digest todavía.")


def personality_text(lines: int = 80) -> str:
    return "Personalidad actual:\n" + _legacy_text("personality", lines)


def project_status_text(lines: int = 80) -> str:
    return "Estado del proyecto:\n" + _legacy_text("project_status", lines)


def full_brain_status_text() -> str:
    parts = [
        project_status_text(50),
        "",
        memory_summary_text(50),
        "",
        learned_text(20),
    ]

    return "\n".join(parts).strip()[:3900]


def clear_learned_text() -> str:
    """
    Clear the learnings Iclirius recorded.

    Only the encrypted ones. The legacy plaintext file is left untouched:
    deleting a file this code no longer owns is not this command's business.
    """
    try:
        from app.memory_core import MemoryCore

        core = MemoryCore()
        core._mutate(lambda state: state.update({"learnings": []}))
    except Exception:
        return "No pude limpiar los aprendizajes."

    return "Aprendizajes automáticos limpiados."
