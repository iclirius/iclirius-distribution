"""
Turning an analysis into a concrete, grounded patch proposal.

Phase 3.5 could validate and apply a patch but nothing built one: asking
Iclirius to fix something produced an explanation and no proposal. This module
is the missing half, and it is the point where model output is closest to
becoming a file change, so the rules here are deliberately narrow.

    MODEL PROPOSES CHANGE. ICLIRIUS VALIDATES CHANGE.
    LOCAL EXECUTOR APPLIES CHANGE.

Grounding is the core idea. A model may only propose edits to a file that
OpenClaw has already read from disk in this session, whose full content it was
shown, and whose fingerprint still matches. It cannot name a path it has never
seen, cannot edit a file it was told about only in summary, and cannot act on
a version of the file that has since changed under it. A proposal that fails
any of those checks is refused, not repaired.

Nothing here writes. The output is a list of FileChange objects handed to
app.safe_write, which applies its own independent validation afterwards.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime

from app.config import settings
from app.logger import logger
from app.safe_write import (
    Change,
    FileChange,
    fingerprint,
    validate_write_path,
)


class GroundingError(RuntimeError):
    """The model referred to a file it is not entitled to change."""


class PatchGenerationError(RuntimeError):
    """The model's proposal could not be turned into a valid patch."""


# The model must answer with JSON and nothing else. It routinely wraps it in a
# fenced block anyway, so we tolerate the fence and refuse everything else.
_FENCE = re.compile(r"```(?:json)?\s*(.+?)```", re.DOTALL)

_VALID_RISK = {"LOW", "MEDIUM", "HIGH"}


@dataclass
class GroundedFile:
    """A file the model is allowed to see and propose changes to."""

    path: str
    content: str
    base_fingerprint: str
    grounded_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @property
    def name(self) -> str:
        from pathlib import Path
        return Path(self.path).name

    def summary(self) -> dict:
        """Metadata only: sizes and hashes, never the body."""
        return {
            "path": self.name,
            "chars": len(self.content),
            "fingerprint": self.base_fingerprint,
        }


class GroundingStore:
    """
    Which files this agent has read, and which it may therefore edit.

    Two stages on purpose. Reading a directory listing mentions many paths;
    that only makes a file a *candidate*. A candidate becomes grounded when
    its full content has been loaded and fingerprinted, and only grounded
    files can appear in a patch. Keeping those separate is what stops a model
    from editing a file it merely saw the name of.
    """

    def __init__(self, max_files: int = 32):
        self._read_paths: dict[str, str] = {}
        self._grounded: dict[str, GroundedFile] = {}
        self._max_files = max_files

    # -- stage one: what has been read ------------------------------------

    def note_read(self, path: str | None) -> None:
        """Record that a local read touched this path. Never raises."""
        if not path:
            return

        try:
            resolved = str(validate_write_path(path))
        except Exception:
            # Not writable-eligible, so it can never be grounded anyway.
            return

        if len(self._read_paths) >= self._max_files:
            self._read_paths.pop(next(iter(self._read_paths)), None)

        self._read_paths[resolved] = datetime.now().isoformat(timespec="seconds")

    def was_read(self, path: str) -> bool:
        try:
            return str(validate_write_path(path)) in self._read_paths
        except Exception:
            return False

    def candidates(self) -> list[str]:
        return list(self._read_paths)

    # -- stage two: full content and fingerprint --------------------------

    def ground(self, path: str) -> GroundedFile:
        """
        Load a candidate's full content so the model can reason about it.

        The whole file, or nothing. A truncated view is what makes an anchored
        replacement dangerous: the anchor could also occur in the part we never
        looked at, and the edit would land somewhere nobody inspected.
        """
        target = validate_write_path(path)
        resolved = str(target)

        if resolved not in self._read_paths:
            raise GroundingError(
                f"No he leído {target.name} en esta sesión, así que no puedo "
                f"proponer cambios sobre él."
            )

        if not target.is_file():
            raise GroundingError(f"No es un archivo: {target.name}")

        size = target.stat().st_size

        if size > settings.patch_model_max_file_chars:
            raise GroundingError(
                f"{target.name} ocupa {size} caracteres y el límite para "
                f"generar parches es {settings.patch_model_max_file_chars}. "
                f"Dime qué parte concreta quieres cambiar."
            )

        try:
            content = target.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            raise GroundingError(f"No pude leer {target.name}: {exc}") from exc

        grounded = GroundedFile(
            path=resolved,
            content=content,
            base_fingerprint=fingerprint(content),
        )

        self._grounded[resolved] = grounded

        return grounded

    def grounded(self, path: str) -> GroundedFile | None:
        try:
            return self._grounded.get(str(validate_write_path(path)))
        except Exception:
            return None

    def all_grounded(self) -> list[GroundedFile]:
        return list(self._grounded.values())

    def clear(self) -> None:
        self._read_paths.clear()
        self._grounded.clear()


def select_for_context(store: GroundingStore, hints: list[str] | None = None
                       ) -> tuple[list[GroundedFile], list[str]]:
    """
    Ground as many relevant candidates as the character budget allows.

    Returns the files to show the model and the reasons any were left out, so
    the user can be told why a file was not considered rather than silently
    seeing it ignored.
    """
    wanted: list[str] = []
    skipped: list[str] = []

    for hint in (hints or []):
        if hint and hint not in wanted:
            wanted.append(hint)

    for candidate in store.candidates():
        if candidate not in wanted:
            wanted.append(candidate)

    selected: list[GroundedFile] = []
    spent = 0

    for path in wanted:
        if len(selected) >= settings.patch_model_max_files:
            skipped.append(f"{path}: se alcanzó el máximo de archivos")
            continue

        try:
            grounded = store.ground(path)
        except (GroundingError, PermissionError, RuntimeError, OSError) as exc:
            skipped.append(f"{path}: {exc}")
            continue

        if spent + len(grounded.content) > settings.patch_model_max_context_chars:
            skipped.append(f"{grounded.name}: no cabe en el presupuesto de contexto")
            continue

        selected.append(grounded)
        spent += len(grounded.content)

    return selected, skipped


PATCH_RULES = """Eres un motor de parches. Devuelve SOLO un objeto JSON, sin texto alrededor.

Formato exacto:
{"reason": "<por qué, una frase>",
 "risk": "LOW|MEDIUM|HIGH",
 "files": [{"path": "<ruta exacta de las mostradas>",
            "changes": [{"original": "<texto literal actual>",
                         "replacement": "<texto nuevo>",
                         "context_before": "<texto justo antes, si hace falta>",
                         "context_after": "<texto justo después, si hace falta>"}]}]}

Reglas:
- "original" debe ser una copia LITERAL del archivo mostrado, con su sangría.
- Si ese texto aparece más de una vez, rellena context_before o context_after
  hasta que la combinación sea única. No confíes en la primera aparición.
- Cambia lo mínimo necesario. No reformatees el archivo entero.
- Sólo puedes tocar las rutas mostradas más abajo.
- Si no puedes hacer el cambio con seguridad, responde {"files": []} y explica
  el motivo en "reason"."""


def build_patch_prompt(request: str, files: list[GroundedFile],
                       analysis: str = "") -> str:
    """Assemble the patch-generation prompt from grounded content only."""
    blocks = [PATCH_RULES, f"\n## PETICIÓN\n{request.strip()}"]

    if analysis:
        blocks.append(f"\n## ANÁLISIS PREVIO\n{analysis.strip()}")

    for item in files:
        blocks.append(
            f"\n## ARCHIVO: {item.path}\n"
            f"<<<CONTENIDO_INICIO>>>\n{item.content}\n<<<CONTENIDO_FIN>>>"
        )

    return "\n".join(blocks)


def parse_patch_response(raw: str) -> dict:
    """Extract the JSON object, refusing anything that is not the schema."""
    text = (raw or "").strip()

    if not text:
        raise PatchGenerationError("El modelo no devolvió nada.")

    fenced = _FENCE.search(text)
    if fenced:
        text = fenced.group(1).strip()

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1 or end <= start:
        raise PatchGenerationError("El modelo no devolvió JSON.")

    try:
        payload = json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise PatchGenerationError(f"JSON inválido: {exc.msg}") from exc

    if not isinstance(payload, dict):
        raise PatchGenerationError("El JSON no es un objeto.")

    files = payload.get("files")

    if files is None:
        raise PatchGenerationError("El JSON no trae 'files'.")

    if not isinstance(files, list):
        raise PatchGenerationError("'files' debe ser una lista.")

    risk = str(payload.get("risk", "MEDIUM")).upper()

    return {
        "reason": str(payload.get("reason", ""))[:400],
        "risk": risk if risk in _VALID_RISK else "MEDIUM",
        "files": files,
    }


def normalise_anchor(content: str, change: Change, index: int, name: str) -> Change:
    """
    Pin the change to exactly one place in the file, or refuse.

    Uniqueness is what makes an edit safe; the context is only a disambiguator
    for when the anchor alone is not unique. So when the anchor occurs exactly
    once the edit is already fully determined, and a context that does not
    match is dropped rather than treated as a failure — a small local model
    reconstructs surrounding lines imperfectly, and rejecting a
    well-determined edit over redundant decoration helps nobody.

    When the anchor is not unique the context stops being optional, and a
    context that does not resolve it is a refusal.
    """
    plain = content.count(change.original)

    if plain == 0:
        raise PatchGenerationError(
            f"El texto del cambio {index} no aparece en {name}. "
            f"El modelo lo inventó o lo reescribió."
        )

    if plain == 1:
        if change.context_before or change.context_after:
            anchored = f"{change.context_before}{change.original}{change.context_after}"

            if content.count(anchored) != 1:
                # Redundant and wrong: the anchor already pins the edit.
                logger.info(
                    "Dropping unmatched context for change %s in %s", index, name)
                return Change(original=change.original,
                              replacement=change.replacement)

        return change

    if not (change.context_before or change.context_after):
        raise PatchGenerationError(
            f"El cambio {index} de {name} encaja en {plain} sitios y no trae "
            f"contexto. No elijo por ti."
        )

    anchored = f"{change.context_before}{change.original}{change.context_after}"
    found = content.count(anchored)

    if found == 1:
        return change

    if found == 0:
        raise PatchGenerationError(
            f"El contexto del cambio {index} no coincide con {name}, y sin él "
            f"el texto encaja en {plain} sitios."
        )

    raise PatchGenerationError(
        f"El cambio {index} de {name} sigue encajando en {found} sitios "
        f"incluso con contexto."
    )


def changes_from_payload(payload: dict, store: GroundingStore) -> list[FileChange]:
    """
    Convert a parsed model response into FileChange objects.

    Every check here answers one question: could this edit land somewhere the
    user did not intend? A path that was never grounded, a file that moved
    under us, an anchor that matches nothing, an anchor that matches twice —
    all of them are refusals. safe_write validates independently afterwards;
    this is not the only line of defence, but it is the one that can explain
    the problem in terms of what the model actually proposed.
    """
    entries = payload.get("files") or []

    if not entries:
        raise PatchGenerationError(
            payload.get("reason")
            or "El modelo no propuso ningún cambio concreto."
        )

    if len(entries) > settings.write_max_files_per_interaction:
        raise PatchGenerationError(
            f"El modelo propuso tocar {len(entries)} archivos y el límite es "
            f"{settings.write_max_files_per_interaction}."
        )

    file_changes: list[FileChange] = []

    for entry in entries:
        if not isinstance(entry, dict):
            raise PatchGenerationError("Cada archivo debe ser un objeto JSON.")

        path = entry.get("path")

        if not path or not isinstance(path, str):
            raise PatchGenerationError("Un archivo propuesto no trae 'path'.")

        grounded = store.grounded(path)

        if grounded is None:
            raise GroundingError(
                f"El modelo propuso cambiar '{path}', que no está entre los "
                f"archivos que leí y le mostré. No lo aplico."
            )

        # The file may have been edited while the model was thinking.
        current = fingerprint(grounded.content)
        try:
            on_disk = fingerprint(
                validate_write_path(grounded.path).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, PermissionError, RuntimeError) as exc:
            raise PatchGenerationError(
                f"No pude releer {grounded.name}: {exc}") from exc

        if on_disk != current:
            raise PatchGenerationError(
                f"{grounded.name} cambió mientras preparaba el parche. "
                f"Vuelve a pedírmelo y lo leo de nuevo."
            )

        raw_changes = entry.get("changes")

        if not isinstance(raw_changes, list) or not raw_changes:
            raise PatchGenerationError(
                f"El modelo no indicó cambios para {grounded.name}.")

        if len(raw_changes) > settings.write_max_patches_per_file:
            raise PatchGenerationError(
                f"{len(raw_changes)} cambios en {grounded.name}; el límite es "
                f"{settings.write_max_patches_per_file}."
            )

        changes: list[Change] = []

        for index, raw in enumerate(raw_changes, start=1):
            if not isinstance(raw, dict):
                raise PatchGenerationError("Cada cambio debe ser un objeto JSON.")

            original = raw.get("original")
            replacement = raw.get("replacement")

            if not isinstance(original, str) or not original:
                raise PatchGenerationError(
                    f"El cambio {index} de {grounded.name} no trae el texto original."
                )

            if not isinstance(replacement, str):
                raise PatchGenerationError(
                    f"El cambio {index} de {grounded.name} no trae texto de reemplazo."
                )

            if original == replacement:
                raise PatchGenerationError(
                    f"El cambio {index} de {grounded.name} no cambia nada."
                )

            change = Change(
                original=original,
                replacement=replacement,
                context_before=str(raw.get("context_before") or ""),
                context_after=str(raw.get("context_after") or ""),
            )

            changes.append(
                normalise_anchor(grounded.content, change, index, grounded.name))

        file_changes.append(FileChange(
            target_path=grounded.path,
            changes=changes,
            base_fingerprint=grounded.base_fingerprint,
        ))

    logger.info(
        "Patch generated from grounded content files=%s changes=%s",
        len(file_changes), sum(len(f.changes) for f in file_changes),
    )

    return file_changes
