import logging
import os
from app.config import settings


def setup_logger() -> logging.Logger:
    os.makedirs(settings.logs_path, exist_ok=True)

    logger = logging.getLogger("openclaw")
    logger.setLevel(logging.INFO)

    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    file_handler = logging.FileHandler(
        os.path.join(settings.logs_path, "openclaw.log")
    )
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


logger = setup_logger()


def configure_cli_logging(*, debug: bool = False) -> logging.Logger:
    """Keep operational logs available without polluting CLI conversation.

    The file handler remains active in every mode.  Only the console handler
    is changed, and this function is called by the CLI entrypoint rather than
    by Telegram or other runtimes.
    """
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.propagate = False
    for handler in logger.handlers:
        # FileHandler subclasses StreamHandler, so check it first.
        if isinstance(handler, logging.FileHandler):
            continue
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(logging.INFO if debug else logging.CRITICAL + 1)
    return logger
