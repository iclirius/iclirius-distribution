"""
Deciding when a conversation is work.

Most messages are conversation. Some are work, and work deserves a task with
a goal, a project and a memory that survives the interface. This module draws
that line, and resolves "sigamos con lo del login" to an existing task.

Two rules shape it:

  - Deterministic first. Rules, the active project and recent tasks answer
    almost everything. The local model is consulted only to break a genuine
    tie, and never a cloud model.

  - When in doubt, do nothing. Creating a spurious task pollutes memory and
    misdirects context; failing to create one costs nothing, because the next
    message can still create it and the user can always be explicit.

Facts carry provenance. A model saying "probably TokenStore" is a hypothesis,
not a verified fact, and the two are stored differently on purpose.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from app.config import settings
from app.delegation import contains_sensitive_content  # noqa: F401
from app.logger import logger
from app.project_identity import resolve_by_name


class TaskAction(str, Enum):
    NONE = "none"
    CREATE = "create"
    RESUME = "resume"
    AMBIGUOUS = "ambiguous"


class TaskKind(str, Enum):
    """The work domain, kept separate from task lifecycle action."""
    CONVERSATION = "conversation"
    LOCAL_READ = "local_read_task"
    LOCAL_WRITE = "local_write_task"
    SHELL = "shell_task"
    GIT = "git_task"
    PROJECT = "project_task"
    EXTERNAL = "external_provider_task"


class Provenance(str, Enum):
    """Where a fact came from. A model is not a source of truth."""

    USER = "user"
    LOCAL_VERIFIED = "local_verified"
    WEB_EVIDENCE = "web_evidence"
    MODEL_SUGGESTION = "model_suggestion"
    # Added in Phase 4.1. A remote model reasoning about evidence is still
    # reasoning, not evidence — and it is worth distinguishing from a local
    # model so it is visible when a conclusion left the machine.
    CLOUD_REASONING = "cloud_reasoning"


# Reading, running or being told something. A model saying "I verified this"
# is not on this list and never will be.
VERIFIED_SOURCES = {Provenance.USER, Provenance.LOCAL_VERIFIED}


@dataclass
class TaskDecision:
    action: str
    reason: str
    task: dict | None = None
    project_id: str | None = None
    candidates: list[dict] | None = None
    kind: str = TaskKind.CONVERSATION.value

    @property
    def task_id(self) -> str | None:
        return (self.task or {}).get("task_id")


# --- signals --------------------------------------------------------------

# Phrases that mean "carry on with what we were doing".
CONTINUATION_MARKERS = [
    r"\bcontinuemos\b", r"\bcontin[úu]a\b", r"\bcontinuar\b",
    r"\bsigamos\b", r"\bsigue\b", r"\bretomemos\b", r"\bretoma\b",
    r"\bdonde nos quedamos\b", r"\bd[óo]nde nos quedamos\b",
    r"\bqu[ée] falta\b", r"\bc[óo]mo va\b", r"\bc[óo]mo vamos\b",
    r"\bseguimos\b", r"\blo de\b",
]

# Intent to do work on something.
WORK_MARKERS = [
    r"\brevisa\b", r"\brevisar\b", r"\barregla\b", r"\barreglar\b",
    r"\brepara\b", r"\breparar\b", r"\bcorrige\b", r"\bcorregir\b",
    r"\bdiagnostica\b", r"\bdiagnosticar\b", r"\binvestiga\b", r"\binvestigar\b",
    r"\banaliza\b", r"\banalizar\b", r"\bimplementa\b", r"\bimplementar\b",
    r"\bquiero (?:arreglar|revisar|entender|investigar|mejorar|migrar|refactorizar)\b",
    r"\bnecesito (?:arreglar|revisar|entender|investigar)\b",
    r"\bhay que\b", r"\btengo que\b",
    r"\bpor qu[ée] falla\b", r"\bpor qu[ée] no funciona\b",
    r"\bno funciona\b", r"\best[áa] fallando\b", r"\bfalla\b", r"\bbug\b", r"\berror en\b",
]

# Subjects that make work concrete enough to be worth remembering.
SUBJECT_MARKERS = [
    r"\blogin\b", r"\bautenticaci[óo]n\b", r"\bauth\b", r"\btoken\b",
    r"\brepo(sitorio)?\b", r"\bproyecto\b", r"\bm[óo]dulo\b", r"\bfunci[óo]n\b",
    r"\bclase\b", r"\bendpoint\b", r"\bapi\b", r"\bbase de datos\b",
    r"\bmigraci[óo]n\b", r"\bnavegaci[óo]n\b", r"\bpantalla\b", r"\btest(s)?\b",
    r"\bbuild\b", r"\bdeploy\b", r"\bversi[óo]n\b", r"\bdependencia\b",
]

# Small talk and general knowledge. These never become tasks.
CHATTER_MARKERS = [
    r"^\s*hola\b", r"^\s*buenas\b", r"^\s*qu[ée] tal\b", r"^\s*c[óo]mo est[áa]s\b",
    r"^\s*gracias\b", r"^\s*ok\b", r"^\s*vale\b", r"^\s*listo\b",
    r"\bqu[ée] es un?\b", r"\bqu[ée] significa\b", r"\bexpl[íi]came\b",
    r"\bcu[ée]ntame algo\b", r"\bqui[ée]n (?:fue|es)\b",
]

MIN_WORK_LENGTH = 15

# Patterns that look like an actual secret *value*, as opposed to a secret as
# a topic. The shared contains_sensitive_content() guards exfiltration and is
# deliberately broad: it refuses anything mentioning "token" at all, which is
# right before sending text off the machine. Durable local memory needs a
# narrower rule, otherwise a legitimate task like "arreglar la persistencia
# del token" could never be remembered.
SECRET_VALUE_PATTERNS = [
    r"-----BEGIN [A-Z ]*PRIVATE KEY",
    r"\bssh-(?:rsa|ed25519|dss)\s+[A-Za-z0-9+/]{20,}",
    # key=value where the value looks like a credential
    r"\b(?:token|password|passwd|secret|api[_-]?key|contrase[ñn]a)\b\s*[:=]\s*\S{8,}",
    # Telegram bot token shape
    r"\b\d{8,10}:[A-Za-z0-9_-]{30,}",
    # Long opaque blobs
    r"\b[A-Za-z0-9_-]{40,}\b",
]


def contains_secret_value(message: str) -> bool:
    """True when the text appears to carry a credential, not just mention one."""
    return _any(message or "", SECRET_VALUE_PATTERNS)


def _any(text: str, patterns: list[str]) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


def _matches_any(text: str, patterns: list[str]) -> bool:
    return _any(text, patterns)


def looks_like_chatter(message: str) -> bool:
    return _any((message or "").lower(), CHATTER_MARKERS)


def looks_like_continuation(message: str) -> bool:
    return _any((message or "").lower(), CONTINUATION_MARKERS)


def looks_like_work(message: str) -> bool:
    """
    Work needs both an intent and a subject.

    "revisa" alone could be about anything; "revisa el login" is a task.
    """
    text = (message or "").strip()

    if len(text) < MIN_WORK_LENGTH or looks_like_chatter(text):
        return False

    lowered = text.lower()
    return _any(lowered, WORK_MARKERS) and _any(lowered, SUBJECT_MARKERS)


def classify_task_kind(message: str) -> str:
    """Classify intent without creating a task or granting a capability."""
    text = (message or "").strip().lower()
    if not text:
        return TaskKind.CONVERSATION.value

    # Import lazily to keep this module's task/memory boundary independent.
    from app.local_planner import looks_like_local_read_intent, looks_like_write_request

    if looks_like_write_request(text):
        return TaskKind.LOCAL_WRITE.value
    if re.search(r"\b(?:git|commit|branch|merge|diff|status)\b", text):
        return TaskKind.GIT.value
    if re.search(r"\b(?:comando|terminal|shell|ejecuta|corre)\b", text):
        return TaskKind.SHELL.value
    if looks_like_local_read_intent(text):
        return TaskKind.LOCAL_READ.value
    if re.search(r"\b(?:proyecto|repositorio|código|módulo|endpoint|api)\b", text):
        return TaskKind.PROJECT.value
    if re.search(r"\b(?:web|internet|proveedor|gemini|ollama|modelo externo)\b", text):
        return TaskKind.EXTERNAL.value
    return TaskKind.CONVERSATION.value


def derive_goal(message: str) -> str:
    """A short goal sentence from the user's own words, not invented."""
    text = re.sub(r"\s+", " ", (message or "").strip())
    text = re.sub(r"^(?:oye|hey|por favor|porfa)[,\s]+", "", text, flags=re.IGNORECASE)

    for splitter in (" porque ", " ya que ", ". ", "; "):
        if splitter in text:
            head, _, tail = text.partition(splitter)
            if len(head) >= MIN_WORK_LENGTH:
                text = head if splitter not in (". ", "; ") else f"{head}. {tail}"
                break

    return text[: settings.memory_fact_chars].strip()


def _similarity(a: str, b: str) -> float:
    """Word overlap. Enough to spot "the same task said twice"."""
    def words(text):
        return {w for w in re.findall(r"[a-záéíóúñü0-9]{3,}", (text or "").lower())}

    first, second = words(a), words(b)

    if not first or not second:
        return 0.0

    return len(first & second) / len(first | second)


# --- engine ---------------------------------------------------------------


class TaskEngine:
    """
    Turns a message plus current state into a decision about tasks.

    It never raises into the caller: on any failure it reports NONE and the
    conversation continues normally.
    """

    def __init__(self, core):
        self.core = core

    def resolve_project(self, message: str, working_project: dict | None) -> str | None:
        """Working directory first; otherwise a project named in the message."""
        if working_project and working_project.get("project_id"):
            return working_project["project_id"]

        try:
            known = self.core.list_projects()
        except Exception:
            return None

        if not known:
            return None

        for word in re.findall(r"[A-Za-z][A-Za-z0-9._-]{2,}", message or ""):
            match = resolve_by_name(word, known)
            if match:
                return match

        return None

    def decide(self, message: str, working_project: dict | None = None) -> TaskDecision:
        if not settings.enable_task_engine:
            return TaskDecision(TaskAction.NONE.value, "task engine disabled")

        try:
            return self._decide(message, working_project)
        except Exception:
            logger.warning("Task engine failed; continuing without a task", exc_info=False)
            return TaskDecision(TaskAction.NONE.value, "task engine error")

    def _decide(self, message: str, working_project: dict | None) -> TaskDecision:
        text = (message or "").strip()
        kind = classify_task_kind(text)

        if not text:
            return TaskDecision(TaskAction.NONE.value, "empty message", kind=kind)

        # A literal credential is never written to durable memory. Mentioning
        # a token as a subject of work is fine and stays local anyway.
        if contains_secret_value(text):
            return TaskDecision(TaskAction.NONE.value, "possible secret value", kind=kind)

        project_id = self.resolve_project(text, working_project)

        if looks_like_continuation(text):
            return self._resume(text, project_id)

        if looks_like_work(text):
            return self._create_or_reuse(text, project_id)

        return TaskDecision(TaskAction.NONE.value, "conversation, not work",
                            project_id=project_id, kind=kind)

    def _resume(self, message: str, project_id: str | None) -> TaskDecision:
        """
        Find the task the user means.

        Preference order: the named project, then the working project, then
        the most recently touched open task. Two equally plausible candidates
        are reported as ambiguous rather than guessed.
        """
        open_tasks = [
            task for task in self.core.find_tasks(project_id=project_id, limit=20)
            if task.get("status") in ("active", "blocked", "paused")
        ]

        if not open_tasks:
            open_tasks = [
                task for task in self.core.find_tasks(limit=20)
                if task.get("status") in ("active", "blocked", "paused")
            ]

        if not open_tasks:
            return TaskDecision(TaskAction.NONE.value, "nothing open to resume",
                                project_id=project_id, kind=classify_task_kind(message))

        keywords = [
            word for word in re.findall(r"[a-záéíóúñü0-9]{4,}", message.lower())
            if not _any(word, CONTINUATION_MARKERS)
        ]

        if keywords:
            scored = [
                (max(_similarity(word, f"{t.get('goal','')} {t.get('compact_summary','')}")
                     for word in keywords), t)
                for t in open_tasks
            ]
            scored.sort(key=lambda pair: pair[0], reverse=True)

            best_score = scored[0][0]
            matches = [task for score, task in scored if score > 0 and score >= best_score * 0.9]

            if len(matches) > 1 and len({m["task_id"] for m in matches}) > 1:
                return TaskDecision(
                    TaskAction.AMBIGUOUS.value,
                    "several open tasks match equally well",
                    project_id=project_id,
                    candidates=matches[:4],
                    kind=classify_task_kind(message),
                )

            if matches:
                task = matches[0]
                self.core.set_active(task_id=task["task_id"], project_id=task.get("project_id"))
                return TaskDecision(TaskAction.RESUME.value, "keyword match",
                                    task=task, project_id=task.get("project_id"),
                                    kind=classify_task_kind(message))

        task = open_tasks[0]
        self.core.set_active(task_id=task["task_id"], project_id=task.get("project_id"))
        return TaskDecision(TaskAction.RESUME.value, "most recently updated open task",
                            task=task, project_id=task.get("project_id"),
                            kind=classify_task_kind(message))

    def _create_or_reuse(self, message: str, project_id: str | None) -> TaskDecision:
        """Reuse an equivalent open task rather than creating a near-duplicate."""
        goal = derive_goal(message)
        kind = classify_task_kind(message)

        for task in self.core.find_tasks(project_id=project_id, status="active", limit=20):
            if _similarity(goal, task.get("goal", "")) >= settings.task_duplicate_threshold:
                self.core.set_active(task_id=task["task_id"], project_id=task.get("project_id"))
                return TaskDecision(TaskAction.RESUME.value, "equivalent task already open",
                                    task=task, project_id=task.get("project_id"), kind=kind)

        task = self.core.create_task(goal, project_id=project_id)

        if not task:
            return TaskDecision(TaskAction.NONE.value, "memory unavailable",
                                project_id=project_id, kind=kind)

        return TaskDecision(TaskAction.CREATE.value, "explicit work request",
                            task=task, project_id=project_id, kind=kind)

    # -- recording ---------------------------------------------------------

    def record_fact(self, task_id: str, value: str, provenance: Provenance,
                    source_ref: str = "") -> dict:
        """
        Attach a fact with its provenance.

        A verified fact and a model hypothesis are stored in different fields
        on purpose: a model can be wrong, and "Ollama said X" must never
        silently become "X is true".
        """
        if not task_id or not value:
            return {}

        stamp = datetime.now().isoformat(timespec="seconds")
        verified = provenance in VERIFIED_SOURCES
        marker = "✔" if verified else "?"
        origin = provenance.value if isinstance(provenance, Provenance) else str(provenance)

        entry = f"[{marker} {origin}] {value.strip()}"
        if source_ref:
            entry += f" ({source_ref})"
        entry += f" · {stamp}"

        field = "known_facts" if verified else "decisions"

        try:
            return self.core.update_task(task_id, **{field: entry})
        except Exception:
            logger.warning("Could not record fact", exc_info=False)
            return {}

    def record_model_suggestion(self, task_id: str, suggestion: str) -> dict:
        """Model output is a hypothesis until something local verifies it."""
        return self.record_fact(task_id, suggestion, Provenance.MODEL_SUGGESTION)


# --- write intent ---------------------------------------------------------
#
# Four different things a user can mean, and only two of them may touch a
# file. When in doubt, nothing is written.

WRITE_APPLY_MARKERS = [
    r"\barr[ée]glalo\b", r"\barregla\b", r"\bc[áa]mbialo\b", r"\bcambia\b",
    r"\bcorr[íi]gelo\b", r"\bcorrige\b", r"\bapl[íi]calo\b", r"\baplica\b",
    r"\bh[áa]zlo\b", r"\bimpleméntalo\b", r"\bimpl[eé]mentalo\b",
    r"\bescr[íi]belo\b", r"\bactual[íi]zalo\b",
]

WRITE_PROPOSE_MARKERS = [
    r"\bc[óo]mo lo (?:arreglar[íi]as|cambiar[íi]as|corregir[íi]as)\b",
    r"\bqu[ée] cambiar[íi]as\b", r"\bpropón\b", r"\bpropon\b",
    r"\bsugi[eé]reme\b", r"\bqu[ée] har[íi]as\b", r"\bmu[ée]strame el cambio\b",
]

APPROVAL_MARKERS = [
    r"^\s*s[íi]\b", r"^\s*ok\b", r"^\s*dale\b", r"^\s*adelante\b",
    r"^\s*h[áa]zlo\b", r"^\s*aplica(?:lo)?\b", r"^\s*confirmo\b",
    r"\bapl[íi]ca(?:lo)? (?:ese|el) cambio\b",
]

DENIAL_MARKERS = [
    r"^\s*no\b", r"^\s*cancela\b", r"^\s*mejor no\b", r"^\s*d[ée]jalo\b",
    r"^\s*para\b", r"^\s*detente\b", r"\bno lo apliques\b",
]


# What the user is asking to be run. Each entry maps to one closed operation
# name; the words never become part of a command line. app.safe_execute owns
# the argv, and these markers only choose which of its four verbs applies.
EXECUTION_MARKERS = {
    "RUN_TESTS": [
        r"\b(?:corre|ejecuta|lanza|pasa)\s+(?:los\s+)?tests?\b",
        r"\b(?:corre|ejecuta|lanza|pasa)\s+(?:las\s+)?pruebas\b",
        r"\bhaz\s+(?:los\s+)?tests?\b", r"\bverifica\s+con\s+tests?\b",
        r"\b(?:corre|ejecuta|lanza)\s+pytest\b",
        r"\b¿?(?:pasan|siguen pasando)\s+los\s+tests?\b",
    ],
    "RUN_BUILD": [
        r"\bcompila\b", r"\bcompílalo\b", r"\bcomp[íi]lalo\b",
        r"\bhaz\s+(?:el\s+)?build\b", r"\bconstruye\s+(?:el\s+)?proyecto\b",
        r"\b¿?compila\b",
    ],
    "RUN_LINT": [
        r"\bpasa\s+(?:el\s+)?lint(?:er)?\b", r"\bejecuta\s+(?:el\s+)?lint(?:er)?\b",
        r"\brevisa\s+(?:el\s+)?estilo\b",
        r"\b(?:corre|ejecuta|lanza|pasa)\s+ruff\b",
    ],
    "RUN_TYPECHECK": [
        r"\bcomprueba\s+(?:los\s+)?tipos\b", r"\bchequea\s+(?:los\s+)?tipos\b",
        r"\btype\s*check\b", r"\b(?:corre|ejecuta|lanza|pasa)\s+mypy\b",
    ],
}


def detect_execution_intent(message: str) -> str | None:
    """
    Which execution operation the user asked for, if any.

    Returns one of the four closed operation names or None. It never returns
    anything derived from the user's words: a match selects a constant.
    """
    lowered = (message or "").strip().lower()

    if not lowered:
        return None

    # A path is not a request. Temporary directories and repositories are full
    # of words like "test" and "build", and "revisa /tmp/pytest-of-x" asks to
    # read a folder, not to run a suite.
    lowered = " ".join(word for word in lowered.split() if "/" not in word)

    if not lowered:
        return None

    for operation, patterns in EXECUTION_MARKERS.items():
        if _matches_any(lowered, patterns):
            return operation

    return None


class WriteIntent(str, Enum):
    NONE = "none"
    PROPOSE = "propose"
    APPLY = "apply"
    APPROVE = "approve"
    DENY = "deny"


def detect_write_intent(message: str) -> str:
    """
    What the user wants done to a file, if anything.

    Denial is checked first so "no, cancela" can never read as approval, and
    an explicit approval outranks a fresh request so a bare "sí" resolves a
    pending proposal instead of starting a new one.
    """
    text = (message or "").strip()

    if not text:
        return WriteIntent.NONE.value

    lowered = text.lower()

    if _matches_any(lowered, DENIAL_MARKERS):
        return WriteIntent.DENY.value

    if _matches_any(lowered, APPROVAL_MARKERS):
        return WriteIntent.APPROVE.value

    # Asking how it would be fixed is not asking for it to be fixed.
    if _matches_any(lowered, WRITE_PROPOSE_MARKERS):
        return WriteIntent.PROPOSE.value

    if _matches_any(lowered, WRITE_APPLY_MARKERS):
        return WriteIntent.APPLY.value

    return WriteIntent.NONE.value
