"""Deterministic capability routing for personal/local resource questions."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from app.config import settings
from app.file_roots import RootProvider, RootResolutionStatus, detect_provider, resolve_file_root

LOCAL_OPERATION_MARKERS = (
    r"\bpuedes\s+ver\b", r"\bpuedes\s+revisar\b", r"\bqu[ée]\s+tengo\b",
    r"\bbusca\b", r"\bcu[áa]ntos?\b", r"\bcu[áa]ndo\s+modifiqu[ée]\b",
    r"\blista(?:r)?\b", r"\bmu[ée]strame\b", r"\bdame\b", r"\bnombres?\b",
    r"\bqu[ée]\s+carpetas?\b", r"\bm[aá]s\s+(?:antigu|reciente|nuevo|grande|peque)", r"\btodos?\b", r"\btodas?\b",
    r"\bqu[ée]\s+proyectos?\b", r"\bqu[ée]\s+tipos?\b", r"\bespacio\b", r"\bocupan?\b",
    r"\bm[aá]s\s+grandes?\b", r"\bmodifiqu[ée]\b",
)
PERSONAL_MARKERS = (r"\bmi(?:s)?\b", r"\bm[íi]o(?:s)?\b", r"\bm[íi]a(?:s)?\b",
                    r"\ben\s+mis?\b", r"\bmis?\s+(?:documentos?|archivos?|carpetas?)\b")
RESOURCE_MARKERS = (r"\bgoogle\s+drive\b", r"\bdrive\b", r"\bcarpeta\b", r"\barchivos?\b",
                    r"\bdocumentos?\b", r"\bpdfs?\b", r"\binvoice\.[a-z0-9]+\b",
                    r"\bproyectos?\b", r"\btipos?\s+de\s+archivos?\b", r"\bcada\s+tipo\b", r"\bespacio\b", r"\bmodifiqu[ée]\b",
                    r"\b(?:pdf|xml|csv|json|docx|txt|md)s?\b")
PUBLIC_OPERATION_MARKERS = (r"\bc[óo]mo\s+funciona\b", r"\bcu[áa]nto\s+cuesta\b",
                             r"\best[áa]\s+ca[íi]do\b", r"\bdocumentaci[óo]n\b",
                             r"\bnoticias?\b", r"\bprecio\b", r"\ben\s+internet\b",
                             r"\ben\s+la\s+web\b")


def normalize_query_for_intent(message: str) -> str:
    """Normalize only conversational punctuation for intent parsing.

    Paths and filenames are never passed through this helper; it is limited
    to the user-query routing surface so ``. muéstrame el resto`` behaves like
    ``muéstrame el resto`` without changing document content.
    """
    value = str(message or "").strip()
    return re.sub(r"^(?:[\s.,;:!?¡¿])+|(?:[\s.,;:!?¡¿])+$", "", value).strip()


def _has(text: str, patterns: tuple[str, ...]) -> bool:
    return any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)


@dataclass(frozen=True)
class CapabilityDecision:
    capability: str
    scope: str
    resource_type: str
    operation: str
    reason: str
    available: bool = False
    root_path: str | None = None
    evidence_provider: str | None = None
    web_fallback: str = "ALLOWED"
    signals: tuple[str, ...] = field(default_factory=tuple)
    root_resolution_status: str | None = None
    root_id: str | None = None
    provider: str | None = None
    root_paths: tuple[str, ...] = field(default_factory=tuple)
    root_selection_reason: str | None = None
    logical_result_set_id: str | None = None
    displayed_result_set_id: str | None = None
    parent_result_set_id: str | None = None
    continuation_target: str | None = None


@dataclass
class RoutingTrace:
    entrypoint: str
    message: str
    routing_decision: str
    selected_capability: str
    evidence_provider: str | None = None
    web_search_calls: int = 0
    web_evidence_records: int = 0
    context_package: str | None = None
    final_response: str | None = None
    stages: list[str] = field(default_factory=list)
    provider_requested: str | None = None
    root_resolution_status: str | None = None
    root_id: str | None = None
    root_selection_reason: str | None = None
    filesystem_operation: str | None = None
    coverage: str | None = None
    filters: dict | None = None
    limit: int | None = None
    selected_tool: str | None = None
    tool_call_id: str | None = None
    execution_path: str | None = None
    identity: str | None = None
    evidence_ids: tuple[str, ...] = ()
    native_dispatch: str | None = None
    tool_chain: tuple[str, ...] = ()
    attachment_id: str | None = None
    attachment_source: str | None = None
    attachment_status: str | None = None
    attachment_tool: str | None = None
    attachment_evidence_ids: tuple[str, ...] = ()
    attachment_coverage: str | None = None
    snapshot_id: str | None = None
    snapshot_reused: bool = False
    subquery_ids: tuple[str, ...] = ()
    web_recovery_used: bool = False
    web_failure_reason: str | None = None

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def classify(message: str, allowed_roots: list[str] | tuple[str, ...] = ()) -> CapabilityDecision | None:
    text = normalize_query_for_intent(message).lower()
    if not text:
        return None
    personal = _has(text, PERSONAL_MARKERS)
    resource = _has(text, RESOURCE_MARKERS)
    operation = _has(text, LOCAL_OPERATION_MARKERS)
    public = _has(text, PUBLIC_OPERATION_MARKERS)
    if public and not personal:
        return None
    # A possessive noun in an ordinary statement ("tengo ... mi carpeta") is
    # not enough to inspect the disk. Require an inspection operation as well.
    if not (resource and operation):
        return None
    roots = [str(value) for value in (allowed_roots or ())]
    requested_provider = RootProvider.GOOGLE_DRIVE if re.search(r"\bdrive\b", text) else RootProvider.LOCAL
    resolution = resolve_file_root(provider=requested_provider, allowed_roots=roots,
                                   node_id=str(getattr(settings, "node_id", "unknown-node")),
                                   user_id=str(getattr(settings, "user_id", "") or "") or None)
    # A generic personal scope such as "mi carpeta" may omit the provider.
    # Reuse the sole authorized root's provenance when it is unambiguous;
    # never guess among multiple roots.
    if not re.search(r"\bdrive\b", text) and resolution.status != RootResolutionStatus.RESOLVED and len(roots) == 1:
        inferred = detect_provider(roots[0])
        if inferred != RootProvider.LOCAL:
            requested_provider = inferred
            resolution = resolve_file_root(provider=inferred, allowed_roots=roots,
                                           node_id=str(getattr(settings, "node_id", "unknown-node")),
                                           user_id=str(getattr(settings, "user_id", "") or "") or None)
    root = resolution.root.canonical_path if resolution.root else None
    resolved_paths = tuple(item.canonical_path for item in resolution.candidates)
    root_available = resolution.status == RootResolutionStatus.RESOLVED or (
        requested_provider == RootProvider.LOCAL and bool(resolved_paths)
    )
    selection_reason = "EXPLICIT_ROOT" if re.search(r"\b(?:google\s+drive|drive|icloud|dropbox|onedrive)\b", text) else (
        "UNIQUE_DEFAULT_ROOT" if resolution.status == RootResolutionStatus.RESOLVED else None)
    return CapabilityDecision(
        capability="FILESYSTEM_LOCAL", scope="PERSONAL", resource_type="filesystem",
        operation="INSPECT", reason="personal/local resource scope", available=root_available,
        root_path=root, evidence_provider="FILESYSTEM", web_fallback="FORBIDDEN",
        root_resolution_status=resolution.status.value,
        root_id=resolution.root.root_id if resolution.root else None,
        provider=resolution.provider.value,
        root_paths=resolved_paths,
        root_selection_reason=selection_reason,
        signals=tuple(name for name, active in (("possessive_scope", personal),
                                                  ("resource_type", resource),
                                                  ("local_operation", operation)) if active),
    )
