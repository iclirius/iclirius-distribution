from __future__ import annotations

import json
import os
import subprocess

from app.process_env import redacted_environment
import sys
import uuid
from datetime import datetime
from pathlib import Path
from app.config import settings


JOBS_DIR = Path(settings.state_path) / "jobs"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def new_ingest_job_id() -> str:
    return "ingest_" + datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]


def job_path(job_id: str) -> Path:
    return JOBS_DIR / f"{job_id}.json"


def write_job(job: dict) -> None:
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    job_path(job["id"]).write_text(json.dumps(job, ensure_ascii=False, indent=2))


def read_job(job_id: str) -> dict | None:
    path = job_path(job_id)

    if not path.exists():
        return None

    return json.loads(path.read_text())


def format_job_status(job: dict | None) -> str:
    if not job:
        return "No encontré ese job."

    total = job.get("total_files", 0)
    processed = job.get("processed", 0)
    skipped = job.get("skipped", 0)
    failed = job.get("failed", 0)

    pct = 0
    if total:
        pct = round((processed + skipped + failed) * 100 / total, 2)

    lines = [
        f"Job: {job.get('id')}",
        f"Estado: {job.get('status')}",
        f"Ruta: {job.get('root_path')}",
        f"Progreso: {processed + skipped + failed}/{total} ({pct}%)",
        f"Procesados: {processed}",
        f"Omitidos: {skipped}",
        f"Fallidos: {failed}",
    ]

    current = job.get("current_file")
    if current:
        lines.append(f"Actual: {current}")

    last_error = job.get("last_error")
    if last_error:
        lines.append(f"Último error: {last_error}")

    started_at = job.get("started_at")
    finished_at = job.get("finished_at")

    if started_at:
        lines.append(f"Inicio: {started_at}")

    if finished_at:
        lines.append(f"Fin: {finished_at}")

    return "\n".join(lines)[:3900]


def list_ingest_jobs(limit: int = 10) -> str:
    JOBS_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(JOBS_DIR.glob("ingest_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

    if not files:
        return "No hay jobs de ingesta."

    lines = ["Jobs de ingesta recientes:"]

    for path in files[:limit]:
        try:
            job = json.loads(path.read_text())
            total = job.get("total_files", 0)
            done = job.get("processed", 0) + job.get("skipped", 0) + job.get("failed", 0)
            lines.append(f"- {job.get('id')} | {job.get('status')} | {done}/{total} | {job.get('root_path')}")
        except Exception:
            lines.append(f"- {path.name}")

    return "\n".join(lines)[:3900]


def start_ingest_subprocess(root_path: str, chat_id: int | str, notify_every: int = 25) -> dict:
    job_id = new_ingest_job_id()

    job = {
        "id": job_id,
        "type": "learn_folder",
        "status": "queued",
        "root_path": root_path,
        "chat_id": str(chat_id),
        "notify_every": notify_every,
        "created_at": _now(),
        "started_at": None,
        "finished_at": None,
        "pid": None,
        "total_files": 0,
        "processed": 0,
        "skipped": 0,
        "failed": 0,
        "current_file": "",
        "last_error": "",
    }

    write_job(job)

    cmd = [
        sys.executable,
        "-m",
        "app.ingest_worker",
        "--job-id",
        job_id,
        "--root-path",
        root_path,
        "--chat-id",
        str(chat_id),
        "--notify-every",
        str(notify_every),
    ]

    log_path = Path("logs") / f"{job_id}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    out = log_path.open("a")

    process = subprocess.Popen(
        cmd,
        stdout=out,
        stderr=out,
        cwd=str(Path.cwd()),
        start_new_session=True,
        env=redacted_environment(),
    )

    job["status"] = "running"
    job["pid"] = process.pid
    job["started_at"] = _now()
    job["log_path"] = str(log_path)
    write_job(job)

    return job
