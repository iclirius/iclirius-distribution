"""Fail-closed protection against test processes touching production memory."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path


class MemorySafetyError(RuntimeError):
    """A memory path is unsafe for the current execution environment."""


def test_environment() -> bool:
    value = os.getenv("ICLIRIUS_ENV", "").strip().lower()
    return value in {"test", "testing"} or bool(os.getenv("PYTEST_CURRENT_TEST"))


def _resolved(path: str | Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def _approved_roots() -> tuple[Path, ...]:
    roots = [Path(tempfile.gettempdir()).resolve()]
    explicit = os.getenv("ICLIRIUS_TEST_ROOT", "").strip()
    if explicit:
        roots.append(_resolved(explicit))
    explicit_home = os.getenv("ICLIRIUS_TEST_MEMORY_HOME", "").strip()
    if explicit_home:
        roots.append(_resolved(explicit_home))
    return tuple(dict.fromkeys(roots))


def _inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def assert_memory_path_safe(state_file: str | Path, memory_home: str = "") -> None:
    """Reject production or unapproved paths before Core initialization.

    Production mode is unchanged. Test mode requires an explicit temporary
    path, and separately rejects a configured Memory Home even if a caller
    passes a nested state path directly.
    """
    if not test_environment():
        return

    target = _resolved(state_file)
    configured_home = str(memory_home or os.getenv("MEMORY_HOME", "")).strip()
    if configured_home:
        home = _resolved(configured_home)
        if target == home or _inside(target, home):
            raise MemorySafetyError(
                "Refusing to initialize MemoryCore for production Memory Home in test environment"
            )

    if not any(_inside(target, root) for root in _approved_roots()):
        raise MemorySafetyError(
            "Refusing to initialize MemoryCore outside an approved test memory root"
        )

