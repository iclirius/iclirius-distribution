from pathlib import Path
import os
import tempfile
import asyncio
import time

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

from app.agent import OpenClawAgent
from app.config import settings
from app.worker_client import ask_worker, worker_status_text
from app.worker_control import worker_awake_text, worker_sleep_text, worker_logs_text
from app.security import is_allowed_user, is_owner_user, is_leader
from app.logger import logger
from app.task_runner import run_task_on_worker
from app.file_manager import file_empty_text, file_reports_text, file_quarantine_text
from app.file_catalog import catalog_folder_text, catalog_stats_text, find_file_text
from app.library_ingest import library_status_text, ask_library_text
from app.ingest_jobs import start_ingest_subprocess, read_job, format_job_status, list_ingest_jobs
from app.catalog_jobs import start_catalog_subprocess, read_catalog_job, format_catalog_status, list_catalog_jobs
from app.task_queue import (
    tasks_text,
    add_task_text,
    done_task_text,
    cancel_task_text,
    clear_tasks_text,
    task_result_text,
)
from app.memory_tools import (
    full_brain_status_text,
    memory_summary_text,
    learned_text,
    digest_log_text,
    personality_text,
    project_status_text,
    clear_learned_text,
)
from app.system_tools import (
    get_health_text,
    get_version_text,
    get_git_status_text,
    run_backup_text,
    get_backup_status_text,
    get_recent_logs_text,
    write_node_status,
)
from models.ollama_client import OllamaClient
from app.response_router import classify_message, processing_message
from app.library_queries import answer_library_question
from app.background_jobs import resume_jobs, background_status, answer_background_question
from app.request_learning import log_request, learning_summary
from app.library_status import library_status
from app.response_guard import replace_stale_book_processing_response
from app.status_router import answer_status_or_books_progress
from app.voice import (Capability, VoiceMode, compact_for_voice, voice_service)
from app.runtime_events import EventType, Status, emit


# Telegram is an interface onto the principal user, not an identity of its
# own. The project comes from what the user names, not from a directory.
agent = OpenClawAgent(interface="telegram")
memory = agent.memory


MAX_TELEGRAM_REPLY = 3900


def _effective_user_id(update: Update) -> int | None:
    """
    Extract the user id from an update without assuming it is present.

    Returns None when the update has no identifiable user, so callers can
    fail closed instead of raising.
    """
    user = getattr(update, "effective_user", None)
    return getattr(user, "id", None)


def is_allowed_update(update: Update) -> bool:
    """Fail-closed allowlist check for a Telegram update."""
    user_id = _effective_user_id(update)

    if user_id is None:
        return False

    return is_allowed_user(user_id)


def is_owner_update(update: Update) -> bool:
    """Fail-closed owner check for a Telegram update."""
    user_id = _effective_user_id(update)

    if user_id is None:
        return False

    return is_owner_user(user_id)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    help_text = """Comandos de iclirius:

Básicos:
/start - iniciar el bot
/status - estado general
/health - diagnóstico local
/version - versión, nodo, branch y commit
/whoami - identidad del agente

Tareas:
/tasks - ver tareas recientes
/tasks pending - ver tareas pendientes
/task_add texto - crear una tarea
/task_done id - marcar tarea como terminada
/task_cancel id - cancelar tarea
/task_clear - limpiar tareas done/cancelled

Memoria:
/brain - ver estado de cerebro, resumen y aprendizajes
/summary - ver resumen vivo
/learned - ver aprendizajes automáticos
/learned_clear - limpiar aprendizajes automáticos
/digest_log - ver historial de digest
/personality - ver personalidad actual
/project_status - ver estado del proyecto
/memory - ver memoria local
/remember texto - guardar una nota explícita
/history - ver historial reciente
/history 10 - ver hasta 10 conversaciones
/forget_last - borrar la última conversación del historial local

Backups y sistema owner-only:
/reset - reiniciar runtime local
/backup - ejecutar backup a Google Drive
/backup_status - ver último snapshot
/gitstatus - ver cambios pendientes de Git
/logs - ver logs recientes
/logs 80 - ver hasta 80 líneas recientes

Worker:
/worker texto - enviar una tarea manualmente a la Mac worker
/worker_status - revisar si la Mac worker está viva
/worker_awake - mantener despierta la Mac worker
/worker_sleep - desactivar modo despierto en la worker
/worker_logs - ver logs recientes de la worker

Internet:
/web pregunta - buscar en Internet y responder con fuentes

Lectura local (solo lectura):
/localread petición - inspeccionar archivos, carpetas y repos
/localstatus - estado y límites de la lectura local
/capabilities - qué puedo hacer y qué te preguntaré antes
/models - motores de razonamiento disponibles
/providers - proveedores y cuentas
/usage - consumo agregado

Memoria de Iclirius:
/memory_core - estado del Memory Core
/project [nombre] - proyectos conocidos y su estado
/mytasks - tareas recientes

Libros y catálogo:
/catalog_folder ruta - catalogar una carpeta
/catalog_stats - estadísticas del catálogo
/find_file texto - buscar archivo catalogado
/learn_folder ruta - procesar/aprender libros de una carpeta
/ingest_status id - ver estado de ingesta de libros
/library_status - estado de librería procesada
/ask_library pregunta - preguntar a la librería local

Audio:
- Puedes mandar una nota de voz y la principal intentará transcribirla localmente.
- Si el audio llega como archivo de audio, también intentará procesarlo.
/voice on|off|status - activar, desactivar o revisar voz local
/say texto - enviar una nota de voz local

Notas:
- La memoria explícita se guarda con /remember.
- El historial se guarda localmente.
- Los datos se respaldan en Google Drive.
- El código vive en GitHub.
"""
    await update.message.reply_text(help_text)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    write_node_status()

    # Telegram is bound to the one principal user; it never creates its own.
    agent.bind_interface(reference=str(user_id))

    try:
        resumed = resume_jobs(chat_id="system")
        logger.info("Background auto-resume checked. resumed=%s", len(resumed))
    except Exception as exc:
        logger.exception("Background auto-resume failed: %s", exc)

    await update.message.reply_text(
        f"{settings.agent_name} está activo.\nNodo: {settings.node_id}\nRol: {settings.role}"
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    from app import identity as identity_module
    from app.runtime_state import build_snapshot
    from app.status_view import build_view, render_telegram

    ollama = OllamaClient()
    healthy = ollama.health()

    write_node_status()

    # The same snapshot the terminal renders, at a phone's density. Read-only:
    # a snapshot carries identifiers, counts and statuses, never prompts, file
    # contents, memory, program output or credentials.
    snapshot = build_snapshot(
        agent=agent,
        ollama_healthy=healthy,
        installed_models=[settings.default_model] if healthy else [],
    )
    view = build_view(snapshot, assistant_name=identity_module.display_name())

    await update.message.reply_text(render_telegram(view)[:MAX_TELEGRAM_REPLY])


async def health(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    write_node_status()
    await update.message.reply_text(get_health_text())


async def version(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(get_version_text())


async def gitstatus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(get_git_status_text()[:MAX_TELEGRAM_REPLY])


async def backup(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text("Iniciando backup a Google Drive...")
    result = run_backup_text()
    await update.message.reply_text(result)


async def backup_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(get_backup_status_text())


async def logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    lines_count = 30

    if context.args and context.args[0].isdigit():
        lines_count = min(int(context.args[0]), 80)

    await update.message.reply_text(get_recent_logs_text(lines_count))


async def worker_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text("Consultando worker...")

    status = worker_status_text()
    await update.message.reply_text(status[:3900])


async def worker_awake(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text("Activando modo despierto en worker...")
    result = worker_awake_text()
    await update.message.reply_text(result[:3900])


async def worker_sleep(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text("Desactivando modo despierto en worker...")
    result = worker_sleep_text()
    await update.message.reply_text(result[:3900])


async def worker_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    lines = 80
    if context.args:
        try:
            lines = max(20, min(int(context.args[0]), 200))
        except ValueError:
            lines = 80

    await update.message.reply_text("Consultando logs de worker...")
    result = worker_logs_text(lines)
    await update.message.reply_text(result[:3900])


async def worker_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    prompt = " ".join(context.args).strip()

    if not prompt:
        await update.message.reply_text('Uso: /worker escribe aquí la tarea')
        return

    await update.message.reply_text("Enviando tarea al worker...")

    try:
        response = ask_worker(prompt)
    except Exception as exc:
        await update.message.reply_text(f"Error consultando worker: {exc}")
        return

    if not response:
        response = "El worker respondió vacío."

    response = replace_stale_book_processing_response(response)
    await update.message.reply_text(response[:3900])


async def web_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    query = " ".join(context.args).strip()

    if not query:
        await update.message.reply_text("Uso: /web tu pregunta\nEjemplo: /web última versión estable de Kotlin")
        return

    await update.message.reply_text("Buscando en Internet...")

    try:
        answer = agent.answer_with_web(query, explicit=True)
    except Exception:
        logger.exception("/web failed")
        await update.message.reply_text("Tuve un error haciendo la búsqueda. Revisa /logs.")
        return

    if not answer:
        answer = "No pude obtener resultados para esa búsqueda."

    await update.message.reply_text(answer[:MAX_TELEGRAM_REPLY])


async def localread_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    request = " ".join(context.args).strip()

    if not request:
        await update.message.reply_text(
            "Uso: /localread petición\n"
            "Ejemplos:\n"
            "/localread lista ~/Documents/Proyecto\n"
            "/localread busca AuthRepository en ~/repo\n"
            "/localread git status de ~/repo"
        )
        return

    await update.message.reply_text("Revisando en local...")

    try:
        answer = agent.answer_with_local_read(request, explicit=True)
    except Exception:
        logger.exception("/localread failed")
        await update.message.reply_text("Tuve un error con la lectura local. Revisa /logs.")
        return

    if not answer:
        answer = "No pude interpretar esa petición local."

    await update.message.reply_text(answer[:MAX_TELEGRAM_REPLY])


async def memory_core_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    stats = agent.core.stats()
    user = agent.core.principal_user()
    active = agent.core.active_state()

    lines = [
        "Memory Core:",
        f"- Estado: {'disponible' if agent.core.health() else 'NO DISPONIBLE'}",
        f"- Usuario principal: {'sí' if stats.get('has_principal_user') else 'no'}",
        f"- Interfaces vinculadas: {', '.join(sorted((user.get('interfaces') or {}).keys())) or 'ninguna'}",
        f"- Proyectos: {stats.get('projects', 0)}",
        f"- Tareas: {stats.get('tasks', 0)} ({stats.get('active_tasks', 0)} activas)",
    ]

    if active.get("task_id"):
        task = agent.core.get_task(active["task_id"])
        if task:
            lines.append(f"- Tarea activa: {task.get('goal', '')[:80]}")

    lines.append("")
    lines.append("La memoria vive en Iclirius, cifrada y local. Los modelos no la poseen.")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def project_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    projects = agent.core.list_projects()

    if not projects:
        await update.message.reply_text(
            "Todavía no hay proyectos. Se registran solos al usar la CLI dentro de un repo."
        )
        return

    wanted = " ".join(context.args).strip()

    if wanted:
        from app.project_identity import resolve_by_name
        match = resolve_by_name(wanted, projects)

        if not match:
            await update.message.reply_text(f"No encontré un proyecto que se parezca a: {wanted}")
            return

        record = projects[match]
        lines = [f"Proyecto: {record.get('display_name')}"]

        for key, value in (record.get("facts") or {}).items():
            lines.append(f"- {key}: {value}")

        tasks = agent.core.find_tasks(project_id=match, limit=5)
        if tasks:
            lines.append("")
            lines.append("Tareas:")
            for task in tasks:
                lines.append(f"- [{task.get('status')}] {task.get('goal', '')[:70]}")

        await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])
        return

    lines = ["Proyectos conocidos:"]
    for record in projects.values():
        lines.append(f"- {record.get('display_name')}")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def memtasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    tasks = agent.core.find_tasks(limit=10)

    if not tasks:
        await update.message.reply_text("No hay tareas en el Memory Core todavía.")
        return

    projects = agent.core.list_projects()
    lines = ["Tareas recientes:"]

    for task in tasks:
        project = projects.get(task.get("project_id") or "", {})
        label = project.get("display_name", "sin proyecto")
        lines.append("")
        lines.append(f"[{task.get('status')}] {task.get('goal', '')[:80]}")
        lines.append(f"  proyecto: {label} | actualizada: {task.get('updated_at', '')}")

        if task.get("current_blocker"):
            lines.append(f"  bloqueo: {task['current_blocker'][:80]}")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def localstatus_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    from app.local_planner import Operation

    roots = settings.file_manager_allowed_roots
    enabled = settings.enable_local_read_tools

    lines = [
        "Lectura local:",
        f"- Estado: {'activada' if enabled else 'desactivada'}",
        f"- Roots permitidos: {len(roots)}",
    ]

    # Only the folder name, never the full path.
    for root in roots:
        lines.append(f"    .../{Path(root).name}")

    lines.append(f"- Operaciones disponibles: {len(Operation)}")
    lines.append("    " + ", ".join(sorted(member.value for member in Operation)))
    lines.append("")
    lines.append("Límites:")
    lines.append(f"- Resultados por operación: {settings.local_read_max_results}")
    lines.append(f"- Profundidad máxima: {settings.local_read_max_depth}")
    lines.append(f"- Bytes por archivo: {settings.local_read_max_bytes}")
    lines.append(f"- Líneas por archivo: {settings.local_read_max_lines}")
    lines.append(f"- Texto al modelo: {settings.local_read_model_chars} caracteres")
    lines.append("")
    lines.append("Solo lectura. No hay crear, editar, mover, borrar ni shell.")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def models_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Which engines Iclirius can actually route to. Read-only."""
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    described = agent.gateway.registry.describe()

    if not described:
        await update.message.reply_text("No hay proveedores registrados.")
        return

    lines = [f"Modo: {agent.mode}", ""]

    for entry in described:
        lines.append(f"{entry.get('provider_type', '?').capitalize()} "
                     f"({entry.get('account_ref', '?')}) — {entry.get('status', '?')}")

        for name in entry.get("models", []):
            lines.append(f"  • {name}")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def providers_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Which engines and accounts exist. Read-only, and never a credential."""
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    lines = [f"Modo: {agent.mode}", ""]

    for entry in agent.gateway.registry.describe():
        local = entry.get("capabilities", {}).get("local", True)
        lines.append(f"{entry.get('provider_id', '?')} — {entry.get('status', '?')} "
                     f"({'local' if local else 'remoto'})")

    accounts = agent.gateway.accounts.describe()

    if accounts:
        lines.append("")
        lines.append("Cuentas:")

        for account in accounts:
            cooldown = account.get("cooldown_seconds") or 0
            suffix = f" · enfriando {cooldown}s" if cooldown else ""
            lines.append(f"• {account.get('account_ref', '?')} "
                         f"({account.get('status', '?').lower()}){suffix}")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def usage_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Aggregates only. No prompts and no conversation history."""
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    usage = agent.gateway.ledger.summary()
    budget = agent.gateway.governor.summary()

    lines = [
        f"Modo: {agent.mode}",
        f"Peticiones totales: {usage.get('requests', 0)}",
        "",
        "Por proveedor:",
    ]

    for name, count in (usage.get("providers") or {}).items():
        lines.append(f"• {name}: {count}")

    lines.extend([
        "",
        f"Nube: {budget.get('cloud_requests', 0)} peticiones · "
        f"{budget.get('cloud_denials', 0)} denegadas",
        f"Tokens de nube: {budget.get('cloud_input_tokens', 0)} entrada / "
        f"{budget.get('cloud_output_tokens', 0)} salida",
    ])

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def capabilities_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """What Iclirius may do right now, and what it will ask before doing."""
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    from app.permissions import Capability, permission_layer
    from app.safe_execute import Operation as ExecuteOperation

    lines = ["Capacidades:"]

    for capability in Capability:
        decision = permission_layer.check(capability)
        mark = {"ALLOWED": "sí", "CONFIRM_REQUIRED": "pregunta antes",
                "DENIED": "no"}[decision.value]
        lines.append(f"- {capability.value.lower()}: {mark}")

    lines.append("")
    lines.append("Ejecución:")
    lines.append("- Operaciones: " + ", ".join(
        sorted(member.value for member in ExecuteOperation)))
    lines.append(f"- Tiempo límite: {settings.execute_timeout_seconds}s")
    lines.append(
        "- Herramientas del propio repositorio: "
        + ("permitidas" if settings.execute_allow_project_local_tools else "no")
    )
    lines.append("")
    lines.append(
        "El modelo elige la operación, nunca la línea de comandos. "
        "Sin red, sin shell, sin sudo."
    )

    pending = agent.pending_execution_summary()

    if pending:
        lines.append("")
        lines.append(f"Pendiente de aprobar: {pending['command']}")

    await update.message.reply_text("\n".join(lines)[:MAX_TELEGRAM_REPLY])


async def whoami(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    profile = memory.read_profile()

    await update.message.reply_text(
        f"Soy {profile.get('agent_name', settings.agent_name)}.\n"
        f"Framework: {profile.get('framework', 'OpenClaw')}\n"
        f"Owner: {profile.get('owner', 'Luis')}\n"
        f"Propósito: {profile.get('purpose', 'No definido')}"
    )


async def catalog_folder_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    root_path = " ".join(context.args).strip()

    if not root_path:
        await update.message.reply_text("Uso: /catalog_folder ruta")
        return

    await update.message.reply_text("Catalogando carpeta. No modificaré archivos...")
    result = catalog_folder_text(root_path)
    await update.message.reply_text(result[:3900])


async def catalog_stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(catalog_stats_text()[:3900])


async def find_file_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    query = " ".join(context.args).strip()

    if not query:
        await update.message.reply_text("Uso: /find_file palabras")
        return

    await update.message.reply_text(find_file_text(query)[:3900])


async def learn_folder_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    raw = " ".join(context.args).strip()

    if not raw:
        await update.message.reply_text('Uso: /learn_folder "ruta" [avisar_cada_n_libros]')
        return

    notify_every = 25

    parts = raw.rsplit(" ", 1)
    if len(parts) == 2 and parts[1].isdigit():
        root_path = parts[0].strip()
        notify_every = max(1, int(parts[1]))
    else:
        root_path = raw

    root_path = root_path.strip().strip('"').strip("'")

    try:
        job = start_ingest_subprocess(
            root_path=root_path,
            chat_id=update.effective_chat.id,
            notify_every=notify_every,
        )

        message = (
            "Ingesta iniciada en background.\n"
            f"Job ID: {job['id']}\n"
            f"PID: {job['pid']}\n"
            f"Te avisaré cada {notify_every} libros.\n\n"
            f"Consulta avance con: /ingest_status {job['id']}"
        )

        await update.message.reply_text(message)

    except Exception as exc:
        await update.message.reply_text(f"No pude iniciar la ingesta: {exc}")


async def ingest_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    if not context.args:
        await update.message.reply_text(list_ingest_jobs()[:3900])
        return

    job = read_job(context.args[0])
    await update.message.reply_text(format_job_status(job)[:3900])


async def library_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(library_status_text()[:3900])


async def ask_library_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    query = " ".join(context.args).strip()

    if not query:
        await update.message.reply_text("Uso: /ask_library pregunta")
        return

    await update.message.reply_text(ask_library_text(query)[:3900])


async def file_empty_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    root_path = " ".join(context.args).strip()

    if not root_path:
        await update.message.reply_text("Uso: /file_empty ruta")
        return

    await update.message.reply_text("Escaneando archivos vacíos. No borraré nada...")
    result = file_empty_text(root_path)
    await update.message.reply_text(result[:3900])


async def file_reports_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(file_reports_text()[:3900])


async def file_quarantine_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    if not context.args:
        await update.message.reply_text("Uso: /file_quarantine scan_id")
        return

    scan_id = context.args[0]
    await update.message.reply_text(f"Moviendo a cuarentena archivos del reporte {scan_id}...")
    result = file_quarantine_text(scan_id)
    await update.message.reply_text(result[:3900])


async def tasks_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    status = context.args[0] if context.args else None
    await update.message.reply_text(tasks_text(status=status)[:3900])


async def task_add_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    task_text = " ".join(context.args).strip()

    if not task_text:
        await update.message.reply_text("Uso: /task_add texto de la tarea")
        return

    await update.message.reply_text(add_task_text(task_text)[:3900])


async def task_done_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    if not context.args:
        await update.message.reply_text("Uso: /task_done id")
        return

    await update.message.reply_text(done_task_text(context.args[0])[:3900])


async def task_cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    if not context.args:
        await update.message.reply_text("Uso: /task_cancel id")
        return

    await update.message.reply_text(cancel_task_text(context.args[0])[:3900])


async def task_run_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    if not context.args:
        await update.message.reply_text("Uso: /task_run id")
        return

    task_id = context.args[0]
    await update.message.reply_text(f"Ejecutando tarea en worker: {task_id}")
    result = run_task_on_worker(task_id)
    await update.message.reply_text(result[:3900])


async def task_result_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    if not context.args:
        await update.message.reply_text("Uso: /task_result id")
        return

    await update.message.reply_text(task_result_text(context.args[0])[:3900])


async def task_clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(clear_tasks_text())


async def brain_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(full_brain_status_text())


async def summary_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(memory_summary_text()[:3900])


async def learned_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(learned_text()[:3900])


async def learned_clear_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_owner_user(user_id):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(clear_learned_text())


async def digest_log_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(digest_log_text()[:3900])


async def personality_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(personality_text()[:3900])


async def project_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(project_status_text()[:3900])


async def memory_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    await update.message.reply_text(memory.summary()[:MAX_TELEGRAM_REPLY])


async def history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    limit = 5

    if context.args and context.args[0].isdigit():
        limit = min(int(context.args[0]), 10)

    await update.message.reply_text(
        memory.history_text(limit=limit, principal_id=agent.principal_id())[:MAX_TELEGRAM_REPLY])


async def forget_last(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    removed = memory.forget_last_conversation()

    if removed:
        await update.message.reply_text("Olvidé la última conversación del historial local.")
    else:
        await update.message.reply_text("No había conversaciones para olvidar.")


async def remember(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id

    if not is_allowed_user(user_id):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    text = " ".join(context.args).strip()

    if not text:
        await update.message.reply_text("Uso: /remember texto que quieres guardar")
        return

    memory.add_note(text, source="telegram")
    await update.message.reply_text("Memoria guardada.")


async def voice_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return
    action = (context.args[0].lower() if context.args else "status")
    if action == "on":
        settings.voice_enabled_raw = "true"
        settings.voice_mode = VoiceMode.ALWAYS.value
    elif action == "off":
        settings.voice_enabled_raw = "false"
        settings.voice_mode = VoiceMode.OFF.value
    elif action in {"always", "request"}:
        settings.voice_enabled_raw = "true"
        settings.voice_mode = VoiceMode.ALWAYS.value if action == "always" else VoiceMode.ON_REQUEST.value
    elif action != "status":
        await update.message.reply_text("Uso: /voice on|off|always|request|status")
        return
    status = voice_service.status()
    await update.message.reply_text(
        f"Voice\nMode: {status['mode']}\nTTS: {status['tts_provider']}\n"
        f"Encoder: {status['encoder']}\nSTT: {status['stt_provider']}\n"
        f"Status: {status['tts']}")


async def say_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return
    text = " ".join(context.args).strip()
    if not text:
        await update.message.reply_text("Uso: /say texto")
        return
    if voice_service.tts.capability() != Capability.AVAILABLE:
        await update.message.reply_text("La voz local no está disponible en este nodo.")
        return
    artifact = None
    try:
        emit(EventType.VOICE_REQUESTED.value, status=Status.STARTED.value,
             interface="telegram", metadata={"chars": min(len(text), settings.voice_max_chars)})
        artifact = voice_service.synthesize(compact_for_voice(text))
        with artifact.path.open("rb") as audio:
            await update.message.reply_voice(voice=audio)
        emit(EventType.VOICE_SENT.value, status=Status.OK.value,
             interface="telegram", metadata={"bytes": artifact.bytes, "provider": artifact.provider})
    except Exception:
        emit(EventType.VOICE_SEND_FAILED.value, status=Status.FAILED.value,
             interface="telegram", metadata={"provider": voice_service.tts.name})
        await update.message.reply_text("No pude generar la nota de voz local.")
    finally:
        if artifact:
            artifact.path.unlink(missing_ok=True)


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = _effective_user_id(update)
    started = time.monotonic()
    emit(EventType.VOICE_RECEIVED.value, status=Status.STARTED.value,
         interface="telegram", metadata={"kind": "pending"})

    if not is_allowed_update(update):
        logger.warning("Audio rejected: user not allowed user_id=%s", user_id)
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    logger.info("Audio permission OK user_id=%s", user_id)
    emit(EventType.VOICE_AUTHORIZED.value, status=Status.OK.value,
         interface="telegram", metadata={"elapsed_ms": int((time.monotonic() - started) * 1000)})

    message = update.effective_message or update.message
    logger.info(
        "Audio message object: voice=%s audio=%s document=%s mime=%s",
        bool(getattr(message, "voice", None)),
        bool(getattr(message, "audio", None)),
        bool(getattr(message, "document", None)),
        getattr(getattr(message, "document", None), "mime_type", None),
    )

    audio_obj = None
    audio_kind = "unknown"
    extension = "oga"

    if message.voice:
        audio_obj = message.voice
        audio_kind = "voice"
        extension = "oga"
    elif message.audio:
        audio_obj = message.audio
        audio_kind = "audio"
        extension = "mp3"
    elif message.document and message.document.mime_type and message.document.mime_type.startswith("audio/"):
        audio_obj = message.document
        audio_kind = "document_audio"
        extension = "audio"

    if not audio_obj:
        logger.warning("Audio object not identified")
        await update.message.reply_text("Recibí algo, pero no pude identificarlo como audio.")
        return

    logger.info(
        "Audio object selected kind=%s file_id=%s unique_id=%s",
        audio_kind,
        getattr(audio_obj, "file_id", None),
        getattr(audio_obj, "file_unique_id", None),
    )

    file_id = getattr(audio_obj, "file_id", None)

    if not file_id:
        await update.message.reply_text("No pude obtener el archivo de audio.")
        return

    duration = int(getattr(audio_obj, "duration", 0) or 0)
    if duration > settings.voice_input_max_duration:
        await update.message.reply_text("El audio supera el límite permitido.")
        return
    advertised_size = int(getattr(audio_obj, "file_size", 0) or 0)
    if advertised_size > settings.voice_input_max_bytes:
        await update.message.reply_text("El audio supera el límite permitido.")
        return
    if voice_service.stt.capability() == Capability.UNAVAILABLE:
        await update.message.reply_text("La transcripción local no está disponible en este nodo.")
        return

    logger.info("Sending audio received acknowledgement")
    await update.message.reply_text("Recibí tu audio. Transcribiendo...")
    logger.info("Audio acknowledgement sent")

    audio_path = None
    stage = "download"
    try:
        handle, raw_path = tempfile.mkstemp(prefix="iclirius-inbound-", suffix=f".{extension}")
        os.close(handle)
        audio_path = Path(raw_path)
        os.chmod(audio_path, 0o600)
        download_started = time.monotonic()
        emit(EventType.VOICE_DOWNLOAD_STARTED.value, status=Status.STARTED.value,
             interface="telegram", metadata={"kind": audio_kind, "duration": duration})
        file = await context.bot.get_file(file_id)
        await file.download_to_drive(custom_path=str(audio_path))
        downloaded_bytes = audio_path.stat().st_size
        if downloaded_bytes > settings.voice_input_max_bytes:
            await update.message.reply_text("El audio supera el límite permitido.")
            return
        emit(EventType.VOICE_DOWNLOAD_COMPLETED.value, status=Status.OK.value,
             interface="telegram", metadata={"kind": audio_kind, "bytes": downloaded_bytes,
                                               "elapsed_ms": int((time.monotonic() - download_started) * 1000)})
        stt_started = time.monotonic()
        stage = "stt"
        emit(EventType.VOICE_STT_STARTED.value, status=Status.STARTED.value,
             interface="telegram", metadata={"provider": voice_service.stt.name,
                                               "bytes": downloaded_bytes})
        # faster-whisper initializes and iterates a CPU model synchronously;
        # keep it off Telegram's event loop so polling and error replies stay
        # live while transcription runs.
        transcript, metadata = await asyncio.to_thread(
            voice_service.stt.transcribe, audio_path
        )
        emit(EventType.VOICE_STT_COMPLETED.value, status=Status.OK.value,
             interface="telegram", metadata={"provider": metadata.get("provider", "local"),
                                               "elapsed_ms": int((time.monotonic() - stt_started) * 1000)})
        emit(EventType.USER_INPUT_TRANSCRIBED.value, status=Status.OK.value,
             interface="telegram", metadata={"chars": min(len(transcript), 300),
                                               "provider": metadata.get("provider", "local"),
                                               "confidence": metadata.get("confidence", "UNKNOWN")})
    except Exception:
        if stage == "download":
            emit(EventType.VOICE_DOWNLOAD_FAILED.value, status=Status.FAILED.value,
                 interface="telegram", metadata={"category": "download"})
        else:
            emit(EventType.VOICE_STT_FAILED.value, status=Status.FAILED.value,
                 interface="telegram", metadata={"provider": voice_service.stt.name,
                                                   "category": "local_stt"})
        logger.exception("Audio transcription failed")
        await update.message.reply_text("No pude transcribir ese audio con suficiente claridad.")
        return
    finally:
        if audio_path:
            audio_path.unlink(missing_ok=True)


    if not transcript:
        await update.message.reply_text("No detecté texto claro en el audio.")
        return

    await update.message.reply_text(f"Transcripción:\n{transcript[:3000]}")

    agent_started = time.monotonic()
    emit(EventType.VOICE_AGENT_STARTED.value, status=Status.STARTED.value,
         interface="telegram", metadata={"chars": min(len(transcript), 300)})
    try:
        agent.request_user_id = str(user_id) if user_id is not None else None
        response = agent.respond(transcript)
        agent.record_conversation_turn(
            transcript, response, source="telegram_audio", user_id=user_id)
        response = replace_stale_book_processing_response(response)
        emit(EventType.VOICE_AGENT_COMPLETED.value, status=Status.OK.value,
             interface="telegram", metadata={"elapsed_ms": int((time.monotonic() - agent_started) * 1000)})
    except Exception:
        emit(EventType.VOICE_AGENT_FAILED.value, status=Status.FAILED.value,
             interface="telegram", metadata={"category": "agent"})
        logger.exception("Voice agent response failed")
        await update.message.reply_text("No pude procesar el mensaje de voz.")
        return

    try:
        await update.message.reply_text(response[:3900])
    except Exception:
        logger.exception("Voice text response failed")
        return

    if voice_service.should_speak():
        artifact = None
        try:
            artifact = voice_service.synthesize(compact_for_voice(response))
            with artifact.path.open("rb") as audio:
                await update.message.reply_voice(voice=audio)
            emit(EventType.VOICE_SENT.value, status=Status.OK.value,
                 interface="telegram", metadata={"bytes": artifact.bytes,
                                                   "provider": artifact.provider})
        except Exception:
            emit(EventType.VOICE_SEND_FAILED.value, status=Status.FAILED.value,
                 interface="telegram", metadata={"provider": voice_service.tts.name})
            logger.exception("Telegram voice response failed")
        finally:
            if artifact:
                artifact.path.unlink(missing_ok=True)


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Stage one Telegram document through the bounded local AttachmentGateway."""
    user_id = _effective_user_id(update)
    if not is_allowed_update(update):
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return
    if not is_leader():
        await update.message.reply_text("Este nodo no es líder. Telegram solo responde desde el nodo líder.")
        return
    message = update.effective_message or update.message
    document = getattr(message, "document", None)
    if not document or not getattr(document, "file_id", None):
        await update.message.reply_text("No pude identificar el documento adjunto.")
        return
    gateway = agent.attachment_gateway
    original = str(getattr(document, "file_name", None) or "attachment")
    reported_mime = getattr(document, "mime_type", None)
    attachment_id, staged_path = gateway.allocate_path(original)
    try:
        remote = await context.bot.get_file(document.file_id)
        await remote.download_to_drive(custom_path=str(staged_path))
        record = gateway.finalize_staged(
            staged_path, attachment_id=attachment_id, original_filename=original,
            reported_mime=reported_mime, authenticated_user_id=str(user_id) if user_id is not None else None,
            source="telegram", source_message_id=getattr(message, "message_id", None),
            source_session_id=agent.session_id,
        )
    except Exception:
        staged_path.unlink(missing_ok=True)
        await update.message.reply_text("No pude guardar el archivo adjunto de forma segura.")
        return
    if record.status != "AUTHORIZED":
        staged_path.unlink(missing_ok=True)
        await update.message.reply_text(f"No puedo procesar este adjunto: {record.reason_code or record.status}.")
        return
    agent.last_attachment_id = record.attachment_id
    agent.last_attachment_by_user[str(user_id)] = record.attachment_id
    caption = str(getattr(message, "caption", None) or "").strip()
    if not caption:
        await update.message.reply_text("Recibí el archivo. Puedes preguntarme qué contiene.")
        return
    agent.request_user_id = str(user_id) if user_id is not None else None
    agent.request_attachment_id = record.attachment_id
    try:
        response = agent.respond(caption)
        agent.record_conversation_turn(caption, response, source="telegram_attachment", user_id=user_id)
    except Exception:
        logger.exception("Attachment agent response failed")
        await update.message.reply_text("Recibí el archivo, pero no pude procesarlo localmente.")
        return
    await update.message.reply_text(response[:MAX_TELEGRAM_REPLY])

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Authorization must come first. Nothing about the internal state of the
    # node may reach an unauthorized user, not even progress or status text.
    if not is_allowed_update(update):
        logger.warning("Blocked unauthorized user_id=%s", _effective_user_id(update))
        await update.message.reply_text("No tienes permiso para usar este agente.")
        return

    if not is_leader():
        await update.message.reply_text(
            "Este nodo no es líder. Telegram solo responde desde el nodo líder."
        )
        return

    user_id = _effective_user_id(update)
    message = update.message.text

    try:
        if is_owner_update(update):
            log_request(message, source="telegram")
    except Exception:
        logger.exception("Failed to log request learning")

    logger.info("Message from user_id=%s length=%s", user_id, len(message))

    try:
        status_progress_response = answer_status_or_books_progress(message)
        if status_progress_response:
            await update.message.reply_text(status_progress_response[:MAX_TELEGRAM_REPLY])
            return

        agent.request_user_id = str(user_id) if user_id is not None else None
        response = agent.respond(message)

        agent.record_conversation_turn(
            message, response, source="telegram", user_id=user_id)

        response = replace_stale_book_processing_response(response)
    except Exception:
        logger.exception("handle_message failed for user_id=%s", user_id)
        await update.message.reply_text(
            "Tuve un error interno procesando tu mensaje. Revisa /logs para el detalle."
        )
        return

    await update.message.reply_text(response[:MAX_TELEGRAM_REPLY])

    if voice_service.should_speak():
        artifact = None
        try:
            artifact = voice_service.synthesize(compact_for_voice(response))
            with artifact.path.open("rb") as audio:
                await update.message.reply_voice(voice=audio)
            emit(EventType.VOICE_SENT.value, status=Status.OK.value,
                 interface="telegram", metadata={"bytes": artifact.bytes,
                                                   "provider": artifact.provider})
        except Exception:
            emit(EventType.VOICE_SEND_FAILED.value, status=Status.FAILED.value,
                 interface="telegram", metadata={"provider": voice_service.tts.name})
            logger.exception("Telegram voice response failed")
        finally:
            if artifact:
                artifact.path.unlink(missing_ok=True)


def run_telegram_bot():
    if not settings.telegram_bot_token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN no está configurado en .env")

    if not settings.allowed_user_ids:
        raise RuntimeError("ALLOWED_USER_IDS no está configurado en .env")

    write_node_status()

    logger.info(
        "Starting Telegram bot for agent=%s node=%s role=%s",
        settings.agent_name,
        settings.node_id,
        settings.role,
    )

    lease_guard = None
    if settings.telegram_mode == "FAILOVER":
        from app.telegram_lease import LeaseBusy, LeaseGuard, provider_from_config
        lease_path = settings.telegram_lease_path or str(
            Path.home() / ".iclirius" / "telegram-lease.json")
        backend_path = settings.telegram_lease_database or lease_path
        provider = provider_from_config(settings.telegram_lease_backend, backend_path)
        try:
            lease = provider.acquire(bot_token=settings.telegram_bot_token,
                                     node_id=settings.node_id,
                                     user_id=settings.user_id,
                                     ttl_seconds=settings.telegram_lease_ttl_seconds)
        except LeaseBusy as exc:
            raise RuntimeError("Telegram node is STANDBY: another authorized node owns the lease") from exc
        lease_guard = LeaseGuard(provider, lease, settings.telegram_lease_ttl_seconds,
                                 lambda: app.stop() if 'app' in locals() else None)

    app = ApplicationBuilder().token(settings.telegram_bot_token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("background", background_command))
    app.add_handler(CommandHandler("health", health))
    app.add_handler(CommandHandler("version", version))
    app.add_handler(CommandHandler("gitstatus", gitstatus))
    app.add_handler(CommandHandler("logs", logs))
    app.add_handler(CommandHandler("reset", reset_command))
    app.add_handler(CommandHandler("backup", backup))
    app.add_handler(CommandHandler("backup_status", backup_status))
    app.add_handler(CommandHandler("whoami", whoami))
    app.add_handler(CommandHandler("web", web_command))
    app.add_handler(CommandHandler("localread", localread_command))
    app.add_handler(CommandHandler("localstatus", localstatus_command))
    app.add_handler(CommandHandler("capabilities", capabilities_command))
    app.add_handler(CommandHandler("models", models_command))
    app.add_handler(CommandHandler("providers", providers_command))
    app.add_handler(CommandHandler("usage", usage_command))
    app.add_handler(CommandHandler("voice", voice_command))
    app.add_handler(CommandHandler("say", say_command))
    app.add_handler(CommandHandler("memory_core", memory_core_command))
    app.add_handler(CommandHandler("project", project_command))
    app.add_handler(CommandHandler("mytasks", memtasks_command))
    app.add_handler(CommandHandler("worker_awake", worker_awake))
    app.add_handler(CommandHandler("worker_sleep", worker_sleep))
    app.add_handler(CommandHandler("worker_logs", worker_logs))
    app.add_handler(CommandHandler("worker", worker_command))
    app.add_handler(CommandHandler("worker_status", worker_status))
    app.add_handler(CommandHandler("catalog_folder", catalog_folder_command))
    app.add_handler(CommandHandler("catalog_stats", catalog_stats_command))
    app.add_handler(CommandHandler("find_file", find_file_command))
    app.add_handler(CommandHandler("learn_folder", learn_folder_command))
    app.add_handler(CommandHandler("ingest_status", ingest_status_command))
    app.add_handler(CommandHandler("library_status", library_status_command))
    app.add_handler(CommandHandler("ask_library", ask_library_command))
    app.add_handler(CommandHandler("file_empty", file_empty_command))
    app.add_handler(CommandHandler("file_reports", file_reports_command))
    app.add_handler(CommandHandler("file_quarantine", file_quarantine_command))
    app.add_handler(CommandHandler("tasks", tasks_command))
    app.add_handler(CommandHandler("task_add", task_add_command))
    app.add_handler(CommandHandler("task_done", task_done_command))
    app.add_handler(CommandHandler("task_cancel", task_cancel_command))
    app.add_handler(CommandHandler("task_clear", task_clear_command))
    app.add_handler(CommandHandler("task_run", task_run_command))
    app.add_handler(CommandHandler("task_result", task_result_command))
    app.add_handler(CommandHandler("brain", brain_command))
    app.add_handler(CommandHandler("summary", summary_command))
    app.add_handler(CommandHandler("learned", learned_command))
    app.add_handler(CommandHandler("learning", learning_command))
    app.add_handler(CommandHandler("learned_clear", learned_clear_command))
    app.add_handler(CommandHandler("digest_log", digest_log_command))
    app.add_handler(CommandHandler("personality", personality_command))
    app.add_handler(CommandHandler("project_status", project_status_command))
    app.add_handler(CommandHandler("memory", memory_command))
    app.add_handler(CommandHandler("history", history))
    app.add_handler(CommandHandler("forget_last", forget_last))
    app.add_handler(CommandHandler("remember", remember))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO | filters.Document.AUDIO, handle_voice))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    if lease_guard:
        lease_guard.start()
    try:
        app.run_polling()
    finally:
        if lease_guard:
            lease_guard.stop()

async def reset_command(update, context):
    if not is_owner_update(update):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text("Reiniciando runtime local...")

    import subprocess
    from pathlib import Path

    candidates = [
        Path("scripts/reset_runtime.sh"),
        Path("./reset_runtime.sh"),
    ]

    script = next((p for p in candidates if p.exists()), None)

    if not script:
        await update.message.reply_text("No encontré script de reset runtime.")
        return

    result = subprocess.run(
        ["bash", str(script)],
        capture_output=True,
        text=True,
        timeout=120,
    )

    output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
    if not output:
        output = "Reset ejecutado."

    await update.message.reply_text(output[-3500:])

async def background_command(update, context):
    if not is_owner_update(update):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(background_status(15)[:MAX_TELEGRAM_REPLY])

async def learning_command(update, context):
    if not is_owner_update(update):
        await update.message.reply_text("Este comando solo está disponible para el owner.")
        return

    await update.message.reply_text(learning_summary()[:MAX_TELEGRAM_REPLY])


if __name__ == "__main__":
    run_telegram_bot()
