import argparse
import subprocess
import sys

from interfaces.cli_chat import run_single_message, run_interactive_chat
from coding.code_agent import run_code_plan, analyze_file, generate_diff_plan
from coding.project_context import collect_project_context, format_project_context
from coding.safe_reader import safe_list_files, safe_read_file, SafeReadError
from coding.workspace import inspect_workspace, format_workspace
from coding.intelligence import (find_definition, find_imports, find_references,
                                 related_files, related_tests, search_code, snippet)
from coding.workers import WorkerRegistry, make_task
from coding.execution import SafeExecutor, make_request
from coding.workflow import CodeChangeWorkflow, CodeWorkflowError, normalize_model_plan
import json

from app.worker_client import ask_worker
from app.worker_control import worker_update_text, worker_logs_text, worker_restart_text, worker_awake_text, worker_sleep_text
from app.system_tools import (
    get_health_text,
    get_version_text,
    get_git_status_text,
    get_backup_status_text,
    get_recent_logs_text,
    run_backup_text,
)


def run_script(command: list[str]) -> int:
    process = subprocess.run(command)
    return process.returncode


def daemon_command(args):
    return run_script(["./scripts/daemon_start.sh"])



def reset_command(args):
    """Reset local iclirius runtime state without deleting memory or documents."""
    import subprocess
    import time
    from pathlib import Path

    print("Resetting iclirius runtime...")

    # 1) Ask normal daemon to stop first
    subprocess.run(["bash", "-lc", "iclirius sleep 2>/dev/null || true"])

    # 2) Kill known runtime processes gently, then forcefully
    patterns = [
        "run.py",
        "run_node.sh",
        "telegram_bot",
        "caffeinate.*run_node",
        "caffeinate -dimsu",
    ]

    for pattern in patterns:
        subprocess.run(["bash", "-lc", f"pkill -f '{pattern}' 2>/dev/null || true"])

    time.sleep(2)

    for pattern in patterns:
        subprocess.run(["bash", "-lc", f"pkill -9 -f '{pattern}' 2>/dev/null || true"])

    time.sleep(1)

    project_dir = Path.cwd()

    state_files = [
        project_dir / "data/state/iclirius.lock",
        project_dir / "data/state/iclirius_daemon.pid",
    ]

    for item in state_files:
        try:
            item.unlink(missing_ok=True)
            print(f"Removed: {item}")
        except Exception as exc:
            print(f"Could not remove {item}: {exc}")

    audio_dir = project_dir / "data/audio"
    if audio_dir.exists():
        for item in audio_dir.glob("*"):
            if item.is_file():
                try:
                    item.unlink()
                except Exception as exc:
                    print(f"Could not remove temp audio {item}: {exc}")
        print("Cleaned temporary audio files.")

    print("Checking remaining processes...")
    check = subprocess.run(
        ["bash", "-lc", "ps auxww | grep -E 'run.py|run_node|telegram_bot|caffeinate' | grep -v grep || true"],
        text=True,
        capture_output=True,
    )

    if check.stdout.strip():
        print("Warning: some related processes are still running:")
        print(check.stdout)
        return 1

    print("No iclirius runtime processes found.")
    print("Reset complete. Start again with: iclirius daemon")
    return 0


def sleep_command(args):
    return run_script(["./scripts/daemon_stop.sh"])


def start_command(args):
    return run_script(["./scripts/run_node.sh"])


def health_command(args):
    print(get_health_text())
    return 0


def version_command(args):
    print(get_version_text())
    return 0


def gitstatus_command(args):
    print(get_git_status_text())
    return 0


def backup_command(args):
    print("Starting backup...")
    print(run_backup_text())
    return 0


def backup_status_command(args):
    print(get_backup_status_text())
    return 0


def logs_command(args):
    print(get_recent_logs_text(args.lines))
    return 0


def worker_awake_command(args):
    print("Enabling worker awake mode over SSH...")
    print(worker_awake_text())
    return 0


def worker_sleep_command(args):
    print("Disabling worker awake mode over SSH...")
    print(worker_sleep_text())
    return 0


def worker_update_command(args):
    print("Updating worker over SSH...")
    print(worker_update_text())
    return 0


def worker_restart_command(args):
    print("Restarting worker over SSH...")
    print(worker_restart_text())
    return 0


def worker_logs_command(args):
    print(worker_logs_text(args.lines))
    return 0


def worker_command(args):
    prompt = " ".join(args.prompt).strip()

    if not prompt:
        print('Use: iclirius worker "tu tarea"')
        return 1

    print("Sending task to worker...")
    response = ask_worker(prompt)
    print()
    print(response)
    return 0


def chat_command(args):
    message = " ".join(args.message).strip()

    if message:
        return run_single_message(message)

    return run_interactive_chat()


def code_command(args):
    prompt = " ".join(args.prompt).strip()

    # C1's default is a deterministic workspace snapshot.  Keep the older
    # explicitly requested analysis/read modes available for compatibility.
    is_fix = "fix" in args.prompt
    legacy_mode = any((args.files, args.read, (args.plan and not is_fix), args.diff, args.context, args.analyze))
    if not legacy_mode:
        tokens = list(args.prompt)
        if tokens and tokens[0] == "workers":
            registry = WorkerRegistry()
            if getattr(args, "json", False):
                print(json.dumps({"workers": [c.to_dict() for c in registry.capabilities()]}, ensure_ascii=False, indent=2))
            else:
                print("ICLIRIUS CODE WORKERS\n")
                for capability in registry.capabilities():
                    print(f"{capability.worker_id:<18} {capability.availability:<11} {capability.execution_type.lower()}")
            return 0
        operations = {"search", "definition", "references", "imports", "tests", "related", "snippet"}
        requested = None
        operation = None
        query = ""
        if tokens and tokens[0] in operations:
            operation, query = tokens[0], " ".join(tokens[1:])
        elif len(tokens) >= 2 and tokens[1] in operations:
            requested, operation, query = tokens[0], tokens[1], " ".join(tokens[2:])
        elif tokens and tokens[0] == "fix":
            operation, query = "fix", " ".join(tokens[1:])
        elif len(tokens) >= 2 and tokens[1] == "fix":
            requested, operation, query = tokens[0], "fix", " ".join(tokens[2:])
        elif tokens and tokens[0] == "reason":
            operation, query = "reason", " ".join(tokens[1:])
        elif len(tokens) >= 2 and tokens[1] == "reason":
            requested, operation, query = tokens[0], "reason", " ".join(tokens[2:])
        elif tokens and tokens[0] == "action":
            operation, query = "action", " ".join(tokens[1:])
        elif len(tokens) >= 2 and tokens[1] == "action":
            requested, operation, query = tokens[0], "action", " ".join(tokens[2:])
        elif len(tokens) == 1:
            requested = tokens[0]
        try:
            workspace = inspect_workspace(requested)
        except ValueError as exc:
            print(f"Workspace error: {exc}")
            return 2
        if operation:
            if not query:
                print("Code query is required")
                return 2
            if operation == "reason":
                evidence = search_code(workspace, query)
                task = make_task("code.reason", workspace, instruction=f"Interpret evidence for {query}", evidence_package=evidence)
                result = WorkerRegistry().run(task)
                if getattr(args, "json", False): print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
                else: print(result.output if result.status == "SUCCESS" else f"Worker failed: {', '.join(result.errors)}")
                return 0 if result.status == "SUCCESS" else 1
            if operation == "fix":
                evidence = search_code(workspace, query)
                task = make_task("code.reason", workspace, instruction=f"Propose a JSON change plan for: {query}", evidence_package=evidence)
                result = WorkerRegistry().run(task)
                if result.status != "SUCCESS":
                    print(f"Worker unavailable: {', '.join(result.errors)}")
                    return 1
                try:
                    plan = normalize_model_plan(workspace, query, evidence, result.output)
                except CodeWorkflowError as exc:
                    print(f"No se pudo validar el plan: {exc}")
                    return 2
                if getattr(args, "json", False):
                    print(json.dumps({"plan": plan.to_dict(), "approval_required": True}, ensure_ascii=False, indent=2))
                else:
                    print("ICLIRIUS CODE PLAN\n")
                    print(json.dumps(plan.to_dict(), ensure_ascii=False, indent=2))
                    print("\nApply this plan? [y/N]")
                return 0
            if operation == "action":
                action = make_request(workspace, query)
                decision, result = SafeExecutor().execute(action, workspace, noninteractive=True)
                payload = {"decision": decision.to_dict(), "result": result.to_dict()}
                if getattr(args, "json", False): print(json.dumps(payload, ensure_ascii=False, indent=2))
                else: print(f"{decision.decision}: {result.status} {result.error or result.output[:500]}")
                return 0 if result.status == "SUCCESS" else 1
            if operation == "search": package = search_code(workspace, query)
            elif operation == "definition": package = find_definition(workspace, query)
            elif operation == "references": package = find_references(workspace, query)
            elif operation == "imports": package = find_imports(workspace, query)
            elif operation == "tests": package = related_tests(workspace, query)
            else: package = related_files(workspace, query)
            if getattr(args, "json", False):
                print(json.dumps(package.to_dict(), ensure_ascii=False, indent=2))
            else:
                print(f"ICLIRIUS CODE\n\nWorkspace  {workspace.project_name}\nOperation  {package.operation}\nQuery      {package.query}\n")
                for finding in package.findings:
                    print(f"{finding.relative_path}:{finding.line_start} [{finding.kind}] {finding.reason}")
                    if finding.snippet:
                        print(finding.snippet)
                print(f"\nEvidence: {len(package.findings)} finding(s)" + (" (truncated)" if package.truncated else ""))
            return 0
        if getattr(args, "json", False):
            print(json.dumps({"schema_version": 1, "workspace": workspace.to_dict()}, ensure_ascii=False, indent=2))
        else:
            print(format_workspace(workspace))
        return 0

    context = collect_project_context()

    print("iclirius code mode: safe analysis only")
    print("No files will be modified.")
    print()
    print(f"Project root: {context['project_root']}")
    print(f"Git status: {context['git_status']}")
    print("Detected stack:")
    for item in context["stack"]:
        print(f"- {item}")
    print()

    if args.files:
        for file in safe_list_files(max_files=args.max_files):
            print(file)
        return 0

    if args.read:
        try:
            if args.analyze:
                response = analyze_file(args.read, prompt or None)
                print(response)
            else:
                file_data = safe_read_file(args.read)
                print(f"File: {file_data['path']}")
                print(f"Size chars: {file_data['size_chars']}")
                print(f"Truncated: {file_data['truncated']}")
                print()
                print(file_data["content"])
        except SafeReadError as exc:
            print(f"Safe read blocked: {exc}")
            return 1

        return 0

    if args.plan:
        if not prompt:
            print("Use --plan with a request, for example:")
            print('iclirius code --plan "agrega una página About"')
            return 1

        plan_prompt = f"""
Modo PLAN de código.

Reglas:
- No edites archivos.
- No generes diff todavía.
- No ejecutes comandos.
- No digas que modificaste nada.
- Solo entrega un plan seguro.
- Responde en español.

Solicitud del usuario:
{prompt}

Responde exactamente con estas secciones:
1. Objetivo
2. Archivos que revisaría
3. Archivos que probablemente tocaría
4. Cambios propuestos
5. Riesgos
6. Comandos de prueba sugeridos
7. Preguntas antes de editar, si aplica
""".strip()

        response = run_code_plan(plan_prompt)
        print(response)
        return 0

    if args.diff:
        if not prompt:
            print("Use --diff with a request, for example:")
            print('iclirius code --diff "agrega una página About"')
            return 1

        response = generate_diff_plan(prompt)
        print(response)
        return 0

    if args.context:
        print(format_project_context(context))
        return 0

    if not args.analyze:
        print("Use --files to list readable files.")
        print("Use --read path/to/file.py to safely read a file.")
        print("Use --context to print full detected context.")
        print("Use --analyze \"your request\" to ask iclirius for a code analysis.")
        return 0

    response = run_code_plan(prompt or None)
    print(response)
    return 0

def build_parser():
    parser = argparse.ArgumentParser(
        prog="iclirius",
        description="iclirius CLI powered by the OpenClaw framework"
    )

    subparsers = parser.add_subparsers(dest="command")
    daemon = subparsers.add_parser("daemon", help="Run iclirius in background and prevent idle sleep")
    daemon.set_defaults(func=daemon_command)

    # "demain" is a legacy typo of "daemon". Kept as a hidden alias so any
    # existing muscle memory or script keeps working.
    demain = subparsers.add_parser("demain", help=argparse.SUPPRESS)
    demain.set_defaults(func=daemon_command)

    reset = subparsers.add_parser("reset", help="Reset iclirius runtime state")
    reset.set_defaults(func=reset_command)

    sleep = subparsers.add_parser("sleep", help="Stop iclirius daemon completely")
    sleep.set_defaults(func=sleep_command)


    start = subparsers.add_parser("start", help="Start iclirius Telegram node")
    start.set_defaults(func=start_command)

    health = subparsers.add_parser("health", help="Show local health check")
    health.set_defaults(func=health_command)

    version = subparsers.add_parser("version", help="Show version and node info")
    version.set_defaults(func=version_command)

    gitstatus = subparsers.add_parser("gitstatus", help="Show Git status")
    gitstatus.set_defaults(func=gitstatus_command)

    backup = subparsers.add_parser("backup", help="Run Google Drive backup")
    backup.set_defaults(func=backup_command)

    backup_status = subparsers.add_parser("backup-status", help="Show backup status")
    backup_status.set_defaults(func=backup_status_command)

    logs = subparsers.add_parser("logs", help="Show recent logs")
    logs.add_argument("--lines", type=int, default=30)
    logs.set_defaults(func=logs_command)

    worker_awake = subparsers.add_parser("worker-awake", help="Keep worker Mac awake over SSH")
    worker_awake.set_defaults(func=worker_awake_command)

    worker_sleep = subparsers.add_parser("worker-sleep", help="Disable worker awake mode over SSH")
    worker_sleep.set_defaults(func=worker_sleep_command)

    worker_update = subparsers.add_parser("worker-update", help="Update worker node over SSH")
    worker_update.set_defaults(func=worker_update_command)

    worker_restart = subparsers.add_parser("worker-restart", help="Restart worker server over SSH")
    worker_restart.set_defaults(func=worker_restart_command)

    worker_logs = subparsers.add_parser("worker-logs", help="Show worker logs over SSH")
    worker_logs.add_argument("--lines", type=int, default=80)
    worker_logs.set_defaults(func=worker_logs_command)

    worker = subparsers.add_parser("worker", help="Send a task to the configured worker node")
    worker.add_argument("prompt", nargs="*", help="Task to send to worker")
    worker.set_defaults(func=worker_command)

    chat = subparsers.add_parser("chat", help="Chat with iclirius in terminal")
    chat.add_argument("message", nargs="*", help="Message to send to iclirius")
    chat.set_defaults(func=chat_command)

    code = subparsers.add_parser("code", help="Inspect a project workspace (read-only)")
    code.add_argument("--files", action="store_true", help="List readable project files")
    code.add_argument("--max-files", type=int, default=120, help="Maximum files to list")
    code.add_argument("--read", help="Safely read a project file")
    code.add_argument("--plan", action="store_true", help="Generate a safe implementation plan without editing files")
    code.add_argument("--diff", action="store_true", help="Generate a proposed diff without editing files")
    code.add_argument("--context", action="store_true", help="Only print detected project context without calling Ollama")
    code.add_argument("--analyze", action="store_true", help="Ask Ollama to analyze the detected project context")
    code.add_argument("--json", action="store_true", help="Print the deterministic workspace snapshot as JSON")
    code.add_argument("prompt", nargs="*", help="Coding request")
    code.set_defaults(func=code_command)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        return start_command(args)

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
