from pathlib import Path

from coding.project_context import find_project_root, list_project_files


BLOCKED_NAMES = {
    ".env",
    ".env.local",
    ".env.production",
    ".env.development",
    "id_rsa",
    "id_ed25519",
}

BLOCKED_SUFFIXES = {
    ".pem",
    ".key",
    ".crt",
    ".p12",
    ".pfx",
    ".enc",
}

BLOCKED_PARTS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".next",
    "dist",
    "build",
    "logs",
    "data/memory",
    "data/identity",
    "data/state",
    "data/chroma",
}


class SafeReadError(Exception):
    pass


def is_blocked_path(relative_path: str) -> bool:
    path = Path(relative_path)
    normalized = relative_path.replace("\\", "/")

    if path.name in BLOCKED_NAMES:
        return True

    if path.suffix in BLOCKED_SUFFIXES:
        return True

    for part in BLOCKED_PARTS:
        if normalized == part or normalized.startswith(part + "/"):
            return True

    return False


def safe_resolve(project_root: Path, relative_path: str) -> Path:
    if not relative_path:
        raise SafeReadError("No file path provided.")

    if is_blocked_path(relative_path):
        raise SafeReadError(f"Blocked sensitive or ignored path: {relative_path}")

    root = project_root.resolve()
    target = (root / relative_path).resolve()

    if not str(target).startswith(str(root)):
        raise SafeReadError("Path escapes project root.")

    if not target.exists():
        raise SafeReadError(f"File does not exist: {relative_path}")

    if not target.is_file():
        raise SafeReadError(f"Path is not a file: {relative_path}")

    return target


def safe_read_file(relative_path: str, max_chars: int = 12000) -> dict:
    project_root = find_project_root()
    target = safe_resolve(project_root, relative_path)

    content = target.read_text(encoding="utf-8", errors="ignore")
    truncated = len(content) > max_chars

    return {
        "project_root": str(project_root),
        "path": relative_path,
        "size_chars": len(content),
        "truncated": truncated,
        "content": content[:max_chars],
    }


def safe_list_files(max_files: int = 120) -> list[str]:
    project_root = find_project_root()
    files = list_project_files(project_root, max_files=max_files)

    return [
        file for file in files
        if not is_blocked_path(file)
    ]
