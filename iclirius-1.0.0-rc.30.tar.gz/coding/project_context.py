import os
import subprocess
from pathlib import Path


SAFE_README_NAMES = [
    "README.md",
    "README.txt",
    "readme.md",
]


IMPORTANT_FILES = [
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "Pipfile",
    "poetry.lock",
    "next.config.js",
    "next.config.mjs",
    "tsconfig.json",
    "vite.config.js",
    "vite.config.ts",
    "Dockerfile",
    "docker-compose.yml",
    ".env.example",
    "README.md",
]


IGNORED_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".next",
    "dist",
    "build",
    ".cache",
    ".idea",
    ".vscode",
    "logs",
    "data/chroma",
}


def run_command(command: list[str], cwd: str, timeout: int = 10) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = (result.stdout + result.stderr).strip()
        return result.returncode == 0, output
    except Exception as exc:
        return False, str(exc)


def find_project_root(start_path: str | None = None) -> Path:
    current = Path(start_path or os.getcwd()).resolve()

    for path in [current, *current.parents]:
        if (path / ".git").exists():
            return path

    return current


def get_git_status(project_root: Path) -> str:
    ok, output = run_command(["git", "status", "--short"], cwd=str(project_root))

    if not ok:
        return "Git no disponible o este directorio no es un repo."

    if not output:
        return "working tree clean"

    return output


def list_project_files(project_root: Path, max_files: int = 80) -> list[str]:
    results = []

    for root, dirs, files in os.walk(project_root):
        root_path = Path(root)
        relative_root = root_path.relative_to(project_root)

        dirs[:] = [
            d for d in dirs
            if str(relative_root / d) not in IGNORED_DIRS and d not in IGNORED_DIRS
        ]

        for file in files:
            relative_file = str((root_path / file).relative_to(project_root))

            if any(relative_file.startswith(ignored + "/") for ignored in IGNORED_DIRS):
                continue

            results.append(relative_file)

            if len(results) >= max_files:
                return sorted(results)

    return sorted(results)


def detect_stack(project_root: Path) -> list[str]:
    stack = []

    if (project_root / "package.json").exists():
        stack.append("Node.js / JavaScript / TypeScript")

    if (project_root / "next.config.js").exists() or (project_root / "next.config.mjs").exists():
        stack.append("Next.js")

    if (project_root / "vite.config.js").exists() or (project_root / "vite.config.ts").exists():
        stack.append("Vite")

    if (project_root / "tsconfig.json").exists():
        stack.append("TypeScript")

    if (project_root / "requirements.txt").exists():
        stack.append("Python requirements.txt")

    if (project_root / "pyproject.toml").exists():
        stack.append("Python pyproject.toml")

    if (project_root / "Dockerfile").exists():
        stack.append("Docker")

    if not stack:
        stack.append("Stack no detectado automáticamente")

    return stack


def read_small_file(path: Path, max_chars: int = 4000) -> str:
    if not path.exists() or not path.is_file():
        return ""

    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
        return content[:max_chars]
    except Exception:
        return ""


def collect_project_context(start_path: str | None = None) -> dict:
    project_root = find_project_root(start_path)

    important_found = [
        file for file in IMPORTANT_FILES
        if (project_root / file).exists()
    ]

    readme_content = ""
    for readme_name in SAFE_README_NAMES:
        readme_content = read_small_file(project_root / readme_name)
        if readme_content:
            break

    return {
        "project_root": str(project_root),
        "git_status": get_git_status(project_root),
        "stack": detect_stack(project_root),
        "important_files": important_found,
        "file_tree": list_project_files(project_root),
        "readme": readme_content,
    }


def format_project_context(context: dict) -> str:
    lines = [
        "Project context:",
        f"Root: {context['project_root']}",
        "",
        "Git status:",
        context["git_status"],
        "",
        "Detected stack:",
    ]

    for item in context["stack"]:
        lines.append(f"- {item}")

    lines.append("")
    lines.append("Important files:")

    if context["important_files"]:
        for file in context["important_files"]:
            lines.append(f"- {file}")
    else:
        lines.append("- None detected")

    lines.append("")
    lines.append("File tree sample:")

    for file in context["file_tree"]:
        lines.append(f"- {file}")

    if context["readme"]:
        lines.append("")
        lines.append("README excerpt:")
        lines.append(context["readme"])

    return "\n".join(lines)
