"""Local C3 worker runtime: bounded task/result envelopes and registry."""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum

from app.evidence import EvidenceRecord
from app.reasoning import Purpose, ReasoningRequest, ResponseStatus
from app.reasoning_gateway import GatewayError, ReasoningGateway
from app.config import settings
from coding.intelligence import (CodeEvidencePackage, find_definition,
                                 find_imports, find_references, related_tests,
                                 search_code, snippet)
from coding.workspace import CodeWorkspace


MAX_OUTPUT_CHARS = 4000
MAX_INSTRUCTION_CHARS = 1000
MAX_EVIDENCE_CHARS = 12000
MAX_EVIDENCE_ITEMS = 50


class WorkerStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    PARTIAL = "PARTIAL"


@dataclass(frozen=True)
class WorkerCapability:
    schema_version: int
    worker_id: str
    name: str
    kind: str
    description: str
    input_types: tuple[str, ...] = ()
    output_types: tuple[str, ...] = ()
    execution_type: str = "DETERMINISTIC"
    provider_requirement: str = ""
    model_requirement: str = ""
    read_only: bool = True
    writes_project: bool = False
    executes_commands: bool = False
    requires_network: bool = False
    availability: str = "READY"
    reason: str = ""

    def to_dict(self) -> dict:
        data = asdict(self)
        data["input_types"] = list(self.input_types)
        data["output_types"] = list(self.output_types)
        return data


@dataclass(frozen=True)
class WorkerTask:
    schema_version: int
    task_id: str
    worker_id: str
    workspace_id: str
    task_type: str
    instruction: str = ""
    evidence_package: CodeEvidencePackage | None = field(default=None, repr=False)
    inputs: dict = field(default_factory=dict)
    limits: dict = field(default_factory=dict)
    created_at: str = ""

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "task_id": self.task_id, "worker_id": self.worker_id, "workspace_id": self.workspace_id, "task_type": self.task_type, "instruction": self.instruction[:MAX_INSTRUCTION_CHARS], "inputs": self.inputs, "limits": self.limits, "created_at": self.created_at, "evidence_package": self.evidence_package.to_dict() if self.evidence_package else None}


@dataclass(frozen=True)
class WorkerResult:
    schema_version: int
    task_id: str
    worker_id: str
    status: str
    summary: str = ""
    output: str = ""
    evidence: tuple[EvidenceRecord, ...] = field(default_factory=tuple, repr=False)
    warnings: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    provider: str = ""
    model: str = ""
    duration_ms: int = 0
    truncated: bool = False

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "task_id": self.task_id, "worker_id": self.worker_id, "status": self.status, "summary": self.summary, "output": self.output[:MAX_OUTPUT_CHARS], "evidence": [e.to_dict() for e in self.evidence], "warnings": list(self.warnings), "errors": list(self.errors), "provider": self.provider, "model": self.model, "duration_ms": self.duration_ms, "truncated": self.truncated or len(self.output) > MAX_OUTPUT_CHARS}


class WorkerError(RuntimeError):
    pass


def make_task(worker_id: str, workspace: CodeWorkspace, *, instruction: str = "", evidence_package=None, inputs=None, task_type: str = "code") -> WorkerTask:
    return WorkerTask(1, f"wt_{uuid.uuid4().hex[:12]}", worker_id, workspace.workspace_id, task_type, instruction[:MAX_INSTRUCTION_CHARS], evidence_package, inputs or {}, {"max_output_chars": MAX_OUTPUT_CHARS, "max_evidence_chars": MAX_EVIDENCE_CHARS}, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))


class _DeterministicWorker:
    def __init__(self, worker_id, name, operation):
        self.capability = WorkerCapability(1, worker_id, name, "repository", f"Deterministic {name.lower()}", ("CodeWorkspace",), ("CodeEvidencePackage",))
        self.operation = operation

    def run(self, task: WorkerTask) -> WorkerResult:
        if not task.evidence_package and task.inputs.get("workspace") is None:
            raise WorkerError("workspace or evidence is required")
        started = time.monotonic()
        package = task.evidence_package
        if package and package.workspace_id != task.workspace_id:
            raise WorkerError("workspace mismatch")
        try:
            if package is None:
                workspace = task.inputs["workspace"]
                if self.operation == "search": package = search_code(workspace, task.inputs["query"])
                elif self.operation == "definition": package = find_definition(workspace, task.inputs["symbol"])
                elif self.operation == "references": package = find_references(workspace, task.inputs["symbol"])
                elif self.operation == "imports": package = find_imports(workspace, task.inputs["path"])
                elif self.operation == "tests": package = related_tests(workspace, task.inputs["path"])
                elif self.operation == "snippet": package = snippet(workspace, task.inputs["path"], int(task.inputs["line_start"]), int(task.inputs["line_end"]))
            return WorkerResult(1, task.task_id, task.worker_id, WorkerStatus.SUCCESS.value, f"{len(package.findings)} finding(s)", json.dumps(package.to_dict(), ensure_ascii=False), package.evidence_records, duration_ms=int((time.monotonic()-started)*1000), truncated=package.truncated)
        except ValueError as exc:
            return WorkerResult(1, task.task_id, task.worker_id, WorkerStatus.BLOCKED.value, errors=(str(exc),), duration_ms=int((time.monotonic()-started)*1000))


class _ReasonWorker:
    capability = WorkerCapability(1, "code.reason", "Code reason", "code", "Interpret supplied code evidence", ("WorkerTask", "CodeEvidencePackage"), ("WorkerResult",), "MODEL_BACKED", "ollama-local", "configured default", True, False, False, False)

    def __init__(self, gateway=None):
        self.gateway = gateway or ReasoningGateway()

    def availability(self) -> WorkerCapability:
        try:
            provider = self.gateway.registry.get("ollama-local")
            if provider is None:
                return WorkerCapability(**{**self.capability.to_dict(), "input_types": tuple(self.capability.input_types), "output_types": tuple(self.capability.output_types), "availability": "UNAVAILABLE", "reason": "ollama-local provider unavailable"})
            health = provider.health()
            ready = str(getattr(health, "value", health)).upper() not in {"UNAVAILABLE", "DISABLED"}
            if ready:
                try:
                    models = provider.models()
                    if models and settings.default_model not in models:
                        ready = False
                        reason = f"model {settings.default_model} unavailable"
                    else:
                        reason = ""
                except Exception:
                    reason = ""
            else:
                reason = "Ollama unavailable"
            return WorkerCapability(**{**self.capability.to_dict(), "input_types": tuple(self.capability.input_types), "output_types": tuple(self.capability.output_types), "availability": "READY" if ready else "UNAVAILABLE", "reason": reason})
        except Exception as exc:
            return WorkerCapability(**{**self.capability.to_dict(), "input_types": tuple(self.capability.input_types), "output_types": tuple(self.capability.output_types), "availability": "UNAVAILABLE", "reason": type(exc).__name__})

    def run(self, task: WorkerTask) -> WorkerResult:
        started = time.monotonic()
        package = task.evidence_package
        if package is None or package.workspace_id != task.workspace_id:
            raise WorkerError("matching evidence package is required")
        compact = {"workspace_id": task.workspace_id, "operation": package.operation, "query": package.query, "findings": [f.to_dict() for f in package.findings[:MAX_EVIDENCE_ITEMS]]}
        prompt = ("You are a local code analysis worker. Use ONLY the supplied evidence. Separate observed facts, interpretation, and uncertainty. Do not claim to inspect files not supplied. If insufficient, say so.\n\n" + json.dumps(compact, ensure_ascii=False))[:MAX_EVIDENCE_CHARS]
        request = ReasoningRequest(purpose=Purpose.ANALYZE_EVIDENCE.value, prompt=prompt, task_id=task.task_id, provider_preference="ollama-local", model_preference=settings.default_model, tier="default", max_output_chars=MAX_OUTPUT_CHARS, metadata={"worker_id": task.worker_id, "workspace_id": task.workspace_id})
        try:
            result = self.gateway.submit(request, mode="LOCAL", model_chain=[settings.default_model], interface="code-worker")
        except (GatewayError, Exception) as exc:
            return WorkerResult(1, task.task_id, task.worker_id, WorkerStatus.FAILED.value, errors=(f"{type(exc).__name__}: {str(exc)[:300]}",), duration_ms=int((time.monotonic()-started)*1000))
        response = result.response
        if not response.ok:
            return WorkerResult(1, task.task_id, task.worker_id, WorkerStatus.FAILED.value, errors=(response.error or response.status,), provider=response.provider_id, model=response.model_id, duration_ms=int((time.monotonic()-started)*1000))
        return WorkerResult(1, task.task_id, task.worker_id, WorkerStatus.SUCCESS.value, "Evidence interpreted", response.content[:MAX_OUTPUT_CHARS], package.evidence_records, provider=response.provider_id, model=response.model_id, duration_ms=int((time.monotonic()-started)*1000), truncated=len(response.content) > MAX_OUTPUT_CHARS)


class WorkerRegistry:
    def __init__(self, workers=None):
        self._workers = {}
        for worker in (default_workers() if workers is None else workers):
            self.register(worker)

    def register(self, worker):
        worker_id = worker.capability.worker_id
        if worker_id in self._workers:
            raise ValueError(f"duplicate worker id: {worker_id}")
        self._workers[worker_id] = worker

    def get(self, worker_id):
        if worker_id not in self._workers:
            raise WorkerError(f"unknown worker: {worker_id}")
        return self._workers[worker_id]

    def capabilities(self, *, include_unavailable=True):
        values = []
        for worker in self._workers.values():
            capability = worker.availability() if hasattr(worker, "availability") else worker.capability
            if include_unavailable or capability.availability == "READY": values.append(capability)
        return values

    def list(self):
        return list(self._workers.values())

    def run(self, task: WorkerTask) -> WorkerResult:
        worker = self.get(task.worker_id)
        if not task.instruction and task.worker_id == "code.reason":
            raise WorkerError("instruction is required")
        return worker.run(task)


def default_workers():
    return [_DeterministicWorker("repo.search", "Repository search", "search"), _DeterministicWorker("repo.definition", "Repository definitions", "definition"), _DeterministicWorker("repo.references", "Repository references", "references"), _DeterministicWorker("repo.imports", "Repository imports", "imports"), _DeterministicWorker("repo.tests", "Related tests", "tests"), _DeterministicWorker("repo.snippet", "Repository snippet", "snippet"), _ReasonWorker()]
