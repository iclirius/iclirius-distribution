"""Deterministic, read-only project workspace inspection for Iclirius Code C1."""
from __future__ import annotations

import hashlib
import os
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from app.evidence import Coverage, EvidenceRecord, SourceType


SCHEMA_VERSION = 1
IGNORED_DIRS = {".git", ".venv", "venv", "node_modules", "dist", "build", "coverage", "__pycache__", ".cache", ".pytest_cache", ".idea", ".vscode"}
LANGUAGES = {".py": "Python", ".sh": "Shell", ".bash": "Shell", ".js": "JavaScript", ".jsx": "JavaScript", ".ts": "TypeScript", ".tsx": "TypeScript", ".rs": "Rust", ".go": "Go", ".java": "Java", ".swift": "Swift"}
BUILD_MARKERS = {"pyproject.toml": "Python / pyproject.toml", "setup.py": "Python / setup.py", "setup.cfg": "Python / setup.cfg", "requirements.txt": "Python requirements.txt", "package.json": "Node.js / package.json", "Cargo.toml": "Rust / Cargo", "go.mod": "Go modules", "pom.xml": "Java / Maven", "build.gradle": "Java / Gradle", "Package.swift": "Swift / SwiftPM"}
INSTRUCTION_NAMES = {"AGENTS.md", "CLAUDE.md", "CONTRIBUTING.md", "README.md", "README.txt"}


@dataclass(frozen=True)
class CodeWorkspace:
    schema_version: int
    workspace_id: str
    requested_path: str
    root_path: str
    repo_root: str | None
    project_name: str
    repository_type: str
    git_available: bool
    git_branch: str | None
    git_head: str | None
    git_dirty: bool | None
    git_changed_files_count: int | None
    languages: tuple[str, ...] = ()
    build_system: tuple[str, ...] = ()
    package_manager: tuple[str, ...] = ()
    test_frameworks: tuple[str, ...] = ()
    suggested_test_commands: tuple[str, ...] = ()
    project_markers: tuple[str, ...] = ()
    instruction_files: tuple[str, ...] = ()
    inspected_at: str = ""
    evidence: tuple[EvidenceRecord, ...] = field(default_factory=tuple, repr=False)

    def to_dict(self) -> dict:
        data = asdict(self)
        data.pop("evidence", None)
        for key in ("languages", "build_system", "package_manager", "test_frameworks", "suggested_test_commands", "project_markers", "instruction_files"):
            data[key] = list(data[key])
        data["repository"] = {"type": self.repository_type, "git_available": self.git_available, "branch": self.git_branch, "head": self.git_head, "dirty": self.git_dirty, "changed_files_count": self.git_changed_files_count}
        return data


def _git(args: list[str], cwd: Path) -> tuple[bool, str]:
    try:
        p = subprocess.run(["git", *args], cwd=str(cwd), shell=False, capture_output=True, text=True, timeout=5)
        return p.returncode == 0, p.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return False, ""


def _repo_root(root: Path) -> Path | None:
    ok, value = _git(["rev-parse", "--show-toplevel"], root)
    if not ok or not value:
        return None
    try:
        return Path(value).resolve()
    except OSError:
        return None


def _git_state(repo: Path | None) -> tuple[str | None, str | None, bool | None, int | None]:
    if repo is None:
        return None, None, None, None
    _, branch = _git(["symbolic-ref", "--quiet", "--short", "HEAD"], repo)
    if not branch:
        _, branch = _git(["rev-parse", "--short", "HEAD"], repo)
    _, head = _git(["rev-parse", "--short", "HEAD"], repo)
    ok, status = _git(["status", "--short", "--untracked-files=all"], repo)
    if not ok:
        return branch or None, head or None, None, None
    lines = [line for line in status.splitlines() if line.strip()]
    return branch or None, head or None, bool(lines), len(lines)


def _walk(root: Path, limit: int = 5000) -> tuple[list[str], set[str]]:
    files: list[str] = []
    languages: set[str] = set()
    seen = 0
    for current, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS)
        for name in sorted(names):
            seen += 1
            if seen > limit:
                return files, languages
            rel = str((Path(current) / name).relative_to(root))
            files.append(rel)
            language = LANGUAGES.get(Path(name).suffix.lower())
            if language:
                languages.add(language)
    return files, languages


def inspect_workspace(path: str | os.PathLike[str] | None = None) -> CodeWorkspace:
    requested = Path(path or os.getcwd()).expanduser()
    try:
        requested = requested.resolve(strict=True)
    except FileNotFoundError as exc:
        raise ValueError("Path does not exist") from exc
    if not requested.is_dir():
        raise ValueError("Path is not a directory")
    if not os.access(requested, os.R_OK):
        raise ValueError("Workspace is not readable")
    root = _repo_root(requested) or requested
    repo = _repo_root(requested)
    branch, head, dirty, changed = _git_state(repo)
    files, language_set = _walk(root)
    names = {Path(f).name for f in files}
    directory_markers = {name for name in ("tests", "test", "src", "app") if (root / name).is_dir()}
    markers = sorted((set(names) & set(BUILD_MARKERS)) | directory_markers | ({".git"} if repo else set()))
    build = tuple(BUILD_MARKERS[name] for name in BUILD_MARKERS if name in names)
    package = ("pip",) if any(name in names for name in ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg")) else ()
    if "package.json" in names:
        package = package + ("npm",)
    tests: list[str] = []
    if any(Path(f).parts and Path(f).parts[0] in {"tests", "test"} for f in files) or any(name in names for name in ("pytest.ini", "tox.ini")) or any((root / d).is_dir() for d in ("tests", "test")):
        tests.append("pytest")
    if "package.json" in names and any("jest" in f.lower() or "vitest" in f.lower() for f in files):
        tests.append("Jest/Vitest")
    if "Cargo.toml" in names:
        tests.append("cargo test")
    instructions = tuple(sorted(f for f in files if Path(f).name in INSTRUCTION_NAMES and len(Path(f).parts) <= 2))
    identity = str(root).encode("utf-8")
    workspace_id = "ws_" + hashlib.sha256(identity).hexdigest()[:16]
    evidence = (EvidenceRecord(SourceType.FILESYSTEM.value, "workspace_inspection", str(root), {"markers": markers, "languages": sorted(language_set)}, Coverage(complete=True)),)
    if repo:
        evidence += (EvidenceRecord(SourceType.GIT.value, "rev_parse", str(repo), {"branch": branch, "head": head, "dirty": dirty, "changed_files_count": changed}, Coverage(complete=True)),)
    return CodeWorkspace(SCHEMA_VERSION, workspace_id, str(Path(path or os.getcwd()).expanduser()), str(root), str(repo) if repo else None, root.name, "git" if repo else "none", repo is not None, branch, head, dirty, changed, tuple(sorted(language_set)), build, package, tuple(tests), ("pytest" if "pytest" in tests else "",) if "pytest" in tests else (), tuple(markers), instructions, str(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())), evidence)


def format_workspace(workspace: CodeWorkspace) -> str:
    def value(items, empty="Not detected"):
        return ", ".join(items) if items else empty
    changes = "clean" if workspace.git_dirty is False else (f"{workspace.git_changed_files_count} files" if workspace.git_changed_files_count is not None else "unknown")
    lines = ["ICLIRIUS CODE", "", f"Project      {workspace.project_name}", f"Workspace    {workspace.root_path}", f"Repository   {workspace.repository_type.upper()}", f"Branch       {workspace.git_branch or 'n/a'}", f"HEAD         {workspace.git_head or 'n/a'}", f"Changes      {changes}", f"Languages    {value(workspace.languages)}", f"Build        {value(workspace.build_system)}", f"Tests        {value(workspace.test_frameworks)}", f"Instructions {value(workspace.instruction_files)}", "Evidence     READY", "", "Workspace ready."]
    return "\n".join(lines)
