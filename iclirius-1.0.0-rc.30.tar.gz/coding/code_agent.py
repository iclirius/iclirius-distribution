from models.ollama_client import OllamaClient
from app.config import settings
from coding.project_context import collect_project_context
from coding.safe_reader import safe_read_file


def compact_project_context(context: dict) -> str:
    file_tree = context.get("file_tree", [])[:40]
    important_files = context.get("important_files", [])
    stack = context.get("stack", [])

    lines = [
        f"Root: {context.get('project_root')}",
        "",
        "Git status:",
        context.get("git_status", "unknown"),
        "",
        "Detected stack:",
    ]

    for item in stack:
        lines.append(f"- {item}")

    lines.append("")
    lines.append("Important files:")

    if important_files:
        for file in important_files:
            lines.append(f"- {file}")
    else:
        lines.append("- None detected")

    lines.append("")
    lines.append("File sample:")

    for file in file_tree:
        lines.append(f"- {file}")

    return "\n".join(lines)


def run_code_plan(prompt: str | None = None) -> str:
    context = collect_project_context()
    context_text = compact_project_context(context)
    request = prompt or "Haz un resumen técnico corto del proyecto."

    full_prompt = f"""
Eres {settings.agent_name}, un asistente local de análisis de código.

Modo actual:
- Solo lectura.
- No puedes editar archivos.
- No puedes ejecutar cambios.
- Responde en español.
- Sé concreto.

Solicitud:
{request}

Contexto del proyecto:
{context_text}

Responde con:
1. Resumen del proyecto
2. Stack detectado
3. Estado de Git
4. Riesgos o faltantes
5. Próximos pasos recomendados
""".strip()

    ollama = OllamaClient()
    response = ollama.generate(full_prompt)

    if not response:
        return "No recibí respuesta del modelo. Usa: iclirius code --context"

    return response


def analyze_file(relative_path: str, prompt: str | None = None) -> str:
    file_data = safe_read_file(relative_path)
    request = prompt or "Explícame este archivo y su papel dentro del proyecto."

    full_prompt = f"""
Eres {settings.agent_name}, un asistente local de análisis de código.

Modo actual:
- Solo lectura.
- No puedes editar archivos.
- No puedes ejecutar cambios.
- Responde en español.
- Sé práctico y específico.

Solicitud:
{request}

Archivo:
{file_data["path"]}

Tamaño en caracteres:
{file_data["size_chars"]}

Truncado:
{file_data["truncated"]}

Contenido:
{file_data["content"]}

Responde con:
1. Qué hace este archivo.
2. Partes importantes.
3. Riesgos o mejoras.
4. Cómo se relaciona con el resto del proyecto.
""".strip()

    ollama = OllamaClient()
    response = ollama.generate(full_prompt)

    if not response:
        return "No recibí respuesta del modelo, pero el archivo se pudo leer correctamente."

    return response



def generate_diff_plan(prompt: str) -> str:
    context = collect_project_context()
    context_text = compact_project_context(context)

    full_prompt = f"""
Eres {settings.agent_name}, un asistente local de código.

Modo DIFF SEGURO:
- NO edites archivos.
- NO ejecutes comandos.
- NO apliques cambios.
- Solo propone un diff conceptual o patch sugerido.
- Si no tienes suficiente contexto, di qué archivos necesitas leer.
- No inventes rutas si no estás seguro.
- Responde en español.

Solicitud del usuario:
{prompt}

Contexto del proyecto:
{context_text}

Entrega:
1. Resumen del cambio
2. Archivos que probablemente cambiarían
3. Patch propuesto si tienes suficiente contexto
4. Archivos que necesitas leer antes de generar un patch confiable
5. Riesgos
6. Comandos de prueba sugeridos

Importante:
No digas que modificaste archivos. Esto es solo una propuesta.
""".strip()

    ollama = OllamaClient()
    response = ollama.generate(full_prompt)

    if not response:
        return "No recibí respuesta del modelo. No se generó ningún diff."

    return response
