"""Deterministic, bounded code investigation for Code C2."""
from __future__ import annotations

import ast
import json
import os
import re
import subprocess
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from app.evidence import Coverage, EvidenceRecord, SourceType
from coding.workspace import CodeWorkspace, IGNORED_DIRS

MAX_MATCHES = 50
MAX_FILES = 5000
MAX_SNIPPET_CHARS = 500
MAX_SNIPPET_LINES = 12
MAX_FILE_BYTES = 1_000_000
SECRET_NAMES = {".env", ".env.local", ".env.production", "id_rsa", "id_ed25519"}
SECRET_SUFFIXES = (".pem", ".key", ".p12", ".pfx")


def _sensitive(path: Path) -> bool:
    name = path.name.lower()
    return name in SECRET_NAMES or name.endswith(SECRET_SUFFIXES) or any(part.lower() in {"secrets", "credentials"} for part in path.parts)


def _files(workspace: CodeWorkspace):
    root = Path(workspace.root_path).resolve()
    count = 0
    for current, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS)
        for name in sorted(names):
            count += 1
            if count > MAX_FILES:
                return
            path = Path(current) / name
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if _sensitive(path) or size > MAX_FILE_BYTES:
                continue
            if path.suffix.lower() not in {".py", ".js", ".jsx", ".ts", ".tsx", ".rs", ".go", ".java", ".swift", ".sh", ".bash", ".txt", ".md", ".toml", ".json", ".yaml", ".yml"}:
                continue
            yield path


def _safe_path(workspace: CodeWorkspace, relative: str) -> Path:
    root = Path(workspace.root_path).resolve()
    candidate = (root / relative).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError("path escapes workspace")
    if _sensitive(candidate):
        raise ValueError("sensitive file content is blocked")
    if not candidate.is_file() or candidate.stat().st_size > MAX_FILE_BYTES:
        raise ValueError("file is unavailable or too large")
    return candidate


@dataclass(frozen=True)
class CodeFinding:
    schema_version: int
    kind: str
    path: str
    relative_path: str
    line_start: int
    line_end: int
    symbol: str = ""
    language: str = ""
    snippet: str = ""
    source: str = "text"
    evidence_id: str = ""
    reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class CodeEvidencePackage:
    schema_version: int
    workspace_id: str
    query: str
    operation: str
    findings: tuple[CodeFinding, ...] = ()
    evidence_records: tuple[EvidenceRecord, ...] = field(default_factory=tuple, repr=False)
    truncated: bool = False
    limits: dict = field(default_factory=dict)
    created_at: str = ""

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "workspace_id": self.workspace_id, "query": self.query, "operation": self.operation, "findings": [f.to_dict() for f in self.findings], "evidence": [e.to_dict() for e in self.evidence_records], "truncated": self.truncated, "limits": self.limits, "created_at": self.created_at}


def _read(path: Path) -> list[str] | None:
    try:
        return path.read_text(encoding="utf-8", errors="strict").splitlines()
    except (OSError, UnicodeError):
        return None


def _finding(workspace: CodeWorkspace, path: Path, line: int, line_end: int, kind: str, query: str = "", source: str = "text", reason: str = "") -> CodeFinding:
    lines = _read(path) or []
    snippet = "\n".join(f"{i} | {lines[i-1]}" for i in range(max(1, line), min(len(lines), line_end, line + MAX_SNIPPET_LINES - 1) + 1))[:MAX_SNIPPET_CHARS]
    rel = str(path.relative_to(Path(workspace.root_path).resolve()))
    language = "Python" if path.suffix == ".py" else path.suffix.lstrip(".").upper()
    return CodeFinding(1, kind, str(path), rel, line, line_end, query, language, snippet, source, "", reason)


def _package(workspace: CodeWorkspace, operation: str, query: str, findings: list[CodeFinding], truncated: bool = False, reason: str = "") -> CodeEvidencePackage:
    records = []
    for finding in findings:
        records.append(EvidenceRecord(SourceType.FILESYSTEM.value, f"code.{operation}", finding.relative_path, {"kind": finding.kind, "line_start": finding.line_start, "line_end": finding.line_end, "symbol": finding.symbol, "source": finding.source, "snippet": finding.snippet}, Coverage(complete=True), provenance={"workspace_id": workspace.workspace_id}))
    return CodeEvidencePackage(1, workspace.workspace_id, query, operation, tuple(findings[:MAX_MATCHES]), tuple(records[:MAX_MATCHES]), truncated or len(findings) > MAX_MATCHES, {"max_matches": MAX_MATCHES, "max_files": MAX_FILES, "max_snippet_chars": MAX_SNIPPET_CHARS}, str(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())))


def search_code(workspace: CodeWorkspace, query: str, *, regex: bool = False) -> CodeEvidencePackage:
    if not query or not query.strip():
        raise ValueError("query is required")
    pattern = re.compile(query) if regex else None
    findings: list[CodeFinding] = []
    scanned = 0
    for path in _files(workspace):
        scanned += 1
        lines = _read(path) or []
        for number, line in enumerate(lines, 1):
            if (pattern.search(line) if pattern else query in line):
                findings.append(_finding(workspace, path, number, number, "TEXT_MATCH", query, "regex" if regex else "literal"))
                if len(findings) >= MAX_MATCHES:
                    return _package(workspace, "search", query, findings, True)
    return _package(workspace, "search", query, findings, scanned >= MAX_FILES)


def _python_nodes(path: Path):
    lines = _read(path)
    if lines is None:
        return []
    try:
        tree = ast.parse("\n".join(lines), filename=str(path))
    except SyntaxError:
        return []
    nodes = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            nodes.append((node.name, node.lineno, getattr(node, "end_lineno", node.lineno), "class" if isinstance(node, ast.ClassDef) else "function"))
    return nodes


def find_definition(workspace: CodeWorkspace, symbol: str) -> CodeEvidencePackage:
    findings = []
    had_python = False
    for path in _files(workspace):
        if path.suffix == ".py":
            had_python = True
            for name, start, end, kind in _python_nodes(path):
                if name == symbol:
                    findings.append(_finding(workspace, path, start, end, "DEFINITION", symbol, "python-ast", f"Python AST {kind}"))
        if len(findings) >= MAX_MATCHES:
            break
    if not findings and not had_python:
        fallback = search_code(workspace, symbol)
        findings = [CodeFinding(f.schema_version, "DEFINITION", f.path, f.relative_path, f.line_start, f.line_end, symbol, f.language, f.snippet, "text-fallback", "", "textual definition candidate") for f in fallback.findings if re.search(rf"\b(class|def|function)\s+{re.escape(symbol)}\b", f.snippet)]
    return _package(workspace, "definition", symbol, findings, len(findings) >= MAX_MATCHES)


def find_references(workspace: CodeWorkspace, symbol: str) -> CodeEvidencePackage:
    definitions = {(f.relative_path, f.line_start) for f in find_definition(workspace, symbol).findings}
    result = search_code(workspace, symbol)
    findings = [CodeFinding(f.schema_version, "REFERENCE", f.path, f.relative_path, f.line_start, f.line_end, symbol, f.language, f.snippet, f.source, "", "textual reference") for f in result.findings if (f.relative_path, f.line_start) not in definitions]
    return _package(workspace, "references", symbol, findings, result.truncated)


def find_imports(workspace: CodeWorkspace, relative_path: str) -> CodeEvidencePackage:
    path = _safe_path(workspace, relative_path)
    lines = _read(path) or []
    try:
        tree = ast.parse("\n".join(lines), filename=str(path))
    except SyntaxError:
        return _package(workspace, "imports", relative_path, [])
    findings = []
    root = Path(workspace.root_path).resolve()
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Import): names = [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module: names = [node.module]
        for name in names:
            local = root / Path(*name.split("."))
            target = local.with_suffix(".py")
            if not target.exists():
                target = local / "__init__.py"
            reason = "local module" if target.exists() else "external or unresolved"
            findings.append(_finding(workspace, path, node.lineno, getattr(node, "end_lineno", node.lineno), "IMPORT", name, "python-ast", reason))
    return _package(workspace, "imports", relative_path, findings)


def related_tests(workspace: CodeWorkspace, relative_path: str) -> CodeEvidencePackage:
    target = Path(relative_path)
    stem = target.stem.removeprefix("test_")
    findings = []
    for path in _files(workspace):
        rel = path.relative_to(Path(workspace.root_path).resolve())
        if any(p.lower() == "test" or p.lower().startswith("test") for p in rel.parts) and (stem in path.stem or target.stem in path.stem):
            findings.append(_finding(workspace, path, 1, min(1, len(_read(path) or [])), "TEST", stem, "filename", "related test candidate"))
    return _package(workspace, "related_tests", relative_path, findings)


def related_files(workspace: CodeWorkspace, query: str) -> CodeEvidencePackage:
    """Return conservative files containing the requested symbol/text."""
    result = search_code(workspace, query)
    findings = [CodeFinding(f.schema_version, "RELATED_FILE", f.path, f.relative_path, f.line_start, f.line_end, query, f.language, f.snippet, f.source, "", "shares a deterministic text reference") for f in result.findings]
    return _package(workspace, "related_files", query, findings, result.truncated)


def snippet(workspace: CodeWorkspace, relative_path: str, line_start: int, line_end: int) -> CodeEvidencePackage:
    if line_start < 1 or line_end < line_start or line_end - line_start + 1 > MAX_SNIPPET_LINES:
        raise ValueError("line range exceeds bounds")
    path = _safe_path(workspace, relative_path)
    lines = _read(path) or []
    if line_start > len(lines):
        raise ValueError("line is outside file")
    finding = _finding(workspace, path, line_start, min(line_end, len(lines)), "RELATED_FILE", relative_path, "filesystem", "bounded source snippet")
    return _package(workspace, "snippet", relative_path, [finding])
