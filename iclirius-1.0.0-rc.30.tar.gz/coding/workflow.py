"""C5 approved patch → test → verify workflow."""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from coding.execution import (Decision, ExecutionResult, ResultStatus,
                              SafeExecutor, make_request)
from coding.intelligence import CodeEvidencePackage, search_code
from coding.workspace import CodeWorkspace


@dataclass(frozen=True)
class ProposedChange:
    path: str
    operation: str
    description: str
    expected_before: str = ""
    replacement: str = ""
    evidence_ids: tuple[str, ...] = ()

    def to_dict(self):
        data = asdict(self); data["evidence_ids"] = list(self.evidence_ids); return data


@dataclass(frozen=True)
class CodeChangePlan:
    schema_version: int
    plan_id: str
    workspace_id: str
    request: str
    summary: str
    proposed_changes: tuple[ProposedChange, ...] = ()
    affected_files: tuple[str, ...] = ()
    related_tests: tuple[str, ...] = ()
    evidence: tuple = field(default_factory=tuple, repr=False)
    reasoning_provenance: dict = field(default_factory=dict)
    risk: str = "SAFE_WRITE"
    requires_approval: bool = True
    created_at: str = ""
    baseline: dict = field(default_factory=dict, repr=False)

    def to_dict(self):
        return {"schema_version": self.schema_version, "plan_id": self.plan_id, "workspace_id": self.workspace_id, "request": self.request, "summary": self.summary, "proposed_changes": [c.to_dict() for c in self.proposed_changes], "affected_files": list(self.affected_files), "related_tests": list(self.related_tests), "evidence": [e.to_dict() for e in self.evidence], "reasoning_provenance": self.reasoning_provenance, "risk": self.risk, "requires_approval": self.requires_approval, "created_at": self.created_at}


@dataclass(frozen=True)
class TestRequest:
    workspace_id: str
    framework: str
    targets: tuple[str, ...]
    timeout: float = 60.0
    reason: str = ""

    def to_dict(self): return asdict(self) | {"targets": list(self.targets)}


@dataclass(frozen=True)
class CodeVerificationResult:
    schema_version: int
    plan_id: str
    workspace_id: str
    patch_applied: bool
    files_expected: tuple[str, ...]
    files_changed: tuple[str, ...]
    diff_observed: bool
    tests_requested: tuple[str, ...]
    tests_result: dict
    unexpected_changes: tuple[str, ...] = ()
    status: str = "FAILED"
    evidence: tuple = field(default_factory=tuple, repr=False)
    warnings: tuple[str, ...] = ()

    def to_dict(self):
        return {"schema_version": self.schema_version, "plan_id": self.plan_id, "workspace_id": self.workspace_id, "patch_applied": self.patch_applied, "files_expected": list(self.files_expected), "files_changed": list(self.files_changed), "diff_observed": self.diff_observed, "tests_requested": list(self.tests_requested), "tests_result": self.tests_result, "unexpected_changes": list(self.unexpected_changes), "status": self.status, "evidence": [e.to_dict() for e in self.evidence], "warnings": list(self.warnings)}


class CodeWorkflowError(RuntimeError): pass


def _hash(text: str) -> str: return hashlib.sha256(text.encode()).hexdigest()


def normalize_model_plan(workspace: CodeWorkspace, request: str, evidence: CodeEvidencePackage, raw: str) -> CodeChangePlan:
    """Accept only a small JSON change proposal; model text is never executed."""
    try:
        data = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        raise CodeWorkflowError("model did not return a structured change plan") from exc
    if not isinstance(data, dict) or not isinstance(data.get("changes"), list):
        raise CodeWorkflowError("invalid structured change plan")
    changes = []
    for item in data["changes"][:20]:
        if not isinstance(item, dict):
            raise CodeWorkflowError("invalid proposed change")
        changes.append(ProposedChange(str(item.get("path", "")), str(item.get("operation", "")), str(item.get("description", "")), str(item.get("expected_before", "")), str(item.get("replacement", ""))))
    return CodeChangeWorkflow(workspace).plan(request, changes, evidence, summary=str(data.get("summary", "")))


class CodeChangeWorkflow:
    def __init__(self, workspace: CodeWorkspace, *, executor: SafeExecutor | None = None, worker_registry=None):
        self.workspace = workspace
        self.executor = executor or SafeExecutor()
        self.worker_registry = worker_registry

    def inspect(self): return self.workspace

    def plan(self, request: str, changes: list[ProposedChange], evidence: CodeEvidencePackage | None = None, *, summary: str = "") -> CodeChangePlan:
        if not changes: raise CodeWorkflowError("plan requires at least one change")
        if len(changes) > 20: raise CodeWorkflowError("too many changes")
        for change in changes:
            if change.operation not in {"CREATE", "MODIFY"}: raise CodeWorkflowError("delete and unsupported changes are blocked")
            if Path(change.path).is_absolute() or ".." in Path(change.path).parts: raise CodeWorkflowError("change path escapes workspace")
        baseline = {"files": self._status_files()}
        return CodeChangePlan(1, f"plan_{uuid.uuid4().hex[:12]}", self.workspace.workspace_id, request[:1000], summary[:500] or request[:500], tuple(changes), tuple(c.path for c in changes), (), evidence.evidence_records if evidence else (), {}, "SAFE_WRITE", True, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), baseline)

    def approve(self, plan: CodeChangePlan, *, confirmed: bool) -> str:
        if not confirmed: raise CodeWorkflowError("explicit approval required")
        return plan.plan_id

    def apply(self, plan: CodeChangePlan, approval: str | None = None) -> list[ExecutionResult]:
        if approval != plan.plan_id: raise CodeWorkflowError("plan approval is required")
        prepared = []
        for change in plan.proposed_changes:
            target = (Path(self.workspace.root_path) / change.path).resolve()
            if target != Path(self.workspace.root_path).resolve() and Path(self.workspace.root_path).resolve() not in target.parents: raise CodeWorkflowError("path escapes workspace")
            if change.operation == "MODIFY":
                if not target.is_file() or target.read_text(encoding="utf-8") != change.expected_before: raise CodeWorkflowError("STALE_PLAN")
                content = change.replacement
            else:
                if target.exists(): raise CodeWorkflowError("file already exists")
                content = change.replacement
            prepared.append((change, content))
        results = []
        for change, content in prepared:
            request = make_request(self.workspace, "file.write" if change.operation == "MODIFY" else "file.create", {"path": change.path, "content": content}, reason=plan.plan_id)
            _, result = self.executor.execute(request, self.workspace, confirmed=True)
            results.append(result)
            if result.status != ResultStatus.SUCCESS.value: break
        return results

    def run_tests(self, plan: CodeChangePlan, approval: str | None, targets: list[str] | None = None):
        if approval != plan.plan_id: raise CodeWorkflowError("approved plan required for tests")
        selected = tuple(targets or plan.related_tests)
        if not selected: raise CodeWorkflowError("no validated test targets")
        request = make_request(self.workspace, "tests.run", {"framework": "pytest", "targets": list(selected), "approved_plan_id": plan.plan_id}, reason=plan.plan_id)
        return self.executor.execute(request, self.workspace, confirmed=True)

    def verify(self, plan: CodeChangePlan, results: list[ExecutionResult], test_result: ExecutionResult | None = None) -> CodeVerificationResult:
        changed = tuple(r.changed_files[0] for r in results if r.changed_files)
        expected = tuple(c.path for c in plan.proposed_changes)
        patch_ok = bool(results) and all(r.status == ResultStatus.SUCCESS.value for r in results) and len(results) == len(expected)
        tests = test_result.to_dict() if test_result else {"status": "NOT_RUN"}
        status = "VERIFIED" if patch_ok and test_result and test_result.status == ResultStatus.SUCCESS.value else ("PARTIAL" if patch_ok else "FAILED")
        return CodeVerificationResult(1, plan.plan_id, self.workspace.workspace_id, patch_ok, expected, changed, patch_ok, tuple(plan.related_tests), tests, tuple(set(changed)-set(expected)), status, tuple(plan.evidence))

    def _status_files(self):
        result = search_code(self.workspace, "") if False else None
        from coding.execution import make_request
        _, status = self.executor.execute(make_request(self.workspace, "git.status"), self.workspace)
        return status.output
