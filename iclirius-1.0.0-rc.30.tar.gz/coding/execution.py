"""Policy-controlled, non-shell execution primitives for Code C4."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path

from coding.workspace import CodeWorkspace

MAX_OUTPUT_CHARS = 12000
MAX_WRITE_BYTES = 1_000_000
TIMEOUT_SECONDS = 10
SAFE_ENV = {"PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "TZ"}
SECRET_PARTS = {".env", ".env.local", ".env.production", "id_rsa", "id_ed25519"}
SECRET_SUFFIXES = (".pem", ".key", ".p12", ".pfx")


class Risk(str, Enum):
    READ = "READ"
    SAFE_WRITE = "SAFE_WRITE"
    EXECUTE = "EXECUTE"
    DESTRUCTIVE = "DESTRUCTIVE"
    EXTERNAL = "EXTERNAL"
    PRIVILEGED = "PRIVILEGED"


class Decision(str, Enum):
    ALLOW = "ALLOW"
    CONFIRM = "CONFIRM"
    DENY = "DENY"
    BLOCKED = "BLOCKED"


class ResultStatus(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    CANCELLED = "CANCELLED"
    TIMEOUT = "TIMEOUT"
    PARTIAL = "PARTIAL"


@dataclass(frozen=True)
class ActionRequest:
    schema_version: int
    action_id: str
    workspace_id: str
    requester_type: str
    requester_id: str
    operation: str
    arguments: dict = field(default_factory=dict)
    reason: str = ""
    created_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class PolicyDecision:
    decision: str
    operation: str
    risk: str
    reason: str = ""
    requires_confirmation: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ExecutionResult:
    schema_version: int
    action_id: str
    operation: str
    status: str
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    output: str = ""
    changed_files: tuple[str, ...] = ()
    truncated: bool = False
    duration_ms: int = 0
    error: str = ""
    verification: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        data = asdict(self)
        data["changed_files"] = list(self.changed_files)
        data["truncated"] = self.truncated or len(self.stdout) > MAX_OUTPUT_CHARS or len(self.stderr) > MAX_OUTPUT_CHARS
        data["stdout"] = self.stdout[:MAX_OUTPUT_CHARS]
        data["stderr"] = self.stderr[:MAX_OUTPUT_CHARS]
        data["output"] = self.output[:MAX_OUTPUT_CHARS]
        return data


def make_request(workspace: CodeWorkspace, operation: str, arguments: dict | None = None, *, requester_type: str = "interface", requester_id: str = "local", reason: str = "") -> ActionRequest:
    return ActionRequest(1, f"act_{uuid.uuid4().hex[:12]}", workspace.workspace_id, requester_type, requester_id, operation, arguments or {}, reason, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))


def _sensitive(path: Path) -> bool:
    name = path.name.lower()
    return name in SECRET_PARTS or name.endswith(SECRET_SUFFIXES)


def _path(workspace: CodeWorkspace, value: str, *, must_exist: bool = False) -> Path:
    if not isinstance(value, str) or not value or "\x00" in value:
        raise ValueError("invalid path")
    root = Path(workspace.root_path).resolve()
    target = (root / value).resolve()
    if target != root and root not in target.parents:
        raise ValueError("path escapes workspace")
    if _sensitive(target):
        raise ValueError("sensitive path is blocked")
    if must_exist and not target.exists():
        raise ValueError("path does not exist")
    return target


class ExecutionOperationRegistry:
    OPERATIONS = {
        "file.read": Risk.READ,
        "file.create": Risk.SAFE_WRITE,
        "file.write": Risk.SAFE_WRITE,
        "git.status": Risk.READ,
        "git.diff": Risk.READ,
        "git.show": Risk.READ,
        "tests.run": Risk.EXECUTE,
    }

    def get(self, operation: str):
        if operation not in self.OPERATIONS:
            raise KeyError(f"unknown operation: {operation}")
        return self.OPERATIONS[operation]

    def list(self) -> list[str]:
        return list(self.OPERATIONS)


class ExecutionPolicy:
    def __init__(self, registry: ExecutionOperationRegistry | None = None):
        self.registry = registry or ExecutionOperationRegistry()

    def evaluate(self, request: ActionRequest, workspace: CodeWorkspace, *, confirmed: bool = False) -> PolicyDecision:
        if request.workspace_id != workspace.workspace_id:
            return PolicyDecision(Decision.DENY.value, request.operation, Risk.PRIVILEGED.value, "workspace mismatch")
        try:
            risk = self.registry.get(request.operation)
        except KeyError:
            return PolicyDecision(Decision.BLOCKED.value, request.operation, Risk.PRIVILEGED.value, "operation is not registered")
        try:
            self._validate_arguments(request, workspace)
        except ValueError as exc:
            return PolicyDecision(Decision.DENY.value, request.operation, risk.value, str(exc))
        if risk == Risk.EXECUTE and request.operation == "tests.run" and confirmed and request.arguments.get("approved_plan_id"):
            return PolicyDecision(Decision.ALLOW.value, request.operation, risk.value)
        if risk in {Risk.DESTRUCTIVE, Risk.EXTERNAL, Risk.PRIVILEGED, Risk.EXECUTE}:
            return PolicyDecision(Decision.DENY.value, request.operation, risk.value, "risk class is blocked")
        if risk == Risk.SAFE_WRITE and not confirmed:
            return PolicyDecision(Decision.CONFIRM.value, request.operation, risk.value, "explicit user confirmation required", True)
        return PolicyDecision(Decision.ALLOW.value, request.operation, risk.value)

    def _validate_arguments(self, request: ActionRequest, workspace: CodeWorkspace) -> None:
        args = request.arguments
        if request.operation.startswith("file."):
            _path(workspace, args.get("path", ""), must_exist=request.operation == "file.write")
            if request.operation in {"file.create", "file.write"}:
                content = args.get("content")
                if not isinstance(content, str):
                    raise ValueError("text content is required")
                if len(content.encode("utf-8")) > MAX_WRITE_BYTES:
                    raise ValueError("write exceeds size limit")
        elif request.operation == "git.show":
            rev = args.get("revision", "HEAD")
            if not isinstance(rev, str) or not rev or rev.startswith("-") or any(c in rev for c in ";&|\n"):
                raise ValueError("invalid revision")
            if args.get("path"):
                _path(workspace, args["path"], must_exist=True)
        elif request.operation in {"git.status", "git.diff"} and args:
            raise ValueError("arguments are not accepted")
        elif request.operation == "tests.run":
            if args.get("framework") != "pytest" or not isinstance(args.get("targets"), list) or not args["targets"] or len(args["targets"]) > 10 or not args.get("approved_plan_id"):
                raise ValueError("approved pytest targets are required")
            for target in args["targets"]:
                path = _path(workspace, target, must_exist=True)
                if not path.is_file():
                    raise ValueError("test target must be a file")


class SafeExecutor:
    def __init__(self, policy: ExecutionPolicy | None = None, *, timeout: float = TIMEOUT_SECONDS):
        self.policy = policy or ExecutionPolicy()
        self.timeout = timeout

    def execute(self, request: ActionRequest, workspace: CodeWorkspace, *, confirmed: bool = False, noninteractive: bool = False) -> tuple[PolicyDecision, ExecutionResult]:
        decision = self.policy.evaluate(request, workspace, confirmed=confirmed)
        if decision.decision != Decision.ALLOW.value or (noninteractive and decision.decision == Decision.CONFIRM):
            return decision, ExecutionResult(1, request.action_id, request.operation, ResultStatus.BLOCKED.value, error=decision.reason or "confirmation required")
        started = time.monotonic()
        try:
            if request.operation == "file.read":
                result = self._read(request, workspace)
            elif request.operation in {"file.create", "file.write"}:
                result = self._write(request, workspace)
            elif request.operation == "tests.run":
                result = self._tests(request, workspace)
            else:
                result = self._git(request, workspace)
            return decision, result_with_duration(result, started)
        except subprocess.TimeoutExpired:
            return decision, ExecutionResult(1, request.action_id, request.operation, ResultStatus.TIMEOUT.value, duration_ms=int((time.monotonic()-started)*1000), error="operation timed out")
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            return decision, ExecutionResult(1, request.action_id, request.operation, ResultStatus.FAILED.value, duration_ms=int((time.monotonic()-started)*1000), error=str(exc)[:300])

    def _read(self, request, workspace):
        target = _path(workspace, request.arguments["path"], must_exist=True)
        if not target.is_file() or target.stat().st_size > MAX_WRITE_BYTES:
            raise ValueError("file unavailable or too large")
        content = target.read_text(encoding="utf-8")
        return ExecutionResult(1, request.action_id, request.operation, ResultStatus.SUCCESS.value, stdout=content, output=content, verification={"exists": True, "sha256": hashlib.sha256(content.encode()).hexdigest()})

    def _write(self, request, workspace):
        target = _path(workspace, request.arguments["path"])
        if request.operation == "file.create" and target.exists():
            raise ValueError("file already exists")
        target.parent.mkdir(parents=True, exist_ok=True)
        content = request.arguments["content"]
        fd, temp_name = tempfile.mkstemp(prefix=".iclirius-write-", dir=str(target.parent), text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, target)
        finally:
            try: os.unlink(temp_name)
            except FileNotFoundError: pass
        actual = target.read_text(encoding="utf-8")
        return ExecutionResult(1, request.action_id, request.operation, ResultStatus.SUCCESS.value, changed_files=(str(target.relative_to(Path(workspace.root_path).resolve())),), verification={"exists": target.exists(), "bytes": target.stat().st_size, "sha256": hashlib.sha256(actual.encode()).hexdigest()})

    def _git(self, request, workspace):
        root = Path(workspace.root_path).resolve()
        argv = {"git.status": ["git", "status", "--short"], "git.diff": ["git", "diff", "--no-ext-diff"], "git.show": ["git", "show", "--no-ext-diff", request.arguments.get("revision", "HEAD")] }[request.operation]
        if request.operation == "git.show" and request.arguments.get("path"):
            argv += ["--", request.arguments["path"]]
        env = {key: value for key, value in os.environ.items() if key in SAFE_ENV and not any(part in key.upper() for part in ("TOKEN", "KEY", "SECRET", "PASSWORD"))}
        proc = subprocess.run(argv, cwd=str(root), env=env, shell=False, capture_output=True, text=True, timeout=self.timeout)
        truncated = len(proc.stdout) > MAX_OUTPUT_CHARS or len(proc.stderr) > MAX_OUTPUT_CHARS
        return ExecutionResult(1, request.action_id, request.operation, ResultStatus.SUCCESS.value if proc.returncode == 0 else ResultStatus.FAILED.value, proc.returncode, proc.stdout[:MAX_OUTPUT_CHARS], proc.stderr[:MAX_OUTPUT_CHARS], proc.stdout[:MAX_OUTPUT_CHARS], truncated=truncated, error="" if proc.returncode == 0 else "git command failed")

    def _tests(self, request, workspace):
        root = Path(workspace.root_path).resolve()
        argv = [sys.executable, "-m", "pytest", *request.arguments["targets"], "-q", "-p", "no:cacheprovider"]
        env = {key: value for key, value in os.environ.items() if key in SAFE_ENV}
        proc = subprocess.run(argv, cwd=str(root), env=env, shell=False, capture_output=True, text=True, timeout=self.timeout)
        truncated = len(proc.stdout) > MAX_OUTPUT_CHARS or len(proc.stderr) > MAX_OUTPUT_CHARS
        return ExecutionResult(1, request.action_id, request.operation, ResultStatus.SUCCESS.value if proc.returncode == 0 else ResultStatus.FAILED.value, proc.returncode, proc.stdout[:MAX_OUTPUT_CHARS], proc.stderr[:MAX_OUTPUT_CHARS], proc.stdout[:MAX_OUTPUT_CHARS], truncated=truncated, error="" if proc.returncode == 0 else "tests failed")


def result_with_duration(result: ExecutionResult, started: float) -> ExecutionResult:
    return ExecutionResult(result.schema_version, result.action_id, result.operation, result.status, result.exit_code, result.stdout, result.stderr, result.output, result.changed_files, result.truncated, int((time.monotonic()-started)*1000), result.error, result.verification)
