import time

import requests

from app.config import settings
from app.logger import logger


class OllamaError(RuntimeError):
    """Raised when the local engine cannot produce a usable answer."""


class OllamaUnavailableError(OllamaError):
    """Raised when the local engine cannot be reached at all."""


class OllamaClient:
    def __init__(
        self,
        base_url: str | None = None,
        timeout: int | None = None,
        max_attempts: int | None = None,
    ):
        self.base_url = base_url or settings.ollama_base_url
        self.timeout = timeout or settings.ollama_timeout
        self.max_attempts = max_attempts or settings.ollama_max_attempts

    # --- introspection ----------------------------------------------------

    def health(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except Exception:
            return False

    def installed_models(self) -> list[str]:
        """Model names known to the local Ollama server. Empty when unreachable."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            response.raise_for_status()
            data = response.json()
        except Exception:
            return []

        if not isinstance(data, dict):
            return []

        return [
            model.get("name", "")
            for model in data.get("models", [])
            if isinstance(model, dict) and model.get("name")
        ]

    # --- generation -------------------------------------------------------

    def generate(
        self,
        prompt: str,
        model: str | None = None,
        num_ctx: int | None = None,
    ) -> str:
        """
        Run a prompt against one local model.

        Retries a bounded number of times with a small linear backoff, then
        gives up with a typed error. It never retries forever and never hides
        a failure behind an empty string.
        """
        selected_model = model or settings.default_model
        num_ctx = num_ctx if num_ctx is not None else settings.ollama_num_ctx

        payload: dict = {
            "model": selected_model,
            "prompt": prompt,
            "stream": False,
        }

        if num_ctx:
            payload["options"] = {"num_ctx": num_ctx}

        last_error: Exception | None = None
        unreachable = False

        for attempt in range(1, self.max_attempts + 1):
            try:
                response = requests.post(
                    f"{self.base_url}/api/generate",
                    json=payload,
                    timeout=self.timeout,
                )
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
                last_error = exc
                unreachable = True
                logger.warning(
                    "Ollama unreachable model=%s attempt=%s/%s error=%s",
                    selected_model, attempt, self.max_attempts, type(exc).__name__,
                )
                self._backoff(attempt)
                continue
            except Exception as exc:
                last_error = exc
                logger.warning(
                    "Ollama request failed model=%s attempt=%s/%s error=%s",
                    selected_model, attempt, self.max_attempts, type(exc).__name__,
                )
                self._backoff(attempt)
                continue

            if response.status_code >= 500:
                # Server-side hiccup: worth another attempt.
                last_error = OllamaError(
                    f"Ollama HTTP {response.status_code} for model {selected_model}"
                )
                logger.warning(
                    "Ollama HTTP %s model=%s attempt=%s/%s",
                    response.status_code, selected_model, attempt, self.max_attempts,
                )
                self._backoff(attempt)
                continue

            if response.status_code >= 400:
                # Client-side: a missing model or bad request will not fix
                # itself, so fail immediately instead of burning retries.
                raise OllamaError(
                    f"Ollama rejected the request for model {selected_model} "
                    f"(HTTP {response.status_code})"
                )

            text = self._extract_response(response, selected_model)

            if text:
                return text

            last_error = OllamaError(f"Ollama returned an empty body for model {selected_model}")
            logger.warning(
                "Ollama empty response model=%s attempt=%s/%s",
                selected_model, attempt, self.max_attempts,
            )
            self._backoff(attempt)

        message = (
            f"Ollama no respondió tras {self.max_attempts} intentos "
            f"para el modelo {selected_model}: {last_error}"
        )

        if unreachable:
            raise OllamaUnavailableError(message)

        raise OllamaError(message)

    def _backoff(self, attempt: int) -> None:
        """Small linear backoff. Skipped after the final attempt."""
        if attempt < self.max_attempts:
            time.sleep(settings.ollama_backoff_seconds * attempt)

    @staticmethod
    def _extract_response(response, selected_model: str) -> str:
        try:
            data = response.json()
        except Exception as exc:
            raise OllamaError(
                f"Ollama returned a non-JSON body for model {selected_model}"
            ) from exc

        if not isinstance(data, dict):
            raise OllamaError(
                f"Ollama returned an unexpected payload for model {selected_model}"
            )

        return str(data.get("response", "")).strip()
