import os

from app.agent import OpenClawAgent
from app.config import settings
from app.memory import MemoryStore


def _agent() -> OpenClawAgent:
    """
    CLI agent bound to the current working directory.

    The directory is the project signal: running `iclirius chat` inside a repo
    associates the conversation with that project automatically.
    """
    agent = OpenClawAgent(interface="cli", working_dir=os.getcwd())
    agent.bind_interface(reference="local-shell")
    return agent


def _project_banner(agent: OpenClawAgent) -> str:
    project = agent.current_project()

    if not project:
        return ""

    task = agent.core.active_task_for(project.get("project_id"))
    line = f"proyecto: {project.get('display_name', '?')}"

    if task:
        line += f" | tarea: {task.get('goal', '')[:60]}"

    return line


def _capability_banner() -> str:
    """
    What is switched on, shown before the first message.

    Write and execute are off in a default install, and someone using the CLI
    to fix code should learn that from the banner rather than from a refusal
    three messages later.
    """
    from app.permissions import Capability, permission_layer

    marks = {"ALLOWED": "sí", "CONFIRM_REQUIRED": "pregunta", "DENIED": "no"}

    parts = [
        f"{capability.value.lower()}: {marks[permission_layer.check(capability).value]}"
        for capability in (Capability.READ, Capability.WRITE, Capability.EXECUTE)
    ]

    return "permisos: " + " | ".join(parts)


def _footer(agent: OpenClawAgent) -> str:
    """The one-line strip after a reply. Empty when there is no room for it."""
    try:
        from app.status_view import detect_terminal, render_footer

        return render_footer(_view(agent), detect_terminal())
    except Exception:
        # A status strip must never be the reason a chat session dies.
        return ""


def run_single_message(message: str) -> int:
    agent = _agent()
    memory = MemoryStore()

    banner = _project_banner(agent)
    if banner:
        print(banner)

    print("iclirius está pensando...")
    response = agent.respond(message)

    agent.record_conversation_turn(message, response, source="cli")

    print()
    print(response)
    return 0


# --- developer commands ---------------------------------------------------
#
# All of them read the same RuntimeSnapshot the Telegram /status reads. None
# of them inspect processes, parse logs or query memory directly.


def _snapshot(agent: OpenClawAgent):
    from app.runtime_state import build_snapshot

    healthy = agent.ollama.health()

    return build_snapshot(
        agent=agent,
        ollama_healthy=healthy,
        installed_models=[settings.default_model] if healthy else [],
    )


def _view(agent: OpenClawAgent):
    from app import identity as identity_module
    from app.status_view import build_view

    return build_view(_snapshot(agent), assistant_name=identity_module.display_name())


def handle_command(agent: OpenClawAgent, message: str) -> str | None:
    """
    Run a slash command, or return None when the message is conversation.

    Kept small: these are views onto state that already exists. Anything that
    would need its own state does not belong here.
    """
    from app.status_view import (
        detect_terminal,
        render_telegram,
        render_terminal,
    )

    if not message.startswith("/"):
        return None

    parts = message[1:].strip().split() if message[1:].strip() else []
    command = parts[0].lower() if parts else ""
    view = _view(agent)

    if command == "status":
        return render_terminal(view, detect_terminal())

    if command == "models":
        # From the provider registry when there is one, so /models reports
        # what can actually be routed to rather than what happens to be
        # installed.
        if view.providers:
            lines = []

            for entry in view.providers:
                for name in entry.get("models", []):
                    lines.append(
                        f"{entry.get('provider_type', '?').lower():<10} "
                        f"{name:<20} {entry.get('status', 'UNKNOWN')}")

            if lines:
                return "\n".join(lines)

        if not view.runtimes:
            return "No hay runtimes que reportar."

        return "\n".join(
            f"{item.get('provider', '?')}  {item.get('model', '?')}  "
            f"{item.get('status', 'UNKNOWN')}"
            for item in view.runtimes
        )

    if command == "providers":
        if not view.providers:
            return "No hay proveedores de razonamiento registrados."

        lines = [f"Modo: {view.mode}"]

        for entry in view.providers:
            capabilities = entry.get("capabilities", {})
            lines.append(
                f"{entry.get('provider_id', '?'):<18}"
                f"{entry.get('status', 'UNKNOWN'):<14}"
                f"{'local' if capabilities.get('local') else 'remoto'}"
            )

        if view.provider_accounts:
            lines.append("")
            lines.append("Cuentas:")

            for account in view.provider_accounts:
                cooldown = account.get("cooldown_seconds") or 0
                suffix = f"  enfriando {cooldown}s" if cooldown else ""
                lines.append(
                    f"  {account.get('account_ref', '?'):<20}"
                    f"prioridad {account.get('priority', '?'):<5}"
                    f"{account.get('status', 'UNKNOWN')}{suffix}"
                )

        # Deliberately absent: credential references. A Keychain service name
        # can describe how someone organises their accounts.
        return "\n".join(lines)

    if command == "nodes":
        return "\n".join(
            f"{node.get('display_name', '?')}  {node.get('status', 'UNKNOWN')}  "
            f"{node.get('role', '')}".rstrip()
            for node in (view.nodes or [{}])
        ) or "Sólo este nodo."

    if command == "node":
        node = view.nodes[0] if view.nodes else {}
        return (f"Nodo: {node.get('display_name', settings.node_id)}\n"
                f"Estado: {node.get('status', 'UNKNOWN')}\n"
                f"Rol: {node.get('role', '') or 'local'}")

    if command == "memory":
        healthy = bool(getattr(agent.core, "health", lambda: False)())
        return "Memory Core: saludable" if healthy else "Memory Core: no disponible"

    if command == "voice":
        try:
            from app.voice import voice_service
            state = voice_service.status()
            return (f"Voice\nTTS: {state.get('tts', 'UNAVAILABLE')}\n"
                    f"STT: {state.get('stt', 'UNAVAILABLE')}\n"
                    f"Mode: {state.get('mode', 'off')}")
        except Exception:
            return "Voice: no disponible"

    if command == "debug":
        from app.logger import configure_cli_logging
        enabled = len(parts) > 1 and parts[1].lower() in {"on", "1", "true", "sí", "si"}
        configure_cli_logging(debug=enabled)
        return "Debug logging: ON (stderr + archivo)." if enabled else "Debug logging: OFF (archivo operativo conservado)."

    if command == "context":
        if not view.context_chars:
            return "Todavía no he construido contexto en esta sesión."

        lines = [
            f"Contexto: {view.context_chars} caracteres",
            f"Tokens estimados: ~{view.context_tokens}",
        ]

        if view.context_sections:
            lines.append("Secciones: " + ", ".join(view.context_sections))

        if view.compaction_count:
            lines.append(f"Compactaciones: {view.compaction_count} "
                         f"(última reducción {int(view.compaction_ratio * 100)}%)")

        return "\n".join(lines)

    if command == "task":
        if not view.task:
            return "No hay tarea activa."

        lines = [f"Tarea: {view.task}"]

        if view.plan_progress:
            lines.append(f"Plan: {view.plan_progress} ({view.plan_state})")

        if view.task_verification:
            lines.append(f"Verificación: {view.task_verification}")

        return "\n".join(lines)

    if command == "project":
        return f"Proyecto: {view.project}" if view.project else "Sin proyecto activo."

    if command == "mode":
        requested = parts[1].upper() if len(parts) > 1 else ""
        if requested and requested != "LOCAL":
            return "Modo no disponible en v1.0. Sólo LOCAL está habilitado."
        return f"Modo actual: {view.mode} (LOCAL es el default en v1.0)."

    if command == "clear":
        return "No hay estado conversacional efímero que limpiar; Memory Core permanece intacto."

    if command == "usage":
        budget = view.cloud_budget
        usage = view.provider_usage
        # Cloud is not implemented, so the number is zero — but it is counted
        # from what non-local providers actually served, not asserted.
        return (
            f"Modo: {view.mode}\n"
            f"Peticiones: {usage.get('requests', 0)} "
            f"(errores {usage.get('errors', 0)})\n"
            f"Tokens estimados: ~{usage.get('estimated_input_tokens', 0)} entrada / "
            f"~{usage.get('estimated_output_tokens', 0)} salida\n"
            f"Coste: {usage.get('cost_estimated', 0)}\n"
            f"Llamadas a cloud: {view.cloud_calls}\n"
            f"Motor local: {view.active_model or 'ninguno'}\n"
            f"Contexto actual: ~{view.context_tokens} tokens\n"
            f"\n"
            f"Nube: {budget.get('cloud_requests', 0)} peticiones "
            f"({budget.get('cloud_denials', 0)} denegadas por presupuesto)\n"
            f"Tokens de nube: {budget.get('cloud_input_tokens', 0)} entrada / "
            f"{budget.get('cloud_output_tokens', 0)} salida\n"
            f"Límites por tarea: "
            f"{(budget.get('limits') or {}).get('requests_per_task', '?')} peticiones"
        )

    if command == "telegram":
        # Same state, the other presentation. Useful for confirming they agree.
        return render_telegram(view)

    if command in {"help", "?"}:
        return (
            "/status   estado completo\n"
            "/models   modelos enrutables\n"
            "/providers proveedores de razonamiento\n"
            "/nodes    nodos conocidos\n"
            "/node     nodo actual\n"
            "/memory   estado de Memory Core\n"
            "/context  métricas de contexto\n"
            "/task     tarea y plan\n"
            "/project  proyecto activo\n"
            "/usage    modo y consumo\n"
            "/mode     modo actual (sólo LOCAL)\n"
            "/clear    estado efímero, sin borrar memoria\n"
            "/debug    logging técnico (on/off)\n"
            "/exit     cerrar la sesión\n"
            "/telegram el mismo estado, vista de Telegram"
        )

    return f"No conozco /{command}. Prueba /help."


def run_interactive_chat() -> int:
    from app.cli_session import InteractiveCLISession
    return InteractiveCLISession(_agent).run()
