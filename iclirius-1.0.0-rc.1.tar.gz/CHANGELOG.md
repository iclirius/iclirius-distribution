# Changelog

## Unreleased

- Local identity authentication for interactive sessions: macOS Touch ID with
  a machine-local scrypt recovery passphrase, safe auth status, and no changes
  to Fernet Memory Core encryption or Telegram authentication.
- Canonical local `NodeSnapshot`, `iclirius node status`, bounded resource and
  Ollama probes, Memory Core revision metadata, and a small responsive TUI
  status panel.
- Standalone Python packaging, console entrypoint, release-archive builder and
  local Homebrew formula prototype; no public release or tap published.

- CLI interactiva limpia: logs operativos permanecen en archivo y se muestran
  explícitamente con `--debug`.
- Clasificación de tareas locales y awareness de capacidades del nodo sin
  relajar sandboxing ni permisos.
- Entradas vacías o secuencias de terminal no generan turnos ni llamadas al
  modelo.
- Capa visual ligera para el chat CLI: header runtime, color TTY opcional,
  indicador de trabajo y señales breves de lectura/fallback.
- Instalador reproducible para macOS (`install.sh`), diagnóstico read-only
  (`iclirius doctor --json`) y desinstalación que preserva datos de usuario.
- `iclirius setup` para identidad humana, Memory Home versionado, bootstrap
  local de Keychain y migración cifrada sin borrar el estado anterior.
- Phase 5 hardening: setup reuses an existing Memory Home user ID, validates
  its complete structure, avoids duplicating the legacy encrypted core, rejects
  unsafe symlinks/overlapping paths, and keeps session node metadata stable.
- Chat TUI mínima basada en Textual: alternate screen, historial desplazable,
  composer multilinea con pegado seguro, worker para generación local y
  fallback `iclirius --plain`.

## 1.0.0-rc.1

- Canonical Iclirius identity shared by Telegram and the interactive CLI.
- Encrypted Memory Core with shared Project and Task continuity.
- Task Engine, Context Engine and ReasoningGateway boundaries.
- Local Ollama reasoning as the default.
- Optional Gemini provider, account pool and durable budget governor.
- Safe Web, READ, WRITE and EXECUTE flows with verification.
- Telegram interface with local TTS/STT voice support.
- Lightweight interactive CLI and shared RuntimeSnapshot/StatusView observability.

### Known limitations

- Real Gemini generation smoke is pending explicit credentials and model configuration.
- No cloud provider other than Gemini is implemented.
- AUTO, DEEP and COUNCIL routing modes are not implemented.
- Multi-node orchestration is not production-ready.
- TTS and STT are local; no cloud voice provider exists.
- Nine legacy files under `data/audio` are preserved intentionally because deletion was prohibited.
- `app/pending_scan.py` remains an untracked historical file intentionally.
