import json
import os
import subprocess
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken


KEYCHAIN_ACCOUNT = "iclirius"
KEYCHAIN_SERVICE = "iclirius_memory_key"


class SecureStorageError(Exception):
    pass


class KeychainMaterialMissing(SecureStorageError):
    """The Keychain item does not exist yet."""


class SecureStorage:
    def __init__(self):
        self.fernet = Fernet(self._load_key_from_keychain())

    def _load_key_from_keychain(self) -> bytes:
        key = load_keychain_key()

        if not key:
            raise SecureStorageError("Memory encryption key is empty.")

        return key.encode("utf-8")

    def write_text(self, path: str | Path, text: str) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        encrypted = self.fernet.encrypt(text.encode("utf-8"))
        path.write_bytes(encrypted)

    def read_text(self, path: str | Path, default: str = "") -> str:
        path = Path(path)

        if not path.exists():
            return default

        try:
            encrypted = path.read_bytes()
            decrypted = self.fernet.decrypt(encrypted)
            return decrypted.decode("utf-8")
        except InvalidToken as exc:
            raise SecureStorageError(f"Could not decrypt file: {path}") from exc

    def write_json(self, path: str | Path, data: Any) -> None:
        self.write_text(
            path,
            json.dumps(data, ensure_ascii=False, indent=2),
        )

    def read_json(self, path: str | Path, default: Any) -> Any:
        text = self.read_text(path, default="")

        if not text:
            return default

        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return default

    def append_jsonl(self, path: str | Path, item: dict) -> None:
        existing = self.read_text(path, default="")
        line = json.dumps(item, ensure_ascii=False)
        new_text = existing + line + "\n"
        self.write_text(path, new_text)

    def read_jsonl_tail(self, path: str | Path, limit: int = 5) -> list[dict]:
        text = self.read_text(path, default="")

        if not text:
            return []

        lines = [line.strip() for line in text.splitlines() if line.strip()]
        items = []

        for line in lines[-limit:]:
            try:
                items.append(json.loads(line))
            except Exception:
                continue

        return items

    def remove_last_jsonl(self, path: str | Path) -> bool:
        text = self.read_text(path, default="")

        if not text:
            return False

        lines = [line for line in text.splitlines() if line.strip()]

        if not lines:
            return False

        new_text = "\n".join(lines[:-1])

        if new_text:
            new_text += "\n"

        self.write_text(path, new_text)
        return True


def load_keychain_key() -> str:
    """Read the memory key without exposing it to callers that only audit."""
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-a", KEYCHAIN_ACCOUNT,
             "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except Exception as exc:
        raise SecureStorageError(f"Could not access macOS Keychain: {type(exc).__name__}") from exc
    if result.returncode != 0:
        raise KeychainMaterialMissing(
            "Memory encryption key not found in macOS Keychain. "
            "Run iclirius setup to bootstrap this machine."
        )
    return result.stdout.strip()


def ensure_keychain_key() -> bool:
    """Create local Fernet material once; never prints or persists its value."""
    try:
        existing = load_keychain_key()
        if not existing:
            raise SecureStorageError("Memory encryption key is empty.")
        # Validate before declaring the machine ready. Never replace an
        # existing value automatically: that would make encrypted memory
        # unreadable and would violate setup's no-data-loss contract.
        Fernet(existing.encode("utf-8"))
        return True
    except KeychainMaterialMissing:
        pass
    except (SecureStorageError, ValueError) as exc:
        raise SecureStorageError("Existing Keychain memory material is invalid; refusing to replace it.") from exc
    key = Fernet.generate_key().decode("ascii")
    try:
        result = subprocess.run(
            ["security", "add-generic-password", "-U", "-a", KEYCHAIN_ACCOUNT,
             "-s", KEYCHAIN_SERVICE, "-w", key],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except Exception as exc:
        raise SecureStorageError(f"Could not create macOS Keychain material: {type(exc).__name__}") from exc
    if result.returncode != 0:
        raise SecureStorageError("Could not create memory encryption material in macOS Keychain.")
    return True
