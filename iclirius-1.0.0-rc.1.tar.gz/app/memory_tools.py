from pathlib import Path

from app.config import settings

SUMMARY_PATH = Path(settings.memory_path) / "summary.md"
LEARNED_PATH = Path(settings.memory_path) / "learned.jsonl"
DIGEST_LOG_PATH = Path(settings.memory_path) / "digest_log.jsonl"
PERSONALITY_PATH = Path(settings.identity_path) / "personality.md"
PROJECT_STATUS_PATH = Path(settings.state_path) / "project_status.md"


def _tail_text(path: Path, lines: int = 80, empty: str = "Sin datos.") -> str:
    if not path.exists():
        return empty

    content = path.read_text().splitlines()
    if not content:
        return empty

    return "\n".join(content[-lines:])


def memory_summary_text(lines: int = 80) -> str:
    return "Resumen vivo:\n" + _tail_text(SUMMARY_PATH, lines)


def learned_text(lines: int = 30) -> str:
    """
    What Iclirius has picked up, encrypted first and legacy file after.

    New learnings live in the Memory Core since Phase 4.1. The plaintext file
    is still read so the history recorded before that does not vanish from
    the interfaces that used to show it, but nothing writes to it any more.
    """
    entries = []

    try:
        from app.memory_core import MemoryCore

        entries = MemoryCore().learnings(limit=lines)
    except Exception:
        entries = []

    parts = ["Aprendizajes automáticos:"]

    if entries:
        parts.extend(f"- {item.get('text', '')}" for item in entries)
    else:
        parts.append("Sin aprendizajes nuevos todavía.")

    legacy = _tail_text(LEARNED_PATH, lines, "")

    if legacy:
        parts.append("")
        parts.append("Histórico anterior (archivo legacy, sólo lectura):")
        parts.append(legacy)

    return "\n".join(parts)


def digest_log_text(lines: int = 40) -> str:
    return "Digest log:\n" + _tail_text(DIGEST_LOG_PATH, lines, "Sin digest todavía.")


def personality_text(lines: int = 80) -> str:
    return "Personalidad actual:\n" + _tail_text(PERSONALITY_PATH, lines)


def project_status_text(lines: int = 80) -> str:
    return "Estado del proyecto:\n" + _tail_text(PROJECT_STATUS_PATH, lines)


def full_brain_status_text() -> str:
    parts = [
        project_status_text(50),
        "",
        memory_summary_text(50),
        "",
        learned_text(20),
    ]

    return "\n".join(parts).strip()[:3900]


def clear_learned_text() -> str:
    """
    Clear the learnings Iclirius recorded.

    Only the encrypted ones. The legacy plaintext file is left untouched:
    deleting a file this code no longer owns is not this command's business.
    """
    try:
        from app.memory_core import MemoryCore

        core = MemoryCore()
        core._mutate(lambda state: state.update({"learnings": []}))
    except Exception:
        return "No pude limpiar los aprendizajes."

    return "Aprendizajes automáticos limpiados."
