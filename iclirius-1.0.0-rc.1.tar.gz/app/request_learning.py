import json
import re
import unicodedata
from collections import Counter
from datetime import datetime
from pathlib import Path
from app.config import settings
from typing import Dict, List


LEARNING_DIR = Path(settings.state_path) / "learning"
LEARNING_DIR.mkdir(parents=True, exist_ok=True)

REQUEST_LOG = LEARNING_DIR / "request_log.jsonl"
TOPICS_INDEX = LEARNING_DIR / "topics_index.json"

# Personal topic phrases are user data, not source code. They live in a local
# file under data/learning/, which is gitignored, so the repository never
# carries anybody's private interests. Without that file the classifier falls
# back to generic project vocabulary.
KNOWN_PHRASES_PATH = LEARNING_DIR / "known_phrases.json"

DEFAULT_KNOWN_PHRASES = [
    "openclaw",
    "iclirius",
    "worker",
    "telegram",
    "task queue",
]


def load_known_phrases() -> List[str]:
    """Local phrase list if present, otherwise the generic defaults."""
    if KNOWN_PHRASES_PATH.exists():
        try:
            data = json.loads(KNOWN_PHRASES_PATH.read_text(encoding="utf-8"))
        except Exception:
            return list(DEFAULT_KNOWN_PHRASES)

        if isinstance(data, list):
            phrases = [str(item).strip() for item in data if str(item).strip()]
            if phrases:
                return phrases

    return list(DEFAULT_KNOWN_PHRASES)


STOPWORDS = {
    "que", "qué", "como", "cómo", "para", "pero", "esto", "esta",
    "este", "estos", "estas", "quiero", "puedo", "puedes", "dame",
    "dime", "hacer", "hace", "con", "sin", "los", "las", "del",
    "una", "uno", "por", "mis", "tus", "sus", "hay", "van", "ser",
    "sea", "todo", "todos", "todas", "algo", "mas", "más", "ahora",
    "bien", "solo", "sólo", "desde", "hasta", "tengo", "tienes"
}


def now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", text.lower()).strip()


def extract_terms(text: str) -> List[str]:
    t = norm(text)
    words = re.findall(r"[a-z0-9áéíóúñü_+-]{3,}", t)
    terms = []

    for w in words:
        if w in STOPWORDS:
            continue
        terms.append(w)

    phrases = []

    for phrase in load_known_phrases():
        if norm(phrase) in t:
            phrases.append(norm(phrase))

    return phrases + terms


def classify_request(text: str) -> str:
    t = norm(text)

    if any(x in t for x in ["libro", "libros", "murakami", "epub", "biblioteca"]):
        return "library"
    if any(x in t for x in ["drive", "archivo", "archivos", "pdf", "documento", "carpeta"]):
        return "drive"
    if any(x in t for x in ["worker", "job", "proceso", "procesando", "fondo", "estado"]):
        return "jobs"
    if any(x in t for x in ["recuerda", "aprende", "memoria", "learned"]):
        return "memory"
    if any(x in t for x in ["error", "fallo", "debug", "comando", "terminal"]):
        return "debug"

    return "chat"


def log_request(text: str, source: str = "telegram") -> Dict:
    terms = extract_terms(text)
    kind = classify_request(text)

    row = {
        "ts": now(),
        "source": source,
        "kind": kind,
        "text": text,
        "terms": terms,
    }

    with REQUEST_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")

    rebuild_topics_index()
    return row


def rebuild_topics_index() -> Dict:
    counter = Counter()
    kinds = Counter()

    if REQUEST_LOG.exists():
        with REQUEST_LOG.open("r", encoding="utf-8") as f:
            for line in f:
                try:
                    row = json.loads(line)
                except Exception:
                    continue

                kinds[row.get("kind", "unknown")] += 1

                for term in row.get("terms", []):
                    counter[term] += 1

    index = {
        "updated_at": now(),
        "kinds": dict(kinds.most_common()),
        "top_terms": dict(counter.most_common(100)),
    }

    TOPICS_INDEX.write_text(
        json.dumps(index, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return index


def learning_summary() -> str:
    if not TOPICS_INDEX.exists():
        return "Aún no hay aprendizaje de solicitudes."

    index = json.loads(TOPICS_INDEX.read_text(encoding="utf-8"))

    lines = []
    lines.append("Aprendizaje de solicitudes:")
    lines.append(f"Actualizado: {index.get('updated_at')}")
    lines.append("")
    lines.append("Tipos de petición:")
    for k, v in index.get("kinds", {}).items():
        lines.append(f"- {k}: {v}")

    lines.append("")
    lines.append("Temas frecuentes:")
    for k, v in list(index.get("top_terms", {}).items())[:20]:
        lines.append(f"- {k}: {v}")

    return "\n".join(lines)
