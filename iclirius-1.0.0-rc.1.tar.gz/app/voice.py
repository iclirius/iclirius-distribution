"""Local voice presentation and transcription boundaries.

Providers receive only text or a transient audio artifact. They do not know
about Telegram, Memory Core, tasks, permissions or tools.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from app.config import settings
from app.runtime_events import EventType, Status, emit


class Capability(str, Enum):
    AVAILABLE = "AVAILABLE"
    DEGRADED = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"
    DISABLED = "DISABLED"


class VoiceMode(str, Enum):
    OFF = "off"
    ON_REQUEST = "on_request"
    ALWAYS = "always"


@dataclass
class AudioArtifact:
    path: Path
    duration_seconds: float = 0.0
    bytes: int = 0
    provider: str = ""
    voice: str = ""


class TTSProvider:
    name = ""

    def capability(self) -> Capability:
        raise NotImplementedError

    def synthesize(self, text: str, voice: str = "", rate: int = 180) -> AudioArtifact:
        raise NotImplementedError


class MacOSLocalTTS(TTSProvider):
    name = "macOS local"

    def __init__(self, say_path: str | None = None, ffmpeg_path: str | None = None,
                 ffprobe_path: str | None = None):
        self.say_path = say_path or shutil.which("say")
        self.ffmpeg_path = ffmpeg_path or shutil.which("ffmpeg")
        self.ffprobe_path = ffprobe_path or shutil.which("ffprobe")

    def capability(self) -> Capability:
        if not self.say_path:
            return Capability.UNAVAILABLE
        if not self.ffmpeg_path:
            return Capability.DEGRADED
        return Capability.AVAILABLE

    def synthesize(self, text: str, voice: str = "", rate: int = 180) -> AudioArtifact:
        if not self.say_path:
            raise RuntimeError("macOS say no está disponible")
        if not self.ffmpeg_path:
            raise RuntimeError("No hay encoder OGG/Opus local disponible")

        bounded = str(text or "")[: settings.voice_max_chars]
        if not bounded.strip():
            raise ValueError("No hay texto para convertir a voz")

        started = time.monotonic()
        with tempfile.TemporaryDirectory(prefix="iclirius-voice-") as directory:
            root = Path(directory)
            aiff = root / "speech.aiff"
            ogg = root / "speech.ogg"
            argv = [self.say_path, "-o", str(aiff), "-r", str(max(1, min(int(rate), 500)))]
            if voice:
                argv.extend(["-v", str(voice)[:80]])
            argv.append(bounded)
            subprocess.run(argv, shell=False, check=True,
                           capture_output=True, timeout=settings.voice_tts_timeout)
            subprocess.run([
                self.ffmpeg_path, "-y", "-i", str(aiff), "-c:a", "libopus",
                "-b:a", "32k", "-vn", str(ogg),
            ], shell=False, check=True, capture_output=True,
                timeout=settings.voice_tts_timeout)
            data = ogg.read_bytes()
            if not data:
                raise RuntimeError("El encoder produjo audio vacío")
            fd, output_path = tempfile.mkstemp(prefix="iclirius-voice-", suffix=".ogg")
            os.close(fd)
            artifact = AudioArtifact(path=Path(output_path), bytes=len(data),
                                     provider=self.name, voice=voice)
            artifact.path.write_bytes(data)
        os.chmod(artifact.path, 0o600)

        if self.ffprobe_path:
            try:
                probe = subprocess.run(
                    [self.ffprobe_path, "-v", "error", "-show_entries",
                     "format=duration", "-of", "default=noprint_wrappers=1:nokey=1",
                     str(artifact.path)], capture_output=True, text=True,
                    shell=False, timeout=settings.voice_tts_timeout, check=True)
                artifact.duration_seconds = max(0.0, float(probe.stdout.strip()))
            except (ValueError, OSError, subprocess.SubprocessError):
                artifact.duration_seconds = 0.0

        artifact.duration_seconds = 0.0
        emit(EventType.VOICE_TTS_COMPLETED.value, status=Status.OK.value,
             metadata={"provider": self.name, "voice": voice,
                       "bytes": artifact.bytes,
                       "duration": artifact.duration_seconds,
                       "latency_ms": int((time.monotonic() - started) * 1000)})
        return artifact


class STTProvider:
    name = ""

    def capability(self) -> Capability:
        raise NotImplementedError

    def transcribe(self, path: Path) -> tuple[str, dict]:
        raise NotImplementedError


class FasterWhisperSTT(STTProvider):
    name = "faster-whisper local"

    def capability(self) -> Capability:
        try:
            import faster_whisper  # noqa: F401
            return Capability.AVAILABLE
        except ImportError:
            return Capability.UNAVAILABLE

    def transcribe(self, path: Path) -> tuple[str, dict]:
        from app.transcription import transcribe_audio
        return transcribe_audio(path), {"confidence": "UNKNOWN", "provider": self.name}


class VoiceService:
    def __init__(self, tts: TTSProvider | None = None, stt: STTProvider | None = None):
        self.tts = tts or MacOSLocalTTS()
        self.stt = stt or FasterWhisperSTT()

    @property
    def mode(self) -> VoiceMode:
        if not settings.voice_enabled:
            return VoiceMode.OFF
        try:
            return VoiceMode(settings.voice_mode)
        except ValueError:
            return VoiceMode.OFF

    def status(self) -> dict:
        return {"enabled": self.mode != VoiceMode.OFF, "mode": self.mode.value,
                "tts_provider": self.tts.name, "tts": self.tts.capability().value,
                "encoder": "Opus" if isinstance(self.tts, MacOSLocalTTS) and self.tts.ffmpeg_path else "unavailable",
                "stt_provider": self.stt.name, "stt": self.stt.capability().value}

    def should_speak(self, requested: bool = False) -> bool:
        return self.mode == VoiceMode.ALWAYS or (self.mode == VoiceMode.ON_REQUEST and requested)

    def synthesize(self, text: str) -> AudioArtifact:
        emit(EventType.VOICE_TTS_STARTED.value, status=Status.STARTED.value,
             metadata={"chars": min(len(text or ""), settings.voice_max_chars),
                       "provider": self.tts.name})
        try:
            artifact = self.tts.synthesize(text, settings.voice_name, settings.voice_rate)
        except Exception:
            emit(EventType.VOICE_TTS_FAILED.value, status=Status.FAILED.value,
                 metadata={"provider": self.tts.name})
            raise
        emit(EventType.VOICE_TTS_COMPLETED.value, status=Status.OK.value,
             metadata={"provider": artifact.provider, "bytes": artifact.bytes,
                       "voice": artifact.voice, "duration": artifact.duration_seconds})
        return artifact


voice_service = VoiceService()


def compact_for_voice(text: str, max_chars: int | None = None) -> str:
    """Deterministically remove noisy presentation content before TTS."""
    import re
    value = re.sub(r"```[\s\S]*?```", "Incluí un bloque de código en el mensaje escrito.", text or "")
    value = re.sub(r"https?://\S+", "Te dejé el enlace en el mensaje.", value)
    value = re.sub(r"\b[0-9a-f]{24,}\b", "un identificador largo", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip()
    return value[: max_chars or settings.voice_max_chars]
