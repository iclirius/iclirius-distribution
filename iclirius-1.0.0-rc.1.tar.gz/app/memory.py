import json
import os
from datetime import datetime

from app.config import settings
from app.secure_storage import SecureStorage, SecureStorageError


class MemoryStore:
    def __init__(self):
        self.identity_path = settings.identity_path
        self.memory_path = settings.memory_path

        self._secure: SecureStorage | None = None

        self.profile_file = os.path.join(self.identity_path, "profile.json.enc")
        self.projects_file = os.path.join(self.memory_path, "projects.json.enc")
        self.preferences_file = os.path.join(self.memory_path, "preferences.json.enc")
        self.notes_file = os.path.join(self.memory_path, "notes.jsonl.enc")
        self.conversations_file = os.path.join(self.memory_path, "conversations.jsonl.enc")

    @property
    def secure(self) -> SecureStorage:
        """
        Encryption backend, built on first use.

        SecureStorage reads the key from the macOS Keychain in its constructor.
        Building it lazily keeps importing this module (and everything that
        imports it, including interfaces.telegram_bot) free of any Keychain,
        network or runtime dependency. The storage format is unchanged.
        """
        if self._secure is None:
            os.makedirs(self.identity_path, exist_ok=True)
            os.makedirs(self.memory_path, exist_ok=True)
            self._secure = SecureStorage()

        return self._secure

    def _read_json(self, path: str, default: dict) -> dict:
        try:
            return self.secure.read_json(path, default)
        except SecureStorageError:
            return default

    def read_profile(self) -> dict:
        return self._read_json(self.profile_file, {})

    def read_projects(self) -> dict:
        return self._read_json(self.projects_file, {"projects": {}})

    def read_preferences(self) -> dict:
        return self._read_json(self.preferences_file, {"preferences": {}})

    def add_note(self, text: str, source: str = "telegram") -> None:
        note = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "source": source,
            "text": text.strip()
        }

        self.secure.append_jsonl(self.notes_file, note)

    def read_recent_notes(self, limit: int = 5) -> list[dict]:
        try:
            return self.secure.read_jsonl_tail(self.notes_file, limit=limit)
        except SecureStorageError:
            return []

    def add_conversation_turn(
        self,
        user_id: int,
        user_message: str,
        assistant_response: str,
        source: str = "telegram",
        principal_id: str = "",
        interface: str = "",
        session_id: str = "",
    ) -> None:
        turn = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "source": source,
            "user_id": user_id,
            "user_message": user_message.strip(),
            "assistant_response": assistant_response.strip()
        }
        if principal_id:
            turn["principal_id"] = str(principal_id)
        if interface:
            turn["interface"] = str(interface)
        if session_id:
            turn["session_id"] = str(session_id)

        self.secure.append_jsonl(self.conversations_file, turn)

    def read_recent_conversations(self, limit: int = 5,
                                  principal_id: str = "") -> list[dict]:
        try:
            # Read a bounded tail larger than the requested result so turns
            # from another principal cannot fill the visible window. Legacy
            # rows without a principal id are deliberately excluded: they
            # predate identity scoping and cannot safely be attributed.
            rows = self.secure.read_jsonl_tail(
                self.conversations_file, limit=max(limit * 8, limit))
            if not principal_id:
                return rows[-limit:]
            matching = [
                row for row in rows
                if row.get("principal_id") == principal_id
            ]
            return matching[-limit:]
        except SecureStorageError:
            return []

    def forget_last_conversation(self) -> bool:
        try:
            return self.secure.remove_last_jsonl(self.conversations_file)
        except SecureStorageError:
            return False

    def summary(self) -> str:
        profile = self.read_profile()
        projects = self.read_projects()
        preferences = self.read_preferences()
        notes = self.read_recent_notes(limit=5)
        conversations = self.read_recent_conversations(limit=3)

        project_names = list(projects.get("projects", {}).keys())

        lines = [
            f"Agente: {profile.get('agent_name', settings.agent_name)}",
            f"Framework: {profile.get('framework', 'OpenClaw')}",
            f"Owner: {profile.get('owner', 'Luis')}",
            f"Propósito: {profile.get('purpose', 'No definido')}",
            "",
            "Proyectos:",
        ]

        if project_names:
            for name in project_names:
                project = projects["projects"][name]
                lines.append(f"- {project.get('name', name)}: {project.get('status', 'sin estado')}")
        else:
            lines.append("- Sin proyectos registrados")

        lines.append("")
        lines.append("Preferencias:")

        prefs = preferences.get("preferences", {})
        if prefs:
            for key, value in prefs.items():
                lines.append(f"- {key}: {value}")
        else:
            lines.append("- Sin preferencias registradas")

        lines.append("")
        lines.append("Notas explícitas recientes:")

        if notes:
            for note in notes:
                lines.append(f"- {note.get('timestamp')}: {note.get('text')}")
        else:
            lines.append("- Sin notas recientes")

        lines.append("")
        lines.append("Conversaciones recientes:")

        if conversations:
            for turn in conversations:
                user_message = turn.get("user_message", "")
                assistant_response = turn.get("assistant_response", "")
                lines.append(f"- Usuario: {user_message[:180]}")
                lines.append(f"  iclirius: {assistant_response[:180]}")
        else:
            lines.append("- Sin conversaciones recientes")

        return "\n".join(lines)

    def history_text(self, limit: int = 5, principal_id: str = "") -> str:
        conversations = self.read_recent_conversations(
            limit=limit, principal_id=principal_id)

        if not conversations:
            return "No hay historial de conversaciones todavía."

        lines = ["Historial reciente:"]

        for turn in conversations:
            lines.append("")
            lines.append(f"Fecha: {turn.get('timestamp')}")
            lines.append(f"Usuario: {turn.get('user_message')}")
            lines.append(f"iclirius: {turn.get('assistant_response')}")

        return "\n".join(lines)
