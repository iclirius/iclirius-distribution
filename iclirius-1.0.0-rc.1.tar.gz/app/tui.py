"""Textual based minimal chat interface for interactive terminals."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field

from app.cli_ui import _clean_input
from app.logger import logger
from app.runtime_events import EventType, Status, emit

try:
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, VerticalScroll
    from textual.message import Message
    from textual.widgets import Label, Static, TextArea
    _TEXTUAL_AVAILABLE = True
except ImportError:  # pragma: no cover
    App = object  # type: ignore[assignment,misc]
    ComposeResult = object  # type: ignore[assignment,misc]
    Binding = Container = Horizontal = VerticalScroll = Message = Label = Static = TextArea = object  # type: ignore[assignment]
    _TEXTUAL_AVAILABLE = False


@dataclass
class TUIState:
    messages: list[tuple[str, str]] = field(default_factory=list)
    input_text: str = ""
    activity: str = ""
    scroll: int = 0


if _TEXTUAL_AVAILABLE:
    class Composer(TextArea):
        """Reusable multiline composer; bracketed paste remains editable."""

        class Submitted(Message):
            def __init__(self, text: str) -> None:
                super().__init__()
                self.text = text

        def on_key(self, event) -> None:  # pragma: no cover - framework dispatch
            if event.key == "enter":
                event.prevent_default()
                event.stop()
                self.post_message(self.Submitted(self.text))
            elif event.key in {"shift+enter", "alt+enter", "ctrl+enter"}:
                event.prevent_default()
                event.stop()
                self.insert("\n")


    class ChatMessage(Static):
        def __init__(self, role: str, text: str) -> None:
            super().__init__()
            self.role = role
            self.message_text = text

        def compose(self) -> ComposeResult:
            yield Label(self.role, classes="message-role")
            yield Static(self.message_text, classes="message-body")


    class IcliriusChatApp(App[None]):
        CSS = """
        Screen { background: $surface; color: $text; }
        #header { height: 3; padding: 0 2; border-bottom: solid $primary-darken-2; }
        #brand { width: 1fr; color: $accent; text-style: bold; }
        #runtime { width: auto; color: $text-muted; content-align: right middle; }
        #conversation { height: 1fr; padding: 1 3; scrollbar-size: 1 1; }
        #body { height: 1fr; }
        #node-status { width: 30; display: none; border-left: solid $primary-darken-2; padding: 1 2; color: $text-muted; }
        ChatMessage { height: auto; margin: 0 0 1 0; }
        .message-role { color: $accent; text-style: bold; height: 1; }
        .message-body { color: $text; height: auto; padding: 0 0 0 2; }
        #activity { height: 1; color: $text-muted; padding: 0 3; }
        #composer-box { height: auto; min-height: 3; max-height: 12; border-top: solid $primary-darken-2; padding: 1 2 0 2; }
        #composer { height: auto; min-height: 1; max-height: 10; border: round $primary-darken-1; }
        #hint { height: 1; color: $text-muted; padding: 0 1; }
        """
        BINDINGS = [
            Binding("ctrl+c", "cancel_or_quit", "Cancel/Quit", show=False),
            Binding("ctrl+d", "quit_if_empty", "Quit", show=False),
        ]

        def __init__(self, agent_factory, *, stdout=None) -> None:
            super().__init__()
            self.agent_factory = agent_factory
            self.stdout = stdout or sys.stdout
            self.state = TUIState()
            self.agent = None
            self._busy = False
            self._event_bus = None

        def compose(self) -> ComposeResult:
            yield Horizontal(
                Static("ICLIRIUS", id="brand"),
                Static("LOCAL · initializing", id="runtime"),
                id="header",
            )
            yield Horizontal(
                VerticalScroll(id="conversation"),
                Static("NODE\nInitializing…", id="node-status"),
                id="body",
            )
            yield Label("", id="activity")
            yield Container(
                Composer("", id="composer"),
                Label("Enter send · Shift/Alt/Ctrl+Enter newline · / commands", id="hint"),
                id="composer-box",
            )

        def on_mount(self) -> None:
            self.agent = self.agent_factory()
            self._set_runtime()
            self._append_message("Iclirius", "Iclirius listo. ¿En qué te puedo ayudar?")
            self.query_one(Composer).focus()
            self._subscribe_events()
            self.query_one("#node-status", Static).display = self.size.width >= 120
            self._refresh_node_status()
            try:
                emit(EventType.CLI_SESSION_STARTED, status=Status.SUCCESS,
                     interface="cli", metadata={"ui": "textual"})
            except Exception:
                logger.debug("Unable to emit CLI session start", exc_info=True)

        def on_unmount(self) -> None:
            self._unsubscribe_events()
            try:
                emit(EventType.CLI_SESSION_ENDED, status=Status.SUCCESS,
                     interface="cli", metadata={"ui": "textual"})
            except Exception:
                logger.debug("Unable to emit CLI session end", exc_info=True)

        def _set_runtime(self) -> None:
            model = "configured-local-model"
            provider = "LOCAL"
            try:
                from app.config import settings
                model = settings.default_model or model
                mode = getattr(self.agent, "mode", "LOCAL")
                provider = "LOCAL" if mode == "LOCAL" else str(mode)
            except Exception:
                pass
            self.query_one("#runtime", Static).update(f"{provider} · {model}")

        def _refresh_node_status(self) -> None:
            try:
                from app.node_snapshot import collect
                self.run_worker(
                    lambda: collect(agent=self.agent, interface="tui",
                                    session_id=getattr(self.agent, "session_id", ""), active=True),
                    thread=True, exclusive=True, name="node-status",
                )
            except Exception:
                self.query_one("#node-status", Static).update("NODE\nUnavailable")

        def on_worker_state_changed(self, event) -> None:
            if getattr(event.worker, "name", "") != "node-status" or not event.worker.is_finished:
                return
            try:
                from app.node_snapshot import render
                self.query_one("#node-status", Static).update(render(event.worker.result))
            except Exception:
                self.query_one("#node-status", Static).update("NODE\nUnavailable")

        def on_resize(self, event) -> None:
            try:
                self.query_one("#node-status", Static).display = event.size.width >= 120
            except Exception:
                pass

        def _append_message(self, role: str, text: str) -> None:
            self.state.messages.append((role, text))
            conversation = self.query_one("#conversation", VerticalScroll)
            conversation.mount(ChatMessage(role, text))
            conversation.scroll_end(animate=False)

        def on_composer_submitted(self, message: Composer.Submitted) -> None:
            self._submit(message.text)

        def _submit(self, raw: str) -> None:
            message = _clean_input(raw)
            if not message or self._busy:
                return
            composer = self.query_one(Composer)
            composer.clear()
            if message == "/exit":
                self.exit()
                return
            try:
                from interfaces.cli_chat import handle_command
                command_result = handle_command(self.agent, message)
            except Exception:
                command_result = None
                logger.exception("CLI command failed")
            if command_result is not None:
                self._append_message("You", message)
                self._append_message("Iclirius", command_result)
                return
            self._append_message("You", message)
            self._busy = True
            self._set_activity("Iclirius · thinking…")
            try:
                emit(EventType.CLI_MESSAGE_RECEIVED, status=Status.SUCCESS,
                     interface="cli", metadata={"chars": len(message)})
            except Exception:
                pass
            self.run_worker(lambda: self._respond(message), thread=True,
                            exclusive=True, name="agent-response")

        def _respond(self, message: str) -> None:
            try:
                response = self.agent.respond(message)
                self.agent.record_conversation_turn(message, response, source="cli")
                self.call_from_thread(self._response_ready, response)
            except Exception as exc:
                logger.exception("TUI agent response failed")
                self.call_from_thread(self._response_ready,
                                      "No pude completar la respuesta local. Revisa /status.",
                                      exc)

        def _response_ready(self, response: str, error=None) -> None:
            self._busy = False
            self._set_activity("")
            self._append_message("Iclirius", response)
            self.query_one(Composer).focus()
            if error:
                logger.debug("TUI response error category=%s", type(error).__name__)

        def _set_activity(self, text: str) -> None:
            self.state.activity = text
            self.query_one("#activity", Label).update(text)

        def action_cancel_or_quit(self) -> None:
            if self._busy:
                self._set_activity("Iclirius · finishing current response…")
                return
            self.exit()

        def action_quit_if_empty(self) -> None:
            if not self._busy and not self.query_one(Composer).text.strip():
                self.exit()

        def _subscribe_events(self) -> None:
            try:
                from app.runtime_events import event_bus
                self._event_bus = event_bus
                self._unsubscribe_callback = event_bus.subscribe(self._on_event)
            except Exception:
                self._event_bus = None
                self._unsubscribe_callback = None

        def _unsubscribe_events(self) -> None:
            unsubscribe = getattr(self, "_unsubscribe_callback", None)
            if callable(unsubscribe):
                try:
                    unsubscribe()
                except Exception:
                    pass
            self._event_bus = None
            self._unsubscribe_callback = None

        def _on_event(self, event) -> None:
            event_type = getattr(event, "event_type", "")
            metadata = getattr(event, "metadata", {}) or {}
            if event_type == "PROVIDER_FALLBACK":
                source = metadata.get("from_model", "current model")
                target = metadata.get("to_model", "next model")
                self.call_from_thread(self._set_activity, f"⚠ {source} unavailable → {target}")
            elif event_type == "TOOL_STARTED":
                operation = metadata.get("operation") or getattr(event, "operation", "")
                if operation:
                    self.call_from_thread(self._set_activity, f"→ {operation}")

class IcliriusTUI:
    """Compatibility wrapper used by the CLI and legacy layout tests."""
    def __init__(self, agent_factory, stdin=None, stdout=None):
        self.agent_factory = agent_factory
        self.stdin = stdin or sys.stdin
        self.stdout = stdout or sys.stdout
        self.state = TUIState()
        self.agent = None

    @staticmethod
    def compatible(stdin=None, stdout=None) -> bool:
        stdin = stdin or sys.stdin
        stdout = stdout or sys.stdout
        try:
            return _TEXTUAL_AVAILABLE and stdin.isatty() and stdout.isatty()
        except Exception:
            return False

    def run(self) -> int:
        if not _TEXTUAL_AVAILABLE:
            logger.error("Textual is unavailable; use iclirius --plain")
            return 1
        try:
            IcliriusChatApp(self.agent_factory, stdout=self.stdout).run()
            return 0
        except Exception:
            logger.exception("TUI failed to start; use iclirius --plain")
            return 1

    def _layout(self, width: int, height: int) -> list[str]:
        mode = "wide" if width >= 120 else "medium" if width >= 85 else "narrow"
        lines = ["ICLIRIUS", "Chat", "Iclirius", "> Escribe un mensaje..."]
        if mode != "narrow":
            lines.append("RUNTIME")
        if mode == "wide":
            lines.append("CAPABILITIES")
        lines.extend(text for role, text in self.state.messages if text)
        return lines[: max(1, height)]

    def _on_event(self, event) -> None:
        if getattr(event, "event_type", "") == "PROVIDER_FALLBACK":
            metadata = getattr(event, "metadata", {}) or {}
            self.state.activity = f"⚠ {metadata.get('from_model', 'current model')} unavailable → switching to {metadata.get('to_model', 'next model')}"

    def _leave_terminal(self) -> None:
        return None
