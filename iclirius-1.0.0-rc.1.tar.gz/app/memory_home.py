"""Portable Memory Home layout and safe manifest operations.

Memory Home is a portable *location and metadata contract*. The encrypted
state files remain encrypted with the local Keychain material already used by
Memory Core. This module never writes credentials or raw secrets to the home.
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


SCHEMA_VERSION = 1
MANIFEST_NAME = "manifest.json"
VERSION_NAME = "version"


class MemoryHomeError(ValueError):
    """The Memory Home is unsafe, invalid, or incompatible."""


def _validate_user_id(user_id: str) -> str:
    value = str(user_id or "").strip()
    if (not value or len(value) > 128 or value in {".", ".."}
            or Path(value).name != value or "/" in value or "\\" in value):
        raise MemoryHomeError("Memory Home user_id is invalid.")
    return value


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _atomic_write(path: Path, text: str, mode: int = 0o600) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    temp = Path(name)
    try:
        os.fchmod(fd, mode)
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _safe_root(raw: str | Path) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        raise MemoryHomeError("Memory Home path must be absolute.")
    if path.exists() and path.is_symlink():
        raise MemoryHomeError("Memory Home cannot be a symlink.")
    # resolve() normalises traversal while preserving a valid mounted folder.
    resolved = path.resolve()
    if resolved == Path.home().resolve() or resolved == Path("/"):
        raise MemoryHomeError("Memory Home cannot be the filesystem or home root.")
    return resolved


@dataclass(frozen=True)
class MemoryHome:
    root: Path
    user_id: str
    primary_identity: str
    manifest: dict

    @property
    def user_root(self) -> Path:
        return self.root / "users" / self.user_id

    @property
    def profile_path(self) -> Path:
        return self.user_root / "profile"

    @property
    def memory_path(self) -> Path:
        return self.user_root / "memory"

    @property
    def core_path(self) -> Path:
        return self.user_root / "core"

    @property
    def sessions_path(self) -> Path:
        return self.user_root / "sessions"

    @property
    def metadata_path(self) -> Path:
        return self.user_root / "metadata"

    @property
    def required_directories(self) -> tuple[Path, ...]:
        return (
            self.profile_path, self.memory_path, self.core_path,
            self.sessions_path, self.user_root / "indexes",
            self.user_root / "journal", self.metadata_path,
            self.root / "shared", self.root / "locks",
        )


def _manifest_for(root: Path, user_id: str, primary_identity: str) -> dict:
    return {
        "format": "iclirius-memory-home",
        "schema_version": SCHEMA_VERSION,
        "created_at": _now(),
        "updated_at": _now(),
        "user": {"user_id": user_id, "primary_identity": primary_identity},
        "encryption": {
            "state": "fernet",
            "key_location": "macos-keychain",
            "key_reference": "iclirius_memory_key",
        },
        "machine_secrets": "excluded",
    }


def create(root: str | Path, user_id: str, primary_identity: str) -> MemoryHome:
    user_id = _validate_user_id(user_id)
    path = _safe_root(root)
    try:
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    except OSError as exc:
        raise MemoryHomeError("Memory Home cannot be created at this path.") from exc
    manifest_path = path / MANIFEST_NAME
    if manifest_path.exists():
        return load(path, expected_user_id=user_id, expected_identity=primary_identity)

    home = MemoryHome(path, user_id, primary_identity,
                      _manifest_for(path, user_id, primary_identity))
    for directory in home.required_directories:
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    _atomic_write(manifest_path, json.dumps(home.manifest, ensure_ascii=False, indent=2))
    _atomic_write(path / VERSION_NAME, f"{SCHEMA_VERSION}\n")
    return home


def load(root: str | Path, expected_user_id: str = "", expected_identity: str = "") -> MemoryHome:
    path = _safe_root(root)
    manifest_path = path / MANIFEST_NAME
    if not manifest_path.is_file():
        raise MemoryHomeError("Memory Home manifest.json is missing.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise MemoryHomeError("Memory Home manifest.json is invalid.") from exc
    if manifest.get("format") != "iclirius-memory-home":
        raise MemoryHomeError("Memory Home format is not supported.")
    if manifest.get("schema_version") != SCHEMA_VERSION:
        raise MemoryHomeError("Memory Home schema version is not supported.")
    user = manifest.get("user") or {}
    user_id = str(user.get("user_id") or "")
    _validate_user_id(user_id)
    identity = str(user.get("primary_identity") or "")
    if expected_user_id and user_id != expected_user_id:
        raise MemoryHomeError("Memory Home belongs to a different user_id.")
    if expected_identity and identity.casefold() != expected_identity.casefold():
        raise MemoryHomeError("Memory Home belongs to a different identity.")
    home = MemoryHome(path, user_id, identity, manifest)
    if any(not directory.is_dir() for directory in home.required_directories):
        raise MemoryHomeError("Memory Home structure is incomplete.")
    version_path = path / VERSION_NAME
    if (not version_path.is_file()
            or version_path.read_text(encoding="utf-8").strip() != str(SCHEMA_VERSION)):
        raise MemoryHomeError("Memory Home version marker is missing or invalid.")
    return home


def inspect(root: str | Path) -> dict:
    try:
        home = load(root)
    except (MemoryHomeError, OSError) as exc:
        return {"configured": False, "readable": False, "writable": False,
                "status": "invalid", "error": str(exc)}
    try:
        writable = all(os.access(directory, os.W_OK)
                       for directory in home.required_directories)
        readable = all(os.access(directory, os.R_OK)
                       for directory in home.required_directories)
        return {"configured": True, "readable": readable, "writable": writable,
                "status": "ready" if readable and writable else "not writable",
                "path": str(home.root), "schema_version": SCHEMA_VERSION,
                "user_id": home.user_id, "primary_identity": home.primary_identity}
    except OSError as exc:
        return {"configured": True, "readable": False, "writable": False,
                "status": "unavailable", "error": type(exc).__name__}


def copy_legacy_tree(source: str | Path, destination: str | Path,
                     exclude_top_level: set[str] | None = None) -> int:
    """Copy legacy encrypted data without deleting or overwriting destination."""
    source_path = Path(source).expanduser()
    destination_path = Path(destination).expanduser()
    exclude_top_level = exclude_top_level or set()
    if not source_path.exists():
        return 0
    if source_path.is_symlink():
        raise MemoryHomeError("Legacy memory source cannot be a symlink.")
    copied = 0
    for item in source_path.rglob("*"):
        relative = item.relative_to(source_path)
        if relative.parts and relative.parts[0] in exclude_top_level:
            continue
        if item.is_symlink():
            raise MemoryHomeError("Legacy memory contains an unsafe symlink.")
        if not item.is_file():
            continue
        target = destination_path / relative
        if target.exists():
            continue
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        shutil.copy2(item, target)
        if target.stat().st_size != item.stat().st_size:
            raise MemoryHomeError("Encrypted migration copy could not be verified.")
        os.chmod(target, stat.S_IRUSR | stat.S_IWUSR)
        copied += 1
    return copied
