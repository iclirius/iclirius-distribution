"""Read-only installation and runtime diagnostics for Iclirius."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _command(name: str) -> str | None:
    return shutil.which(name)


def _run(argv: list[str], timeout: float = 8) -> tuple[bool, str]:
    try:
        result = subprocess.run(argv, capture_output=True, text=True,
                                timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return False, ""
    return result.returncode == 0, (result.stdout or result.stderr or "").strip()


def _configured_models() -> tuple[list[str], list[str]]:
    try:
        from app.config import settings
        required = [settings.default_model, settings.fast_model, settings.heavy_model]
        optional = [settings.embed_model]
    except Exception:
        required, optional = [], []
    return (list(dict.fromkeys(name for name in required if name)),
            list(dict.fromkeys(name for name in optional if name)))


def _installed_models(ollama: str | None) -> list[str]:
    if not ollama:
        return []
    ok, output = _run([ollama, "list"])
    if not ok:
        return []
    models = []
    for line in output.splitlines()[1:]:
        fields = line.split()
        if fields:
            models.append(fields[0])
    return models


def _ollama_service() -> tuple[bool, str]:
    try:
        with urlopen("http://127.0.0.1:11434/api/tags", timeout=2) as response:
            return response.status == 200, "running"
    except (OSError, URLError, ValueError):
        return False, "not running"


def collect() -> dict:
    """Return safe, machine-readable diagnostics without secrets or mutation."""
    python_ok = sys.version_info >= (3, 10)
    git = _command("git")
    brew = _command("brew")
    ollama = _command("ollama")
    ffmpeg = _command("ffmpeg")
    ollama_running, ollama_state = _ollama_service() if ollama else (False, "not installed")
    configured_required, configured_optional = _configured_models()
    configured = configured_required + configured_optional
    installed = _installed_models(ollama) if ollama_running else []
    model_state = {name: (name in installed) for name in configured}

    try:
        import faster_whisper  # noqa: F401
        stt_installed = True
    except Exception:
        stt_installed = False

    try:
        from app.config import settings
        memory_enabled = settings.enable_memory_core
        local_read = settings.enable_local_read_tools
        execute = settings.execute_enabled
        telegram_enabled = settings.enable_telegram
        telegram_configured = bool(settings.telegram_bot_token and settings.allowed_user_ids)
        identity = settings.principal_user_name or "not configured"
    except Exception:
        memory_enabled = local_read = execute = telegram_enabled = False
        telegram_configured = False
        identity = "not configured"

    keychain_ok = False
    security = _command("security")
    if security:
        keychain_ok, _ = _run([security, "find-generic-password", "-a", "iclirius",
                               "-s", "iclirius_memory_key", "-w"])

    venv = Path(sys.prefix) != Path(sys.base_prefix)
    package_ok = (PROJECT_ROOT / "app" / "cli.py").exists()
    git_repo = (PROJECT_ROOT / ".git").exists()
    try:
        from app.setup import status as setup_status
        setup = setup_status()
    except Exception:
        setup = {
            "setup_complete": False,
            "identity": {"configured": False},
            "memory_home": {"configured": False, "status": "unavailable"},
            "keychain": {"configured": False},
            "node": {"configured": False},
        }
    try:
        from app.local_auth import status as auth_status
        authentication = auth_status()
    except Exception:
        authentication = {"enrolled": False, "touch_id": "unavailable",
                          "recovery_credential": False, "user_id": "",
                          "primary_identity": ""}
    required_models_ok = bool(configured_required) and all(model_state.get(name, False) for name in configured_required)
    blockers = {
        "platform": platform.system() == "Darwin",
        "python": python_ok,
        "venv": venv,
        # A packaged installation is valid without a .git directory. Git is
        # reported separately for project tooling.
        "package": package_ok,
        "git": bool(git),
        "ollama": bool(ollama and ollama_running),
        "models": required_models_ok,
        "setup": bool(setup.get("setup_complete")),
    }
    overall = "ready" if all(blockers.values()) else "blocked"
    return {
        "overall": overall,
        "platform": {"system": platform.system(), "release": platform.mac_ver()[0] or platform.release(),
                      "architecture": platform.machine(), "supported": blockers["platform"]},
        "python": {"version": platform.python_version(), "supported": python_ok, "venv": venv},
        "package": {"runtime": "OpenClaw embedded", "present": package_ok, "repository": git_repo},
        "git": {"installed": bool(git), "branch": _git_branch(git), "dirty": _git_dirty(git)},
        "homebrew": {"installed": bool(brew), "path": brew or ""},
        "ollama": {"installed": bool(ollama), "running": ollama_running, "state": ollama_state},
        "models": {"configured": configured, "required": configured_required,
                    "optional": configured_optional, "installed": installed,
                    "available": model_state},
        "memory": {"enabled": memory_enabled,
                    "status": "ready" if memory_enabled and keychain_ok else ("not configured" if memory_enabled else "disabled")},
        "identity": {"display_name": identity, "configured": identity != "not configured"},
        "setup": setup,
        "authentication": authentication,
        "tools": {"filesystem": local_read, "shell": execute, "git": bool(git), "python": python_ok},
        "voice": {"tts": bool(shutil.which("say")), "stt": stt_installed, "ffmpeg": bool(ffmpeg)},
        "interfaces": {"cli": package_ok, "telegram": telegram_enabled and telegram_configured},
        "providers": {"local": "ollama" if ollama else "not installed", "gemini": "disabled by default"},
        "blockers": blockers,
    }


def _git_branch(git: str | None) -> str:
    if not git:
        return ""
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "branch", "--show-current"])
    return value if ok else ""


def _git_dirty(git: str | None) -> bool:
    if not git:
        return False
    ok, value = _run([git, "-C", str(PROJECT_ROOT), "status", "--porcelain"])
    return bool(value) if ok else False


def _mark(ok: bool, text: str, optional: bool = False) -> str:
    return f"{'✓' if ok else ('○' if optional else '✗')} {text}"


def render(report: dict) -> str:
    lines = ["Iclirius Doctor", "", "CORE"]
    lines += [_mark(report["platform"]["supported"], "macOS"),
              _mark(report["python"]["supported"], f"Python {report['python']['version']}"),
              _mark(report["python"]["venv"], "virtualenv", optional=True),
              _mark(report["package"]["present"] and report["package"]["repository"], "Iclirius / OpenClaw runtime"),
              _mark(report["git"]["installed"], "Git")]
    lines.append(_mark(report["memory"]["status"] == "ready", "Memory Core", optional=True))
    setup = report.get("setup", {})
    identity = setup.get("identity", {})
    home = setup.get("memory_home", {})
    lines += ["", "SETUP",
              _mark(bool(setup.get("setup_complete")), "Setup complete"),
              _mark(bool(identity.get("configured")), "Identity", optional=True),
              _mark(home.get("status") == "ready", "Memory Home", optional=True),
              _mark(bool(setup.get("keychain", {}).get("configured")), "Keychain", optional=True),
              _mark(bool(setup.get("node", {}).get("configured")), "Node", optional=True)]
    auth = report.get("authentication", {})
    lines += ["", "LOCAL AUTHENTICATION",
              _mark(bool(auth.get("enrolled")), "Recovery credential", optional=True),
              _mark(auth.get("touch_id") == "available", f"Touch ID ({auth.get('touch_id', 'unavailable')})", optional=True)]
    lines += ["", "LOCAL AI",
              _mark(report["ollama"]["installed"], "Ollama installed"),
              _mark(report["ollama"]["running"], f"Ollama service ({report['ollama']['state']})"),]
    optional = set(report["models"].get("optional", []))
    for name, available in report["models"]["available"].items():
        lines.append(_mark(available, name, optional=name in optional))
    lines += ["", "TOOLS",
              _mark(report["tools"]["filesystem"], "Filesystem", optional=True),
              _mark(report["tools"]["shell"], "Shell", optional=True),
              _mark(report["tools"]["git"], "Git"),
              _mark(report["tools"]["python"], "Python"),
              "", "VOICE",
              _mark(report["voice"]["tts"], "TTS", optional=True),
              _mark(report["voice"]["stt"], "STT", optional=True),
              _mark(report["voice"]["ffmpeg"], "ffmpeg", optional=True),
              "", "INTERFACES",
              _mark(report["interfaces"]["cli"], "CLI"),
              _mark(report["interfaces"]["telegram"], "Telegram", optional=True),
              "", f"Overall: {report['overall'].upper()}"]
    if report["git"]["dirty"]:
        lines.append("Note: repository has uncommitted changes.")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = list(argv or [])
    report = collect()
    if "--json" in args:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(render(report))
    return 0 if report["overall"] == "ready" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
