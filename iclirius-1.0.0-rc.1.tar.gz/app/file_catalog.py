from __future__ import annotations

import json
import mimetypes
from collections import Counter
from datetime import datetime
from pathlib import Path
from app.config import settings

from app.config import settings


CATALOG_DIR = Path(settings.state_path) / "catalog"
CATALOG_PATH = CATALOG_DIR / "files.jsonl"
SUMMARY_PATH = CATALOG_DIR / "summary.json"


# Directory names that must never be traversed. Matched against whole path
# components, not as substrings: ".config" must not blacklist a folder called
# "mi.configuracion", and ".git" must not blacklist "notas.git-ideas".
BLOCKED_PARTS = {
    ".ssh",
    ".gnupg",
    ".config",
    ".venv",
    "node_modules",
    ".git",
    "Keychains",
}

BLOCKED_FILENAMES = {
    ".env",
    ".env.local",
    ".env.production",
    "id_rsa",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
    "authorized_keys",
    "known_hosts",
    "credentials",
    ".netrc",
    ".pgpass",
    ".htpasswd",
}

# Secret-bearing file types. Encrypted OpenClaw memory (.enc) is included so
# the agent can never read its own vault back out through a file tool.
BLOCKED_SUFFIXES = {
    ".pem",
    ".key",
    ".crt",
    ".cer",
    ".p12",
    ".pfx",
    ".jks",
    ".keystore",
    ".enc",
    ".kdbx",
}


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _expand(path: str | Path) -> Path:
    return Path(str(path)).expanduser().resolve()


def _allowed_roots() -> list[Path]:
    roots = []

    for root in settings.file_manager_allowed_roots:
        try:
            roots.append(_expand(root))
        except Exception:
            continue

    return roots


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def validate_safe_path(path: str | Path) -> Path:
    target = _expand(path)
    roots = _allowed_roots()

    if not roots:
        raise RuntimeError("FILE_MANAGER_ALLOWED_ROOTS no está configurado en .env")

    if not any(_is_under(target, root) or target == root for root in roots):
        allowed = "\n".join(str(root) for root in roots)
        raise PermissionError(f"Ruta no permitida: {target}\nRutas permitidas:\n{allowed}")

    # Component-wise, so a blocked name only matches a real directory or file
    # component. Case-insensitive because macOS filesystems usually are.
    lowered_parts = {part.lower() for part in target.parts}

    for blocked in BLOCKED_PARTS:
        if blocked.lower() in lowered_parts:
            raise PermissionError(f"Ruta bloqueada por seguridad: {target}")

    if target.name.lower() in {name.lower() for name in BLOCKED_FILENAMES}:
        raise PermissionError(f"Archivo bloqueado por seguridad: {target.name}")

    if target.suffix.lower() in BLOCKED_SUFFIXES:
        raise PermissionError(f"Tipo de archivo bloqueado por seguridad: {target.name}")

    return target


def classify_file(path: Path) -> str:
    ext = path.suffix.lower()

    if ext in {".xlsx", ".xls", ".csv", ".numbers", ".ods"}:
        return "spreadsheet"
    if ext in {".pdf", ".docx", ".doc", ".txt", ".md", ".rtf", ".epub"}:
        return "document"
    if ext in {".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".tiff"}:
        return "image"
    if ext in {".mp3", ".m4a", ".flac", ".wav", ".aac", ".ogg"}:
        return "audio"
    if ext in {".mp4", ".mov", ".mkv", ".avi", ".m4v"}:
        return "video"
    if ext in {".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml", ".html", ".css"}:
        return "code"
    if ext in {".zip", ".tar", ".gz", ".rar", ".7z"}:
        return "archive"

    return "other"


def _read_catalog() -> list[dict]:
    if not CATALOG_PATH.exists():
        return []

    rows = []
    for line in CATALOG_PATH.read_text().splitlines():
        if not line.strip():
            continue

        try:
            rows.append(json.loads(line))
        except Exception:
            continue

    return rows


def _write_catalog(rows: list[dict]) -> None:
    CATALOG_DIR.mkdir(parents=True, exist_ok=True)

    with CATALOG_PATH.open("w") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def catalog_folder(root_path: str, max_files: int = 20000) -> dict:
    root = validate_safe_path(root_path)

    if not root.exists():
        raise FileNotFoundError(f"No existe la ruta: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"No es carpeta: {root}")

    existing = _read_catalog()
    by_path = {row.get("path"): row for row in existing}

    scanned = 0
    skipped = 0
    updated = 0

    for item in root.rglob("*"):
        try:
            item = validate_safe_path(item)

            if not item.is_file():
                continue

            scanned += 1

            if scanned > max_files:
                skipped += 1
                break

            stat = item.stat()
            mime, _ = mimetypes.guess_type(str(item))

            row = {
                "path": str(item),
                "name": item.name,
                "parent": str(item.parent),
                "extension": item.suffix.lower(),
                "kind": classify_file(item),
                "mime": mime or "",
                "size": stat.st_size,
                "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                "cataloged_at": _now(),
                "source_root": str(root),
            }

            by_path[str(item)] = row
            updated += 1

        except Exception:
            skipped += 1

    rows = list(by_path.values())
    _write_catalog(rows)

    counts_by_kind = Counter(row.get("kind", "other") for row in rows)
    counts_by_ext = Counter(row.get("extension", "") or "no_ext" for row in rows)

    summary = {
        "updated_at": _now(),
        "total_files": len(rows),
        "last_scan_root": str(root),
        "last_scan_files": scanned,
        "updated_or_added": updated,
        "skipped": skipped,
        "by_kind": dict(counts_by_kind),
        "by_extension": dict(counts_by_ext.most_common(50)),
    }

    SUMMARY_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def catalog_folder_text(root_path: str) -> str:
    summary = catalog_folder(root_path)

    lines = [
        "Catálogo actualizado.",
        f"Ruta: {summary['last_scan_root']}",
        f"Archivos escaneados: {summary['last_scan_files']}",
        f"Total en catálogo: {summary['total_files']}",
        f"Actualizados/agregados: {summary['updated_or_added']}",
        f"Omitidos: {summary['skipped']}",
        "",
        "Por tipo:",
    ]

    for kind, count in sorted(summary["by_kind"].items(), key=lambda item: item[1], reverse=True):
        lines.append(f"- {kind}: {count}")

    return "\n".join(lines)[:3900]


def catalog_stats_text() -> str:
    rows = _read_catalog()

    if not rows:
        return "El catálogo está vacío. Usa /catalog_folder ruta primero."

    by_kind = Counter(row.get("kind", "other") for row in rows)
    by_ext = Counter(row.get("extension", "") or "no_ext" for row in rows)
    total_size = sum(int(row.get("size", 0)) for row in rows)

    lines = [
        "Estadísticas del catálogo:",
        f"- Archivos: {len(rows)}",
        f"- Tamaño total aproximado: {round(total_size / (1024 * 1024), 2)} MB",
        "",
        "Por tipo:",
    ]

    for kind, count in by_kind.most_common():
        lines.append(f"- {kind}: {count}")

    lines.append("")
    lines.append("Extensiones principales:")

    for ext, count in by_ext.most_common(20):
        lines.append(f"- {ext}: {count}")

    return "\n".join(lines)[:3900]


def find_file_text(query: str, limit: int = 20) -> str:
    query = query.strip().lower()

    if not query:
        return "Uso: /find_file palabras"

    rows = _read_catalog()

    if not rows:
        return "El catálogo está vacío. Usa /catalog_folder ruta primero."

    terms = [term for term in query.split() if term.strip()]
    matches = []

    for row in rows:
        haystack = " ".join([
            row.get("name", ""),
            row.get("path", ""),
            row.get("extension", ""),
            row.get("kind", ""),
        ]).lower()

        score = sum(1 for term in terms if term in haystack)

        if score:
            matches.append((score, row))

    matches.sort(key=lambda item: (item[0], item[1].get("modified_at", "")), reverse=True)

    if not matches:
        return f"No encontré archivos para: {query}"

    lines = [f"Resultados para: {query}"]

    for index, (_, row) in enumerate(matches[:limit], start=1):
        size_mb = round(int(row.get("size", 0)) / (1024 * 1024), 2)
        lines.append(
            f"{index}. {row.get('name')}\n"
            f"   Tipo: {row.get('kind')} | Tamaño: {size_mb} MB\n"
            f"   Ruta: {row.get('path')}"
        )

    return "\n".join(lines)[:3900]
