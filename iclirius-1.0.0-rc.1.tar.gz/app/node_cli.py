from __future__ import annotations

import argparse
import json

from app.node_snapshot import collect, render


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="iclirius node")
    parser.add_argument("command", nargs="?", choices=("status",), default="status")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv or [])
    snapshot = collect()
    print(json.dumps(snapshot, ensure_ascii=False, indent=2, sort_keys=True)
          if args.json else render(snapshot))
    return 0
