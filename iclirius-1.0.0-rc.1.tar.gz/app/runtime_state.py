"""
What Iclirius looks like right now.

Events answer "what happened". A snapshot answers "how is it now". The future
TUI needs both, and it must not have to replay the event stream from the
beginning to draw a screen: that is why this exists separately.

Same rule as events: identifiers, sizes, statuses, durations. Never a prompt,
a file body, memory contents or a credential. A snapshot is safe to hand to a
UI process.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime

from app.config import settings
from app.logger import logger
from app import runtime_events
from app.runtime_events import NodeStatus, RuntimeStatus, local_node


@dataclass
class ContextMetricsView:
    context_chars: int = 0
    estimated_tokens: int = 0
    history_chars: int = 0
    evidence_chars: int = 0
    task_chars: int = 0
    project_chars: int = 0
    planner_context_chars: int = 0
    included_sections: list[str] = field(default_factory=list)
    truncated_sections: list[str] = field(default_factory=list)
    fingerprint: str = ""


@dataclass
class RuntimeSnapshot:
    generated_at: str
    agent_status: str = "idle"
    interface: str = ""
    node: dict = field(default_factory=dict)
    nodes: list[dict] = field(default_factory=list)
    runtimes: list[dict] = field(default_factory=list)
    project: dict = field(default_factory=dict)
    task: dict = field(default_factory=dict)
    plan: dict = field(default_factory=dict)
    current_step: dict = field(default_factory=dict)
    context_metrics: dict = field(default_factory=dict)
    recent_activity: list[dict] = field(default_factory=list)
    capabilities: dict = field(default_factory=dict)
    # Metadata for a pending write: target, counts, approval state. Never the
    # diff body, so a UI can render it without seeing the change itself.
    pending_patch: dict = field(default_factory=dict)
    pending_execution: dict = field(default_factory=dict)
    last_execution: dict = field(default_factory=dict)
    # Backup metadata only: status, counts, timestamps. Never a path, since a
    # backup directory can sit under a home folder.
    memory_backup: dict = field(default_factory=dict)
    # Reasoning routing: which mode, which providers, what has been spent.
    mode: str = "LOCAL"
    providers: list[dict] = field(default_factory=list)
    provider_usage: dict = field(default_factory=dict)
    provider_accounts: list[dict] = field(default_factory=list)
    cloud_budget: dict = field(default_factory=dict)
    voice: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def _project_view(project: dict) -> dict:
    """Name and id only. A full path is not something a UI needs."""
    if not project:
        return {}

    return {
        "project_id": project.get("project_id", ""),
        "display_name": project.get("display_name", ""),
        "fact_count": len(project.get("facts") or {}),
    }


def _task_view(task: dict) -> dict:
    if not task:
        return {}

    return {
        "task_id": task.get("task_id", ""),
        "goal": str(task.get("goal", ""))[:120],
        "status": task.get("status", ""),
        "verification_state": task.get("verification_state", ""),
        "known_fact_count": len(task.get("known_facts") or []),
        "hypothesis_count": len(task.get("decisions") or []),
        "web_finding_count": len(task.get("web_findings") or []),
        "updated_at": task.get("updated_at", ""),
    }


def _plan_view(plan) -> tuple[dict, dict]:
    """Plan shape and the step in flight, without results."""
    if plan is None:
        return {}, {}

    steps = getattr(plan, "steps", [])

    summary = {
        "plan_id": getattr(plan, "plan_id", ""),
        "status": getattr(plan, "status", ""),
        "verification_state": getattr(plan, "verification_state", ""),
        "goal": str(getattr(plan, "goal", ""))[:120],
        "total_steps": len(steps),
        "completed_steps": sum(1 for s in steps if s.get("status") == "COMPLETED"),
        "failed_steps": sum(1 for s in steps if s.get("status") == "FAILED"),
        "tool_calls": getattr(plan, "tool_calls", 0),
        "iterations": getattr(plan, "iterations", 0),
        "steps": [
            {
                "step_id": step.get("step_id", ""),
                "operation": step.get("operation", ""),
                "status": step.get("status", ""),
                "result_ref": str(step.get("result_ref", ""))[:80],
            }
            for step in steps
        ],
    }

    running = next((s for s in steps if s.get("status") == "RUNNING"), None)
    pending = next((s for s in steps if s.get("status") == "PENDING"), None)
    current = running or pending or {}

    step_view = {
        "step_id": current.get("step_id", ""),
        "operation": current.get("operation", ""),
        "status": current.get("status", ""),
    } if current else {}

    return summary, step_view


def build_snapshot(agent=None, ollama_healthy: bool | None = None,
                   installed_models: list[str] | None = None) -> RuntimeSnapshot:
    """
    Assemble the current picture.

    Cheap by construction: it reads objects the agent already holds and the
    bounded event history. It never walks the filesystem and never decrypts
    more than the active task, so calling it does not slow the chat down.
    """
    snapshot = RuntimeSnapshot(
        generated_at=datetime.now().isoformat(timespec="seconds"),
        interface=getattr(agent, "interface", "") if agent else "",
    )

    try:
        node = local_node(settings, ollama_healthy=ollama_healthy,
                          installed_models=installed_models)
        snapshot.node = node.to_dict()
        snapshot.nodes = [node.to_dict()]
        snapshot.runtimes = list(node.runtimes)
    except Exception:
        logger.warning("Could not describe the local node", exc_info=False)
        snapshot.node = {"status": NodeStatus.UNKNOWN.value}

    snapshot.capabilities = {
        "memory_core": settings.enable_memory_core,
        "task_engine": settings.enable_task_engine,
        "planner": settings.enable_planner,
        "local_read": settings.enable_local_read_tools,
        "web_search": settings.enable_web_search,
        "write": settings.write_enabled,
        "write_confirm_required": settings.write_confirm_required,
        "shell": False,
        "delete": False,
        "execute": settings.execute_enabled,
        "execute_confirm_required": settings.execute_confirm_required,
        "execute_project_local_tools": settings.execute_allow_project_local_tools,
        "network": False,
        "cloud_providers": False,
    }

    if agent is not None:
        try:
            project = agent.current_project() or {}
            snapshot.project = _project_view(project)

            task = agent.core.active_task_for(project.get("project_id")) or {}
            snapshot.task = _task_view(task)
        except Exception:
            logger.warning("Could not read project or task for the snapshot", exc_info=False)

        try:
            plan_view, step_view = _plan_view(getattr(agent, "active_plan", None))
            snapshot.plan = plan_view
            snapshot.current_step = step_view

            if plan_view and plan_view.get("status") == "RUNNING":
                snapshot.agent_status = "working"
        except Exception:
            logger.warning("Could not read the plan for the snapshot", exc_info=False)

        try:
            if hasattr(agent, "pending_patch_summary"):
                snapshot.pending_patch = agent.pending_patch_summary() or {}

                if snapshot.pending_patch:
                    snapshot.agent_status = "waiting_approval"
        except Exception:
            logger.warning("Could not read the pending patch", exc_info=False)

        try:
            if hasattr(agent, "pending_execution_summary"):
                snapshot.pending_execution = agent.pending_execution_summary() or {}

                if snapshot.pending_execution:
                    snapshot.agent_status = "waiting_approval"

            snapshot.last_execution = getattr(agent, "last_execution", {}) or {}
        except Exception:
            logger.warning("Could not read the pending execution", exc_info=False)

        try:
            package = getattr(agent, "last_package", None)
            if package is not None:
                metrics = package.metrics
                snapshot.context_metrics = asdict(ContextMetricsView(
                    context_chars=metrics.total_chars,
                    estimated_tokens=metrics.estimated_tokens,
                    history_chars=metrics.history_chars,
                    evidence_chars=metrics.evidence_chars,
                    task_chars=metrics.task_chars,
                    project_chars=metrics.project_chars,
                    planner_context_chars=min(
                        metrics.total_chars, settings.planner_max_context_chars
                    ),
                    included_sections=list(metrics.included_sections),
                    truncated_sections=list(metrics.truncated_sections),
                    fingerprint=metrics.context_fingerprint,
                ))
        except Exception:
            logger.warning("Could not read context metrics", exc_info=False)

        try:
            # Added after the context metrics are built, not before: that
            # block replaces the dict wholesale. Compaction metrics live
            # alongside them so both /status views read one place.
            snapshot.context_metrics.update({
                "compaction_count": int(getattr(agent, "compaction_count", 0) or 0),
                "last_reduction_ratio": round(
                    float(getattr(agent, "last_reduction_ratio", 0.0) or 0.0), 3),
            })
        except Exception:
            logger.warning("Could not read the compaction metrics", exc_info=False)

    if agent is not None:
        try:
            snapshot.mode = getattr(agent, "mode", "LOCAL")

            gateway = getattr(agent, "gateway", None)

            if gateway is not None:
                snapshot.providers = gateway.registry.describe()
                snapshot.provider_usage = gateway.ledger.summary()
                snapshot.provider_accounts = gateway.accounts.describe()
                snapshot.cloud_budget = gateway.governor.summary()
        except Exception:
            logger.warning("Could not read the reasoning providers", exc_info=False)

    try:
        from app.memory_backup import backup_status

        snapshot.memory_backup = backup_status()
    except Exception:
        logger.warning("Could not read the backup status", exc_info=False)
        snapshot.memory_backup = {}

    try:
        # Through the module, so a replaced bus is honoured.
        snapshot.recent_activity = runtime_events.event_bus.recent(limit=settings.runtime_activity_limit)
    except Exception:
        snapshot.recent_activity = []

    try:
        from app.voice import voice_service
        status = voice_service.status()
        snapshot.voice = {"enabled": status["enabled"], "mode": status["mode"],
                          "tts_provider": status["tts_provider"], "status": status["tts"]}
    except Exception:
        snapshot.voice = {"enabled": False, "mode": "off", "status": "UNAVAILABLE"}

    return snapshot


def mark_runtime(snapshot: RuntimeSnapshot, model: str, status: str) -> RuntimeSnapshot:
    """Set the status of one model runtime, for example ACTIVE while generating."""
    for runtime in snapshot.runtimes:
        if runtime.get("model") == model:
            runtime["status"] = status

    for node in snapshot.nodes:
        for runtime in node.get("runtimes", []):
            if runtime.get("model") == model:
                runtime["status"] = status

    return snapshot


__all__ = [
    "ContextMetricsView",
    "RuntimeSnapshot",
    "RuntimeStatus",
    "build_snapshot",
    "mark_runtime",
]
