"""Small interactive terminal session over the canonical Iclirius Agent."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, TextIO

from app.runtime_events import EventType, Status, emit
from app.version import VERSION
from app.logger import logger
from app.cli_ui import CLIUI, _clean_input


@dataclass
class InteractiveCLISession:
    agent_factory: Callable[[], object]
    input_fn: Callable[[str], str] = input
    output: TextIO | None = None

    def _print(self, text: str = "") -> None:
        print(text, file=self.output)

    def run(self) -> int:
        agent = self.agent_factory()
        ui = CLIUI(self.output)
        unsubscribe = None
        try:
            from app.runtime_events import event_bus
            unsubscribe = event_bus.subscribe(ui.event)
        except Exception:
            pass
        emit(EventType.CLI_SESSION_STARTED.value, status=Status.OK.value,
             interface="cli", metadata={"version": VERSION})
        self._print(ui.header(agent, VERSION))
        self._print()

        try:
            while True:
                try:
                    raw_message = self.input_fn(ui.prompt())
                    logger.debug("CLI input received type=%s chars=%d controls=%d",
                                 type(raw_message).__name__, len(raw_message or ""),
                                 sum(ord(char) < 32 for char in (raw_message or "")))
                    message = _clean_input(raw_message)
                except (KeyboardInterrupt, EOFError):
                    self._print()
                    self._print("Iclirius > Sesión terminada.")
                    return 0

                if not message:
                    continue

                if message.lower() in {"/exit", "/quit", "exit", "quit", ":q"}:
                    emit(EventType.CLI_COMMAND.value, status=Status.OK.value,
                         interface="cli", metadata={"command": "exit"})
                    self._print("Iclirius > Sesión terminada.")
                    return 0

                emit(EventType.CLI_MESSAGE_RECEIVED.value, status=Status.INFO.value,
                     interface="cli", metadata={"chars": len(message)})
                from interfaces.cli_chat import handle_command
                command_output = handle_command(agent, message)
                if command_output is not None:
                    emit(EventType.CLI_COMMAND.value, status=Status.OK.value,
                         interface="cli", metadata={"command": message.split()[0][:40]})
                    self._print(command_output)
                    continue

                try:
                    with ui.working():
                        response = agent.respond(message)
                except Exception:
                    emit(EventType.CLI_RESPONSE_COMPLETED.value,
                         status=Status.FAILED.value, interface="cli",
                         metadata={"chars": 0})
                    self._print("Iclirius > No pude completar esa solicitud.")
                    continue

                emit(EventType.CLI_RESPONSE_COMPLETED.value, status=Status.OK.value,
                     interface="cli", metadata={"chars": len(response or "")})
                recorder = getattr(agent, "record_conversation_turn", None)
                if recorder is not None:
                    try:
                        recorder(message, response, source="cli")
                    except Exception:
                        # Persistence must never turn a completed response
                        # into a terminal traceback. The logger retains the
                        # operational detail; the user already has the reply.
                        logger.exception("CLI conversation persistence failed")
                self._print(f"Iclirius > {response}")
        finally:
            if unsubscribe is not None:
                unsubscribe()
            emit(EventType.CLI_SESSION_ENDED.value, status=Status.OK.value,
                 interface="cli", metadata={"version": VERSION})

    @staticmethod
    def _header(agent) -> str:
        from app.config import settings
        model = getattr(settings, "default_model", "") or "configured-local-model"
        mode = getattr(agent, "mode", "LOCAL")
        return (f"Iclirius v{VERSION}\n"
                f"{mode} · Ollama · {model}\n"
                f"node · {settings.node_id}")
