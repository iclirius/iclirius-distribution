"""Local machine identity. It is deliberately separate from the human user."""

from __future__ import annotations

import json
import os
import platform
import re
import socket
import uuid
from datetime import datetime, timezone
from pathlib import Path


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def default_node_id() -> str:
    raw = platform.node() or socket.gethostname() or "local-node"
    value = re.sub(r"[^a-zA-Z0-9]+", "-", raw).strip("-").lower()
    return value or f"local-{uuid.uuid4().hex[:8]}"


def local_node_path() -> Path:
    return Path(os.environ.get("ICLIRIUS_MACHINE_STATE", "~/.iclirius")) \
        .expanduser() / "node.json"


def ensure_node(node_id: str = "") -> dict:
    path = local_node_path()
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("node_id"):
                return data
        except (OSError, ValueError):
            pass
    data = {
        "node_id": node_id.strip() or default_node_id(),
        "created_at": _now(),
        "hostname": platform.node() or socket.gethostname(),
    }
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, path)
    return data


def read_node() -> dict:
    try:
        data = json.loads(local_node_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}
