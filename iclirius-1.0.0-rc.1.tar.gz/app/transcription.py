from pathlib import Path

from faster_whisper import WhisperModel


_MODEL = None


def get_transcription_model():
    global _MODEL

    if _MODEL is None:
        # Opciones:
        # tiny  = más rápido, menos preciso
        # base  = buen balance inicial
        # small = mejor, más lento
        _MODEL = WhisperModel(
            "base",
            device="cpu",
            compute_type="int8",
            # Telegram handling must never turn a missing model into an
            # implicit network download. The caller reports this as a local
            # STT failure and keeps the bot responsive.
            local_files_only=True,
        )

    return _MODEL


def transcribe_audio(audio_path: str | Path) -> str:
    audio_path = Path(audio_path)

    if not audio_path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    model = get_transcription_model()

    segments, info = model.transcribe(
        str(audio_path),
        language="es",
        beam_size=5,
        vad_filter=True,
    )

    text_parts = []

    for segment in segments:
        if segment.text:
            text_parts.append(segment.text.strip())

    return " ".join(text_parts).strip()
