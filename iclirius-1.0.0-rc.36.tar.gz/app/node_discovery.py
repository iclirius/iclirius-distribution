"""Local Bonjour discovery and explicit trusted-LAN enrollment state.

Discovery is deliberately separate from trust.  TXT data is a small,
allow-listed hint; an Ed25519-signed pairing handshake is still required
before a peer is recorded as trusted.
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SERVICE_TYPE = "_iclirius._tcp.local."
SERVICE_REGTYPE = "_iclirius._tcp"
DEFAULT_PORT = 18890
DISCOVERY_RUNTIME_FILE = "discovery-runtime.json"
MIN_ENROLL_MINUTES = 1
MAX_ENROLL_MINUTES = 30
DEFAULT_ENROLL_MINUTES = 10
MAX_TXT_VALUE = 64
MAX_DISCOVERED = 128
MAX_NODE_ID = 128
MAX_DISPLAY_NAME = 80


def fingerprint_hint_matches(hint: str, authoritative: str) -> bool:
    """Compare an untrusted Bonjour hint with an authoritative fingerprint.

    Secure advertisements carry a bounded hexadecimal prefix to keep TXT data
    small. The full fingerprint from the trust registry remains authoritative;
    this helper only decides whether a discovery candidate is worth probing.
    The authenticated TLS exchange must still verify the pinned key.
    """
    raw_hint = str(hint or "").strip()
    raw_authoritative = str(authoritative or "").strip()
    if not raw_hint:
        return True
    hint_hex = re.sub(r"[^0-9a-f]", "", raw_hint).lower()
    authoritative_hex = re.sub(r"[^0-9a-f]", "", raw_authoritative).lower()
    if not hint_hex or not authoritative_hex:
        return False
    return authoritative_hex == hint_hex or authoritative_hex.startswith(hint_hex)


def _state_root() -> Path:
    return Path(os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def _state_path(name: str) -> Path:
    return _state_root() / name


def _read_json(name: str, default: dict) -> dict:
    try:
        value = json.loads(_state_path(name).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else dict(default)
    except (OSError, ValueError):
        return dict(default)


def _write_json(name: str, value: dict) -> None:
    path = _state_path(name)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def _write_json_at(root: str | Path | None, name: str, value: dict) -> None:
    path = Path(root or _state_root()) / name
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def _now() -> int:
    return int(time.time())


def _iso(timestamp: int) -> str:
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat(timespec="seconds")


def discovery_enabled() -> bool:
    return bool(_read_json("discovery.json", {"enabled": True}).get("enabled", True))


def set_discovery_enabled(enabled: bool) -> dict:
    current = _read_json("discovery.json", {})
    current.update({"schema_version": 1, "enabled": bool(enabled)})
    _write_json("discovery.json", current)
    return {"enabled": bool(enabled)}


def enrollment_status() -> dict:
    data = _read_json("enrollment.json", {})
    expires = int(data.get("expires_at", 0) or 0)
    opened = bool(data.get("opened", False)) and expires > _now()
    if not opened and data.get("opened"):
        data.update({"opened": False})
        _write_json("enrollment.json", data)
    return {
        "state": "OPEN" if opened else "CLOSED",
        "opened": opened,
        "opened_at": _iso(int(data["opened_at"])) if data.get("opened_at") else None,
        "expires_at": _iso(expires) if expires else None,
        "remaining_seconds": max(0, expires - _now()) if opened else 0,
    }


def enrollment_open(minutes: int = DEFAULT_ENROLL_MINUTES) -> dict:
    minutes = int(minutes)
    if not MIN_ENROLL_MINUTES <= minutes <= MAX_ENROLL_MINUTES:
        raise ValueError(f"enrollment duration must be {MIN_ENROLL_MINUTES}-{MAX_ENROLL_MINUTES} minutes")
    now = _now()
    _write_json("enrollment.json", {"schema_version": 1, "opened": True,
                                    "opened_at": now, "expires_at": now + minutes * 60})
    return enrollment_status()


def enrollment_close() -> dict:
    _write_json("enrollment.json", {"schema_version": 1, "opened": False,
                                    "closed_at": _now()})
    return enrollment_status()


def enrollment_is_open() -> bool:
    return enrollment_status()["opened"]


def _bounded(value: Any, limit: int = MAX_TXT_VALUE) -> str:
    return str(value or "")[:limit]


def advertisement(*, node_id: str, fingerprint: str, version: str,
                  port: int = DEFAULT_PORT, enrollment: bool | None = None) -> dict:
    """Return the only fields permitted in a LAN discovery record."""
    opened = enrollment_is_open() if enrollment is None else bool(enrollment)
    return {
        "service": SERVICE_TYPE,
        "protocol": "1",
        "iclirius_version": _bounded(version),
        "port": int(port),
        "node_hint": _bounded(fingerprint or node_id, 32),
        "enrollment": "OPEN" if opened else "CLOSED",
    }


def secure_advertisement(*, node_id: str, display_name: str, fingerprint: str,
                         version: str, port: int = DEFAULT_PORT,
                         enrollment: bool | None = None) -> dict:
    """Build the CLUSTER-2 allow-listed public Bonjour metadata.

    This is intentionally separate from the legacy compact ``advertisement``
    shape so older peers and their tests remain compatible.  No address,
    credential, filesystem, or user data is included beyond the endpoint port.
    """
    opened = enrollment_is_open() if enrollment is None else bool(enrollment)
    return {
        "service": SERVICE_TYPE, "protocol": "1",
        "node_id": _bounded(node_id, MAX_NODE_ID),
        "display_name": _bounded(display_name, MAX_DISPLAY_NAME),
        "iclirius_version": _bounded(version), "port": int(port),
        "identity_fingerprint": _bounded(fingerprint, MAX_TXT_VALUE),
        "enrollment": "OPEN" if opened else "CLOSED",
    }


def validate_advertisement(record: dict) -> dict:
    if not isinstance(record, dict) or record.get("service") != SERVICE_TYPE:
        raise ValueError("invalid discovery service")
    allowed = {"service", "protocol", "iclirius_version", "port", "node_hint", "enrollment",
               "node_id", "display_name", "identity_fingerprint"}
    if set(record) - allowed:
        raise ValueError("discovery record contains unsupported fields")
    if str(record.get("protocol")) != "1":
        raise ValueError("unsupported discovery protocol")
    port = int(record.get("port", 0))
    if not 1 <= port <= 65535:
        raise ValueError("invalid discovery port")
    if record.get("enrollment") not in {"OPEN", "CLOSED"}:
        raise ValueError("invalid enrollment state")
    for key in ("iclirius_version", "node_hint", "node_id", "display_name", "identity_fingerprint"):
        if len(str(record.get(key, ""))) > MAX_TXT_VALUE:
            raise ValueError("discovery value too long")
    identity_fingerprint = str(record.get("identity_fingerprint", ""))
    if identity_fingerprint and not re.fullmatch(r"[0-9a-fA-F:]{16,128}", identity_fingerprint):
        raise ValueError("invalid identity fingerprint")
    return {**record, "port": port}


@dataclass(frozen=True)
class DiscoveredNode:
    name: str
    address: str
    port: int
    record: dict
    trusted: bool = False


def deduplicate(nodes: list[DiscoveredNode]) -> list[DiscoveredNode]:
    result: dict[str, DiscoveredNode] = {}
    for node in nodes[:MAX_DISCOVERED]:
        try:
            item = validate_advertisement(node.record)
        except (TypeError, ValueError):
            continue
        key = item.get("node_id") or item.get("identity_fingerprint") or item.get("node_hint") or f"{node.name}:{node.port}"
        # Never let a hostname collision replace a previously observed hint.
        result.setdefault(str(key), DiscoveredNode(node.name[:80], node.address, item["port"], item, node.trusted))
    return list(result.values())


def backend_available() -> bool:
    return platform.system() == "Darwin" and _dns_sd_path() is not None


def _dns_sd_path() -> str | None:
    """Resolve dns-sd for both shells and launchd's minimal environment."""
    if platform.system() != "Darwin":
        return None
    found = shutil.which("dns-sd")
    if found:
        return found
    for candidate in ("/usr/bin/dns-sd", "/usr/sbin/dns-sd"):
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


class BonjourDiscovery:
    """Small lifecycle wrapper around Apple's user-space ``dns-sd`` tool.

    The process is optional.  Failure to start it is reported as unavailable;
    no firewall, root privilege, or subnet scan is attempted.
    """
    def __init__(self, *, name: str, port: int = DEFAULT_PORT, txt: dict | None = None,
                 runtime_file: str = DISCOVERY_RUNTIME_FILE, state_root: str | Path | None = None):
        self.name, self.port, self.txt = name[:63], int(port), txt or {}
        self.runtime_file = runtime_file
        self.state_root = state_root
        self._process: subprocess.Popen | None = None
        self.failure_reason = ""
        self.failure_details: dict = {}
        self._stdout_tail = deque(maxlen=32)
        self._stderr_tail = deque(maxlen=32)

    def _drain(self, stream, target) -> None:
        try:
            for line in stream:
                target.append(str(line).strip()[-512:])
        except (OSError, TypeError, ValueError):
            pass

    def _details(self, *, exit_code=None) -> dict:
        return {
            "exit_code": exit_code,
            "stdout_summary": "\\n".join(self._stdout_tail)[-2048:],
            "stderr_summary": "\\n".join(self._stderr_tail)[-2048:],
            "argv_shape": {"executable": "dns-sd", "mode": "-R",
                           "service_type": SERVICE_REGTYPE,
                           "domain": "local.", "port": self.port},
        }

    def start(self) -> bool:
        executable = _dns_sd_path()
        if not discovery_enabled():
            self.failure_reason = "DISCOVERY_DISABLED"
            return False
        if not executable:
            self.failure_reason = "DNS_SD_UNAVAILABLE"
            return False
        args = [executable, "-R", self.name, SERVICE_REGTYPE, "local.", str(self.port)]
        for key, value in self.txt.items():
            args.append(f"{key}={_bounded(value)}")
        try:
            self._process = subprocess.Popen(args, stdout=subprocess.PIPE,
                                              stderr=subprocess.PIPE, text=True)
            # dns-sd is a long-lived publisher.  A process which exits
            # immediately must not be reported as an active advertisement.
            time.sleep(0.05)
            if self._process.poll() is not None:
                self.failure_reason = "DNS_SD_EXITED"
                try:
                    stdout, stderr = self._process.communicate(timeout=1)
                    if stdout:
                        self._stdout_tail.extend(stdout.splitlines()[-32:])
                    if stderr:
                        self._stderr_tail.extend(stderr.splitlines()[-32:])
                except (AttributeError, OSError, subprocess.SubprocessError):
                    pass
                self.failure_details = self._details(exit_code=getattr(self._process, "returncode", None))
                self._process = None
                (Path(self.state_root or _state_root()) / self.runtime_file).unlink(missing_ok=True)
                return False
            for stream, target in ((getattr(self._process, "stdout", None), self._stdout_tail),
                                   (getattr(self._process, "stderr", None), self._stderr_tail)):
                if stream is not None:
                    threading.Thread(target=self._drain, args=(stream, target), daemon=True).start()
            _write_json_at(self.state_root, self.runtime_file,
                           {"state": "RUNNING", "pid": self._process.pid,
                            "service": SERVICE_TYPE, "name": self.name,
                            "port": self.port, "regtype": SERVICE_REGTYPE,
                            "domain": "local."})
            return True
        except OSError:
            self.failure_reason = "DNS_SD_START_FAILED"
            self.failure_details = self._details()
            self._process = None
            return False

    def stop(self) -> None:
        if self._process and self._process.poll() is None:
            self._process.terminate()
        marker = Path(self.state_root or _state_root()) / self.runtime_file
        try:
            data = json.loads(marker.read_text(encoding="utf-8"))
            if not self._process or data.get("pid") == self._process.pid:
                marker.unlink(missing_ok=True)
        except (OSError, ValueError, TypeError):
            marker.unlink(missing_ok=True)
        self._process = None


def record_advertisement_failure(runtime_file: str, state_root: str | Path | None,
                                 reason: str) -> None:
    details = reason if isinstance(reason, dict) else {"reason": str(reason)[:80]}
    _write_json_at(state_root, runtime_file, {
        "state": "FAILED", "live": False, "service": SERVICE_TYPE,
        **details,
    })


def status() -> dict:
    return {"enabled": discovery_enabled(), "service": SERVICE_TYPE,
            "available": backend_available(), "enrollment": enrollment_status(),
            "secure_advertisement": advertisement_runtime("secure-discovery-runtime.json"),
            "enrollment_advertisement": advertisement_runtime("enrollment-discovery-runtime.json")}


def advertisement_runtime(runtime_file: str = DISCOVERY_RUNTIME_FILE,
                          state_root: str | Path | None = None) -> dict:
    """Return local publisher liveness without contacting the LAN."""
    root = Path(state_root or _state_root())
    try:
        data = json.loads((root / runtime_file).read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    if data.get("state") != "RUNNING":
        return {**data, "state": data.get("state", "NOT_RUNNING"), "live": False}
    try:
        os.kill(int(data["pid"]), 0)
    except (OSError, TypeError, ValueError, KeyError):
        return {**data, "state": "NOT_RUNNING", "live": False}
    return {**data, "live": True}


def discover(timeout: float = 2.0) -> list[DiscoveredNode]:
    """Browse Bonjour services without treating discovery as trust.

    ``dns-sd`` output differs slightly across macOS releases, so this parser
    intentionally returns conservative candidates.  A candidate is useful
    for display or a later authenticated enrollment, never as a trust record.
    """
    if not discovery_enabled() or not backend_available():
        return []
    try:
        executable = _dns_sd_path()
        if not executable:
            return []
        process = subprocess.Popen([executable, "-B", SERVICE_REGTYPE, "local."],
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   text=True)
        try:
            output, _ = process.communicate(timeout=max(0.2, float(timeout)))
        except subprocess.TimeoutExpired:
            process.terminate()
            output, _ = process.communicate(timeout=1)
    except (OSError, subprocess.SubprocessError):
        return []
    found: list[DiscoveredNode] = []
    for line in (output or "").splitlines():
        # ``dns-sd -B`` emits the registration type (``_iclirius._tcp.``),
        # while resolved TXT data carries the fully-qualified service name
        # (``_iclirius._tcp.local.``). Matching SERVICE_TYPE here silently
        # discarded every valid browse candidate.
        if "Add" not in line or not re.search(
                rf"(?:^|\s){re.escape(SERVICE_REGTYPE)}\.(?:\s|$)", line):
            continue
        # dns-sd columns end with the instance name; keep it bounded and
        # leave address resolution to the authenticated connection layer.
        parts = line.split()
        if len(parts) < 2:
            continue
        name = parts[-1][:63]
        address, port, record = _resolve(name, timeout=min(2.0, max(0.2, float(timeout))))
        found.append(DiscoveredNode(name, address or name, port, record, False))
    return deduplicate(found)


def _resolve(name: str, timeout: float = 2.0) -> tuple[str, int, dict]:
    """Resolve an instance and its bounded TXT fields with dns-sd."""
    record = {"service": SERVICE_TYPE, "protocol": "1", "iclirius_version": "unknown",
              "port": DEFAULT_PORT, "node_hint": name[:32], "node_id": name[:MAX_NODE_ID],
              "display_name": name[:MAX_DISPLAY_NAME], "enrollment": "CLOSED"}
    executable = _dns_sd_path()
    if not executable:
        return "", DEFAULT_PORT, record
    try:
        result = subprocess.run([executable, "-L", name, SERVICE_REGTYPE, "local."],
                                capture_output=True, text=True, timeout=timeout, check=False)
        output = result.stdout or ""
    except subprocess.TimeoutExpired as exc:
        # ``dns-sd -L`` prints the resolved endpoint and then remains alive
        # until interrupted. ``run(timeout=...)`` therefore raises after the
        # useful output has arrived. Preserve that bounded partial output
        # instead of falling back to the browse instance name.
        output = exc.stdout or ""
        if isinstance(output, bytes):
            output = output.decode("utf-8", errors="replace")
    except (OSError, subprocess.SubprocessError):
        return "", DEFAULT_PORT, record
    match = re.search(r"can be reached at ([^\s:]+):([0-9]+)", output)
    address = match.group(1).rstrip(".") if match else ""
    port = int(match.group(2)) if match else DEFAULT_PORT
    for key in ("protocol", "iclirius_version", "node_hint", "node_id",
                "display_name", "identity_fingerprint", "enrollment"):
        match = re.search(rf"\b{re.escape(key)}=([^\s]+)", output)
        if match:
            record[key] = match.group(1)[:MAX_TXT_VALUE]
    record["port"] = port
    try:
        validate_advertisement(record)
    except ValueError:
        record["enrollment"] = "CLOSED"
    return address, port, record


def enrollment_candidates(nodes: list[DiscoveredNode]) -> list[DiscoveredNode]:
    """Return only advertised candidates; this does not establish trust."""
    return [node for node in deduplicate(nodes)
            if node.record.get("enrollment") == "OPEN"]


def enroll_discovered(nodes: list[DiscoveredNode]) -> dict:
    """Enroll one unambiguous candidate using the existing signed handshake.

    Multiple eligible discovery domains are deliberately refused instead of
    silently selecting one.  The peer's advertisement is never proof of
    trust; :func:`app.node_pairing.pair` verifies the pinned signature.
    """
    candidates = enrollment_candidates(nodes)
    if not candidates:
        raise ValueError("no enrollment candidate available")
    if len(candidates) > 1:
        raise ValueError("multiple enrollment candidates require selection")
    from app.node_pairing import pair
    node = candidates[0]
    return pair(node.address, node.port, enrollment=True)


def refresh_trusted_endpoint(node_id: str, node: DiscoveredNode) -> dict:
    """Refresh a trusted peer endpoint after an authenticated TLS proof.

    Bonjour is only a location hint.  The pinned public key in the
    authoritative CLUSTER-2 registry is checked by ``SecureNodeClient``
    before the endpoint is persisted.
    """
    from app.secure_channel import SecureNodeClient
    from app.cluster_security import read_registry, update_trusted_endpoint
    registry = read_registry()
    peer = registry.get("peers", {}).get(node_id, {})
    if peer.get("trust_state") != "TRUSTED":
        raise ValueError("peer is not trusted")
    advertised_id = str(node.record.get("node_id", ""))
    if advertised_id and advertised_id != node_id:
        raise ValueError("discovery node identity mismatch")
    advertised_fp = str(node.record.get("identity_fingerprint", "") or node.record.get("node_hint", ""))
    if advertised_fp and not fingerprint_hint_matches(advertised_fp, peer.get("fingerprint", "")):
        raise ValueError("discovery fingerprint mismatch")
    port = int(node.port or 18891)
    result = SecureNodeClient(timeout=5.0).ping(node.address, port, node_id)
    if result.get("fingerprint") != peer.get("fingerprint"):
        raise ValueError("endpoint identity verification failed")
    update_trusted_endpoint(node_id, node.address)
    return {**result, "endpoint": node.address, "port": port, "endpoint_refreshed": True}
