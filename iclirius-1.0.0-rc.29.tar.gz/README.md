# OpenClaw / iclirius

Agente personal **local-first** de Luis.

`OpenClaw` es el framework. `iclirius` es el agente que corre sobre él.

Filosofía: **LOCAL COMPUTE > CLOUD TOKENS**. Se prefiere gastar CPU, GPU, RAM
y tiempo local antes que consumir tokens de APIs en la nube.

> Estado: **Fases 1 a 3.5 completadas** (estabilización, portabilidad,
> privacidad, motor local, supervisión, búsqueda web, lectura local, memoria
> canónica, motor de tareas/contexto, planner, bucle de agente y escritura segura). Este
> README describe lo que
> el sistema hace **hoy**. Lo que todavía no existe está listado explícitamente
> en la sección [No implementado](#no-implementado). Nada de esa sección está
> escrito, ni siquiera parcialmente.

### Checkpoint actual de nodos

La confianza CLUSTER-2.3 fue aceptada físicamente en dos Macs usando RC23:
ambas verificaron identidad Ed25519, confirmaron fingerprints y conservaron
confianza recíproca después de reiniciar. RC29 añade recuperación autenticada
de endpoints cuando cambia una IP, pero el transporte seguro CLUSTER-3 todavía
requiere aceptación física del ping en ambas direcciones.
CLUSTER-4 no ha comenzado. Consulta [la arquitectura de cluster](docs/CLUSTER_ARCHITECTURE.md)
y [el estado actual](docs/CLUSTER_PROJECT_STATUS.md) para no confundir pruebas
automatizadas con evidencia física.

---

## Qué hace hoy

- Conversación en español vía **Telegram** (interfaz principal) y **CLI**.
- Razonamiento **100% local** con **Ollama** (`qwen2.5:14b` por defecto).
- Transcripción de notas de voz **100% local** con faster-whisper.
- Memoria conversacional **cifrada** (Fernet, clave en el Keychain de macOS).
- Catálogo de archivos e ingesta de libros (PDF/EPUB/TXT/MD) en background.
- Delegación opcional a una Mac *worker* en la LAN, **con fallback local**.
- Análisis de código en modo **solo lectura**.
- **Búsqueda web de solo lectura** con síntesis local y fuentes citadas.
- **Inspección local de solo lectura**: archivos, carpetas y repos Git.
- **Escritura segura de archivos**, apagada por defecto y con confirmación.

## Qué NO hace

- **Ningún modelo ejecuta comandos.** No existe ninguna ruta
  `modelo → shell`, `modelo → escritura de archivos` ni `modelo → subprocess`.
  La ejecución la disparan siempre comandos deterministas del usuario.
- No hay proveedores cloud. No hay embeddings. No hay planner.

---

## Arquitectura real

```
Telegram (interfaces/telegram_bot.py)   CLI (interfaces/cli.py)
                    │                          │
                    └───────────┬──────────────┘
                                ▼
                     app/agent.py  OpenClawAgent
                                │
                     app/context_builder.py
                                │
                     app/auto_router.py
                                │
                     app/delegation.py   ¿delegar?
                                │
                ┌───────────────┴───────────────┐
                ▼                               ▼
        worker (LAN, opcional)            Ollama local
                │                               ▲
                └── falla ──────────────────────┘
                     fallback local
```

### Fallback worker → Ollama

Desde la Fase 1, el worker **nunca** puede impedir que iclirius responda.
Si el worker está caído, da timeout, devuelve `ok=false`, lanza una excepción
o responde vacío:

1. el intento se registra en la cola de tareas con estado `failed`;
2. `auto_route_message` devuelve `handled=False`;
3. `OpenClawAgent.respond()` continúa y **Ollama responde localmente**.

El usuario recibe una respuesta útil, no un error de conexión. El intento
fallido queda auditable con `/task_result <id>`.

---

## Requisitos

- macOS (la memoria cifrada usa el Keychain del sistema)
- Python 3.11+
- [Ollama](https://ollama.com) corriendo en local
- Un bot de Telegram creado con [@BotFather](https://t.me/BotFather)

## Instalación

```bash
git clone <repo> ~/OpenClaw/openclaw
cd ~/OpenClaw/openclaw
./scripts/install_node.sh

cp .env.example .env   # si install_node.sh no lo hizo
nano .env              # rellena TELEGRAM_BOT_TOKEN y ALLOWED_USER_IDS

ollama pull qwen2.5:14b
```

Rutas propias de tu máquina. Las tres están vacías por defecto y **no tienen
fallback**: la operación que las necesite avisa de que faltan en vez de adivinar
una carpeta.

| Variable | Para qué |
|---|---|
| `LIBRARY_ROOT` | carpeta de tu biblioteca de libros/documentos |
| `CATALOG_ROOT` | carpeta que recorre el catálogo de archivos |
| `BACKUP_ROOT` | destino de los snapshots de datos |
| `FILE_MANAGER_ALLOWED_ROOTS` | allowlist de rutas legibles |

Las frases de temas personales que usa el clasificador de peticiones viven en
`data/learning/known_phrases.json`, fuera del repositorio. Sin ese archivo se
usa un vocabulario genérico del proyecto.

La clave de cifrado de memoria debe existir en el Keychain:

```bash
security add-generic-password -a iclirius -s iclirius_memory_key -w "<clave-fernet>"
```

## Uso

### Arranque canónico

Un solo punto de entrada, `scripts/run_node.sh`, en dos modos.

**Uso diario — supervisado, sobrevive a caídas:**

```bash
cd ~/OpenClaw/openclaw
./scripts/daemon_start.sh    # instala y carga el agente launchd
./scripts/daemon_stop.sh     # descarga el agente y para el nodo
```

`daemon_start.sh` instala `com.iclirius.openclaw.node` en
`~/Library/LaunchAgents` con `KeepAlive` y `RunAtLoad`, y ese agente ejecuta
`run_node.sh`. Así el nodo **revive solo** tras un fallo de red o un crash, y
arranca al iniciar sesión. `ThrottleInterval=30` evita bucles de reinicio.

Esto existe por una razón concreta: el 2026-07-11 el nodo murió con 346
`NetworkError` seguidos mientras el DNS no resolvía, nada lo reinició, y estuvo
caído tres meses sin que se notara.

**Depuración — primer plano, para ver los logs en vivo:**

```bash
cd ~/OpenClaw/openclaw
./scripts/run_node.sh
```

`run_node.sh` es el wrapper correcto porque, antes de arrancar, hace lo que
`python run.py` por sí solo no hace:

1. toma un lock en `data/state/iclirius.lock`, evitando dos instancias en
   polling (la causa del error `Conflict: terminated by other getUpdates`);
2. activa `.venv`;
3. verifica que Ollama responda;
4. verifica que `DEFAULT_MODEL` esté instalado;
5. ejecuta `python run.py`.

Comprobar que Ollama está arriba, antes o por separado:

```bash
curl -s http://127.0.0.1:11434/api/tags   # debe devolver JSON
ollama list                                # modelos instalados
./scripts/health_check.sh                  # diagnóstico completo
```

Otros comandos:

```bash
iclirius                     # sesión interactiva canónica CLI v1.0
python -m app.cli            # equivalente portable
iclirius chat                # chat interactivo en terminal
iclirius chat "hola"         # un solo mensaje
iclirius health
iclirius code --context      # contexto del proyecto, sin llamar al modelo
iclirius code --plan "..."   # plan de cambios, NO edita nada
```

### Instalación de usuario

La ruta soportada para una Mac nueva no necesita clonar el repositorio privado:

```bash
brew tap iclirius/tap
brew install iclirius/tap/iclirius
iclirius doctor
iclirius setup
```

El paquete Homebrew, `~/.iclirius`, el Memory Home, el Keychain y los modelos
Ollama son capas separadas. El código instalado es de sólo lectura y el runtime
normal no depende de Git, del cwd del repositorio ni de su `.venv`.

### Instalación reproducible de desarrollo

En una Mac nueva, ejecuta `./install.sh --check` para auditar sin modificar
nada y después `./install.sh` para crear `.venv`, instalar las dependencias y
registrar el wrapper `~/.local/bin/iclirius`. `iclirius doctor` ofrece el mismo
diagnóstico en cualquier momento y `iclirius doctor --json` produce una salida
para automatización. Consulta [INSTALL.md](INSTALL.md) para el inicio rápido y
[docs/INSTALLATION.md](docs/INSTALLATION.md) para el detalle completo.

La distribución standalone se prepara como paquete Python y fórmula Homebrew;
el flujo de release está documentado en
[docs/HOMEBREW_DISTRIBUTION.md](docs/HOMEBREW_DISTRIBUTION.md). Hasta que
la instalación Homebrew anterior es la ruta de usuario y `./install.sh` queda
como flujo reproducible de desarrollo.

La sesión `iclirius` es una interfaz de chat ligera basada en Textual: muestra sólo conversación
y hitos útiles, mantiene los logs operativos en archivo y admite
`iclirius --debug` para ver diagnósticos por `stderr`. Respeta `NO_COLOR` y
salidas redirigidas. `/help` lista los comandos administrativos disponibles;
`iclirius code` permanece fuera de esta interfaz visual y conserva su flujo
separado.

Cuando se ejecuta dentro de una terminal interactiva compatible, `iclirius`
abre su Chat TUI en alternate screen y restaura la terminal al salir. Para
pipes, automatización o terminales incompatibles usa automáticamente la sesión
plain; también puede forzarse con `iclirius --plain`. La TUI no es una app
gráfica, no usa Electron/WebView y no implementa todavía `iclirius code`.

### Identidad y Memory Home

En una instalación nueva completa el bootstrap personal una sola vez:

```bash
iclirius setup
iclirius doctor
iclirius
```

`setup` configura la identidad humana, crea o selecciona un `Memory Home`
versionado y prepara el material local del Keychain. Los secretos permanecen
en la máquina; el Memory Home sólo contiene estado cifrado y metadata segura.
Para auditar sin cambios usa `iclirius setup --status`. El flujo completo y
las limitaciones para una segunda Mac están en
[`docs/SETUP_AND_IDENTITY.md`](docs/SETUP_AND_IDENTITY.md).

Durante `iclirius setup`, Ollama se detecta mediante su ejecutable y API local.
Una instalación saludable y sus modelos existentes se reutilizan. Si falta o
está detenida, setup ofrece iniciar, instalar explícitamente, descargar el
modelo predeterminado con confirmación, seleccionar una alternativa instalada,
continuar sin IA local o salir. `brew install` nunca realiza estas acciones.

### Motor local: tiers

Tres tiers, todos Ollama. Los nombres de modelo solo viven en configuración.

| Tier | Variable | Cuándo se usa |
|---|---|---|
| FAST | `FAST_MODEL` | mensaje corto de una línea, sin señales de trabajo |
| DEFAULT | `DEFAULT_MODEL` | todo lo demás |
| HEAVY | `HEAVY_MODEL` | la heurística `looks_heavy` se dispara (código, errores, análisis, textos largos) |

La selección es local y determinista, en `app/delegation.select_model_tier()`.
No hay evaluación de confianza ni escalado a la nube.

### Qué ocurre cuando algo falla

| Fallo | Comportamiento |
|---|---|
| El proceso muere o pierde la red | launchd lo reinicia solo (~5 s) |
| Un tier no está instalado o falla | degradación **local**: tier pedido → DEFAULT → FAST. Nunca sale a la nube. |
| El worker está caído | se registra la tarea como `failed` y responde Ollama en local |
| Ollama entero está caído | mensaje limpio: *"El motor local no está disponible ahora mismo…"*. Nunca deja al usuario esperando. |
| Todos los modelos fallan | mensaje indicando revisar `/health` y `ollama list` |

Si varios tiers apuntan al mismo modelo (el caso actual), la cadena se colapsa
a un solo intento y todo sigue funcionando.

---

## Planner

> **MODEL SUGGESTS INTENT. ICLIRIUS VALIDATES OPERATIONS.**
> **EXECUTORS PERFORM ONLY TYPED ALLOWED OPERATIONS.**

Convierte una petición en un **plan tipado** de operaciones de solo lectura.

```
Task Engine → Context Engine → Planner → Typed Plan
                                            ↓
                                   validación (allowlist + rutas)
                                            ↓
                                   READ executors únicamente
```

### Determinista primero

`"muestra git status"` no necesita modelo: se resuelve en **0,4 ms y 0 tokens**
reutilizando `app/local_planner.py`, que ya mapeaba español a una operación
tipada. No se creó un planner paralelo; el antiguo pasó a ser el **adaptador
determinista** del nuevo.

### Planes pequeños que crecen con la evidencia

Un plan de tres pasos que reacciona a lo que encontró es mejor que uno de diez
escrito a ciegas: menos errores, menos contexto, menos llamadas.

```
SEARCH_TEXT "AuthRepository"  ✔ 171 chars
    ↓ encontró app/Auth.kt
READ_TEXT_FILE app/Auth.kt    ✔   ← añadido por la evidencia
```

### El modelo propone, Iclirius decide

Una propuesta del modelo se parsea como JSON y pasa por allowlist cerrada,
validación de ruta y presupuesto **antes** de que exista un ejecutor. Probado
en real:

| Propuesta | Resultado |
|---|---|
| `{"operation":"DELETE_FILE",…}` | **RECHAZADA** |
| `{"operation":"SHELL","command":"rm -rf /"}` | **RECHAZADA** |
| `{"operation":"READ_TEXT_FILE","target":"/etc/passwd"}` | **RECHAZADA** |
| texto no parseable | **RECHAZADA** |

Sin `eval`, sin `exec`, sin `shell=True`. Un test recorre el AST del módulo y
falla si aparece `subprocess`, `os`, `eval`, `exec` o `Popen`.

### Presupuestos

`PLANNER_MAX_STEPS=6` · `MAX_ITERATIONS=3` · `MAX_TOOL_CALLS=5` ·
`MAX_RESULT_CHARS=1200`. Fail closed.

### Estado de verificación

`NOT_STARTED → EVIDENCE_GATHERING → READY_FOR_ACTION / BLOCKED / VERIFIED_READ_ONLY`

**No existe `VERIFIED` ni `FIXED`**: leer código que parece mal no es saber que
está mal, y menos aún haberlo arreglado.

### Continuidad de plan

El plan compacto se guarda en la tarea, así que la otra interfaz ve qué pasos
se completaron y cuál sigue. Se guardan **operación, referencia y estado**,
nunca el contenido de los archivos.

---

## Escritura segura

La primera capacidad que puede **cambiar un archivo**.

> **MODEL PROPOSES CHANGE. ICLIRIUS VALIDATES CHANGE.**
> **LOCAL EXECUTOR APPLIES CHANGE.**

```
READ → ANALYZE → PROPOSE PATCH → VALIDATE → PREVIEW
     → PERMISSION → APPLY ATOMICALLY → VERIFY DIFF → Memory
```

**Apagada por defecto.** Una instalación nueva lee, tiene la capacidad
presente, y **no escribe sin preguntar**. `WRITE_ENABLED=false`.

### Cambios anclados, no diffs

Un patch lleva el **texto original exacto** y cuántas veces debe aparecer. Un
diff se aplica por posición de línea y se desvía en silencio cuando el archivo
cambió; un anclaje falla ruidosamente en vez de corromper.

### Protección contra escritura obsoleta

El archivo se firma al proponer y **otra vez justo antes de aplicar**. Si
cambió en medio, se aborta. Verificado en real:

```
propuesta       → fingerprint 71dd426911ef3749
alguien edita   → el archivo cambia
"sí"            → No apliqué nada: TokenStore.kt cambió desde que se propuso
                  edición humana preservada ✓
```

### Escribir es más estricto que leer

| | READ | WRITE |
|---|---|---|
| roots permitidos | ✓ | ✓ |
| symlink / `../` | ✓ | ✓ |
| `.env`, claves, `.enc` | bloqueado | bloqueado |
| `.git/`, `data/`, `logs/` | parcial | **bloqueado** |
| extensión | cualquiera legible | **solo texto en allowlist** |
| binarios, PDF, DB | — | **bloqueado** |

**No existen** `DELETE`, `MOVE`, `RENAME`, `CHMOD`, `RUN_COMMAND`,
`GIT_COMMIT` ni `GIT_PUSH`.

### Permisos

Un "sí" **nombra un patch**. Se consume al usarse, expira a los 600 s, y está
acotado a la interfaz que lo pidió. Con dos cambios pendientes **pregunta, no
adivina** — aplicar el cambio equivocado al código de alguien no se deshace.

| Mensaje | Intención |
|---|---|
| `revisa auth` | solo lectura |
| `cómo lo arreglarías` | propuesta, **sin escribir** |
| `arréglalo` | propuesta + aprobación requerida |
| `sí` / `aplica ese cambio` | aplica el patch pendiente |
| `no, cancela` | descarta |

Denegar gana sobre aprobar: `"no, aplica"` es un **no**.

### Nada a medias

Se valida **todo** antes del primer byte. Si un archivo está obsoleto o
bloqueado, cero archivos se escriben. Si algo falla a mitad, los ya escritos se
restauran desde el contenido original en memoria; un archivo recién creado se
elimina.

La escritura es atómica: temporal en el mismo directorio, `fsync`, `os.replace`,
permisos preservados. **Sin `.bak` regados por el repo** — la protección es git
+ fingerprint + atomicidad.

### Diff verificado ≠ código correcto

Tras aplicar se relee, se recalcula el fingerprint y se lee un `git diff`
**de solo lectura**. La tarea queda como `MODIFIED_UNVERIFIED`:

> *"Ojo: esto no significa que el código funcione. Ejecutar build o tests
> todavía no está habilitado."*

---

## Agent Loop

El bucle real: planifica, lee, observa, decide, para.

```
plan  →  READ executor  →  reducción  →  evidencia  →  Memory
  ↑                                                      ↓
  └────────  ¿otra operación?  ←  ANALYZE_EVIDENCE  ←────┘
```

**Determinista primero.** `"muestra git status"` se resuelve en **0,47 ms con
0 tokens**. El modelo solo interviene cuando las reglas no alcanzan.

**El modelo propone, nunca ejecuta.** Su respuesta pasa por
`schema → allowlist → ruta → presupuesto` antes de que exista un ejecutor.
Verificado contra el código real:

| Propuesta | Resultado |
|---|---|
| `DELETE_FILE` | RECHAZADA |
| `SHELL rm -rf /` | RECHAZADA |
| `READ_TEXT_FILE /etc/passwd` | RECHAZADA |
| texto no parseable | RECHAZADA |

**Condiciones de parada:** objetivo satisfecho · `READY_FOR_ACTION` · evidencia
insuficiente · presupuesto de pasos/iteraciones/herramientas · paso fallido ·
operación rechazada · plan bloqueado. Siempre explica dónde paró.

### ANALYZE_EVIDENCE y confianza

Ya no es un no-op. Produce observaciones, hipótesis, confianza
(`LOW`/`MEDIUM`/`HIGH`) y siguiente paso recomendado.

Lo que se leyó es una **observación**. Lo que el modelo sugiere es una
**hipótesis** — se marca *no verificada* y va a `decisions`, nunca a
`known_facts`. La confianza del modelo no es verdad: solo decide si buscamos
una evidencia más.

### READY_FOR_ACTION

Cuando la evidencia alcanza para proponer un cambio:

> *"Tengo suficiente evidencia para proponer un cambio, pero la escritura
> todavía no está habilitada."*

Un test comprueba que el árbol de archivos es idéntico antes y después.

### Su propio código

`INCLUDE_PROJECT_ROOT=true` añade **el directorio del repositorio** a la
allowlist, derivado de la instalación — sin ruta personal en el código. HOME
nunca se añade, y `.env`, claves y memoria cifrada siguen bloqueados.

---

## Runtime Bridge

Una ventana local y de **solo lectura** al agente en marcha, para que una TUI
en otro proceso no tenga que leer logs ni tocar la memoria.

**Unix domain socket, nunca TCP.** No hay puerto que exponer por accidente; el
control de acceso lo hace el filesystem con permisos **0600**. Cuatro comandos
en un conjunto cerrado:

```
$ status   → snapshot completo   (36 ms, 6.7 KB)
$ nodes    → nodos
$ models   → runtimes
$ events   → actividad reciente
```

Ninguno ejecuta una herramienta, cambia de modelo, muta una tarea ni lee un
archivo. `destroy`, `shell`, `{"command":"shell"}`, JSON roto y peticiones
sobredimensionadas se rechazan. Si el bridge no arranca o muere, **al agente le
da igual**: la observabilidad nunca tumba lo observado.

### Snapshot vs eventos

| | Responde |
|---|---|
| `RuntimeEvent` | qué ocurrió |
| `RuntimeSnapshot` | cómo está ahora |

La TUI necesita ambos y **no debe reconstruir el estado reproduciendo eventos
desde el principio**. El snapshot incluye nodo, nodos, runtimes, proyecto,
tarea, plan, paso actual, métricas de contexto, actividad reciente y
capacidades — con `write=false`, `shell=false`, `cloud_providers=false`
explícitos.

Cuesta **menos de 50 ms** y no recorre el filesystem.

---

## Observabilidad y futura TUI

### Los eventos no son logs

Los logs son prosa para depurar. Los `RuntimeEvent` son registros tipados y
pequeños que una interfaz puede consumir **sin parsear texto**.

Un evento lleva identificadores, tamaños, estados y duraciones. **Nunca** un
prompt, el cuerpo de un archivo, memoria ni una credencial. Hay redacción
automática: cualquier cosa con forma de secreto se sustituye por `[redacted]`,
el contenido largo se trunca y las claves de metadata están acotadas.

```
TOOL_STARTED    started  op=READ_TEXT_FILE  plan=…bf9f74
TOOL_COMPLETED  ok       op=READ_TEXT_FILE  plan=…bf9f74  dur=0ms
PLAN_UPDATED    blocked                     refused=forbidden_operation
TOOL_FAILED     failed   op=READ_TEXT_FILE  plan=…bf9f74
```

Bus in-process con historial acotado. Un suscriptor que falle **no tumba
Iclirius**.

### Future Iclirius Developer TUI

Objetivo visual: terminal limpia estilo agente CLI moderno, **no un dashboard
web**. Conversación principal arriba, y debajo un tracker pequeño de nodos con
sus runtimes.

```
ICLIRIUS
STM-COVE • Authentication
AUTO

    ┌───────────┐
    │  ▱  MBP   │
    └─────┬─────┘
      ● ONLINE
          │
    Ollama/qwen
      ● ACTIVE

────────────────────────────────
continúa revisando autenticación
────────────────────────────────
```

Con varios nodos:

```
┌──── MBP ────┐      data      ┌──── MBA ────┐
│   LEADER    │ ─────────────▶ │   WORKER    │
└─────────────┘                └─────────────┘
```

**Contratos ya disponibles** para que la TUI no haya que rehacerla:

| Contrato | Campos |
|---|---|
| `NodeInfo` | `node_id`, `display_name`, `role`, `status`, `is_local`, `capabilities`, `runtimes[]`, `active_jobs`, `last_seen` |
| `ModelRuntime` | `provider`, `model`, `node_id`, `status`, `is_local`, `account_ref` |
| `RuntimeStatus` | AVAILABLE · LOADED · ACTIVE · IDLE · UNAVAILABLE · RATE_LIMITED · EXHAUSTED · DISABLED |
| `NodeStatus` | ONLINE · OFFLINE · DEGRADED · UNKNOWN |

Una máquina puede tener **varios runtimes**, y un runtime servir **varias
tareas**: la relación es muchos-a-muchos por diseño.

`account_ref` es una **etiqueta** (`alguien@example.com`), nunca una
credencial. Las credenciales futuras irán al Keychain. `NodeInfo` no expone IP,
MAC, número de serie ni UUID de hardware.

**Hoy solo Ollama existe de verdad.** Los campos `provider`/`account_ref` están
reservados para que el contrato no cambie cuando lleguen; nada finge estar
conectado.

Comandos futuros contemplados (no implementados): `/status`, `/models`,
`/providers`, `/nodes`, `/context`, `/usage`, `/mode`.

---

## Task & Context Engine

> **LOCAL COMPUTE > LLM TOKENS**

### Task Engine

Distingue conversación de trabajo. `"hola"` no crea nada; `"revisa el login de
STM-COVE porque falla"` sí. Reglas deterministas: hace falta **intención** y
**sujeto** a la vez, y ante la duda **no crea nada** — una tarea espuria
contamina la memoria y desvía todos los prompts siguientes.

| Señal | Acción |
|---|---|
| charla, pregunta general | `none` |
| intención + sujeto | `create` |
| tarea equivalente ya abierta | `resume` (no duplica) |
| `"continuemos"`, `"sigamos con…"` | `resume` por keyword |
| dos tareas igual de plausibles | `ambiguous` → **pregunta, no adivina** |
| credencial literal en el texto | `none` |

### Procedencia: el modelo no es fuente de verdad

Un hecho lleva de dónde salió. Esto importa: *"Ollama dijo X"* no puede
convertirse en *"X es verdad"*.

| Procedencia | Verificado | Dónde se guarda |
|---|---|---|
| `user` | ✔ | `known_facts` |
| `local_verified` | ✔ | `known_facts` |
| `web_evidence` | ? | `decisions` |
| `model_suggestion` | ? | `decisions` |

En el prompt aparecen separados: `Known (verified)` frente a
`Hypotheses and decisions (unverified)`.

### Context Engine

Construye un **ContextPackage** gastando un presupuesto en orden de prioridad:

```
0 user_request   ← nunca se recorta
1 task / identity
2 facts
3 project
4 local_evidence
5 web_evidence
6 history
7 global         ← se descarta primero
```

El paquete es inspeccionable: qué entró, por qué, cuánto ocupa y con qué
`fingerprint` — todo hashes y tamaños, **nunca contenido**.

### Reducción medida

| Escenario | Fase 3.0 | Fase 3.1 | **Fase 3.2** | tokens |
|---|---|---|---|---|
| `"hola"` | 18.843 | 7.955 | **1.701** | 425 |
| tarea activa | ~18.843 | ~7.955 | **1.838** | 460 |
| continuación | ~18.843 | ~7.955 | **1.802** | 450 |
| + evidencia local | — | — | **1.864** | 466 |
| + evidencia web | — | — | **1.882** | 470 |

**~78% menos que en 3.1 · ~91% menos que en 3.0.** Tokens estimados con
`chars / 4`, ratio documentado y estable para español y código.

### Fingerprints

Cada sección lleva un hash de su contenido estructurado. Sirven para detectar
qué cambió entre turnos, para métricas y para una futura caché entre
proveedores. **No se usan todavía para omitir contexto.**

### Concurrencia

La deuda de Fase 3.1 está cerrada. Medido antes del arreglo: cuatro escritores
creando 15 tareas cada uno **perdían 43 de 61**. Ahora hay un `flock` que
envuelve todo el ciclo leer-modificar-escribir. Es de la stdlib, funciona en
macOS, y el kernel lo libera si el proceso muere, así que un crash no deja un
deadlock. La espera está acotada y un timeout **no tumba Telegram**.

### Memoria activa vs backup

`MEMORY_ROOT` es configurable, pero la memoria activa es **siempre un archivo
local**. La arquitectura es:

```
LOCAL ACTIVE MEMORY → snapshot cifrado → destino de backup
```

Nunca un archivo sincronizado por Drive haciendo de vault en vivo.

---

## Memory Core

Iclirius es dueño de su memoria. Los modelos no.

> **Local state is authoritative. LLM context is disposable.**
> **Never resend information that OpenClaw can retrieve, compute, filter,
> summarize or verify locally.**
> **Interfaces do not own memory. Iclirius owns memory.**

```
Telegram ─┐
CLI ──────┼──→ Iclirius ──→ MEMORY CORE ──→ Context Builder ──→ Ollama
Web ──────┤                 (cifrado)         (con presupuesto)
Local ────┘
```

### Identidad

Existe un solo `principal_user`, con id propio. Telegram y la CLI son
**puertas** a esa identidad: se registran como referencias de interfaz, nunca
como identidades. No depende de un id de Telegram, de la CLI, ni de ninguna
cuenta futura de Gemini u OpenAI.

### Namespaces

| Namespace | Contiene |
|---|---|
| **Global** | usuario principal, interfaces vinculadas |
| **Project** | id estable, nombre, raíz, huella del remoto git, hechos estructurados |
| **Task** | objetivo, estado, hechos, decisiones, archivos, hallazgos web, bloqueo, siguientes pasos, resumen compacto |
| **Working** | proyecto y tarea activos |

No hay un transcript infinito: todas las listas están acotadas y las tareas
cerradas se podan.

### Continuidad CLI ↔ Telegram

`iclirius chat` dentro de un repo detecta el proyecto por su **raíz git**,
usando la huella del remoto cuando existe. Dos clones del mismo repositorio
resuelven al mismo proyecto; dos carpetas llamadas `app` no colisionan.

Lo que anotas desde la CLI se recupera desde Telegram por nombre de proyecto,
y al revés. Una sola memoria, dos puertas.

### Qué NO se memoriza

Nada que se pueda recuperar barato en local:

- **contenido de archivos** — se guarda la ruta, y se relee cuando haga falta
- **HTML de páginas** — se guarda `claim + URL + fecha`, no la página
- **transcripts completos** — se guarda un resumen compacto estructurado

> Memoriza qué sabemos, por qué importa y dónde recuperarlo.

### Evidencia web

Un hallazgo web se guarda como evidencia con su fuente y su fecha, **nunca
como instrucción**. Un intento de inyección desde una página queda como
`claim` citado y no puede convertirse en objetivo, decisión ni siguiente paso.

### Presupuesto de contexto

El prompt ya no crece sin cota. Solo entran identidad mínima, proyecto activo,
tarea activa y el historial reciente acotado. Medido en real:

| | Antes (Fase 3) | Ahora |
|---|---|---|
| Prompt para `"hola"` | 18.843 chars | **7.955 chars** |
| `summary.md` inyectado | 11.037 (sin límite) | 1.506 (acotado) |

**57,8% menos contexto.** Se registran `context_chars`, `history_chars`,
`memory_chars`, `task_chars` y `project_chars` — tamaños, nunca contenido.

### Provider-independent

Una tarea pertenece a Iclirius. `provider_refs` existe como metadata auxiliar,
pero ningún `gemini_conversation_id` ni `openai_thread_id` es autoridad. Cambiar
de modelo no pierde el estado: el `compact_summary` es el handoff.

### Si la memoria falla

Degrada limpiamente: se registra un warning y **la conversación sigue con
Ollama**. La memoria nunca tumba la interfaz.

---

## Lectura local

Inspección de archivos, carpetas y repositorios **dentro de los roots
permitidos**. La regla que define la fase:

> El filesystem lo recorre Python y ripgrep. **Ollama solo interpreta un
> resumen ya reducido.** Nunca se le manda un directorio entero.

En una prueba real: `~/Downloads` con **1394 archivos y 3.8 GB** se procesó en
**0.12 s** y el modelo recibió **902 caracteres**.

### Operaciones

| Operación | Qué hace |
|---|---|
| `LIST_DIRECTORY` | contenido inmediato, tipo, tamaño, fecha |
| `FIND_FILES` | búsqueda recursiva por nombre, glob o extensión |
| `SEARCH_TEXT` | texto dentro de archivos (ripgrep, con fallback Python) |
| `READ_TEXT_FILE` | lectura acotada por bytes y líneas, rechaza binarios |
| `FILE_STAT` | tipo, extensión, tamaño, modificación |
| `HASH_FILE` | SHA-256 en streaming, útil para duplicados |
| `DIRECTORY_SUMMARY` | conteos, extensiones, lenguajes, mayores, recientes, build files |
| `GIT_STATUS` / `GIT_DIFF` / `GIT_LOG` | solo lectura, sobre repos dentro de los roots |

### Cómo se usa

| Forma | Cuándo |
|---|---|
| `/localread petición` | siempre |
| `/localstatus` | estado, roots y límites |
| automática | solo si el mensaje incluye una **ruta absoluta** y una intención de inspección |

Sin ruta absoluta no hay lectura local: hablar *sobre* archivos no basta. Ante
la duda, no toca el disco.

### Solo lectura

**No existe crear, editar, mover, copiar, renombrar, borrar, chmod, sudo,
`git commit/checkout/reset/clean/push`, ni shell arbitrario.** Si pides
modificar algo, responde que esa capacidad llegará más adelante.

El planner produce una operación **tipada de un enum cerrado**; no hay ningún
camino de texto del usuario, ni de salida del modelo, a una cadena de shell.
`ripgrep` y `git` se invocan con listas de argumentos fijas, nunca con
`shell=True`.

### Rutas

Se reutiliza `FILE_MANAGER_ALLOWED_ROOTS` y el validador **único** del
proyecto. Se resuelve antes de validar, así que `../` y symlinks que salgan
del root se bloquean. `.env`, claves SSH, `.pem`, `.key`, `.enc` y directorios
como `.ssh` o `.git` están vetados. Sin roots configurados, todo se rechaza.

---

## Búsqueda web

Internet es una **fuente de datos**, no un cerebro. El buscador devuelve
páginas públicas; **Ollama sigue siendo quien razona y sintetiza**. Ningún LLM
en la nube participa.

```
Telegram → OpenClaw → ¿requiere web?
                       ├─ no → Ollama local
                       └─ sí → búsqueda → fetch limitado → Ollama sintetiza
                                       → respuesta + fuentes → Telegram
```

Dos formas de activarla:

| Forma | Cuándo |
|---|---|
| `/web pregunta` | siempre busca |
| automática | solo si la pregunta depende de información actual (`hoy`, `última versión`, `precio`, `quién ganó`, `busca`, …) |

La heurística es deliberadamente conservadora: **ante la duda no busca**, para
que una conversación normal nunca abra la red. Siempre queda `/web`.

**Proveedor:** endpoint *lite* de DuckDuckGo. Sin API key y sin cuenta, así que
el agente sigue siendo autónomo y ningún tercero recibe una identidad tuya.

**Privacidad:** al buscador **solo sale la pregunta**. Nunca memoria, resumen
vivo, historial, identidad ni rutas locales. Los resultados vuelven y se
sintetizan en local. El texto sensible (tokens, contraseñas, `.env`) nunca
dispara búsqueda.

**Solo lectura:** únicamente GET a `http`/`https`. Sin login, sin cookies, sin
formularios, sin JavaScript, sin navegador, sin descargas binarias, sin
crawling. Toda URL pasa por validación anti-SSRF, incluido **cada redirect**:
`localhost`, `127.0.0.0/8`, `::1`, RFC1918, link-local y endpoints de metadata
están bloqueados, y un nombre público que resuelva a IP privada también.

**Contenido no confiable:** lo recuperado se entrega al modelo como evidencia
citada, entre marcas explícitas, con la instrucción de no obedecer órdenes que
aparezcan dentro. El contenido web no puede ejecutar nada: la frontera
modelo/ejecutor sigue intacta.

**Si Internet falla** (buscador caído, DNS, timeout, cero resultados), Iclirius
responde con conocimiento local y **dice claramente que no lo verificó en la
web**. Nunca se queda sin responder.

Se activa con `ENABLE_WEB_SEARCH=true`. Por defecto está **apagada**.

---

## Seguridad

### Autorización de Telegram

Dos niveles, ambos **fail-closed** (lista vacía ⇒ se deniega a todos):

- `ALLOWED_USER_IDS` — pueden conversar y consultar estado.
- `OWNER_USER_IDS` — subconjunto; además pueden ejecutar comandos de sistema
  (`/backup`, `/reset`, `/worker_*`, `/file_quarantine`, catálogo, ingesta).

**Ninguna información interna se emite antes de autorizar.** El chequeo de
permisos es lo primero que ocurre en cada handler.

### Frontera modelo / ejecución

Es la garantía central del diseño y se mantiene intacta:

| Capa | Puede ejecutar |
|---|---|
| Ollama / worker / (futuro) cloud | **No** — solo producen texto |
| Comandos de Telegram y CLI | Sí, con guard de owner |

### Contención de rutas

- `FILE_MANAGER_ALLOWED_ROOTS` define una allowlist obligatoria. Sin ella,
  toda ruta se rechaza.
- Las rutas se resuelven (`..` y symlinks) **antes** de validarse.
- `.env`, claves SSH, `.pem`, `.key`, `.crt`, `.enc` y los directorios de
  memoria/identidad están bloqueados para el lector de código.
- La limpieza de archivos mueve a **cuarentena**; nunca borra.

### Contenido sensible

`app/delegation.py` impide que texto con tokens, contraseñas, claves privadas
o referencias a `.env` salga de la máquina, incluso con delegación activa.
Esta regla tiene precedencia sobre la heurística de carga.

---

## Tests

```bash
.venv/bin/python -m pytest tests/ -q
```

876 tests cubren control de acceso, política de delegación, fallback del
router, contención de rutas, portabilidad/privacidad, el motor local, el
arranque supervisado, la búsqueda web (SSRF, prompt injection, fuentes) y la
lectura local (escapes, symlinks, límites, planner y frontera de solo lectura). Ningún test usa red ni
datos reales: Ollama, el worker, la cola de tareas y los hooks de memoria están
mockeados.

## Instalación nueva

En una Mac limpia, instala el paquete y ejecuta el asistente idempotente:

```sh
brew install iclirius/tap/iclirius
iclirius setup
```

Setup guía identidad, recuperación local, Memory Home, identidad del nodo,
servicio, capacidades y Doctor. El modo cluster queda standalone hasta que el
operador complete una ceremonia explícita de enrollment. Consulta
[SETUP_V2.md](docs/SETUP_V2.md) para el flujo y la aceptación de una Mac limpia.

---

## Datos

| Ruta | Contenido | Cifrado |
|---|---|---|
| `data/memory/*.enc` | conversaciones, notas, preferencias | Sí (Fernet) |
| `data/identity/*.enc` | perfil del agente | Sí |
| `data/memory/summary.md` | resumen vivo | **No** |
| `data/library/` | chunks de documentos ingeridos | No |
| `data/tasks/`, `data/jobs/` | estado de runtime | No |
| `logs/` | logs locales | No |

Nada de `data/` se sube a Git. El respaldo va a la carpeta que definas en
`BACKUP_ROOT` (`./scripts/backup_to_drive.sh`). Ver `RECOVERY.md` y
`OPERATIONS.md`.

---

## No implementado

Roadmap. **Nada de esto existe en el código hoy**, ni parcialmente:

| Área | Estado |
|---|---|
| Proveedores cloud: **OpenAI**, **Anthropic**, **Gemini** | NO IMPLEMENTADO |
| Abstracción `Provider` | NO IMPLEMENTADO |
| Modos **LOCAL / HYBRID / COUNCIL / AUTO** | NO IMPLEMENTADO |
| Evaluación de calidad de la respuesta local | NO IMPLEMENTADO |
| Síntesis local de respuestas múltiples | NO IMPLEMENTADO |
| **Embeddings** y base vectorial (Chroma) | NO IMPLEMENTADO |
| Recuperación semántica (RAG real) | NO IMPLEMENTADO — la búsqueda local es por subcadena |
| Presupuesto de contexto y minimización para cloud | NO IMPLEMENTADO |
| Contabilidad de coste y tokens | NO IMPLEMENTADO |
| **Planner** y executor dirigido por plan | NO IMPLEMENTADO |
| Registro de tools (`tools/`) | NO IMPLEMENTADO — el directorio está vacío |
| Cluster: heartbeat, presencia, failover y cómputo distribuido | NO IMPLEMENTADO; CLUSTER-4 aún no comienza |
| Servidor worker (`workers/`) | NO IMPLEMENTADO — vacío |
| Autenticación worker↔leader | NO IMPLEMENTADO |
| Escalonamiento de modelos (`FAST_MODEL`, `HEAVY_MODEL`) | NO IMPLEMENTADO — solo se usa `DEFAULT_MODEL` |
| Streaming de respuestas | NO IMPLEMENTADO |

Los directorios `tools/`, `cluster/`, `knowledge/`, `workers/` y el archivo
`app/router.py` existen pero están **vacíos**. Son marcadores de posición, no
implementaciones.

---

## Documentación

- `README.md` — este archivo, estado actual
- `OPERATIONS.md` — operación diaria
- `RECOVERY.md` — restauración en una Mac nueva
- `docs/LOCAL_AUTHENTICATION.md` — Touch ID y credencial local de recuperación
- `docs/NODE_RUNTIME_STATUS.md` — snapshot local de nodo y estado operativo
- `docs/HOMEBREW_DISTRIBUTION.md` — empaquetado standalone y fórmula local
- `docs/PRIVATE_BETA_INSTALL.md` — instalación desde el tap de distribución
