# Changelog

## Unreleased

## 1.0.0-rc.39 — pristine observability contract

- Keeps package installation and observational CLI/Doctor commands read-only on a pristine machine.
- Reports truthful unconfigured identity, local reasoning evidence, and never-installed service state.
- RC38 remains immutable; CLUSTER-4.8 physical enrollment stays paused pending validation.


## 1.0.0-rc.38 — CLUSTER-4.7 deterministic N-node simulation

- Packages the CLUSTER-4.7 deterministic five-node simulation and canonical ordering correction from `6aa4fff`.
- RC37 remains immutable. This artifact is the parity candidate for CLUSTER-4.8 physical N-node planning; no third-Mac enrollment is included.


## 1.0.0-rc.37 — CLUSTER-4.6 packaged observability
## CLUSTER-4.6 physical closure
## CLUSTER-4.7 deterministic N-node simulation

- Adds five-node deterministic simulation coverage over the existing trust, membership, discovery, presence, capability, selection and observability authorities.
- Corrects bounded trusted-presence ordering so the maximum-node limit is canonical rather than dependent on registry insertion order.
- No physical third-Mac acceptance, routing, scheduling, execution or new release was introduced.


- Records RC37 Homebrew physical observability PASS in both directions: Mac A→Mac B and Mac B→Mac A.
- Confirms identical authenticated presence projection across `node presence`, `node cluster-status`, TUI and Doctor.
- Records remote resource/capability metadata as UNKNOWN where no authenticated capability report exists; no membership or trust changes were made.
- The next planned gate is CLUSTER-4.7 deterministic N-node simulation; implementation has not started.


- Packages the complete CLUSTER-4.6 real-cluster observability CLI/TUI/Doctor projection and the shared authenticated presence freshness fix from commits `2ab34db` and `78c27d1`.
- RC36 remains immutable; RC37 Homebrew physical observability now passes in both directions.


### Documentation checkpoint — CLUSTER-3 RC36 physical acceptance

- Records the operator-provided RC36 two-Mac production discovery, endpoint
  mobility and authenticated TLS 1.3 PING/PONG PASS in both directions.
- Preserves the RC34, RC35 and RC36 discovery incident history and keeps the
  orphan test Bonjour publisher separate from authorization.
- CLUSTER-4 remains not started; no runtime behavior or release artifact was
  changed by this documentation closure.

### Documentation checkpoint — CLUSTER-4.0 N-node architecture audit

- Records the read-only N-node architecture audit after RC36 physical
  acceptance.
- Separates authoritative trust, discovery, future membership, presence,
  capabilities, and routing; no CLUSTER-4 runtime behavior was added.
- Defines the bounded 4.1–4.8 sequence and reserves the clean third-Mac test
  for N-node physical validation rather than a special three-node mode.

### CLUSTER-4.1 — N-node membership model

- Adds explicit membership intent in `cluster-membership.json`, separate from
  the authoritative trust registry.
- Adds bounded member list/status/add/remove/enable/disable commands.
- Revoked, changed, malformed, or non-TRUSTED identities are immediately
  ineligible; membership never creates trust or authorizes transport.
- Presence, routing, scheduling, remote execution, and third-Mac acceptance
  remain deferred.

### CLUSTER-4.2 — N-node discovery

- Preserves multiple bounded endpoint observations for one node identity,
  including IPv4/IPv6 candidates and interface variants.
- Marks incompatible fingerprint hints as conflicts and fails closed for
  trusted endpoint refresh.
- Evaluates a bounded candidate set with authenticated TLS 1.3/Ed25519 proof
  before updating one endpoint; discovery remains non-authoritative.
- Presence, heartbeat, routing and third-Mac physical validation remain
  deferred.

### CLUSTER-4.3 — authenticated presence/liveness

- Adds bounded on-demand presence based only on authenticated TLS 1.3 PING/PONG
  from an expected trusted identity.
- Defines conservative `UNKNOWN`, `ONLINE`, `STALE` and `OFFLINE` transitions;
  Bonjour appearance/disappearance never asserts presence.
- Persists diagnostics only, demotes historical ONLINE evidence after restart,
  and keeps capability/health/routing work deferred.

### 1.0.0-rc.36 — Bonjour resolution output preservation

- Preserves bounded stdout when `dns-sd -L` reaches its intentional timeout
  after printing a valid resolution. RC35 otherwise fell back to the service
  instance name for address, node ID and metadata.
- Adds physical-format resolution fixtures, timeout coverage and independent
  multi-node browse/resolve coverage. CLUSTER-3 physical acceptance remains
  pending.

### 1.0.0-rc.35 — production Bonjour discovery correction

- Fixes the macOS browse parser to recognize `_iclirius._tcp.` registration
  records, restoring production `node discover --json` candidates.
- Treats the shortened Bonjour fingerprint as a normalized prefix hint only;
  the authoritative full fingerprint and pinned Ed25519 key remain verified by
  the TLS secure channel before endpoint refresh.
- Adds deterministic browse and short-hint regression coverage. RC34's
  bidirectional secure-channel evidence is preserved; final CLUSTER-3 physical
  acceptance remains pending until RC35 is installed and physically retested.

### Documentation checkpoint — RC34 physical recovery evidence

- Recorded the Mac A RC34 managed-service recovery PASS without changing trust,
  enrollment or identity.
- Correlated the residual `Iclirius-enroll-node-a` / port 19092 advertisement
  to the `test_wrong_pairing_code_does_not_persist` publisher leak. It is
  discovery hygiene only; port 19092 has no listener and 18890 remains closed.
- Kept structured observability and readiness-scope work deferred. No RC35 is
  created by this checkpoint; CLUSTER-3 physical acceptance remains pending.

### 1.0.0-rc.34 — managed service migration and repair recovery

- Migrates source-checkout and older Homebrew LaunchAgents to the current
  packaged runtime through an atomic, validated plist/metadata transaction.
- `node.service.reinstall` now starts and verifies the replacement service;
  repair cannot report success without a live, provenance-checked runtime.
- Rejects pytest-derived LaunchAgent log paths and uses the managed runtime log
  directory. Dead secure-discovery markers are cleaned during stop/uninstall.
- Surfaces bounded repair failure categories and details. RC33 physical repair
  exposed a stale source plist, old Cellar runtime and unloaded service;
  CLUSTER-3 physical acceptance remains pending.

### 1.0.0-rc.33 — Bonjour registration argument fix

- Uses the macOS Bonjour registration type `_iclirius._tcp` with the `local.` domain, matching the native `dns-sd -R` contract.
- Captures bounded native `dns-sd` startup diagnostics when registration exits.
- Adds production-shaped complete-TXT and opt-in macOS publisher lifecycle coverage.
- RC32 physical validation found that TLS was live while the publisher exited; CLUSTER-3 physical acceptance remains pending.


### 1.0.0-rc.32 — secure discovery readiness

- Reports a secure listener with a failed Bonjour publisher as `DEGRADED` instead of silently healthy.
- Records bounded publisher failure reasons and passes the managed machine-state root through the runtime.
- Doctor and repair planning now surface a missing secure advertisement without changing trust, enrollment, or identity.
- RC31 physical validation found a live TLS listener with no `_iclirius._tcp.local.` publisher; CLUSTER-3 physical acceptance remains pending.


### 1.0.0-rc.31 — managed secure Bonjour lifecycle

- Resolves `dns-sd` explicitly for launchd/Homebrew runtimes instead of relying on a shell PATH.
- Keeps secure Bonjour advertisements owned by the managed TLS listener, with bounded lifecycle markers and cleanup.
- Adds structured endpoint-mobility failure diagnostics and regression coverage for the RC30 physical discovery failure.
- RC30 physical secure-channel acceptance remains pending; no trust or enrollment state is changed by this release.


### 1.0.0-rc.30 — CLI discovery dispatch fix

- Fixes a Python local-binding regression in `node_cli.main()` where the
  endpoint-mobility fallback imported `discover` inside the function and
  shadowed the module-level binding. `node discover --json` now dispatches
  correctly while endpoint mobility retains its authenticated fail-closed
  behavior.
- RC29's physical discovery attempt failed before any trust or endpoint
  mutation. RC30 physical validation is pending.

### 1.0.0-rc.29 — trusted endpoint mobility

- Recovers a stale trusted endpoint through bounded Bonjour discovery only.
- Verifies the discovered endpoint with the pinned Ed25519 identity over the
  TLS 1.3 secure channel before updating `cluster-trust.json`.
- Publishes the managed secure listener on Bonjour with its actual 18891 port;
  enrollment remains closed and separate on 18890.
- RC28 finding: secure transport was operational, but production `node ping`
  did not invoke the existing authenticated endpoint-refresh primitive.
- Physical RC29 endpoint-mobility acceptance remains pending.

### 1.0.0-rc.27 — trust authority hardening

- Rejects every network `PAIR_INIT` that is not an explicit enrollment request.
- Prevents legacy signed pairing and pairing codes from writing `TRUSTED`.
- Adds direct network regression coverage proving both trust registries remain
  unchanged for rejected legacy requests.
- RC27 is a security candidate; physical CLUSTER-3 acceptance remains pending.

### 1.0.0-rc.28 — trust authority hardening follow-up

- Removes the unreachable legacy trust-writing branches from the network pairing
  implementation after RC27 publication.
- RC28 is the candidate corresponding to the final hardened source commit;
  physical CLUSTER-3 acceptance remains pending.

### 1.0.0-rc.26 — zero-touch setup V2

- Adds an idempotent onboarding state machine for identity, recovery,
  Memory Home, node identity, service, capabilities and final validation.
- Adds safe `iclirius setup --repair` and secret-free `iclirius recovery status`.
- Keeps cluster setup standalone by default; discovery never creates trust.
- Third-Mac clean-install acceptance remains pending.

### Documentation checkpoint — CLUSTER-2.3 physical evidence

- Recorded the operator-provided RC23 two-Mac CLUSTER-2.3 physical trust
  ceremony as PASS, including reciprocal Ed25519 proof, explicit fingerprint
  confirmation, restart persistence and closed enrollment.
- CLUSTER-3 physical secure-channel ping remains pending; CLUSTER-4 has not
  started. No release is created by this checkpoint.

### 1.0.0-rc.25 — CLUSTER-3.1 secure channel hardening

- Enforces the local node as the destination of every inbound secure HELLO.
- Adds machine-local managed secure-channel enable/disable state and truthful
  listener liveness, including safe port-conflict reporting.
- Resolves secure ping endpoints from the authoritative CLUSTER-2 trust
  registry rather than legacy peer metadata.
- RC23 and RC24 remain immutable; physical CLUSTER-3 acceptance is still pending.

### RC20 cryptographic enrollment hardening

- Enrollment trust now requires a verified Ed25519 proof-of-possession.
- Verification codes alone cannot create trusted peers.
- `node enroll --plan` is side-effect-free.
- RC19 remains immutable.

### RC19 release integrity

- Added deterministic build identity (version, installation mode and source
  revision) to version details and service diagnostics.
- Fixed source-checkout LaunchAgents to run with the package root as their
  working directory, independent of the shell CWD.
- RC19 includes the completed CLUSTER-3 secure channel implementation. RC18
  remains immutable and is not republished.

### CLUSTER-3 — secure node channel

- Added a bounded TLS 1.3 transport with Ed25519 application identity
  binding, CLUSTER-2 trust authorization, replay/downgrade checks, revocation
  enforcement, and structured secure-channel status.
- The listener is opt-in until physical CLUSTER-2 acceptance is complete.
- No remote execution or general RPC is exposed.

### CLUSTER-2 — secure discovery and enrollment

- Added bounded Bonjour discovery metadata, machine-local trust states,
  Keychain-backed public node identity fingerprints, expiring enrollment
  sessions, and persistent revocation records.
- Added `nodes`, discovery, enrollment, trust, and revoke CLI views plus
  non-invasive Doctor cluster diagnostics.
- No remote command execution or encrypted general node channel is included;
  the latter is deferred to CLUSTER-3.
- CLUSTER-2.2 keeps enrollment closed by default and lets the persistent node
  runtime advertise bounded Bonjour presence without opening the enrollment
  listener.
- Successful signed pairing now records the peer in the CLUSTER-2 trust
  registry on both sides; revocation is checked before authenticated ping or
  capability observation.

## 1.0.0-rc.18

- Reconciles loaded previous-generation LaunchAgents during install and bases
  stop success on the final unloaded/no-PID postcondition.

## 1.0.0-rc.17

- Makes `python -m app.node_runtime` a persistent signal-controlled node
  process and reports clean immediate exits as startup failures.

## 1.0.0-rc.16

- Preserves the Homebrew virtualenv interpreter path when its Python launcher
  is a symlink into the base Python Cellar.

## 1.0.0-rc.15

- Completes the packaged node startup postcondition by verifying that the live
  PID command is `app.node_runtime`.

## 1.0.0-rc.14

- Resolves the packaged Homebrew service interpreter from the console-script
  environment and verifies that it can import `app.node_runtime` before a
  LaunchAgent is considered valid.

## 1.0.0-rc.13

- Detects stale Homebrew LaunchAgents after package upgrades, distinguishes
  current CLI and installed service runtimes, and makes repair regenerate the
  service from the current packaged interpreter.

## 1.0.0-rc.12

- Fixes packaged Homebrew node runtime resolution and verifies launchd startup
  postconditions with stale-runtime detection.

## 1.0.0-rc.11

- Makes the packaged node LaunchAgent lifecycle truthful and verifies real
  launchd state after install, start, stop, restart and uninstall.

## 1.0.0-rc.10

- Promotes the accepted RC10 stable baseline to the reproducible distribution
  version. Packaging and Homebrew publication remain gated by clean-install
  and immutable-artifact validation.

- RC10 E2E final acceptance records candidate `7ac45bd` as the stable source
  for controlled main integration. Physical Telegram evidence confirms root
  continuity, displayed ResultSet binding, referents, continuation, local PDF
  filtering and public Web separation. Distribution/version promotion remains
  pending.

- RC10-FIX.4 binds conversational referents to the exact visible ResultSet
  page while preserving explicit logical pagination. Derived filters such as
  “de esos cuáles son PDF” cannot escape the displayed page or switch roots;
  lineage and visible-set identifiers are included in routing traces.

- RC10-FIX.3 preserves an explicit authorized filesystem root across related
  turns, records root-selection provenance, enforces strict ResultSet lineage
  and scope checks, and makes continuation/derived filters use the same root.
  Distinct file types are presented by observed frequency while FILE-3 remains
  bounded and local-only.

- RC10-FIX.2 unifies filesystem extension classification from the final
  basename suffix, adds bounded path-based PDF extraction for authorized large
  documents, accepts punctuation-tolerant ResultSet continuation, and routes
  public explanation questions such as “cómo funciona X” through the existing
  bounded C5.6 Web path.  Personal filesystem requests remain local-only.

- RC10-FIX.1 clarifies FILE-3 evidence states and PDF diagnostics, keeps partial
  text usable without claiming unavailable content, separates distinct file
  types from grouped counts, resolves “desde enero” deterministically, and
  adds one bounded public-Web recovery attempt while preserving C5.6 evidence
  and grounding rules.

- RC10-FIX hardens conversational filesystem E2E behavior. Bounded multi-intent
  requests reuse one scoped in-memory filesystem snapshot, derived ResultSets
  preserve parent provenance, partial FILE-3 segments remain usable evidence,
  and grouped responses are compacted without discarding ResultSets. Public
  Web routing remains C5.6-authoritative and personal filesystem requests do
  not fall back to Web.

- Adds the canonical `integration/rc10` candidate, combining NATIVE-4,
  STABILITY-1A.1 filesystem analytics, INSTALL-1/1B profile-aware setup and
  opt-in Telegram lease fencing, and OBSERVABILITY-1 redacted capability-gap
  telemetry. The public release, Homebrew update, clean-Mac acceptance, and
  physical multi-Mac failover remain pending.

- NATIVE-2 adds an Iclirius Tool/Capability Registry boundary with deterministic
  READ adapters for filesystem, Web and Git operations. FILE-1/2/3, C5.6 and
  FILE-4 remain authoritative; WRITE descriptors are protected behind FILE-4.
  The installed Node OpenClaw registry is documented but not bridged through a
  fragile subprocess protocol (`CONTRACT_ONLY_FOR_NOW`).

- NATIVE-3 consolidates migrated filesystem reads behind the Tool Adapter,
  validates structured arguments, distinguishes no matches from failures,
  adds bounded search-to-content chaining, enforces authorized Git roots and
  preserves C5.6/FILE-1/2/3/4 as the authoritative implementations.

- NATIVE-4 adds a bounded LOCAL_ONLY Attachment Gateway for Telegram documents.
  Attachments are identity/node-bound temporary FileRecords processed only by
  FILE-3; unsupported types, unsafe MIME/path conditions and oversized files
  fail explicitly. No OCR, cloud processing, archive extraction or mutation is
  added.

- FILE-3 adds authorized deterministic content extraction and evidence for text,
  Markdown, source code, JSON, XML, CSV, PDF text and minimal DOCX XML, with
  bounded segmentation/search, stale detection and provenance. OCR, archives,
  semantic indexing and filesystem mutation remain deferred.

- FILE-4 adds identity-bound CandidateSets, expiring confirmation-gated action
  plans, dry-run previews, safe Trash, bounded MOVE/RENAME, protected-path and
  symlink validation, post-action verification and receipts. Permanent delete,
  COPY, shell actions and Telegram mutation UX remain unsupported or deferred.

- FILE-2 adds deterministic combined FileQuery search, file-family
  classification, marker-based ProjectRecord detection, read-only Git activity,
  bounded duplicate checks and Generic Evidence Core adapters. No content
  analysis, persistent index or filesystem mutation is added.

- FILE-1 adds deterministic, read-only filesystem metadata inventory with
  explicit allowed roots, node-aware scoped FileRecords, symlink-safe bounded
  scans, coverage states, metadata queries and Generic Evidence Core adapter.
  File contents and filesystem mutations remain out of scope.

- Freezes and documents the C5.6 Web Evidence architecture, generic evidence
  contract, Web-specific boundary, safety invariants, failure behavior, bounds,
  limitation register and File Evidence handoff. No new provider or production
  capability is introduced.

- C5.6-F adds deterministic claim/evidence relation checks and source-origin
  clustering. Corroboration now uses independent clusters rather than hostname
  count, and near-mirror representatives control emitted citations. The
  development corpus passes 13/13; a 5-case holdout exposes one partial-copy
  citation limitation.

- Adds a development-only offline web-evidence evaluation harness, 41 versioned
  cases, canonical record fixtures, independent atomic-claim/citation labels,
  baseline/final metrics and separate live/Ollama observations. Corpus gold
  compliance is 25/41, not a claim of perfect accuracy.
- Calibrates the existing answer guard and deterministic fallback to require
  each emitted statement to satisfy source quality/corroboration/freshness.
  Measured unsupported acceptance falls from 3/41 to 2/41 without increasing
  supported rejection (7/34); no ranking thresholds change.

- Adds deterministic EvidenceAssessment before grounded web synthesis, with
  explicit sufficiency, lexical facet coverage, source-quality/diversity,
  assertion corroboration/conflicts and conservative publication freshness.
  Partial/conflicting answers use attributed extracts; missing evidence never
  falls back to factual model memory. Valid citations cannot authorize added
  claims, negation or changed numeric signs. Context trimming fails closed.

- Adds query-centered web passage extraction and bounded context packing after
  document selection. HTML headings and structural blocks retain offsets;
  relevant passages are selected with deterministic lexical signals and remain
  traceable to their original evidence IDs and URLs. Fixes a same-domain source
  diversity crash found during physical acceptance.
- Adds deterministic, query-intent-aware web evidence quality signals,
  duplicate suppression, context-budget selection, source-diversity handling,
  and explainable `web ask --explain-sources` diagnostics. Ranking describes
  candidate usefulness, not truth.
- Adds request-scoped web evidence IDs, claim-level citation checks, verified
  source rendering, categorical grounding status, and local-only grounded web
  answers through the existing ContextPackage and ReasoningGateway.

## 1.0.0-rc.7

- LAN release candidate combining the trusted multi-node foundation,
  capability advertisement and freshness, discovery/enrollment, multi-node
  TUI, and the LAN listener bind fix.
- Finalizes role-aware Doctor capability truth: required, available, optional,
  untested, and repairable states are reported consistently with
  `NodeCapabilityProfile`.
- Candidate for final LAN physical acceptance; Mac-to-Mac acceptance remains
  scheduled for LAN.3.

## 1.0.0-rc.6

- Fixes the node-to-node listener default so LAN peers can connect through
  `0.0.0.0` while preserving the existing TLS, Ed25519 identity, trust, and
  replay protections. Concrete LAN addresses remain used for peer endpoints;
  local IPC listeners are unchanged.

## 1.0.0-rc.5

- Adds the Web Search + Fetch foundation with bounded `web.search` and
  `web.fetch` tools, canonical EvidenceRecord grounding, current-information
  routing hints, SSRF/private-network protection, and safe node capability
  flags. Browser automation and Firefox are not included.

## 1.0.0-rc.4

- Adds authenticated remote capability advertisement over the existing trusted
  node channel, with bounded safe profiles, freshness-aware local cache, and
  ACTIVE/OFFLINE/UNKNOWN handling.
- Includes role-aware node health, interactive Doctor repair, verified repair
  actions, Git role awareness, and local node role persistence.
- Remote shell, remote repair, remote filesystem, remote Ollama inference,
  task delegation, automatic node selection, failover, OpenAI, and Claude are
  not implemented.

## 1.0.0-rc.3

- Strengthens canonical encrypted memory ownership and test/production Memory
  Home isolation, with deterministic migration dry-run and provenance review
  tooling.
- Includes the evidence source-of-truth foundation, AI account/session
  foundation, Gemini OAuth adapter, node pairing, node repair, repair progress,
  node capabilities, Doctor diagnostics, and CLI/TUI runtime improvements.
- Production historical memory migration is not executed automatically. Gemini
  OAuth still requires physical acceptance and configuration; OpenAI and Claude
  authentication, cloud routing, and remote execution remain unavailable.

## 1.0.0-rc.2

- Adds Doctor deep diagnostics, NodeCapabilityProfile, explicit node repair
  planning/execution, and secure Ed25519/TLS node pairing with authenticated
  ping/pong. Real two-Mac pairing and remote work remain future validation and
  feature phases.

## Unreleased

- Local identity authentication for interactive sessions: macOS Touch ID with
  a machine-local scrypt recovery passphrase, safe auth status, and no changes
  to Fernet Memory Core encryption or Telegram authentication.
- Canonical local `NodeSnapshot`, `iclirius node status`, bounded resource and
  Ollama probes, Memory Core revision metadata, and a small responsive TUI
  status panel.
- Standalone Python packaging, console entrypoint, release-archive builder and
  local Homebrew formula prototype; no public release or tap published.
- Private-source `v1.0.0-rc.1` release candidate published with a verified
  artifact SHA-256.
- Public distribution-only repository and Homebrew tap published for the
  audited RC artifact; source remains private.
- Phase 5.4 existing-identity enrollment foundation: versioned authenticated
  enrollment envelope, real Memory Core validation, local Keychain
  provisioning, and new-node setup flow. Real Mac 1 preparation and Mac 2
  acceptance remain pending.
- Guided local Ollama onboarding in `iclirius setup`: runtime/model detection,
  explicit install/start/pull choices, alternative model selection and
  continue-without-local-AI behavior. Homebrew installation remains
  non-interactive.
- Phase 5.4b capability audit: versioned structured Doctor results with
  required/optional/degraded/blocked/untested semantics, conservative system,
  memory, local-AI, tool, network, remote-access and voice observations, and
  backward-compatible JSON output. Deep diagnostics remain future work.
- Phase 5.4d node capability profiles: structured operational eligibility,
  evidence levels, role-specific blockers and safe `node capabilities` JSON.
  Distributed role assignment and node communication remain future work.
- Phase 5.5a secure node pairing foundation: machine-local Ed25519 node
  identities, ephemeral TLS transport, explicit one-use pairing codes,
  trusted-peer storage, authenticated ping/pong, and local unpair/revocation.
  Remote execution, capability exchange, and real two-Mac acceptance remain
  future work.
- Phase 5.4e node repair/bootstrap: role-aware dry-run plans, explicit approval
  for package/model changes, safe local identity initialization, typed executor
  actions, and post-repair Doctor verification. Restricted capabilities remain
  manual or policy-blocked.

- CLI interactiva limpia: logs operativos permanecen en archivo y se muestran
  explícitamente con `--debug`.
- Clasificación de tareas locales y awareness de capacidades del nodo sin
  relajar sandboxing ni permisos.
- Entradas vacías o secuencias de terminal no generan turnos ni llamadas al
  modelo.
- Capa visual ligera para el chat CLI: header runtime, color TTY opcional,
  indicador de trabajo y señales breves de lectura/fallback.
- Instalador reproducible para macOS (`install.sh`), diagnóstico read-only
  (`iclirius doctor --json`) y desinstalación que preserva datos de usuario.
- `iclirius setup` para identidad humana, Memory Home versionado, bootstrap
  local de Keychain y migración cifrada sin borrar el estado anterior.
- Phase 5 hardening: setup reuses an existing Memory Home user ID, validates
  its complete structure, avoids duplicating the legacy encrypted core, rejects
  unsafe symlinks/overlapping paths, and keeps session node metadata stable.
- Chat TUI mínima basada en Textual: alternate screen, historial desplazable,
  composer multilinea con pegado seguro, worker para generación local y
  fallback `iclirius --plain`.

## 1.0.0-rc.1

- Canonical Iclirius identity shared by Telegram and the interactive CLI.
- Encrypted Memory Core with shared Project and Task continuity.
- Task Engine, Context Engine and ReasoningGateway boundaries.
- Local Ollama reasoning as the default.
- Optional Gemini provider, account pool and durable budget governor.
- Safe Web, READ, WRITE and EXECUTE flows with verification.
- Telegram interface with local TTS/STT voice support.
- Lightweight interactive CLI and shared RuntimeSnapshot/StatusView observability.

### Known limitations

- Real Gemini generation smoke is pending explicit credentials and model configuration.
- No cloud provider other than Gemini is implemented.
- AUTO, DEEP and COUNCIL routing modes are not implemented.
- Multi-node orchestration is not production-ready.
- TTS and STT are local; no cloud voice provider exists.
- Nine legacy files under `data/audio` are preserved intentionally because deletion was prohibited.
- `app/pending_scan.py` remains an untracked historical file intentionally.
# Unreleased

- Add official Gemini OAuth account login with Keychain-backed credentials,
  provider validation, refresh-aware session status, model listing, and
  profile-scoped logout.

### RC21 physical enrollment ceremony

- Added stale enrollment cleanup and explicit confirmation state.
- Added fingerprint-bound confirmation after signed identity verification.
- Added command-specific enrollment help.
- RC20 remains immutable.

### RC22 network enrollment boundary

- Network signed pairing now stops at `CONFIRMATION_REQUIRED`.
- Network enrollment no longer writes authoritative trust automatically.
- Legacy non-enrollment pairing is disabled.
- RC21 remains immutable.

### RC23 enrollment output

- Enrollment listeners now display the verified remote session and fingerprint
  needed for explicit operator confirmation.
- RC22 remains immutable.

### CLUSTER-2.3 physical acceptance

- Recorded operator-provided two-Mac PASS for signed identity exchange,
  fingerprint review, reciprocal confirmation, and trust persistence after
  restart on RC23.
- CLUSTER-3 secure-channel physical acceptance remains pending.
# Unreleased — CLUSTER-4.4

- Added a bounded namespaced node resource/capability registry with explicit
  availability states and single-node eligibility evaluation.
- Kept roles descriptive and capability observations separate from trust,
  membership, presence and authorization. No selection, routing, scheduling or
  remote execution was added.
# Unreleased — CLUSTER-4.5

- Added deterministic, explainable single-node eligibility and selection over
  trusted members and bounded capability/presence evidence.
- Selection is advisory only and does not authorize, route, schedule or execute
  work.
# Unreleased — CLUSTER-4.6

- Added a bounded, read-only real-cluster observability projection for CLI,
  TUI and Doctor, including deterministic node cards and `node cluster-status`.
- Unknown evidence remains UNKNOWN; presentation never grants trust,
  membership, presence, capability permission or execution.
