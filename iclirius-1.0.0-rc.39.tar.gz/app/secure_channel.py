"""Bounded authenticated encrypted channel for trusted Iclirius nodes.

TLS 1.3 supplies confidentiality/integrity.  The existing Ed25519 node key
signs the application HELLO and every message, binding the ephemeral TLS
certificate to the CLUSTER-2 trust registry without inventing a certificate
authority or moving private key material.
"""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import socket
import ssl
import tempfile
import threading
import time
import uuid
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, rsa
from cryptography.x509.oid import NameOID

from app import cluster_security
from app.node_pairing import NodeIdentity, identity

PROTOCOL = "iclirius-secure-node"
PROTOCOL_VERSION = 1
MAX_MESSAGE = 16 * 1024
REPLAY_WINDOW_SECONDS = 300
DEFAULT_SECURE_PORT = 18891
SECURE_CONFIG_FILE = "secure-channel.json"
SECURE_RUNTIME_FILE = "secure-channel-runtime.json"
ALLOWED_TYPES = {"HELLO", "PING", "PONG", "CAPABILITIES_REQUEST", "CAPABILITIES_RESPONSE"}


class SecureChannelError(RuntimeError):
    def __init__(self, code: str, message: str = ""):
        self.code = code
        super().__init__(message or code)


def _canonical(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _fingerprint(public_key: str) -> str:
    return cluster_security.fingerprint(public_key)


def _sign(ident: NodeIdentity, message: dict) -> str:
    return base64.b64encode(ident.private_key.sign(_canonical(message))).decode()


def _verify(public_key: str, message: dict, signature: str) -> bool:
    try:
        key = ed25519.Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key, validate=True))
        key.verify(base64.b64decode(signature, validate=True), _canonical(message))
        return True
    except Exception:
        return False


def envelope(message_type: str, ident: NodeIdentity, payload: dict | None = None,
             destination_node_id: str = "") -> dict:
    if message_type not in ALLOWED_TYPES:
        raise SecureChannelError("MESSAGE_TYPE_UNSUPPORTED")
    message_id = uuid.uuid4().hex
    body = {
        "protocol_version": PROTOCOL_VERSION,
        "message_id": message_id,
        "request_id": message_id,
        "source_node_id": ident.node_id,
        "destination_node_id": destination_node_id,
        "timestamp": int(time.time()),
        "nonce": secrets.token_urlsafe(18),
        "message_type": message_type,
        "payload": payload or {},
    }
    body["signature"] = _sign(ident, body)
    return body


def validate_envelope(message: object, *, expected_source: str = "",
                      expected_destination: str = "", seen: set[str] | None = None) -> dict:
    if not isinstance(message, dict) or len(json.dumps(message)) > MAX_MESSAGE:
        raise SecureChannelError("MESSAGE_TOO_LARGE")
    required = {"protocol_version", "message_id", "request_id", "source_node_id",
                "destination_node_id", "timestamp", "nonce", "message_type",
                "payload", "signature"}
    if not required.issubset(message):
        raise SecureChannelError("MALFORMED_ENVELOPE")
    if message["protocol_version"] != PROTOCOL_VERSION:
        raise SecureChannelError("PROTOCOL_MISMATCH")
    if message["message_type"] not in ALLOWED_TYPES:
        raise SecureChannelError("MESSAGE_TYPE_UNSUPPORTED")
    if expected_source and message["source_node_id"] != expected_source:
        raise SecureChannelError("SOURCE_IDENTITY_MISMATCH")
    if expected_destination and message["destination_node_id"] != expected_destination:
        raise SecureChannelError("DESTINATION_MISMATCH")
    try:
        timestamp = int(message["timestamp"])
    except (TypeError, ValueError):
        raise SecureChannelError("MALFORMED_ENVELOPE")
    if abs(int(time.time()) - timestamp) > REPLAY_WINDOW_SECONDS:
        raise SecureChannelError("EXPIRED_TIMESTAMP")
    message_id = str(message["message_id"]); nonce = str(message["nonce"])
    if seen is not None:
        if message_id in seen or nonce in seen:
            raise SecureChannelError("REPLAY_REJECTED")
        seen.update({message_id, nonce})
        if len(seen) > 512:
            for item in list(seen)[:128]: seen.remove(item)
    return message


def _certificate_context() -> tuple[ssl.SSLContext, tempfile.TemporaryDirectory]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "iclirius-secure-node")])
    now = datetime.now(timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now).not_valid_after(now.replace(year=now.year + 1))
            .sign(key, hashes.SHA256()))
    directory = tempfile.TemporaryDirectory(prefix="iclirius-secure-channel-")
    cert_path = Path(directory.name) / "cert.pem"; key_path = Path(directory.name) / "key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                                           serialization.PrivateFormat.TraditionalOpenSSL,
                                           serialization.NoEncryption()))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.load_cert_chain(str(cert_path), str(key_path))
    return context, directory


def _client_context() -> ssl.SSLContext:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    context.maximum_version = ssl.TLSVersion.TLSv1_3
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def _send(sock: ssl.SSLSocket, message: dict) -> None:
    raw = json.dumps(message, separators=(",", ":")).encode()
    if len(raw) > MAX_MESSAGE: raise SecureChannelError("MESSAGE_TOO_LARGE")
    sock.sendall(raw + b"\n")


def _recv(sock: ssl.SSLSocket) -> dict:
    data = bytearray()
    while len(data) <= MAX_MESSAGE:
        chunk = sock.recv(1)
        if not chunk: break
        if chunk == b"\n": break
        data.extend(chunk)
    if not data or len(data) > MAX_MESSAGE: raise SecureChannelError("MALFORMED_ENVELOPE")
    try: value = json.loads(data.decode())
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SecureChannelError("MALFORMED_ENVELOPE") from exc
    return value


def _trusted_peer(node_id: str, state_root: str | Path | None) -> dict:
    data = cluster_security.read_registry(state_root)
    peer = data.get("peers", {}).get(node_id, {})
    if not peer: raise SecureChannelError("PEER_NOT_TRUSTED")
    if peer.get("trust_state") == cluster_security.REVOKED:
        raise SecureChannelError("PEER_REVOKED")
    if peer.get("trust_state") != cluster_security.TRUSTED:
        raise SecureChannelError("PEER_NOT_TRUSTED")
    return peer


def _state_root(state_root=None) -> Path:
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def configured(state_root=None) -> dict:
    try:
        value = json.loads((_state_root(state_root) / SECURE_CONFIG_FILE).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {"enabled": False}
    except (OSError, ValueError, TypeError):
        return {"enabled": False}


def configure(enabled: bool, *, state_root=None) -> dict:
    root = _state_root(state_root); root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = root / SECURE_CONFIG_FILE
    data = {"schema_version": 1, "enabled": bool(enabled), "bind": "0.0.0.0",
            "port": DEFAULT_SECURE_PORT}
    tmp = path.with_suffix(".tmp"); tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)
    return data


def _runtime_status(state_root=None) -> dict:
    path = _state_root(state_root) / SECURE_RUNTIME_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("state") == "PORT_CONFLICT":
            return {**data, "listener_live": False}
        os.kill(int(data["pid"]), 0)
        return {**data, "listener_live": True}
    except (OSError, ValueError, TypeError, KeyError):
        return {"listener_live": False}


@dataclass
class SecureSession:
    sock: ssl.SSLSocket
    local_identity: NodeIdentity
    peer_node_id: str
    peer_fingerprint: str
    protocol_version: int = PROTOCOL_VERSION
    authenticated: bool = True
    encrypted: bool = True
    connected_at: float = 0.0

    def send(self, message_type: str, payload: dict | None = None) -> dict:
        message = envelope(message_type, self.local_identity, payload, self.peer_node_id)
        _send(self.sock, message); return message

    def receive(self, seen: set[str] | None = None) -> dict:
        return validate_envelope(_recv(self.sock), expected_source=self.peer_node_id,
                                 expected_destination=self.local_identity.node_id, seen=seen)

    def close(self) -> None:
        try: self.sock.close()
        except OSError: pass


def _authenticate(sock: ssl.SSLSocket, local: NodeIdentity, expected_peer: str,
                  state_root: str | Path | None, timeout: float) -> tuple[SecureSession, set[str]]:
    sock.settimeout(timeout)
    seen: set[str] = set()
    _send(sock, envelope("HELLO", local, {"public_key": local.public_key}, expected_peer))
    hello = validate_envelope(_recv(sock), expected_destination=local.node_id, seen=seen)
    peer_id = hello["source_node_id"]
    if expected_peer and peer_id != expected_peer:
        raise SecureChannelError("PEER_IDENTITY_MISMATCH")
    peer = _trusted_peer(peer_id, state_root)
    public = hello.get("payload", {}).get("public_key", "")
    if public != peer.get("public_key") or not _verify(public, {k: hello[k] for k in hello if k != "signature"}, hello["signature"]):
        raise SecureChannelError("PEER_IDENTITY_MISMATCH")
    return SecureSession(sock, local, peer_id, _fingerprint(public), connected_at=time.time()), seen


def _server_authenticate(sock: ssl.SSLSocket, local: NodeIdentity,
                         state_root: str | Path | None, timeout: float) -> tuple[SecureSession, set[str]]:
    sock.settimeout(timeout); seen: set[str] = set()
    hello = validate_envelope(_recv(sock), expected_destination=local.node_id, seen=seen)
    peer_id = hello["source_node_id"]
    peer = _trusted_peer(peer_id, state_root)
    public = hello.get("payload", {}).get("public_key", "")
    if public != peer.get("public_key") or not _verify(public, {k: hello[k] for k in hello if k != "signature"}, hello["signature"]):
        raise SecureChannelError("PEER_IDENTITY_MISMATCH")
    _send(sock, envelope("HELLO", local, {"public_key": local.public_key}, peer_id))
    return SecureSession(sock, local, peer_id, _fingerprint(public), connected_at=time.time()), seen


class SecureNodeClient:
    def __init__(self, *, state_root: str | Path | None = None,
                 local_identity: NodeIdentity | None = None, timeout: float = 5.0):
        self.state_root = state_root; self.local_identity = local_identity or identity(); self.timeout = timeout

    def connect(self, address: str, port: int, peer_node_id: str) -> SecureSession:
        _trusted_peer(peer_node_id, self.state_root)
        raw = socket.create_connection((address, int(port)), timeout=self.timeout)
        try:
            sock = _client_context().wrap_socket(raw, server_hostname="iclirius-secure-node")
            session, _ = _authenticate(sock, self.local_identity, peer_node_id, self.state_root, self.timeout)
            return session
        except Exception:
            raw.close(); raise

    def ping(self, address: str, port: int, peer_node_id: str) -> dict:
        session = self.connect(address, port, peer_node_id)
        seen: set[str] = set()
        try:
            request = session.send("PING", {})
            reply = session.receive(seen)
            if (reply["message_type"] != "PONG"
                    or reply.get("payload", {}).get("request_id") != request["request_id"]):
                raise SecureChannelError("MALFORMED_ENVELOPE")
            return {"state": "AUTHENTICATED", "encrypted": True, "node_id": peer_node_id,
                    "fingerprint": session.peer_fingerprint, "protocol_version": PROTOCOL_VERSION,
                    "observed_at": time.time()}
        finally: session.close()


class SecureNodeServer:
    def __init__(self, *, bind: str = "0.0.0.0", port: int = DEFAULT_SECURE_PORT,
                 state_root: str | Path | None = None, local_identity: NodeIdentity | None = None):
        self.bind, self.port, self.state_root = bind, int(port), state_root
        self.local_identity = local_identity or identity(); self._stop = threading.Event(); self._server = None
        self._temp = None; self._discovery_service = None

    def serve(self, *, once: bool = False) -> None:
        context, self._temp = _certificate_context()
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind((self.bind, self.port))
        except OSError:
            runtime_path = _state_root(self.state_root) / SECURE_RUNTIME_FILE
            runtime_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            runtime_path.write_text(json.dumps({"listener_live": False, "state": "PORT_CONFLICT",
                                                 "bind": self.bind, "port": self.port}), encoding="utf-8")
            os.chmod(runtime_path, 0o600)
            server.close()
            return
        server.listen(5); server.settimeout(0.5); self.port = server.getsockname()[1]; self._server = server
        # Advertise only the endpoint that is actually backed by the managed
        # secure listener. Enrollment remains a separate, operator-opened
        # listener on 18890.
        try:
            from app.node_discovery import (BonjourDiscovery, discovery_enabled,
                                            record_advertisement_failure, secure_advertisement)
            from app.node_identity import read_node
            from app.version import VERSION
            if discovery_enabled():
                node = read_node()
                self._discovery_service = BonjourDiscovery(
                    name=f"Iclirius-{self.local_identity.node_id[:12]}",
                    port=self.port,
                    runtime_file="secure-discovery-runtime.json",
                    state_root=self.state_root,
                    txt=secure_advertisement(
                        node_id=self.local_identity.node_id,
                        display_name=str(node.get("display_name") or node.get("hostname") or self.local_identity.node_id),
                        fingerprint=self.local_identity.fingerprint,
                        version=VERSION, port=self.port, enrollment=False))
                if not self._discovery_service.start():
                    failure = {"reason": self._discovery_service.failure_reason or "DNS_SD_START_FAILED",
                               **self._discovery_service.failure_details}
                    record_advertisement_failure(
                        "secure-discovery-runtime.json", self.state_root,
                        failure)
                    self._discovery_service = None
        except Exception as exc:
            try:
                from app.node_discovery import record_advertisement_failure
                record_advertisement_failure("secure-discovery-runtime.json", self.state_root,
                                             f"DISCOVERY_START_EXCEPTION:{type(exc).__name__}")
            except Exception:
                pass
            self._discovery_service = None
        runtime_path = _state_root(self.state_root) / SECURE_RUNTIME_FILE
        runtime_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        runtime_path.write_text(json.dumps({"pid": os.getpid(), "bind": self.bind,
                                             "port": self.port, "tls": "TLS1.3",
                                             "protocol_version": PROTOCOL_VERSION}), encoding="utf-8")
        os.chmod(runtime_path, 0o600)
        try:
            while not self._stop.is_set():
                try: raw, address = server.accept()
                except socket.timeout: continue
                if once: self._handle(context, raw, address)
                else: threading.Thread(target=self._handle, args=(context, raw, address), daemon=True).start()
                if once: break
        finally:
            server.close(); self._server = None
            if self._discovery_service:
                self._discovery_service.stop(); self._discovery_service = None
            if self._temp: self._temp.cleanup(); self._temp = None
            runtime_path.unlink(missing_ok=True)

    def _handle(self, context: ssl.SSLContext, raw: socket.socket, address) -> None:
        sock = None
        try:
            sock = context.wrap_socket(raw, server_side=True)
            session, seen = _server_authenticate(sock, self.local_identity, self.state_root, 5.0)
            request = session.receive(seen)
            if request["message_type"] == "PING":
                response = envelope("PONG", self.local_identity, {"request_id": request["request_id"]}, session.peer_node_id)
                _send(sock, response)
            elif request["message_type"] == "CAPABILITIES_REQUEST":
                response = envelope("CAPABILITIES_RESPONSE", self.local_identity, {"request_id": request["request_id"], "advertisement": {"status": "BOUNDED"}}, session.peer_node_id)
                _send(sock, response)
            else:
                raise SecureChannelError("MESSAGE_TYPE_UNSUPPORTED")
        except Exception:
            # Safe wire behavior: close without exposing keys or stack traces.
            try: raw.close()
            except OSError: pass
        finally:
            if sock:
                try: sock.close()
                except OSError: pass

    def stop(self) -> None:
        self._stop.set()
        if self._server:
            try: self._server.close()
            except OSError: pass


def status(*, state_root: str | Path | None = None) -> dict:
    """Return local readiness only; never contacts a LAN peer."""
    try:
        local = identity(create=False)
        binding = {"status": "READY", "fingerprint": _fingerprint(local.public_key),
                   "node_id": local.node_id}
    except Exception as exc:
        binding = {"status": "UNAVAILABLE", "reason": type(exc).__name__}
    registry = cluster_security.read_registry(state_root)
    cfg = configured(state_root); runtime = _runtime_status(state_root)
    from app.node_discovery import advertisement_runtime
    discovery_runtime = advertisement_runtime("secure-discovery-runtime.json", state_root)
    discovery_required = bool(cfg.get("enabled"))
    discovery_degraded = bool(runtime.get("listener_live") and discovery_required
                               and not discovery_runtime.get("live"))
    listener_state = ("DISABLED" if not cfg.get("enabled") else
                      ("LISTENING" if runtime.get("listener_live") else
                       ("PORT_CONFLICT" if runtime.get("state") == "PORT_CONFLICT" else
                        "CONFIGURED_NOT_RUNNING")))
    return {"identity_binding": binding, "enabled": bool(cfg.get("enabled")),
            "configured_enabled": bool(cfg.get("enabled")),
            "runtime_enabled": bool(runtime.get("listener_live")),
            "listener_live": bool(runtime.get("listener_live")),
            "listener_state": listener_state,
            "bind": runtime.get("bind", cfg.get("bind", "0.0.0.0")),
            "tls": "TLS1.3",
            "protocol_version": PROTOCOL_VERSION,
            "port": int(runtime.get("port", cfg.get("port", DEFAULT_SECURE_PORT))),
            "discovery_advertisement": discovery_runtime,
            "discovery_required": discovery_required,
            "readiness_state": "DEGRADED" if discovery_degraded else
                               ("READY" if runtime.get("listener_live") else "NOT_READY"),
            "degraded_reason": (discovery_runtime.get("reason") or "SECURE_DISCOVERY_NOT_RUNNING")
                               if discovery_degraded else "",
            "trusted_peers": sum(1 for p in registry.get("peers", {}).values()
                                  if p.get("trust_state") == cluster_security.TRUSTED),
            "revoked_peers": sum(1 for p in registry.get("peers", {}).values()
                                  if p.get("trust_state") == cluster_security.REVOKED),
            "trust_registry_exists": cluster_security.registry_path(state_root).exists(),
            "arbitrary_execution": False}
