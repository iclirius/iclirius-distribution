"""Single source of truth for the current Iclirius release candidate."""

VERSION = "1.0.0-rc.39"
