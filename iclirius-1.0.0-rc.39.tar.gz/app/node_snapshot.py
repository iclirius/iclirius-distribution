"""Canonical, local-only operational snapshot for a future node protocol."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from app.config import settings
from app.memory_home import inspect as inspect_memory_home
from app.node_identity import read_node
from app.runtime_state import RuntimeSnapshot, build_snapshot


SCHEMA_VERSION = 1


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _ollama() -> tuple[str, bool, list[str]]:
    binary = shutil.which("ollama") or ""
    if not binary:
        return "", False, []
    try:
        with urlopen(settings.ollama_base_url.rstrip("/") + "/api/tags", timeout=2) as response:
            reachable = response.status == 200
    except (OSError, URLError, ValueError):
        reachable = False
    models: list[str] = []
    if reachable:
        try:
            result = subprocess.run([binary, "list"], capture_output=True, text=True,
                                    timeout=5, check=False)
            for line in (result.stdout or "").splitlines()[1:]:
                if line.split():
                    models.append(line.split()[0])
        except (OSError, subprocess.SubprocessError):
            pass
    return binary, reachable, models


def _resources() -> dict:
    result = {"cpu_percent": None, "memory_total_bytes": None,
              "memory_used_bytes": None, "memory_available_bytes": None,
              "load_1m": None}
    try:
        result["load_1m"] = round(os.getloadavg()[0], 2)
    except (OSError, AttributeError):
        pass
    try:
        result["memory_total_bytes"] = int(os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        result["memory_available_bytes"] = int(os.sysconf("SC_AVPHYS_PAGES") * os.sysconf("SC_PAGE_SIZE"))
        result["memory_used_bytes"] = result["memory_total_bytes"] - result["memory_available_bytes"]
    except (OSError, ValueError, TypeError):
        sysctl = shutil.which("sysctl")
        if sysctl:
            try:
                raw = subprocess.run([sysctl, "-n", "hw.memsize"], capture_output=True,
                                     text=True, timeout=2, check=False).stdout.strip()
                result["memory_total_bytes"] = int(raw)
            except (OSError, ValueError, subprocess.SubprocessError):
                pass
        vm_stat = shutil.which("vm_stat")
        if vm_stat and result["memory_total_bytes"] is not None:
            try:
                output = subprocess.run([vm_stat], capture_output=True, text=True,
                                        timeout=2, check=False).stdout
                page_size = 4096
                free = 0
                for line in output.splitlines():
                    if "page size of" in line:
                        page_size = int(line.split("page size of", 1)[1].split("bytes", 1)[0].strip())
                    elif line.startswith(("Pages free", "Pages inactive", "Pages speculative")):
                        free += int(line.split(":", 1)[1].strip().rstrip("."))
                result["memory_available_bytes"] = free * page_size
                result["memory_used_bytes"] = result["memory_total_bytes"] - result["memory_available_bytes"]
            except (OSError, ValueError, IndexError, subprocess.SubprocessError):
                pass
    ps = shutil.which("ps")
    if ps:
        try:
            output = subprocess.run([ps, "-A", "-o", "%cpu="], capture_output=True,
                                    text=True, timeout=3, check=False).stdout
            result["cpu_percent"] = round(min(100.0, sum(float(v.strip()) for v in output.split())), 1)
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    return result


def _capabilities(*, local_reasoning_available: bool = False) -> dict:
    try:
        import faster_whisper  # noqa: F401
        stt = True
    except Exception:
        stt = False
    try:
        from app.voice import voice_service
        voice_status = voice_service.status()
        tts = voice_status.get("tts") == "ready" or bool(shutil.which("say"))
    except Exception:
        tts = bool(shutil.which("say"))
    return {
        # Configuration names a desired model; it is not evidence that local
        # inference is usable. Availability requires a reachable Ollama
        # service with the configured model observed by ``collect``.
        "reasoning_local": bool(local_reasoning_available),
        "filesystem_read": settings.enable_local_read_tools,
        "filesystem_write": settings.write_enabled,
        "shell": settings.execute_enabled,
        "git": bool(shutil.which("git")),
        "python": True,
        "telegram": settings.enable_telegram and bool(settings.telegram_bot_token),
        "voice_stt": stt,
        "voice_tts": tts,
        "web_search": True,
        "web_fetch": True,
    }


def _memory() -> dict:
    home = inspect_memory_home(settings.memory_home) if settings.memory_home else {
        "configured": False, "status": "not_configured", "readable": False, "writable": False,
    }
    state_file = Path(settings.memory_root).expanduser() / "state.json.enc"
    metadata = {}
    try:
        from app.memory_metadata import read
        metadata = read(state_file)
    except Exception:
        pass
    encryption = False
    try:
        from app.secure_storage import load_keychain_key
        from cryptography.fernet import Fernet
        encryption = bool(load_keychain_key())
        if encryption:
            Fernet(load_keychain_key().encode("utf-8"))
    except Exception:
        encryption = False
    return {
        "configured": bool(home.get("configured")),
        "memory_home_id": home.get("memory_home_id", ""),
        "schema_version": home.get("schema_version"),
        "path": str(settings.memory_home) if settings.memory_home else "",
        "readable": bool(home.get("readable")),
        "writable": bool(home.get("writable")),
        "encryption_ready": encryption,
        "revision": metadata.get("revision"),
        "journal_head": metadata.get("journal_head", ""),
        "writer_node_id": metadata.get("writer_node_id", ""),
        "last_write_at": metadata.get("last_write_at", ""),
    }


def collect(*, agent=None, interface: str = "", session_id: str = "", active: bool = False) -> dict:
    binary, reachable, models = _ollama()
    node_data = read_node()
    setup_complete = bool(getattr(settings, "setup_complete", True))
    node_id = str(node_data.get("node_id") or
                  (settings.node_id if setup_complete else "unknown-node"))
    hostname = str(node_data.get("hostname") or platform.node() or "unknown-host")
    runtime: RuntimeSnapshot = build_snapshot(agent, ollama_healthy=reachable, installed_models=models)
    model_available = bool(setup_complete and settings.default_model in models)
    provider = "ollama"
    interfaces = {
        "tui": {"configured": True, "available": True, "running": interface == "tui" and active,
                "active": interface == "tui" and active},
        "telegram": {"configured": bool(settings.telegram_bot_token and settings.allowed_user_ids),
                      "enabled": settings.enable_telegram, "listener_running": "unknown",
                      "role": settings.role if settings.enable_telegram else "disabled"},
    }
    snapshot = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": _now(),
        "node": {"node_id": node_id, "hostname": hostname, "platform": platform.system(),
                 "architecture": platform.machine(), "role": node_data.get("role", "INTERFACE"),
                 "state": "active" if active else "ready"},
        "session": {"active": bool(active and session_id), "session_id": session_id if active else "",
                     "user_id": settings.user_id if active else "", "interface": interface if active else "",
                     "started_at": ""},
        "runtime": {"agent": "OpenClawAgent" if agent is not None else "not_initialized",
                    "mode": runtime.mode, "agent_status": runtime.agent_status},
        "provider": {"configured_provider": provider, "active_provider": provider if reachable and model_available else "",
                      "configured_model": settings.default_model, "active_model": settings.default_model if model_available else "",
                      "ollama": {"installed": bool(binary), "configured": bool(settings.ollama_base_url),
                                 "reachable": reachable, "model_available": model_available,
                                 "models": models}},
        "resources": _resources(),
        "capabilities": _capabilities(local_reasoning_available=model_available),
        "memory": _memory(),
        "interfaces": interfaces,
    }
    from app.node_capability_profile import from_snapshot
    snapshot["capability_profile"] = from_snapshot(snapshot)
    try:
        from app.node_service import status as service_status
        snapshot["service"] = service_status()
    except Exception as exc:
        snapshot["service"] = {"state": "UNKNOWN", "error": str(exc)}
    snapshot["node"]["health"] = snapshot["capability_profile"].get("health", {}).get("health", "UNKNOWN")
    if active:
        snapshot["node"]["state"] = "active" if snapshot["node"]["health"] == "HEALTHY" else snapshot["node"]["health"].lower()
    return snapshot


def render(snapshot: dict) -> str:
    node, runtime, provider = snapshot["node"], snapshot["runtime"], snapshot["provider"]
    resources, memory, interfaces = snapshot["resources"], snapshot["memory"], snapshot["interfaces"]
    cpu = "unknown" if resources["cpu_percent"] is None else f"{resources['cpu_percent']}%"
    ram = "unknown"
    if resources["memory_total_bytes"] is not None and resources["memory_used_bytes"] is not None:
        ram = f"{resources['memory_used_bytes'] / 1073741824:.1f} / {resources['memory_total_bytes'] / 1073741824:.1f} GB"
    telegram = interfaces["telegram"]
    service = snapshot.get("service", {})
    return "\n".join([
        "NODE", f"● {node['hostname']}", f"  ID          {node['node_id']}", f"  Role        {node.get('role', 'INTERFACE')}",
        f"  State       {node['state']}", f"  Health      {node.get('health', 'UNKNOWN')}",
        f"  Agent       {runtime['agent']}", f"  Provider    {provider['active_provider'] or provider['configured_provider']}",
        f"  Model       {provider['active_model'] or provider['configured_model']}", f"  Ollama      {'reachable' if provider['ollama']['reachable'] else 'unreachable'}",
        f"  CPU         {cpu}", f"  RAM         {ram}", "", "MEMORY",
        f"  Home        {'ready' if memory['configured'] and memory['readable'] else 'unavailable'}",
        f"  Revision    {memory['revision'] if memory['revision'] is not None else 'unknown'}",
        f"  Writable    {'yes' if memory['writable'] else 'no'}", f"  Encryption  {'ready' if memory['encryption_ready'] else 'unavailable'}",
        f"  Writer      {memory['writer_node_id'] or 'unknown'}", "", "INTERFACES",
        f"  TUI         {'active' if interfaces['tui']['active'] else 'available'}",
        f"  Telegram    {'running' if telegram['listener_running'] is True else 'unknown'} · {telegram['role']}",
        "", "SERVICE", f"  Label       {service.get('label', 'unknown')}",
        f"  Installed   {'yes' if service.get('installed') else 'no'}",
        f"  Loaded      {'yes' if service.get('loaded') else 'no'}",
        f"  State       {service.get('state', 'UNKNOWN')}",
        f"  PID         {service.get('pid') or '—'}",
        f"  Current CLI {service.get('installation_mode', 'UNKNOWN')} {service.get('current_cli_version', service.get('version', ''))}".rstrip(),
        f"  Service     {service.get('state', 'UNKNOWN')} {service.get('service_runtime_version', 'UNKNOWN')}".rstrip(),
        f"  Executable  {service.get('runtime_plist') or '—'}",
        f"  Workdir     {service.get('working_directory') or '—'}",
        f"  Stale       {', '.join(service.get('stale_reasons', [])) or 'no'}",
        f"  Plist       {service.get('plist') or '—'}",
        f"  Logs        {service.get('logs') or '—'}",
    ])
