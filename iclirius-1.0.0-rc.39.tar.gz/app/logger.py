import logging
import os
from app.config import settings


def setup_logger() -> logging.Logger:
    os.makedirs(settings.logs_path, exist_ok=True)

    logger = logging.getLogger("openclaw")
    logger.setLevel(logging.INFO)

    if any(not isinstance(handler, logging.NullHandler) for handler in logger.handlers):
        return logger

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    file_handler = logging.FileHandler(
        os.path.join(settings.logs_path, "openclaw.log")
    )
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger


# Importing a module must not create a user's runtime directory. Explicit
# runtime/CLI entrypoints call setup_logger when logging is actually needed.
logger = logging.getLogger("openclaw")
if not logger.handlers:
    _bootstrap_handler = logging.NullHandler(level=logging.CRITICAL + 1)
    logger.addHandler(_bootstrap_handler)


def configure_cli_logging(*, debug: bool = False) -> logging.Logger:
    """Keep operational logs available without polluting CLI conversation.

    The file handler remains active in every mode.  Only the console handler
    is changed, and this function is called by the CLI entrypoint rather than
    by Telegram or other runtimes.
    """
    setup_logger()
    logger.setLevel(logging.DEBUG if debug else logging.INFO)
    logger.propagate = False
    for handler in logger.handlers:
        # FileHandler subclasses StreamHandler, so check it first.
        if isinstance(handler, logging.FileHandler):
            continue
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(logging.INFO if debug else logging.CRITICAL + 1)
        elif not isinstance(handler, logging.FileHandler):
            handler.setLevel(logging.INFO if debug else logging.CRITICAL + 1)
    return logger
