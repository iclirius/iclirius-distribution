"""Local security state for CLUSTER-2 discovery and explicit enrollment.

This module deliberately contains no remote execution or general RPC.  Bonjour
records are observations only; the local registry is the authority for trust.
Long-lived private node keys remain in the existing Keychain-backed identity
store provided by :mod:`app.node_pairing`.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import time
from pathlib import Path
from typing import Any
from cryptography.hazmat.primitives.asymmetric import ed25519

from app.node_pairing import identity
from app.node_identity import read_node, ensure_node

PROTOCOL_VERSION = 1
SESSION_TTL_SECONDS = 300
MAX_NODE_ID = 128
MAX_DISPLAY_NAME = 80
MAX_FINGERPRINT = 128
REGISTRY_FILE = "cluster-trust.json"

UNSEEN = "UNSEEN"
DISCOVERED = "DISCOVERED"
ENROLLMENT_PENDING = "ENROLLMENT_PENDING"
VERIFIED = "VERIFIED"
TRUSTED = "TRUSTED"
REVOKED = "REVOKED"
LEGACY_TRUST_UNVERIFIED = "LEGACY_TRUST_UNVERIFIED"
IDENTITY_VERIFIED = "IDENTITY_VERIFIED"
CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED"


def _root(state_root: str | Path | None = None) -> Path:
    return Path(state_root or os.getenv("ICLIRIUS_MACHINE_STATE", "~/.iclirius")).expanduser()


def registry_path(state_root: str | Path | None = None) -> Path:
    return _root(state_root) / REGISTRY_FILE


def _now() -> int:
    return int(time.time())


def _bounded(value: Any, limit: int) -> str:
    return str(value or "").strip()[:limit]


def fingerprint(public_key: str) -> str:
    """Return a stable, display-safe fingerprint of a base64 raw public key."""
    raw = base64.b64decode(public_key, validate=True)
    if len(raw) != 32:
        raise ValueError("invalid node public key")
    digest = hashlib.sha256(raw).hexdigest()
    return ":".join(digest[index:index + 4] for index in range(0, 32, 4))


def local_identity(*, create: bool = True) -> dict:
    """Return public identity metadata only; never return private key material."""
    node = read_node()
    if not node:
        if not create:
            return {"node_id": "", "display_name": "", "public_key": "",
                    "fingerprint": "", "protocol_version": PROTOCOL_VERSION}
        node = ensure_node()
    try:
        # Keep the established callable shape for explicit callers and test
        # adapters; the keyword is needed only for read-only inspection.
        ident = identity(create=False) if not create else identity()
    except Exception:
        if create:
            raise
        return {
            "node_id": _bounded(node.get("node_id"), MAX_NODE_ID),
            "display_name": _bounded(node.get("display_name") or node.get("hostname"), MAX_DISPLAY_NAME),
            "public_key": "", "fingerprint": "", "protocol_version": PROTOCOL_VERSION,
        }
    return {
        "node_id": _bounded(node.get("node_id") or ident.node_id, MAX_NODE_ID),
        "display_name": _bounded(node.get("display_name") or node.get("hostname") or ident.node_id,
                                  MAX_DISPLAY_NAME),
        "public_key": ident.public_key,
        "fingerprint": fingerprint(ident.public_key),
        "protocol_version": PROTOCOL_VERSION,
    }


def _empty() -> dict:
    return {"schema_version": 1, "peers": {}, "sessions": {}, "observations": {}}


def read_registry(state_root: str | Path | None = None) -> dict:
    try:
        value = json.loads(registry_path(state_root).read_text(encoding="utf-8"))
        if isinstance(value, dict):
            base = _empty(); base.update(value)
            return base
    except (OSError, ValueError, TypeError):
        pass
    return _empty()


def _write_registry(value: dict, state_root: str | Path | None = None) -> None:
    path = registry_path(state_root); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600); os.replace(tmp, path)


def record_discovered(record: dict, address: str = "") -> dict:
    """Record untrusted metadata without changing trust state."""
    node_id = _bounded(record.get("node_id") or record.get("node_hint"), MAX_NODE_ID)
    if not node_id:
        raise ValueError("discovery record has no node identifier")
    item = {
        "node_id": node_id,
        "display_name": _bounded(record.get("display_name") or node_id, MAX_DISPLAY_NAME),
        "fingerprint": _bounded(record.get("identity_fingerprint") or record.get("node_hint"), MAX_FINGERPRINT),
        "protocol_version": str(record.get("protocol", "")),
        "address": _bounded(address, 255),
        "observed_at": _now(),
        "trust_state": DISCOVERED,
    }
    data = read_registry()
    existing = data["peers"].get(node_id, {})
    if existing.get("trust_state") in {TRUSTED, REVOKED}:
        item["trust_state"] = existing["trust_state"]
    data["observations"][node_id] = item
    _write_registry(data)
    return item


def record_trusted_peer(peer: dict, address: str = "", *, state_root: str | Path | None = None) -> dict:
    """Record a peer after the existing signed pairing ceremony succeeds."""
    public_key = str(peer.get("public_key", ""))
    peer_id = _bounded(peer.get("node_id"), MAX_NODE_ID)
    if not peer_id or not public_key:
        raise ValueError("authenticated peer identity is incomplete")
    derived = fingerprint(public_key)
    now = _now(); data = read_registry(state_root)
    previous = data["peers"].get(peer_id, {})
    if previous.get("trust_state") == REVOKED and previous.get("public_key") != public_key:
        raise ValueError("revoked peer identity changed")
    item = {**previous, "node_id": peer_id, "public_key": public_key,
            "fingerprint": derived, "address": _bounded(address, 255),
            "first_enrolled_at": previous.get("first_enrolled_at", now),
            "last_verified_at": now, "trust_state": TRUSTED,
            "protocol_version": PROTOCOL_VERSION, "revoked_at": None}
    data["peers"][peer_id] = item
    data["observations"].setdefault(peer_id, {}).update({"node_id": peer_id,
                                                           "trust_state": TRUSTED,
                                                           "observed_at": now})
    _write_registry(data, state_root); return dict(item)


def update_trusted_endpoint(node_id: str, address: str, *, state_root: str | Path | None = None) -> dict:
    """Update only the endpoint of an already trusted, pinned identity.

    Endpoint mobility never changes the node id, public key, fingerprint, or
    trust state.  Callers must authenticate the peer before invoking this.
    """
    data = read_registry(state_root)
    peer = data.get("peers", {}).get(node_id, {})
    if peer.get("trust_state") != TRUSTED:
        raise ValueError("peer is not trusted")
    if not peer.get("public_key") or fingerprint(peer["public_key"]) != peer.get("fingerprint"):
        raise ValueError("trusted peer identity is invalid")
    now = _now()
    peer = dict(peer)
    peer["address"] = _bounded(address, 255)
    peer["last_verified_at"] = now
    data["peers"][node_id] = peer
    data.setdefault("observations", {}).setdefault(node_id, {}).update({
        "node_id": node_id, "trust_state": TRUSTED, "observed_at": now,
        "address": peer["address"],
    })
    _write_registry(data, state_root)
    return dict(peer)


def begin_enrollment(node_id: str, public_key: str = "", fingerprint_value: str = "",
                     display_name: str = "") -> dict:
    node_id = _bounded(node_id, MAX_NODE_ID)
    if not node_id:
        raise ValueError("node_id is required")
    data = read_registry(); peer = data["peers"].get(node_id, {})
    if peer.get("trust_state") == REVOKED:
        raise ValueError("peer is revoked; explicit re-enrollment is required")
    session_id = secrets.token_urlsafe(24)
    code = f"{secrets.randbelow(1_000_000):06d}"
    challenge = secrets.token_urlsafe(32)
    now = _now()
    data["sessions"][session_id] = {
        "node_id": node_id, "public_key": public_key,
        "fingerprint": fingerprint_value, "display_name": display_name,
        "code_digest": hashlib.sha256(code.encode()).hexdigest(),
        "challenge": challenge, "identity_verified": False,
        "created_at": now, "expires_at": now + SESSION_TTL_SECONDS,
        "used": False,
    }
    data["observations"].setdefault(node_id, {"node_id": node_id,
                                                "trust_state": DISCOVERED,
                                                "observed_at": now})
    data["observations"][node_id]["trust_state"] = ENROLLMENT_PENDING
    _write_registry(data)
    # The code is returned only to the explicit CLI caller for human comparison;
    # only its digest is persisted.
    return {"session_id": session_id, "node_id": node_id,
            "fingerprint": fingerprint_value, "verification_code": code,
            "challenge": challenge, "state": ENROLLMENT_PENDING, "expires_at": now + SESSION_TTL_SECONDS}


def record_verified_enrollment(peer: dict, *, address: str = "") -> dict:
    """Create a confirmation-required session after a signed network exchange."""
    public_key = str(peer.get("public_key", "")); node_id = _bounded(peer.get("node_id"), MAX_NODE_ID)
    if not node_id or not public_key:
        raise ValueError("verified peer identity is incomplete")
    fp = fingerprint(public_key); data = read_registry(); now = _now()
    session_id = secrets.token_urlsafe(24); code = f"{secrets.randbelow(1_000_000):06d}"
    data["sessions"][session_id] = {"node_id": node_id, "public_key": public_key,
        "fingerprint": fp, "code_digest": hashlib.sha256(code.encode()).hexdigest(),
        "challenge": "network-signed", "identity_verified": True,
        "proof": "ED25519_SIGNATURE_VERIFIED", "created_at": now,
        "expires_at": now + SESSION_TTL_SECONDS, "used": False,
        "address": _bounded(address, 255)}
    data["observations"][node_id] = {"node_id": node_id, "public_key": public_key,
        "fingerprint": fp, "identity_verified": True, "proof": "ED25519_SIGNATURE_VERIFIED",
        "session_id": session_id, "expires_at": now + SESSION_TTL_SECONDS,
        "trust_state": CONFIRMATION_REQUIRED, "observed_at": now,
        "address": _bounded(address, 255)}
    _write_registry(data)
    return {"session_id": session_id, "node_id": node_id, "public_key": public_key,
            "fingerprint": fp, "verification_code": code,
            "state": CONFIRMATION_REQUIRED, "proof": "VERIFIED",
            "expires_at": now + SESSION_TTL_SECONDS}


def verify_enrollment_proof(session_id: str, public_key: str, signature: str) -> dict:
    """Verify a peer's Ed25519 proof before a session can be trusted."""
    data = read_registry(); session = data["sessions"].get(session_id)
    if not session or session.get("used"):
        raise ValueError("enrollment session is invalid or already used")
    if int(session.get("expires_at", 0)) < _now():
        raise ValueError("enrollment session expired")
    try:
        raw = base64.b64decode(public_key, validate=True)
        key = ed25519.Ed25519PublicKey.from_public_bytes(raw)
        key.verify(base64.b64decode(signature, validate=True), session["challenge"].encode())
    except Exception as exc:
        raise ValueError("enrollment proof of possession failed") from exc
    derived = fingerprint(public_key)
    expected = session.get("fingerprint")
    if session.get("public_key") and session["public_key"] != public_key:
        raise ValueError("enrollment public key mismatch")
    if expected and expected != derived:
        raise ValueError("enrollment fingerprint mismatch")
    session.update({"public_key": public_key, "fingerprint": derived,
                    "identity_verified": True, "verified_at": _now()})
    data["observations"].setdefault(session["node_id"], {})["trust_state"] = CONFIRMATION_REQUIRED
    _write_registry(data)
    return {"session_id": session_id, "node_id": session["node_id"],
            "public_key": public_key, "fingerprint": derived,
            "state": CONFIRMATION_REQUIRED, "identity_verified": True}


def confirm_enrollment(session_id: str, verification_code: str,
                       *, public_key: str = "", fingerprint_value: str = "") -> dict:
    data = read_registry(); session = data["sessions"].get(session_id)
    if not session or session.get("used"):
        raise ValueError("enrollment session is invalid or already used")
    if int(session.get("expires_at", 0)) < _now():
        raise ValueError("enrollment session expired")
    if not secrets.compare_digest(session.get("code_digest", ""),
                                  hashlib.sha256(str(verification_code).encode()).hexdigest()):
        raise ValueError("enrollment verification failed")
    if not session.get("identity_verified"):
        raise ValueError("remote identity proof is required before trust")
    if not fingerprint_value:
        raise ValueError("explicit fingerprint confirmation is required")
    expected = session.get("fingerprint")
    if expected != fingerprint_value:
        raise ValueError("confirmation fingerprint mismatch")
    if public_key:
        actual = fingerprint(public_key)
        if expected and actual != expected:
            raise ValueError("enrollment fingerprint mismatch")
    elif expected and fingerprint_value and expected != fingerprint_value:
        raise ValueError("enrollment fingerprint mismatch")
    node_id = session["node_id"]; now = _now()
    peer = {"node_id": node_id, "public_key": public_key or session.get("public_key", ""),
            "fingerprint": expected, "display_name": session.get("display_name", ""),
            "first_enrolled_at": now, "last_verified_at": now,
            "trust_state": TRUSTED, "protocol_version": PROTOCOL_VERSION,
            "revoked_at": None, "address": session.get("address", "")}
    data["peers"][node_id] = peer
    data["observations"].setdefault(node_id, {})
    data["observations"][node_id].update({"node_id": node_id, "trust_state": TRUSTED,
                                           "observed_at": now})
    session["used"] = True; session["confirmed_at"] = now
    _write_registry(data)
    return dict(peer)


def cleanup_enrollment(session_id: str = "") -> dict:
    """Expire only stale sessions; never remove active or trusted state."""
    data = read_registry(); now = _now(); removed = []
    candidates = [session_id] if session_id else list(data["sessions"])
    for sid in candidates:
        session = data["sessions"].get(sid)
        if not session:
            if session_id:
                raise ValueError("enrollment session not found")
            continue
        if session.get("used"):
            continue
        if int(session.get("expires_at", 0)) > now:
            raise ValueError("active enrollment session was not removed")
        removed.append(sid); node_id = session.get("node_id")
        del data["sessions"][sid]
        if node_id and not any(s.get("node_id") == node_id and not s.get("used")
                               for s in data["sessions"].values()):
            observation = data["observations"].get(node_id, {})
            if observation.get("trust_state") in {ENROLLMENT_PENDING, IDENTITY_VERIFIED,
                                                   CONFIRMATION_REQUIRED}:
                observation["trust_state"] = DISCOVERED
    _write_registry(data)
    return {"state": "CLEANED", "removed_sessions": removed,
            "remaining_active_sessions": sum(1 for s in data["sessions"].values()
                                               if not s.get("used") and int(s.get("expires_at", 0)) >= now)}


def revoke(node_id: str, *, state_root: str | Path | None = None) -> bool:
    data = read_registry(state_root); peer = data["peers"].get(node_id)
    if not peer:
        return False
    now = _now(); peer["trust_state"] = REVOKED; peer["revoked_at"] = now
    peer["last_verified_at"] = None
    data["observations"].setdefault(node_id, {}).update({"node_id": node_id,
                                                         "trust_state": REVOKED,
                                                         "observed_at": now})
    _write_registry(data, state_root); return True


def nodes() -> list[dict]:
    data = read_registry(); result = [{**item, "local": False} for item in data["observations"].values()]
    for node_id, peer in data["peers"].items():
        existing = next((item for item in result if item.get("node_id") == node_id), {})
        merged = {**existing, **peer, "local": False};
        if not any(item.get("node_id") == node_id for item in result): result.append(merged)
        else:
            result = [merged if item.get("node_id") == node_id else item for item in result]
    # Legacy peers are read-only historical evidence.  They are never promoted
    # into this registry without a current cryptographic match and explicit
    # enrollment confirmation.
    for item in legacy_trust_audit():
        if not any(existing.get("node_id") == item.get("node_id") for existing in result):
            result.append({**item, "trust_state": LEGACY_TRUST_UNVERIFIED, "local": False})
    local = local_identity(create=False)
    result.insert(0, {**local, "trust_state": "LOCAL", "local": True})
    return result


def status() -> dict:
    data = read_registry(); now = _now()
    pending = sum(1 for item in data["observations"].values() if item.get("trust_state") == ENROLLMENT_PENDING)
    active_sessions = sum(1 for item in data["sessions"].values()
                          if not item.get("used") and int(item.get("expires_at", 0)) >= now)
    path = registry_path()
    return {"identity": local_identity(create=False), "trust_registry": str(path),
            "trust_registry_exists": path.exists(),
            "trusted": sum(1 for item in data["peers"].values() if item.get("trust_state") == TRUSTED),
            "revoked": sum(1 for item in data["peers"].values() if item.get("trust_state") == REVOKED),
            "pending_enrollment": pending, "active_sessions": active_sessions,
            "legacy": legacy_trust_audit(),
            "discovery_enabled": True}


def legacy_trust_audit() -> list[dict]:
    """Inspect peers.json without contacting peers or changing either store."""
    try:
        from app.node_pairing import peers as legacy_peers
        legacy = legacy_peers().get("peers", {})
    except Exception:
        legacy = {}
    current = read_registry().get("peers", {})
    result = []
    for node_id, peer in legacy.items():
        public_key = str(peer.get("public_key", ""))
        stored_fp = str(peer.get("fingerprint", ""))
        derived_fp = ""
        key_valid = False
        if public_key:
            try:
                derived_fp = fingerprint(public_key)
                key_valid = True
            except (ValueError, TypeError):
                pass
        current_peer = current.get(node_id, {})
        cryptographic_match = bool(key_valid and current_peer.get("public_key") == public_key)
        result.append({
            "node_id": str(node_id)[:MAX_NODE_ID],
            "legacy_state": str(peer.get("trust", "UNKNOWN")),
            "legacy_public_key_present": bool(public_key),
            "legacy_fingerprint": stored_fp,
            "derived_fingerprint": derived_fp,
            "key_valid": key_valid,
            "cryptographic_match": cryptographic_match,
            "migration": "MATCH_REQUIRES_EXPLICIT_ENROLLMENT" if cryptographic_match
                          else LEGACY_TRUST_UNVERIFIED,
            "address_present": bool(peer.get("address")),
        })
    return result


def doctor_status() -> dict:
    identity_error = ""
    try:
        ident = local_identity(create=False)
        identity_state = "READY" if ident.get("node_id") else "UNCONFIGURED"
    except Exception as exc:
        ident = {}; identity_state = "UNAVAILABLE"; identity_error = type(exc).__name__
    from app.node_discovery import discovery_enabled, backend_available, enrollment_status
    result = {"identity": {"status": identity_state, "node_id": ident.get("node_id", ""),
                            "fingerprint": ident.get("fingerprint", ""),
                            "private_key_storage": "KEYCHAIN"},
              "discovery": {"enabled": discovery_enabled(), "backend": "BONJOUR",
                            "listener_ready": backend_available(),
                            "advertisement": "NODE_RUNTIME" if discovery_enabled() else "DISABLED",
                            "service_type": "_iclirius._tcp.local."},
              "enrollment": enrollment_status(), "trust_registry": str(registry_path()),
              "trust_registry_exists": registry_path().exists(),
              "legacy": legacy_trust_audit()}
    if identity_state == "UNAVAILABLE": result["identity"]["reason"] = identity_error
    return result
